local menu = fatality.menu
local config = fatality.config
local entity_list = csgo.interface_handler:get_entity_list()
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()
local airduck = config:add_item("misc_airduck", 0)
local local_player
local side = false
local callbacks = fatality.callbacks

function on_paint()
  local_player = entity_list:get_localplayer()
  if(local_player ~= nil and local_player:is_alive()) then	
		local velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
		if (airduck:get_bool()) then
			local onground = velocity.z == 0

			if not onground then
				engine_client:client_cmd('+duck')
				side = true;
			end
			if onground then
				if(side) then
					engine_client:client_cmd('-duck')
					side = false;
				end	
			end
		end
	end		
end

menu:add_checkbox("Air duck","MISC", "MISC", "Movement", airduck)
callbacks:add( "paint", on_paint )