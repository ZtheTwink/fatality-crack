-- _markjelo luas + cfg

print("indicators LUA for my cfg _markjelo#9266")

local render = fatality.render
local input = fatality.input
local menu = fatality.menu
local config = fatality.config
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()

local screensize = render:screen_size()

local forcebaim_item = config:add_item( "forcebaim", 0 )
local doubletap_item = config:add_item( "double tap", 0 )
local slide_item = config:add_item ( "slide", 0 )
local fakeduck_item = config:add_item ( "fakeduck", 0 )

local forcebaim_combobox = menu:add_multi_combo( "indicators", "rage", "aimbot", "misc" ):add_item( "force baim", forcebaim_item ):add_item( "doubletap", doubletap_item ):add_item( "slide", slide_item ):add_item( "fakeduck", fakeduck_item )

function on_paint()

 

    if not engine_client:is_in_game() then	
    return end

    local forcebaim = menu:get_reference("RAGE", "AIMBOT", "Aimbot", "Force fallback")
	local doubletap = menu:get_reference("RAGE", "AIMBOT", "Aimbot", "Double tap" )
	local slide = menu:get_reference("RAGE", "AIMBOT", "Aimbot", "Slide")
	local fakeduck = menu:get_reference("RAGE", "AIMBOT", "Aimbot", "Fake duck")

    if forcebaim:get_bool() then
        fb = true
    else
        fb = false
    end
	
    if doubletap:get_bool() then
        dt = true
    else
        dt = false
    end	
	
    if slide:get_bool() then
        sl = true
    else
        sl = false
    end
	
	 if fakeduck:get_bool() then
        fd = true
    else
        fd = false
    end

    if forcebaim_item:get_bool() then 

        render:indicator( 5, screensize.y - 50, "Force fallback", fb , -1)

    end
	
    if doubletap_item:get_bool() then 

        render:indicator( 5, screensize.y - 30, "DT", si , -1)

    end
	
	if slide_item:get_bool() then 

        render:indicator( 5, screensize.y - 90, "Slidewalk", sl , -1)

    end
	
	if fakeduck_item:get_bool() then 

        render:indicator( 5, screensize.y - 70, "Fakeduck", fd , -1)

    end

end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )