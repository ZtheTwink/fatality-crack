-- https://fatality.win/threads/lua-aimware-v2-spectator-list.2896/
-- interfaces
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local cvar = csgo.interface_handler:get_cvar( )
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input;
local aimware_speclist_item = config:add_item( "speclist_aimware", 0 )
local aimware_speclist_checkbox = menu:add_checkbox( "Show Spectators", "visuals", "misc", "beams", aimware_speclist_item )
local aimware_colors_item = config:add_item( "aimware_styles", 0 )
local aimware_colors_item_combobox = menu:add_combo( "Color Styles", "visuals", "misc", "beams", aimware_colors_item):add_item("default", aimware_colors_item):add_item("legacy", aimware_colors_item):add_item("rainbow", aimware_colors_item):add_item("gradient", aimware_colors_item)     
local position_x = config:add_item( "speclist_aimware_x", 10 )
local position_y = config:add_item( "speclist_aimware_y", 500 )
local screensize = render:screen_size();
local small_12 = render:create_font( "Small Fonts", 11, 600, false );
local ariel_36 = render:create_font( "Ariel", 36, 600, true );


function draw_aimware_container(x,y,w,h,title)
    local bg_color
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
    if aimware_colors_item:get_int() == 0 then 
        bg_color = csgo.color( 255, 0, 0, 255 ) 
    elseif aimware_colors_item:get_int() == 1 then 
        bg_color = csgo.color( 0, 85, 181, 255 ) 
    elseif aimware_colors_item:get_int() == 2 then 
        bg_color = csgo.color( r,g,b, 255 ) 
    end
    
    if aimware_colors_item:get_int() == 3 then 
        render:rect_fade(x , y , w , h , csgo.color(r, g, b, 255), csgo.color(b, g, r, 255), true)
    else 
        render:rect_filled( x , y , w , h , bg_color )
    end
   
    render:text(small_12, x + 6, y + 10, title, csgo.color(255,255,255,230))
    render:rect_filled( x + 4, y + 28, w - 8, h - 35, csgo.color( 15, 15, 15, 255 ) )
end
function draw_aimware_names(x,y,w,h,index)
    render:text(small_12, x + 8, y + 35 + index * 15, name .. " -> " .. local_player:get_name(), csgo.color(255,0,0,230))
    render:rect( x + 4, y + 50 + index * 15, w - 8, 1, csgo.color( 255, 0, 0, 255 ) )
end
local toggle = false
function on_paint()
    if not engine_client:is_in_game( ) then
        return end
    if  aimware_speclist_item:get_bool() then
        local mouse_pos = input:get_mouse_pos()
        local local_player = entity_list:get_localplayer()
        if input:is_key_down(0x2E) then
            render:text(ariel_36, screensize.x / 2 - 200, 60, "Spectator list is draggable", csgo.color(255,255,255,230))
            if input:is_key_down(0x1) then
                position_x:set_int(mouse_pos.x)
                position_y:set_int(mouse_pos.y)
            end
        end
        local spec_names = { }
        local total_spectators = 0
        local local_player = entity_list:get_localplayer()
        for i = 1, entity_list:get_max_players( ), 1 do
            player = entity_list:get_player( i )
            if player == nil or player:is_alive( ) or player:is_dormant( ) then
            goto continue end
            spec_handle = player:get_var_handle( "CBasePlayer->m_hObserverTarget" )
            spec_player = entity_list:get_from_handle( spec_handle )
            if spec_player == nil then
            goto continue end
            -- If the player is spectating us - add him/her to the list
            --if spec_player:get_index( ) == local_player:get_index( ) then
                spec_names[ total_spectators ] = player:get_name( )
                total_spectators = total_spectators + 1;
           -- end
            ::continue::
        end
        draw_aimware_container(position_x:get_int(), position_y:get_int(), 200, total_spectators * 18 + 37, "Show Spectators")
     
        -- Go through all registered spectators and draw the names
        for i = 0, total_spectators, 1 do
            if spec_names[ i ] == nil then break end
             player = entity_list:get_player( i )
             local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
             local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
             local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
             if local_player == nil or player == nil then
                return
             end
            if player:get_name() == local_player:get_name() then
                if aimware_colors_item:get_int() == 0 then 
                    color = csgo.color( 255, 0, 0, 255 ) 
                elseif aimware_colors_item:get_int() == 1 then 
                    color = csgo.color( 0, 85, 181, 255 ) 
                elseif aimware_colors_item:get_int() == 2 or aimware_colors_item:get_int() == 3 then 
                    color = csgo.color( r,g,b, 255 ) 
                end
            else 
                color = csgo.color( 255, 255, 255, 255 )
            end
            if string.len(spec_names[i]) > 14 then
                spec_names[i] = string.sub(spec_names[i], 0, 14)
            end
            local spectated = player:get_name()
            if string.len(spectated) > 14 then 
                spectated = string.sub(spectated, 0, 14)
            end
            render:text(small_12, position_x:get_int() + 8, position_y:get_int() + 33 + i * 18, spec_names[i] .. " -> " .. spectated, color)
            local line_col
            if aimware_colors_item:get_int() == 0 then 
                line_col = csgo.color( 255, 0, 0, 255 ) 
            elseif aimware_colors_item:get_int() == 1 then 
                line_col = csgo.color( 0, 85, 181, 255 ) 
            elseif aimware_colors_item:get_int() == 2  then 
                line_col = csgo.color( r,g,b, 255 ) 
            end
            if aimware_colors_item:get_int() == 3 then 
                render:rect_fade(position_x:get_int() + 4, position_y:get_int() + 47 + i * 18, 200 - 8, 1 , csgo.color(r, g, b, 255), csgo.color(b, g, r, 255), true)
            else 
                render:rect( position_x:get_int() + 4, position_y:get_int() + 47 + i * 18, 200 - 8, 1, line_col)
            end     
        end
    end
end
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )