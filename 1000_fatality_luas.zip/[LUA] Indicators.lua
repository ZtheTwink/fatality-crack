local entity_list = csgo.interface_handler:get_entity_list()
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local cvar = csgo.interface_handler:get_cvar()
local global_vars = csgo.interface_handler:get_global_vars()
local events = csgo.interface_handler:get_events()

local autosniper_doubletap = config:get_weapon_setting("autosniper", "double_tap")
local heavy_doubletap = config:get_weapon_setting("heavy_pistol", "double_tap")
local pistols_doubletap = config:get_weapon_setting("pistol", "double_tap")
local other_doubletap = config:get_weapon_setting("other", "double_tap")

local autosniper_silent = config:get_weapon_setting("autosniper", "silent")
local scout_silent = config:get_weapon_setting("scout", "silent")
local awp_silent = config:get_weapon_setting("awp", "silent")
local heavy_silent = config:get_weapon_setting("heavy_pistol", "silent")
local pistols_silent = config:get_weapon_setting("pistol", "silent")
local other_silent = config:get_weapon_setting("other", "silent")

local backtrack = menu:get_reference("Rage", "Aimbot", "Aimbot", "backtrack")
local ebacktrack = menu:get_reference("Rage", "Aimbot", "Aimbot", "Extended backtrack")
local force_fallback = menu:get_reference("RAGE", "AIMBOT", "Aimbot", "Force safepoint")
local headshot_only = menu:get_reference("RAGE", "AIMBOT", "Aimbot", "Headshot only")

local backaa = menu:get_reference("RAGE", "ANTI-AIM", "General", "Back")
local leftaa = menu:get_reference("RAGE", "ANTI-AIM", "General", "Left")
local rightaa = menu:get_reference("RAGE", "ANTI-AIM", "General", "Right")
local jitter = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Jitter")
local freestand = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "freestand")

local slide = menu:get_reference( "misc", "", "movement", "slide" );
local fd = menu:get_reference( "misc", "", "movement", "fake duck");

local master_item = config:add_item("lua_indicators_master", 0)
local master_checkbox = menu:add_checkbox("Indicators", "VISUALS", "MISC", "Various", master_item)

local scale_item = config:add_item("lua_indicators_scale", 100)
local scale_slider = menu:add_slider( "Indicator scale", "VISUALS", "MISC", "Various", scale_item, 70, 150, 1 )

local indicator_list = {}

local font = render:create_font( "Lucida Console", 20, 800, false )
local last_scale = 0

local function draw_text(font, x, y, text, color)
	
	render:text(font, x, y, text, color)

end

function draw_indicator_with_color(text, color)
	table.insert(indicator_list, {text = string.upper(text), color = color, width = render:text_size(font, string.upper(text)).x})
end

function draw_indicator_with_bool(text, enabled)
	local color = csgo.color(124, 195, 13, 255)

	
	if (enabled) then
		draw_indicator_with_color(text, color)
	end
end

function render_indicator( text, enabled )
    if(_G['draw_indicator_with_bool'] ~= nil) then
        draw_indicator_with_bool(text, enabled)
    end
end

function render_indicator_color( text, color )
    if(_G['draw_indicator_with_color'] ~= nil) then
        draw_indicator_with_color(text, color)
    end
end

local function rescale_fonts()
	local screen_size = render:screen_size( )
	local screen_scale = (100 * (screen_size.x + screen_size.y)) / (1920 + 1080)  

	local scale = scale_item:get_int()

	if not(scale == last_scale) then
		font = render:create_font( "Lucida Console", math.floor((scale / 100) *  17), 600, false )

		last_scale = scale
	end
end

local function weapon_indicator()
	local local_player = entity_list:get_localplayer() 
	local weapon = entity_list:get_from_handle(local_player:get_var_handle("CBaseCombatCharacter->m_hActiveWeapon"))

	if(weapon == nil) then
		return
	end

	local weapon_id = weapon:get_class_id()

	if(weapon_id == 244) or (weapon_id == 238) or (weapon_id == 257) or (weapon_id == 268)  or (weapon_id == 245) or (weapon_id == 257) or (weapon_id == 240) then
		draw_indicator_with_bool("           silent", pistols_silent:get_bool())
        draw_indicator_with_bool("       dt", pistols_doubletap:get_bool())
    elseif (weapon_id == 46) then
    	draw_indicator_with_bool("           silent", heavy_silent:get_bool())
        draw_indicator_with_bool("       dt", heavy_doubletap:get_bool())
    elseif (weapon_id == 266)then 
    	draw_indicator_with_bool("          silent", scout_silent:get_bool())
    elseif (weapon_id == 260) or (weapon_id == 241) then
    	draw_indicator_with_bool("           silent", autosniper_silent:get_bool())
        draw_indicator_with_bool("       dt", autosniper_doubletap:get_bool())
    elseif (weapon_id == 232) then
    	draw_indicator_with_bool("           silent", awp_silent:get_bool())
    elseif not(weapon_id == 107) then
    	draw_indicator_with_bool("           silent", other_silent:get_bool())
        draw_indicator_with_bool("       dt", other_doubletap:get_bool())

    end
end

local function on_paint() 
	local local_player = entity_list:get_localplayer() 
	local screen_size = render:screen_size( )
	local next_item_offset = 0

	if(local_player == nil or not master_item:get_bool() or not local_player:is_alive()) then
		return
	end

	rescale_fonts()

	weapon_indicator()
        draw_indicator_with_bool("          SLIDE", slide:get_bool())

        if fd:get_bool() then
        render_indicator_color("         DUCK", csgo.color(255, 10, 10, 255))
      end
        if force_fallback:get_bool() then
        render_indicator_color("             fallback", csgo.color(60, 170, 255, 255))
      end
        if headshot_only:get_bool() then
        render_indicator_color("         HEAD", csgo.color(60, 170, 255, 255))
      end
        if ebacktrack:get_bool() then
        render_indicator_color("       XT", csgo.color(255, 69, 0, 255))
      end
        if backaa:get_bool() then
        render_indicator_color("         BACK", csgo.color(209, 139, 230, 255))
      end
        if leftaa:get_bool() then
        render_indicator_color("         LEFT", csgo.color(209, 139, 230, 255))
      end
        if rightaa:get_bool() then
        render_indicator_color("          RIGHT", csgo.color(209, 139, 230, 255))
      end
        if jitter:get_bool() then
        render_indicator_color("          jitter", csgo.color(60, 170, 255, 255))
      end
        if freestand:get_bool() then
        render_indicator_color("             freestand", csgo.color(230, 160, 230, 255))
      end

	table.sort( indicator_list,  function (k1, k2) return k1.width < k2.width end)

	for i = 1, #indicator_list
	do
		if not(indicator_list[i] == nil) then
			local text_size = render:text_size(font, indicator_list[i].text)
			draw_text(font, screen_size.x / 2 - text_size.x / 2, screen_size.y / 2 + 38 + next_item_offset, indicator_list[i].text, indicator_list[i].color)
			next_item_offset = next_item_offset + text_size.y

			table.remove(indicator_list, i)
		end
	end
end

local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)