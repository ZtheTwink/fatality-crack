--Fake non pasted indicator KIPPO
local render = fatality.render
local input = fatality.input
local menu = fatality.menu
local config = fatality.config
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()

local screensize = render:screen_size()

local slidewalk_item = config:add_item( "fake", 0 )

local slidewalk_combobox = menu:add_multi_combo( "Indicators", "rage", "aimbot", "misc" ):add_item( "Fake", slidewalk_item )

function on_paint()

 

    if not engine_client:is_in_game() then
    return end

    local fake = menu:get_reference( "rage", "aimbot", "aimbot", "slide" )

    if fake:get_bool() then
        sw = true
    else
        sw = true
    end

    if slidewalk_item:get_bool() then 

        render:indicator( 8, screensize.y - 200, "FAKE", sw , -1)

    end

end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )