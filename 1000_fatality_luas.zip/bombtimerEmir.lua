-- Bomb timer by eslipe v1.0 (version of: 19.02.2019)
 
--[[ Updatelog:
 
(19.02.2019)
- Release
 
]]
 
 
 
-- interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local get_cvar = csgo.interface_handler:get_cvar()
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()
local events = csgo.interface_handler:get_events( )
local globals = csgo.interface_handler:get_global_vars( )
local engine = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
 
-- fonts
local s_pixel7 = render:create_font( "Smallest Pixel-7", 11, 100, false );
local icons = render:create_font( "undefeated", 35, 100, false );
 
-- bomb variables
local C4 = 126
local C4_time = cvar:find_var("mp_c4timer")
local c4_planted = false
local c4_planting = false
 
-- reset bomb function
function reset_bomb()
    c4_planted = false
    c4_planting = false
end
 
 
-- colour & opacity
local white = csgo.color(255, 255, 255, 255)
local red = 0
local alpha = 255
local customAlpha = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
 
 
-- variables for animation
local animation = 0
 
 
function on_paint()
 
    if(not engine_client:is_in_game()) then
        reset_bomb()
    end
 
    local screen_size = render:screen_size();
 
    if(c4_planted) then  
 
        local timeleft = (global_vars.curtime - (planted_time + explosion_time))
   
        if(timeleft <= 0) then
     
            for i = 1, entity_list:get_max_entities(), 1 do
 
                local ent = entity_list:get_entity(i)
 
                if ent == nil or ent:get_class_id() ~= C4 then
                    goto continue
                end
           
                local value = (ent:get_var_float("CPlantedC4->m_flC4Blow") - globals.curtime ) / C4_time:get_float()
 
                    if value <= 0 then
                        goto continue
                    end
       
                    -- opacity animation
                    if math.abs(timeleft) <= 45 and math.abs(timeleft) >= 10 then
                    customAlpha = math.floor( math.sin( global_vars.realtime * 4) * 127 + 128 )
                    end
                    if math.abs(timeleft) <= 10 and math.abs(timeleft) >= 5 then
                    customAlpha = math.floor( math.sin( global_vars.realtime * 7) * 127 + 128 )
                    end
                    if math.abs(timeleft) <= 5 then
                    customAlpha = math.floor( math.sin( global_vars.realtime * 10) * 127 + 128 )
                    end
 
                   
                    -- animation
                    local AnimStep = 110 / 0.6 * global_vars.frametime
                    if math.abs(timeleft) <= 45 and math.abs(timeleft) >= 44 then
                        animation = - 20
                    else
                        animation = animation + AnimStep
 
                        if  animation > 110 then
                            animation = 110
                        end
                    end
 
 
                -- background of bomb indicator
                render:rect_filled( screen_size.x / 2 - 150, animation - 35, 45, 40, csgo.color(0, 0, 0, 120) )
                -- outline of bomb indicator
                render:rect( screen_size.x / 2 - 150, animation - 35, 45, 40, csgo.color(100, 100, 100, 255) )
 
 
                -- text & icon
                render:text(icons,  screen_size.x / 2 - 144, animation - 35, "o", csgo.color(255, 255, 255, customAlpha))
                render:text(s_pixel7,  screen_size.x / 2 - 138, animation - 12, "BOMB",  csgo.color(255, 255, 255, customAlpha))
           
 
                -- bomb bar background
                render:rect_filled( screen_size.x / 2 - 100, animation - 35, 250, 40, csgo.color(0, 0, 0, 120) )
                -- outline of bomb bar background
                render:rect( screen_size.x / 2 - 100, animation - 35, 250, 40, csgo.color(100, 100, 100, 255) )
                -- bomb bar
                render:rect_filled( screen_size.x / 2 - 90, animation - 17, 230, 7, csgo.color(0, 0, 0, 150) )    
 
               
                -- if bomb has been planted
                if math.abs(timeleft) >= 10 and math.abs(timeleft) <= 45  then
                   
                     -- smooth colour switch from green to yellow
                    local step = 255 / 2 * global_vars.frametime
                    if math.abs(timeleft) <= 45 and math.abs(timeleft) >= 12 then
                        red = 0
                    else
                        red = red + step
                    end
 
                    -- green bar
                    render:rect_filled( screen_size.x / 2 - 90, animation - 17,  230 * value, 7, csgo.color(math.floor(red), 255, 0, 255) )
 
                -- if time is less than 10s
                elseif math.abs(timeleft) <= 10 and math.abs(timeleft) >= 5 then
 
                    -- smooth colour switch from yellow to red
                    local step = 255 / 3.3 * global_vars.frametime
                    if math.abs(timeleft) <= 10 and math.abs(timeleft) >= 8 then
                        yellow = 255
                    else
                        yellow = yellow - step
                    end
 
                    -- yellow bar
                    render:rect_filled( screen_size.x / 2 - 90, animation - 17,  230 * value, 7, csgo.color(255, math.floor(yellow), 0, 255) )
 
                -- if critacal time has started
                elseif math.abs(timeleft) <= 5 then
   
                    -- red bar
                    render:rect_filled( screen_size.x / 2 - 90, animation - 17,  230 * value, 7, csgo.color(255, 0, 0, 255) )
 
                end
   
                ::continue::
            end
        end
    end
end
 
-- event function
function on_event(e)
 
    -- if bomb has been planted
    if(e:get_name() == "bomb_planted") then
 
        c4_planted = true
        c4_planting = false
        planted_time = global_vars.curtime
        explosion_time = get_cvar:find_var("mp_c4timer"):get_int()
 
    end
 
    -- resetting bomb
    if(e:get_name() == "bomb_abortplant" or e:get_name() == "bomb_exploded" or e:get_name() == "bomb_defused" or e:get_name() == "round_start") then
 
        reset_bomb()
 
    end
 
    -- resetting animations
    if(e:get_name() == "round_start") then
 
        animation = 0
 
    end
 
end
 
 
-- event access
events:add_event("bomb_beginplant")
events:add_event("bomb_planted")
events:add_event("bomb_abortplant")
events:add_event("bomb_exploded")
events:add_event("round_start")
 
 
-- callbacks
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)
callbacks:add("events", on_event)
 
-- end of the code