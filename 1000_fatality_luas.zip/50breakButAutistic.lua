﻿--Yes im new to making luas
--Yes this is messy asf
--Yes some parts are pasted
--Also this is made for my configs 

local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks
local cvar = csgo.interface_handler:get_cvar( )
local global = csgo.interface_handler:get_global_vars( );
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local standDesync = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount')
local stand_yaw, stand_yaw_add = menu:get_reference("Rage", "Anti-aim", "Standing", "Yaw add"),	menu:get_reference("Rage", "Anti-aim", "Standing", "Add")
local fakelag, flmove = menu:get_reference ("rage", "anti-aim", "standing", "base amount"), menu:get_reference("rage", "anti-aim", "moving", "base amount")
local moveDesync = menu:get_reference ("rage", "anti-aim", "moving", "fake amount")
local move_yaw, move_yaw_add = menu:get_reference("Rage", "Anti-aim", "moving", "Yaw add"),	menu:get_reference("Rage", "Anti-aim", "moving", "Add")
local doubletapstyle = menu:get_reference("rage","weapons", "auto", "double tap")
local autostopstyle = menu:get_reference("rage","weapons", "auto", "autostop")
local global_vars = csgo.interface_handler:get_global_vars()
local screen_size = render:screen_size( )
local engine = csgo.interface_handler:get_engine_client()


function on_paint()		
	if doubletapstyle:get_int() == 2 then
	autostopstyle:set_int(2)
	else
	autostopstyle:set_int(1)
	end
end

callbacks:add("paint", on_paint)

move_yaw:set_bool(true)
move_yaw_add:set_int(0)
function on_paint() 
				if move_yaw_add:get_int() == 0 then
					move_yaw_add:set_int(20)
				elseif move_yaw_add:get_int() == 20 then
					move_yaw_add:set_int(-20)
				elseif move_yaw_add:get_int() == -20 then
					move_yaw_add:set_int(0)
			end
		end

callbacks:add("paint", on_paint)

stand_yaw:set_bool(true)
stand_yaw_add:set_int(-5)
function on_paint()
		if stand_yaw_add:get_int() == -5 then
			stand_yaw_add:set_int(-20)
		elseif stand_yaw_add:get_int() == -20 then
			stand_yaw_add:set_int(-5)	
			end
		end

callbacks:add("paint", on_paint)
moveDesync:set_float(-84)
standDesync:set_float(0)
local invert = true
function on_paint()		
		if invert then
		if standDesync:get_int() == -100 then
		invert = false
	else
		standDesync:set_float(standDesync:get_float() - 5)
		end
	end
		if not invert then
			if standDesync:get_int() == -50 then
			invert = true
		else
			standDesync:set_float(standDesync:get_float() + 5)
			end
		end
	end

callbacks:add("paint", on_paint)

fakelag:set_float(9)
function on_paint()
		if fakelag:get_int() == 9 then
			fakelag:set_float(7)
			elseif fakelag:get_int() == 7 then
			fakelag:set_float(11)
			elseif fakelag:get_int() == 11 then
			fakelag:set_float(6)
			elseif fakelag:get_int() == 6 then
			fakelag:set_float(12)
			elseif fakelag:get_int() == 12 then
			fakelag:set_float(9)
			end
		end

callbacks:add("paint", on_paint)

flmove:set_float(10)
function on_paint()
		if flmove:get_int() == 10 then
			flmove:set_float(8)
			elseif flmove:get_int() == 8 then
			flmove:set_float(11)
			elseif flmove:get_int() == 11 then
			flmove:set_float(10)
		end
	end


callbacks:add("paint", on_paint)

local Show_Indicators = config:add_item ( "misc_movement_Indicators", 0.0)
local Indicators_checkbox = menu:add_checkbox ( "Show Indicators", "misc", "", "Movement", Show_Indicators )
local Indicators = menu:get_reference ( "Show Fakelag", "misc", "", "Movement", Show_Indicators )
local Trash_talk = config:add_item ( "misc_movement_Trashtalk", 0.0)
local Trashtalk_checkbox = menu:add_checkbox ( "Trashtalk", "misc", "", "Movement", Trash_talk )
local Trashtalk = menu:get_reference ( "Trashtalk", "misc", "", "Movement", Trash_talk )
local screensize = render:screen_size( )
local FW_MEDIUMBOLD = 5500
local default_font = render:create_font( "Tahoma", 15, FW_MEDIUMBOLD, false)


function draw_custom_text(font, x, y, text, flags, text_color, outline_color)

    if (flags == "OUTLINE_LIGHT") then
        render:text(font, x + 1, y + 1, text, outline_color)
        render:text(font, x - 1, y - 1, text, outline_color)
        render:text(font, x + 1, y - 1, text, outline_color)
        render:text(font, x - 1, y + 1, text, outline_color)
        render:text(font, x, y, text, text_color)
    elseif (flags == "" or "none") then
        render:text(font, x, y, text, text_color)
    end  
end

function on_paint()
    if Show_Indicators:get_bool() then
		if(engine:is_in_game()) then
			else 
			return end
			local entity_list = csgo.interface_handler:get_entity_list()
			local local_player = entity_list:get_localplayer()
			if(local_player:is_alive())then
				local fatal = csgo.color(2255, 0, 100, 100)
				render:rect_filled(8, 477, 129, 124, fatal)
			end
		end
	end


callbacks:add("paint", on_paint)

function on_paint()
    if Show_Indicators:get_bool() then
	   if(engine:is_in_game()) then
	   else 
	   return end
		 local entity_list = csgo.interface_handler:get_entity_list()
		 local local_player = entity_list:get_localplayer()
			 if(local_player:is_alive())then
				local dark_blue = csgo.color(33, 27, 70, 250)
				render:rect_filled(10, 480, 125, 120, dark_blue)
			end
		end	
	end

callbacks:add("paint", on_paint)




function on_paint()
 if Show_Indicators:get_bool() then
   if(engine:is_in_game()) then
	else 
	return end
	 local entity_list = csgo.interface_handler:get_entity_list()
	 local local_player = entity_list:get_localplayer()
	  if(local_player:is_alive())then	
					draw_custom_text ( default_font, 25, 527, "FAKELAG MOVE", "OUTLIE_LIGHT", csgo.color (150, 0, 255, 255), csgo.color( 0, 0, 0, 255))
						draw_custom_text ( default_font, 25,  490, "FAKELAG STAND", "OUTLIE_LIGHT", csgo.color (150, 0, 255, 255), csgo.color( 0, 0, 0, 255))
		if doubletapstyle:get_int() == 2 then
						draw_custom_text ( default_font, 14,  506, "Doubletap Teleport", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
					return end
			if doubletapstyle:get_int() == 1 then
						draw_custom_text ( default_font, 35,  506, "Doubletap", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
					return	end
						if fakelag:get_int() == 1 then
							draw_custom_text ( default_font, 15,  509, "*", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255)) 
						elseif fakelag:get_int() == 2 then
							draw_custom_text ( default_font, 15,  509, "**", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 3 then
							draw_custom_text ( default_font, 15,  509, "***", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 4 then
							draw_custom_text ( default_font, 15,  509, "****", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 5 then
							draw_custom_text ( default_font, 15,  509, "*****", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 6 then
							draw_custom_text ( default_font, 15,  509, "******", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 7 then
							draw_custom_text ( default_font, 15,  509, "*******", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 8 then
							draw_custom_text ( default_font, 15,  509, "********", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 9 then
							draw_custom_text ( default_font, 15,  509, "*********", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 10 then
							draw_custom_text ( default_font, 15,  509, "**********", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 11 then
							draw_custom_text ( default_font, 15,  509, "***********", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 12 then
							draw_custom_text ( default_font, 15,  509, "************", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 13 then
							draw_custom_text ( default_font, 15,  509, "*************", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif fakelag:get_int() == 14 then
							draw_custom_text ( default_font, 15,  504, "**************", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						end
					end
				end		
			end
	

local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)


local frame_rate = 0.0
function get_abs_fps()
  frame_rate = 0.9 * frame_rate + ( 1.0 - 0.9 ) * global.frametime;
  return math.floor( ( 1.0 / frame_rate ) + 0.5 );
end

function on_paint()
 if Show_Indicators:get_bool() then
 local local_player = entity_list:get_localplayer()
	if(engine:is_in_game()) then
		else 
		return end
		if(local_player:is_alive())then
			draw_custom_text(default_font, 25, 560, "FPS", "OUTLIE_LIGHT", csgo.color (150, 0, 255, 255), csgo.color( 0, 0, 0, 255))
			draw_custom_text(default_font, 24, 575, (get_abs_fps()), "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
			draw_custom_text(default_font, 85, 560, "PING", "OUTLIE_LIGHT", csgo.color (150, 0, 255, 255), csgo.color( 0, 0, 0, 255))
			draw_custom_text(default_font, 85, 575, (engine:get_ping() +0).."ms", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
		end
	end
end	

callbacks:add("paint", on_paint)

function on_paint()
 if Show_Indicators:get_bool() then
        if(engine:is_in_game()) then
			else
				draw_custom_text ( default_font, 1650,  1, "banda#6448", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
				return end
		 local entity_list = csgo.interface_handler:get_entity_list()
		 local local_player = entity_list:get_localplayer()
			if(local_player:is_alive())then
				if doubletapstyle:get_int() == 2 then
					draw_custom_text ( default_font, 14,  545, "Doubletap Teleport", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
				return	end
			if doubletapstyle:get_int() == 1 then
						draw_custom_text ( default_font, 35,  545, "Doubletap", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
					return	end
						if flmove:get_int() == 1 then
							draw_custom_text ( default_font, 15, 547, "*", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 2 then
							draw_custom_text ( default_font, 15, 547, "**", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 3 then
							draw_custom_text ( default_font, 15, 547, "***", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 4 then
							draw_custom_text ( default_font, 15, 547, "****", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 5 then
							draw_custom_text ( default_font, 15, 547, "*****", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 6 then
							draw_custom_text ( default_font, 15, 547, "******", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 7 then
							draw_custom_text ( default_font, 15, 547, "*******", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 8 then
							draw_custom_text ( default_font, 15, 547, "********", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 9 then
							draw_custom_text ( default_font, 15, 547, "*********", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 10 then
							draw_custom_text ( default_font, 15, 547, "**********", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 11 then
							draw_custom_text ( default_font, 15, 547, "************", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 12 then
							draw_custom_text ( default_font, 15, 547, "************", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 13 then
							draw_custom_text ( default_font, 15, 547, "*************", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
						elseif flmove:get_int() == 14 then
							draw_custom_text ( default_font, 15, 547, "**************", "OUTLIE_LIGHT", csgo.color (255, 0, 100, 255), csgo.color( 0, 0, 0, 255))
				end
			end
		end		
	end


local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)
function on_shot(shot)
if Trash_talk:get_bool() then
    player = entity_list:get_player( shot.victim )
	 if player == nil then
		return end
		if (shot.hurt and player:get_var_int("CBasePlayer->m_iHealth") <= 0) then
			 engine_client:client_cmd("say 1'd dog")
		end
	end
end
callbacks:add( "registered_shot", on_shot )
callbacks:add("paint", on_paint)