-- _markjelo luas + cfg

print("Trail LUA for my cfg _markjelo#9266")

local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local entity_list = csgo.interface_handler:get_entity_list()
local debug = csgo.interface_handler:get_debug_overlay()
local engineClient = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()


local color = csgo.color(255,255,255,255)

local trailItem = config:add_item('trail toggle', 1)
local trailCheck = menu:add_checkbox('Trail toggle', 'misc', '', 'movement', trailItem)

local sizeItem = config:add_item('size', 1)
local sizeSlider = menu:add_slider('Trail Size', 'misc', '', 'movement', sizeItem, 1, 10,0.5)

local xItem = config:add_item('x', 0)
local yItem = config:add_item('y', 0)
local zItem = config:add_item('z', 0)

local xSlider = menu:add_slider('Trail X', 'misc', '', 'movement', xItem, -200, 200,1)
local ySlider = menu:add_slider('Trail Y', 'misc', '', 'movement', yItem, -200, 200,1)
local zSlider = menu:add_slider('Trail Z', 'misc', '', 'movement', zItem, -200, 200,1)

local durationItem = config:add_item('duration time', 1)
local durationSlider = menu:add_slider('Trail Duration', 'misc', '', 'movement', durationItem, 0.5, 5,0.5)



local colorItem = config:add_item("color combo box", 1)
local colorCombo = menu:add_combo("Trail Color","misc", "", "movement", colorItem)
colorCombo:add_item("Wireframe", colorItem)
colorCombo:add_item("Rainbow", colorItem)
colorCombo:add_item("White", colorItem)
colorCombo:add_item("Red", colorItem)
colorCombo:add_item("Green", colorItem)
colorCombo:add_item("Blue", colorItem)
colorCombo:add_item("Light blue", colorItem)




function paint()
    
    if not engineClient:is_in_game() then
    return end
    local localPlayer = entity_list:get_localplayer()

    -- the velocity part is from a dif lua i dont remeber who made it
    local velocity = localPlayer:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
    local vel_2d = math.ceil( math.sqrt( math.abs( velocity.x ) * math.abs( velocity.x ) + math.abs( velocity.y ) * math.abs( velocity.y ) ) )
    
    local eyePos = localPlayer:get_eye_pos()
    local min = csgo.vector3(0,0,0)
    local max = csgo.vector3(sizeItem:get_float(),sizeItem:get_float(),sizeItem:get_float())
    local angle = csgo.angle(0, 0, 0)

    local customEyePos = csgo.vector3(eyePos.x + xItem:get_int(), eyePos.y + yItem:get_int(), eyePos.z + zItem:get_int())

    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 )

    if colorItem:get_int() == 0 then 
        color = csgo.color(255,255,255,0)
    elseif colorItem:get_int() == 1 then 
        color = csgo.color(r,g,b,255)
    elseif colorItem:get_int() == 2 then 
        color = csgo.color(255,255,255,255)
    elseif colorItem:get_int() == 3 then 
        color = csgo.color(255,0,0,255)
    elseif colorItem:get_int() == 4 then 
        color = csgo.color(0,255,0,255)
    elseif colorItem:get_int() == 5 then 
        color = csgo.color(0,0,255,255)
    elseif colorItem:get_int() == 6 then 
        color = csgo.color(0,255,255,255)
    end

        
    if trailItem:get_bool() then
        if vel_2d > 5 then
        debug:add_box_overlay(customEyePos, min, max, angle, color, durationItem:get_float())
        end
    end



end

local callbacks = fatality.callbacks
callbacks:add('paint', paint)