-- Fix Scope Sensitivity Lua by johnyy177
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )

local fixscopesens_item = config:add_item( "fixscopesens_lua", 1.0 )
local fixscopesens_checkbox = menu:add_checkbox( "Fix scope sensitivity", "VISUALS", "MISC", "Local", fixscopesens_item )

local force_in_scope = menu:get_reference( "VISUALS", "MISC", "Local", "Force in scope" )

function on_paint()
    if not engine_client:is_in_game( ) then
       return end
        
    local local_player = entity_list:get_localplayer( )

    if not local_player:is_alive( ) then
        return end
        
    local is_scoped = local_player:get_var_bool( "CCSPlayer->m_bIsScoped" )
    local zoom_sens_ratio = cvar:find_var( "zoom_sensitivity_ratio_mouse" )
    
    
    if force_in_scope:get_bool( ) then
        if fixscopesens_item:get_bool( ) then
            if is_scoped then
                zoom_sens_ratio:set_float( 0 )
            else
                zoom_sens_ratio:set_float( 1 )
            end   
        end
    end
end

local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)