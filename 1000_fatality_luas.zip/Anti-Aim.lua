local menu = fatality.menu
local input = fatality.input
local config = fatality.config
local render = fatality.render
local callbacks = fatality.callbacks
local entity_list = csgo.interface_handler:get_entity_list()
local global_vars = csgo.interface_handler:get_global_vars()
local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )
local faketype_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake type" )
local standDesync = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount')
local stand_yaw, stand_yaw_add = menu:get_reference("Rage", "Anti-aim", "Standing", "Yaw add"),    menu:get_reference("Rage", "Anti-aim", "Standing", "Add")
local fakelag, flmove = menu:get_reference ("rage", "anti-aim", "standing", "base amount"), menu:get_reference("rage", "anti-aim", "moving", "base amount")
local moveDesync = menu:get_reference ("rage", "anti-aim", "moving", "fake amount")
local move_yaw, move_yaw_add = menu:get_reference("Rage", "Anti-aim", "moving", "Yaw add"),    menu:get_reference("Rage", "Anti-aim", "moving", "Add")
local flip = 0
local key = 0x46 -- F (key to invert)
local aa_type_stand = fatality.config:add_item( "aa_type_stand", 4 )
local aa_type_stand_add = fatality.menu:add_combo( "Anti-Aim Mode:", "RAGE", "ANTI-AIM", "General", aa_type_stand )
aa_type_stand_add:add_item("Off", aa_type_stand)
aa_type_stand_add:add_item("Static Desync", aa_type_stand)
aa_type_stand_add:add_item("Extended Desync", aa_type_stand)
aa_type_stand_add:add_item("Manual (Sides)", aa_type_stand)
local screen_size = render:screen_size()
local indicators_item = config:add_item( "indicators_item", 0 )
local indicators_checkbox = menu:add_checkbox( "Enable Inverter Key (Mouse5)", "RAGE", "ANTI-AIM", "General", indicators_item )
local bold = render:create_font( "Verdana Bold", 25, 800, false );
local bold1 = render:create_font( "Verdana Bold", 11, 800, false );
local grey = csgo.color(0, 0, 0, 100)
local blue = csgo.color(0,150,255, 255)
local invert = config:add_item("invert", 0)
function on_paint()
local local_player = entity_list:get_localplayer()
if(local_player ~= nil and local_player:is_alive()) then
if input:is_key_pressed(key) then
    invert:set_bool(not invert:get_bool())
end

if indicators_item:get_bool() then
    render:text(bold, screen_size.x / 2 + 0 + 27 + 1, screen_size.y / 2 - 12,  ">", grey)
    render:text(bold, screen_size.x / 2 - 0 - 41 + 1, screen_size.y / 2 - 12,  "<", grey)
    if invert:get_bool() then
        render:text(bold, screen_size.x / 2 + 0 - 41 + 1, screen_size.y / 2 - 12,  "<", blue)
        flip = 1
    else
        render:text(bold, screen_size.x / 2 - 0 + 27 + 1, screen_size.y / 2 - 12,  ">", blue)
        flip = 0
    end
end
if indicators_item:get_bool() then
render:text(bold1, screen_size.x / 2 + 0 + -30 + 1, screen_size.y / 2 - -20,  "A.L.A.S.K.A", blue)
render:text(bold1, screen_size.x / 2 + 0 + -29 + 1, screen_size.y / 2 - -20,  "A.L.A.S.K.A", grey)

end



if aa_type_stand:get_int() == 3 then --Extend desync

    if flip == 1 then
        faketype_stand:set_int(2)
        stand_yaw_add:set_int(-60)
        standDesync:set_float(-100)
   
        faketype_move:set_int(2)
        move_yaw_add:set_int(-60)
        moveDesync:set_float(-100)
        fakelag:set_float(1)
   
    else
        faketype_stand:set_int(2)
        stand_yaw_add:set_int(120)
        standDesync:set_float(-100)
   
        faketype_move:set_int(2)
        move_yaw_add:set_int(120)
        moveDesync:set_float(-100)
        fakelag:set_float(1)
    end
end


if aa_type_stand:get_int() == 1 then -- Jitter
    stand_yaw:set_bool(true)
    move_yaw:set_bool(true)

    if flip == 1 then
        faketype_stand:set_int(1)
        stand_yaw_add:set_int(-25)
        standDesync:set_float(100)
	

        faketype_move:set_int(1)
        move_yaw_add:set_int(-25)
        moveDesync:set_float(100)
        fakelag:set_float(1)

    else
        faketype_stand:set_int(1)
        stand_yaw_add:set_int(25)
        standDesync:set_float(-100)

        faketype_move:set_int(1)
        move_yaw_add:set_int(25)
        moveDesync:set_float(-100)
        fakelag:set_float(1)
        end
    end
end



if aa_type_stand:get_int() == 2 then --Static desync
    stand_yaw:set_bool(true)
    move_yaw:set_bool(true)

    if flip == 1 then
        faketype_stand:set_int(2)
        stand_yaw_add:set_int(25)
        standDesync:set_float(-100)
   
        faketype_move:set_int(2)
        move_yaw_add:set_int(25)
        moveDesync:set_float(-100)
        fakelag:set_float(1)
   
    else
        faketype_stand:set_int(2)
        stand_yaw_add:set_int(-25)
        standDesync:set_float(100)
   
        faketype_move:set_int(2)
        move_yaw_add:set_int(-25)
        moveDesync:set_float(100)
        fakelag:set_float(1)
        end
    end
end

callbacks:add("paint", on_paint)

callbacks:add("paint", on_paint)