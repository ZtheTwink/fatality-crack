
-- https://fatality.win/threads/api-ig-key-picker.5315/
--main instances
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks
local input = fatality.input
--main instances
local key
local comboItem = config:add_item( 'key picker item', 0 )
local comboBox = menu:add_combo( 'KeyPicker', 'misc', ' ', 'movement', comboItem )
comboBox:add_item('No Key', comboItem)
comboBox:add_item('Mouse1', comboItem)
comboBox:add_item('Mouse2', comboItem)
comboBox:add_item('Mouse3', comboItem)
comboBox:add_item('Mouse5', comboItem)
comboBox:add_item('Mouse6', comboItem)
comboBox:add_item('Alt', comboItem)
comboBox:add_item('Q', comboItem)
comboBox:add_item('W', comboItem)
comboBox:add_item('E', comboItem)
comboBox:add_item('R', comboItem)
comboBox:add_item('T', comboItem)
comboBox:add_item('Y', comboItem)
comboBox:add_item('U', comboItem)
comboBox:add_item('I', comboItem)
comboBox:add_item('O', comboItem)
comboBox:add_item('P', comboItem)
comboBox:add_item('A', comboItem)
comboBox:add_item('S', comboItem)
comboBox:add_item('D', comboItem)
comboBox:add_item('F', comboItem)
comboBox:add_item('G', comboItem)
comboBox:add_item('H', comboItem)
comboBox:add_item('J', comboItem)
comboBox:add_item('K', comboItem)
comboBox:add_item('L', comboItem)
comboBox:add_item('Z', comboItem)
comboBox:add_item('X', comboItem)
comboBox:add_item('C', comboItem)
comboBox:add_item('V', comboItem)
comboBox:add_item('B', comboItem)
comboBox:add_item('N', comboItem)
comboBox:add_item('M', comboItem)

function getKetState()
    if comboItem:get_int() == 1 then
        key = 0x01
    elseif comboItem:get_int() == 2 then
        key = 0x02
    elseif comboItem:get_int() == 3 then
        key = 0x04
    elseif comboItem:get_int() == 4 then
        key = 0x05
    elseif comboItem:get_int() == 5 then
        key = 0x06
    elseif comboItem:get_int() == 6 then
        key = 0x12
    elseif comboItem:get_int() == 7 then
        key = 0x51
    elseif comboItem:get_int() == 8 then
        key = 0x57
    elseif comboItem:get_int() == 9 then
        key = 0x45
    elseif comboItem:get_int() == 10 then
        key = 0x52
    elseif comboItem:get_int() == 11 then
        key = 0x54
    elseif comboItem:get_int() == 12 then
        key = 0x59
    elseif comboItem:get_int() == 13 then
        key = 0x55
    elseif comboItem:get_int() == 14 then
        key = 0x49
    elseif comboItem:get_int() == 15 then
        key = 0x4F
    elseif comboItem:get_int() == 16 then
        key = 0x50
    elseif comboItem:get_int() == 17 then
        key = 0x41
    elseif comboItem:get_int() == 18 then
        key = 0x53
    elseif comboItem:get_int() == 19 then
        key = 0x44
    elseif comboItem:get_int() == 20 then
        key = 0x46
    elseif comboItem:get_int() == 21 then
        key = 0x47
    elseif comboItem:get_int() == 22 then
        key = 0x48
    elseif comboItem:get_int() == 23 then
        key = 0x4A
    elseif comboItem:get_int() == 24 then
        key = 0x4B
    elseif comboItem:get_int() == 25 then
        key = 0x4C
    elseif comboItem:get_int() == 26 then
        key = 0x5A
    elseif comboItem:get_int() == 27 then
        key = 0x58
    elseif comboItem:get_int() == 28 then
        key = 0x43
    elseif comboItem:get_int() == 29 then
        key = 0x56
    elseif comboItem:get_int() == 30 then
        key = 0x42
    elseif comboItem:get_int() == 31 then
        key = 0x4E
    elseif comboItem:get_int() == 32 then
        key = 0x4D
    else
        key = 0x73 
    end
end
callbacks:add( "paint", getKetState )