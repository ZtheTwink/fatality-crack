-- https://fatality.win/threads/bomb-bar.664/

-- Fatality interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu

-- Interfaces
local globals = csgo.interface_handler:get_global_vars( )
local engine = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local events = csgo.interface_handler:get_events( )
local cvar = csgo.interface_handler:get_cvar( )

local classid =
{
    planted_c4 = 126
}

local data =
{
    screen_size = render:screen_size( ),
    col = csgo.color( 10, 150, 70, 200 ),
    back_col = csgo.color( 0, 0, 0, 77 ),
    bomb_time = cvar:find_var( "mp_c4timer" ),
    bar_height = 18
}

local function on_paint( )
    for i = 1, entity_list:get_max_entities( ), 1 do
            local ent = entity_list:get_entity( i )
            if ent == nil or ent:get_class_id( ) ~= classid.planted_c4 then
                goto continue end
         
            local bar_size = data.screen_size.x * 0.4
            local factor = ( ent:get_var_float( "CPlantedC4->m_flC4Blow" ) - globals.curtime ) / data.bomb_time:get_float( )

            if factor <= 0 then
                goto continue end

            local pos = csgo.vector2( data.screen_size.x * 0.5 - bar_size * 0.5, data.screen_size.y * 0.1 );
            render:rect_filled( pos.x, pos.y, bar_size, data.bar_height, data.back_col )
            render:rect_filled( pos.x + 2, pos.y + 2, ( bar_size - 4 ) * factor, data.bar_height - 4, data.col )          
         
            ::continue::
        end
end

-- Register callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )