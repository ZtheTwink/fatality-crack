-- https://fatality.win/threads/fps-indicator.536/

--interfaces
local render = fatality.render;
local global = csgo.interface_handler:get_global_vars( );
local engine = csgo.interface_handler:get_engine_client( );

--get fps count
local frame_rate = 0.0
function get_abs_fps( )
  frame_rate = 0.9 * frame_rate + ( 1.0 - 0.9 ) * global.frametime;
  return math.floor( ( 1.0 / frame_rate ) + 0.5 );
end

--menu and config items stuff
local menu = fatality.menu
local config = fatality.config

local fps_indicator_item = config:add_item( "fps_indicator", 1.0 );
local fps_badvalue_item = config:add_item( "fps_indicator_badvalue", 2.0 );

local menu_checkbox = menu:add_checkbox( "FPS Indicator", "visuals", "misc", "various", fps_indicator_item );
local menu_slider = menu:add_slider( "FPS Bad value", "visuals", "misc", "various", fps_badvalue_item, 20.0, 95.0, 0 );

--main render function
function on_paint( )
   if not fps_indicator_item:get_bool( ) or not engine:is_in_game( ) then
        return;
      end
    local screen_size = render:screen_size( );
    local activate = get_abs_fps( ) >= fps_badvalue_item:get_float( );
    render:indicator( screen_size.x / 110, screen_size.y / 2 - 8, tostring( get_abs_fps( ) ) , activate, -1 );
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );