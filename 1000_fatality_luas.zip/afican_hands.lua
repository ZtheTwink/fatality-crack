-- https://fatality.win/threads/african-lua-best-lua-yet.1032/

local cvar = csgo.interface_handler:get_cvar()

fatality.callbacks:add("paint", function(e)
    local rskin = cvar:find_var("r_skin")
    rskin:unlock()
    rskin:set_int(1)
end)