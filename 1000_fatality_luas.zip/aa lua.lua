local globals   = csgo.interface_handler:get_global_vars()
local engine    = csgo.interface_handler:get_engine_client()
local menu      = fatality.menu
local config    = fatality.config
local input     = fatality.input
local callbacks = fatality.callbacks
 
 
local timing = {
    lastTickStandDesync = globals.realtime,
    lastTickMoveDesync = globals.realtime,
    lastTickAirDesync = globals.realtime,
   
    lastTickStandYaw = globals.realtime,
    lastTickMoveYaw = globals.realtime,
    lastTickAirYaw = globals.realtime,
   
    standDesync = false,
    moveDesync = false,
    airDesync = false,
    standYaw = false,
    moveYaw = false,
    airYaw = false,
}
 
 
local items = { --checkbox items
    --------------------------------------------------------DESYNC--------------------------------------------------------
    desyncStandItem = config:add_item('desync stand', 1),--standing
    desyncMoveItem = config:add_item('desync move', 1),--moving
    desyncAirItem = config:add_item('desync air', 0),--air
    --------------------------------------------------------
    desyncStandFirstItem = config:add_item('first standing desync angle', 20), --standing
    desyncStandSecondItem = config:add_item('second standing desync angle', -99),--standing
    desyncMoveFirstItem = config:add_item('first moving desync angle', 14),--moving
    desyncMoveSecondItem = config:add_item('second moving desync angle', -71),--moving
    desyncAirFirstItem = config:add_item('first air desync angle', 0),--air
    desyncAirSecondItem = config:add_item('second air desync angle', 0),--air
    ----------------------------------------------------------
    desyncStandingDelayItem = config:add_item('standing desync delay', 0.1),
    desyncMovingDelayItem = config:add_item('moving desync delay', 0.4),
    desyncAirDelayItem = config:add_item('air desync delay', 0),
 
    ---------------------------------------------------------YAW---------------------------------------------------------
    yawStandItem = config:add_item('yaw stand', 1),--stand
    yawMoveItem = config:add_item('yaw Move', 0),--move
    yawAirItem = config:add_item('yaw Air', 0),--stand    
    --------------------------------------------------------
    yawStandFirstItem = config:add_item('first standing yaw angle', 20), --standing
    yawStandSecondItem = config:add_item('second standing yaw angle', -100),--standing
    yawMoveFirstItem = config:add_item('first moving yaw angle', 0),--moving
    yawMoveSecondItem = config:add_item('second moving yaw angle', 0),--moving
    yawAirFirstItem = config:add_item('first air yaw angle', 0),--air
    yawAirSecondItem = config:add_item('second air yaw angle', 0),--air
    --------------------------------------------------------
    yawStandingDelayItem = config:add_item('standing yaw delay', 0.1),
    yawMovingDelayItem = config:add_item('moving yaw delay', 0),
    yawAirDelayItem = config:add_item('air yaw delay', 0),
 
    ----------------------------aa-mode-------------------------
    aaModeItem = config:add_item('aa modes',0),
 
 
}
local desyncCheckbox = { --its done like this for menu positioning
 
    --------------------------------------------------------DESYNC--------------------------------------------------------
 
    desyncStandCheck = menu:add_checkbox('Desync Jitter Stand', 'rage', 'anti-aim', 'standing', items.desyncStandItem),--standing
    desyncMovedCheck = menu:add_checkbox('Desync Jitter Move', 'rage', 'anti-aim', 'moving', items.desyncMoveItem),--moving
    desyncAirCheck = menu:add_checkbox('Desync Jitter Air', 'rage', 'anti-aim', 'air', items.desyncAirItem),--air
 
   
 
}
 
aaModeCombo = menu:add_combo('AA MODE', 'rage', 'anti-aim','general',items.aaModeItem)
aaModeCombo:add_item('Off',items.aaModeItem)
aaModeCombo:add_item('Custom',items.aaModeItem)
aaModeCombo:add_item('AA Type 1',items.aaModeItem)
aaModeCombo:add_item('AA Type 2',items.aaModeItem)
aaModeCombo:add_item('AA Type 3',items.aaModeItem)
 
 
 
local desyncSliders = { --its done like this for menu positioning
    --standing desync
    desyncStandSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'standing',items.desyncStandFirstItem, -100, 100, 1),
    desyncStandSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'standing',items.desyncStandSecondItem, -100, 100, 1),
    --moving desync
    desyncMoveSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'moving',items.desyncMoveFirstItem, -100, 100, 1),
    desyncMoveSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'moving',items.desyncMoveSecondItem, -100, 100, 1),
    --air desync
    desyncAirSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'air',items.desyncAirFirstItem, -100, 100, 1),
    desyncAirSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'air',items.desyncAirSecondItem, -100, 100, 1),
    --desync delay
    desyncStandingDelaySlider = menu:add_slider('Desync Jitter Delay','rage', 'anti-aim', 'standing',items.desyncStandingDelayItem,0, 60, 0.1),
    desyncMovingDelaySlider = menu:add_slider('Desync Jitter Delay','rage', 'anti-aim', 'moving',items.desyncMovingDelayItem,0, 60, 0.1),
    desyncAirDelaySlider = menu:add_slider('Desync Jitter Delay','rage', 'anti-aim', 'air',items.desyncAirDelayItem,0, 60, 0.1),
 
}
local yawCheckbox = { --its done like this for menu positioning
 
    ---------------------------------------------------------YAW---------------------------------------------------------
 
    yawStandCheck = menu:add_checkbox('Yaw Jitter Stand', 'rage', 'anti-aim', 'standing', items.yawStandItem),--standing
    yawMovedCheck = menu:add_checkbox('Yaw Jitter Move', 'rage', 'anti-aim', 'moving', items.yawMoveItem),--moving
    yawAirCheck = menu:add_checkbox('Yaw Jitter Air', 'rage', 'anti-aim', 'air', items.yawAirItem),--air
}
 
local yawSliders = { --its done like this for menu positioning
 
    --standing yaw
    yawStandSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'standing',items.yawStandFirstItem, -100, 99, 1),
    yawStandSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'standing',items.yawStandSecondItem, -99, 100, 1),
    --moving yaw
    yawMoveSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'moving',items.yawMoveFirstItem, -100, 100, 1),
    yawMoveSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'moving',items.yawMoveSecondItem, -100, 100, 1),
    --air yaw
    yawAirSlider1 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'air',items.yawAirFirstItem, -99, 100, 1),
    yawAirSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'air',items.yawAirSecondItem, -100, 100, 1),
    --yaw delay
    yawStandingDelaySlider = menu:add_slider('Yaw Jitter Delay','rage', 'anti-aim', 'standing',items.yawStandingDelayItem,0, 60, 0.1),
    yawMovingDelaySlider = menu:add_slider('Yaw Jitter Delay','rage', 'anti-aim', 'moving',items.yawMovingDelayItem,0, 60, 0.1),
    yawAirDelaySlider = menu:add_slider('Yaw Jitter Delay','rage', 'anti-aim', 'air',items.yawAirDelayItem,0, 60, 0.1),
}
 
 
 
 
function jitter ()
 
--------------------------------------------------------DESYNC--------------------------------------------------------
    if items.aaModeItem:get_int() == 0 then
        items.desyncStandItem:set_int(0)
        items.yawStandItem:set_int(0)
        items.desyncStandFirstItem:set_int(0)
        items.desyncStandSecondItem:set_int(0)
        items.desyncStandingDelayItem:set_float(0)
    elseif items.aaModeItem:get_int() == 1 then
        --custom
    elseif items.aaModeItem:get_int() == 2 then
--------------------------------------------------------STAND--------------------------------------------------------
         --desync and yaw toggles
         items.desyncStandItem:set_int(1)
         items.yawStandItem:set_int(1)
        --desync
        items.desyncStandFirstItem:set_int(20)
        items.desyncStandSecondItem:set_int(-100)
        items.desyncStandingDelayItem:set_float(0.1)
        --yaw
        items.yawStandFirstItem:set_int(24)
        items.yawStandSecondItem:set_int(0)
        items.yawStandingDelayItem:set_float(0.1)
--------------------------------------------------------MOVING--------------------------------------------------------
         --desync and yaw toggles
         items.desyncMoveItem:set_int(1)
         items.yawMoveItem:set_int(0)
        --desync
        items.desyncMoveFirstItem:set_int(14)
        items.desyncMoveSecondItem:set_int(-71)
        items.desyncMovingDelayItem:set_float(0.4)
        --yaw
        items.yawMoveFirstItem:set_int(0)
        items.yawMoveSecondItem:set_int(0)
        items.yawMovingDelayItem:set_float(30)
--------------------------------------------------------IN-AIR--------------------------------------------------------
         --desync and yaw toggles
         items.desyncAirItem:set_int(1)
         items.yawAirItem:set_int(1)
        --desync
        items.desyncAirFirstItem:set_int(0)
        items.desyncAirSecondItem:set_int(-100)
        items.desyncAirDelayItem:set_float(0.1)
        --yaw
        items.yawAirFirstItem:set_int(20)
        items.yawAirSecondItem:set_int(-20)
        items.yawAirDelayItem:set_float(0.1)
 
    end
 
    if items.desyncStandItem:get_bool() then --STANDING DESYNC
        if timing.lastTickStandDesync + items.desyncStandingDelayItem:get_float() < globals.realtime then
            if timing.standDesync then
                menu:get_reference( 'rage', 'anti-aim', 'standing', 'fake amount'):set_int( items.desyncStandFirstItem:get_int() );
                timing.standDesync = false
            else
                menu:get_reference( 'rage', 'anti-aim', 'standing', 'fake amount'):set_int( items.desyncStandSecondItem:get_int() );
                timing.standDesync = true
            end
            timing.lastTickStandDesync = globals.realtime
        end
    end
    -------------------------------------------------------
    if items.desyncMoveItem:get_bool() then --MOVING DESYNC
       if timing.lastTickMoveDesync + items.desyncMovingDelayItem:get_float() < globals.realtime then
        if timing.moveDesync then
            menu:get_reference( 'rage', 'anti-aim', 'moving', 'fake amount'):set_int( items.desyncMoveFirstItem:get_int() );
            timing.moveDesync = false
        else
            menu:get_reference( 'rage', 'anti-aim', 'moving', 'fake amount'):set_int( items.desyncMoveSecondItem:get_int() );
            timing.moveDesync = true
        end
        timing.lastTickMoveDesync = globals.realtime
       end
    end
    -------------------------------------------------------
    if items.desyncAirItem:get_bool() then --AIR DESYNC
       if timing.lastTickAirDesync + items.desyncAirDelayItem:get_float() < globals.realtime then
        if timing.airDesync then
            menu:get_reference('rage', 'anti-aim', 'air', 'fake amount'):set_int(items.desyncAirFirstItem:get_int())
            timing.airDesync = false
        else
            menu:get_reference('rage', 'anti-aim', 'air', 'fake amount'):set_int(items.desyncAirSecondItem:get_int())
            timing.airDesync = true
       end
       timing.lastTickAirDesync = globals.realtime
       end
    end
 
    ---------------------------------------------------------YAW---------------------------------------------------------
    if items.yawStandItem:get_bool() then --Standing Yaw
        if timing.lastTickStandYaw + items.yawStandingDelayItem:get_float() < globals.realtime then
         if timing.standYaw then
             menu:get_reference('rage', 'anti-aim', 'standing', 'add'):set_int(items.yawStandFirstItem:get_int())
             timing.standYaw = false
         else
             menu:get_reference('rage', 'anti-aim', 'standing', 'add'):set_int(items.yawStandSecondItem:get_int())
             timing.standYaw = true
         end
        timing.lastTickStandYaw = globals.realtime
        end
    end
    -------------------------------------------------------
    if items.yawMoveItem:get_bool() then --Moveing Yaw
        if timing.lastTickMoveYaw + items.yawMovingDelayItem:get_float() < globals.realtime then
         if timing.MoveYaw then
             menu:get_reference('rage', 'anti-aim', 'moving', 'add'):set_int(items.yawMoveFirstItem:get_int())
             timing.MoveYaw = false
         else
             menu:get_reference('rage', 'anti-aim', 'moving', 'add'):set_int(items.yawMoveSecondItem:get_int())
             timing.MoveYaw = true
         end
        timing.lastTickMoveYaw = globals.realtime
        end
    end
    -------------------------------------------------------
    if items.yawAirItem:get_bool() then --Air Yaw
        if timing.lastTickAirYaw + items.yawAirDelayItem:get_float() < globals.realtime then
         if timing.AirYaw then
             menu:get_reference('rage', 'anti-aim', 'air', 'add'):set_int(items.yawAirFirstItem:get_int())
             timing.AirYaw = false
         else
             menu:get_reference('rage', 'anti-aim', 'air', 'add'):set_int(items.yawAirSecondItem:get_int())
             timing.AirYaw = true
         end
        timing.lastTickAirYaw = globals.realtime
        end
    end
   
end
 
callbacks:add('paint', jitter)