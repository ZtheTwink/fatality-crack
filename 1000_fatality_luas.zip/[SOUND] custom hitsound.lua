local config = fatality.config;
local menu = fatality.menu;
local callbacks = fatality.callbacks;
 
local custom_hit_sound_checkbox_item = config:add_item('visuals_custom_hit_sound', 0);
local custom_hit_sound_checkbox = menu:add_checkbox('Custom Hit Sound', 'Visuals', 'Misc', 'Various', custom_hit_sound_checkbox_item);
 
local custom_hit_sound_combo_item = config:add_item('visuals_custom_hit_sound_combo', 0);
local custom_hit_sound_combo = menu:add_combo('Hit Sound', 'Visuals', 'Misc', 'Various', custom_hit_sound_combo_item);
 
custom_hit_sound_combo:add_item('Metal', custom_hit_sound_combo_item);
custom_hit_sound_combo:add_item('Glass', custom_hit_sound_combo_item);
custom_hit_sound_combo:add_item('Timer Bell', custom_hit_sound_combo_item);
custom_hit_sound_combo:add_item('Button 1', custom_hit_sound_combo_item);
custom_hit_sound_combo:add_item('Button 2', custom_hit_sound_combo_item);
custom_hit_sound_combo:add_item('Money Collect', custom_hit_sound_combo_item);
custom_hit_sound_combo:add_item('Warning', custom_hit_sound_combo_item);
custom_hit_sound_combo:add_item('Headshot', custom_hit_sound_combo_item);
 
local engine_client = csgo.interface_handler:get_engine_client();
local entity_list = csgo.interface_handler:get_entity_list();
local events = csgo.interface_handler:get_events();
 
events:add_event('player_hurt');
 
local function on_events(event)
    if not custom_hit_sound_checkbox_item:get_bool() then
        return;
    end
 
    if not engine_client:is_connected() and not engine_client:is_in_game() then
        return;
    end
 
    local local_player = entity_list:get_localplayer();
 
    if local_player == nil then
        return;
    end
 
    if event:get_name() == 'player_hurt' then
        local event_attacker = event:get_int('attacker');
 
        if event_attacker == nil then
            return;
        end
 
        local attacker = entity_list:get_player_from_id(event_attacker);
 
        if attacker == nil then
            return;
        end
 
        if attacker:get_index() == local_player:get_index() then
            if custom_hit_sound_combo_item:get_int() == 0 then
                sound = 'physics\\metal\\metal_solid_impact_bullet2';
            elseif custom_hit_sound_combo_item:get_int() == 1 then
                sound = 'physics\\glass\\glass_impact_bullet1';
            elseif custom_hit_sound_combo_item:get_int() == 2 then
                sound = 'training\\timer_bell';
            elseif custom_hit_sound_combo_item:get_int() == 3 then
                sound = 'buttons\\button14.wav';
            elseif custom_hit_sound_combo_item:get_int() == 4 then
                sound = 'buttons\\button17.wav';
            elseif custom_hit_sound_combo_item:get_int() == 5 then
                sound = 'survival\\money_collect_04.wav';
            elseif custom_hit_sound_combo_item:get_int() == 6 then
                sound = 'resource\\warning.wav';
            elseif custom_hit_sound_combo_item:get_int() == 7 then
                sound = 'player\\headshot2.wav';
            end
 
            if sound == nil then
                return;
            end
 
            engine_client:client_cmd('play ' .. sound);
        end
    end
end
 
callbacks:add('events', on_events);