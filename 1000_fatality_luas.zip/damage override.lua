local globals = csgo.interface_handler:get_global_vars( );

local menu = fatality.menu;
local config = fatality.config;
local input = fatality.input;

local render = fatality.render;

--Done, tested
local options = config:add_item( "options", 0 );
local options_combo = menu:add_combo( "Min-damage bind option", "Rage", "Aimbot", "Aimbot", options );
options_combo:add_item( "Hold", options );
options_combo:add_item( "Toggle", options );

local auto_cfg, awp_cfg, pistols_cfg, scout_cfg, heavyp_cfg, other_cfg =
    config:add_item( "auto_cfg", 0 ),
    config:add_item( "awp_cfg", 0 ),
    config:add_item( "pistols_cfg", 0 ),
    config:add_item( "scout_cfg", 0 ),
    config:add_item( "heavyp_cfg", 0 ),
    config:add_item( "other_cfg", 0 );

--Done, tested
local auto_menu, awp_menu, pistols_menu, scout_menu, heavyp_menu, other_menu =
       menu:add_slider( "Mindmg bind Auto", "Rage", "Aimbot", "Aimbot", auto_cfg, 0, 100, 0 ),
       menu:add_slider( "Mindmg bind AWP", "Rage", "Aimbot", "Aimbot", awp_cfg, 0, 100, 0 ),
       menu:add_slider( "Mindmg bind Pistols", "Rage", "Aimbot", "Aimbot", pistols_cfg, 0, 100, 0 ),
       menu:add_slider( "Mindmg bind Scout", "Rage", "Aimbot", "Aimbot", scout_cfg, 0, 100, 0 ),
       menu:add_slider( "Mindmg bind heavy", "Rage", "Aimbot", "Aimbot", heavyp_cfg, 0, 100, 0 ),
       menu:add_slider( "Mindmg bind other", "Rage", "Aimbot", "Aimbot", other_cfg, 0, 100, 0 );

local backups = {
    auto_mindmg = config:get_weapon_setting("autosniper", "mindmg"):get_int( );
    awp_mindmg = config:get_weapon_setting("awp", "mindmg"):get_int( );
    pistols_mindmg = config:get_weapon_setting("pistol", "mindmg"):get_int( );
    scout_mindmg = config:get_weapon_setting("scout", "mindmg"):get_int( );
    heavyp_mindmg = config:get_weapon_setting("heavy_pistol", "mindmg"):get_int( );
    other_mindmg = config:get_weapon_setting("other", "mindmg"):get_int( );
};

function paint_mindamage_indicator()
    render:indicator( render:screen_size().x * 2.34 / 5, render:screen_size().y * 0.93 / 2, "MIN-DMG", true , -1);
end

function manage_menu( toggle )
    if ( toggle ) then
        paint_mindamage_indicator();
        config:get_weapon_setting("autosniper", "mindmg"):set_int( auto_cfg:get_int( ) );
        config:get_weapon_setting("awp", "mindmg"):set_int( awp_cfg:get_int( ) );
        config:get_weapon_setting("pistol", "mindmg"):set_int( pistols_cfg:get_int( ) );
        config:get_weapon_setting("scout", "mindmg"):set_int( scout_cfg:get_int( ) );
        config:get_weapon_setting("heavy_pistol", "mindmg"):set_int( heavyp_cfg:get_int( ) );
        config:get_weapon_setting("other", "mindmg"):set_int( other_cfg:get_int( ) );
    else
        config:get_weapon_setting("autosniper", "mindmg"):set_int( backups.auto_mindmg );
        config:get_weapon_setting("awp", "mindmg"):set_int( backups.awp_mindmg );
        config:get_weapon_setting("pistol", "mindmg"):set_int( backups.pistols_mindmg );
        config:get_weapon_setting("scout", "mindmg"):set_int( backups.scout_mindmg );
        config:get_weapon_setting("heavy_pistol", "mindmg"):set_int( backups.heavyp_mindmg );
        config:get_weapon_setting("other", "mindmg"):set_int( backups.other_mindmg );
    end
end

local key = 0x43; -- change here, 0x06 is mouse5
local last_timer = globals.tickcount;

function on_paint( )

    local hold = options:get_int( ) == 0;

    if ( hold ) then
        if ( input:is_key_down( key ) ) then
            manage_menu( true );
        else
            manage_menu( false );
        end
    else
        if ( input:is_key_down( key ) and globals.tickcount - last_timer > 20 ) then
            toggled = not toggled;
            last_timer = globals.tickcount;
        end
        if ( toggled ) then
            manage_menu( true );
        else
            manage_menu( false );
        end
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );