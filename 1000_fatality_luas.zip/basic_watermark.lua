-- https://fatality.win/threads/my-basic-watermark.3739/

local menu = fatality.menu
local input = fatality.input
local config = fatality.config
local render = fatality.render
local callbacks = fatality.callbacks

local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )
local global_vars = csgo.interface_handler:get_global_vars( )
local game_events = csgo.interface_handler:get_events( )
local cvar = csgo.interface_handler:get_cvar( )

local font = render:create_font("Smallest Pixel-7", 18, 400, true)
local screen_size = render:screen_size()
local main_advert_size = render:text_size(font, "fatality")
local effect_time = 0

local frame_rate = 0

local kills = 0
local spree = 0
local deaths = 0
local assists = 0

function get_fps( )
    frame_rate = 0.9 * frame_rate + ( 1.0 - 0.9 ) * global_vars.frametime
    return math.floor( ( 1.0 / frame_rate ) + 0.5 )
end

local function get_tickrate( )
    if not engine_client:is_connected( ) then
    return 0 end

    return math.floor( 1.0 / global_vars.interval_per_tick )
end

function events(e)
    local local_player = entity_list:get_localplayer( );

    if (e:get_name() == "player_death") then
        local attacker = entity_list:get_player_from_id( e:get_int( "attacker" ) );
        local victim = entity_list:get_player_from_id( e:get_int( "userid" ) );
        local assist = entity_list:get_player_from_id( e:get_int( "assister" ) );      
        local headshot = e:get_bool( "headshot" );
       
        if (local_player:get_index() == victim:get_index()) then
            deaths = deaths + 1
            spree = 0
        end
       
        if (local_player:get_index() == assist:get_index()) then
            assists = assists + 1
        end
       
        if (local_player:get_index() == attacker:get_index() and local_player:get_index() ~= victim:get_index()) then
            kills = kills + 1
            spree = spree + 1
        end
    end
   
    if (e:get_name() == "player_say") then
        local userid = entity_list:get_player_from_id(e:get_int("userid"))
        local event_text = e:get_string("text")
       
        if (local_player:get_index() == userid:get_index()) then
            if (event_text == "!rs") then
                kills = 0
                deaths = 0
                spree = 0
                assists = 0
            end
        end
    end
   
    if (e:get_name() == "round_announce_warmup") then
        kills = 0
        deaths = 0
        spree = 0
        assists = 0
    end
   
    if (e:get_name() == "round_announce_match_start") then
        kills = 0
        deaths = 0
        spree = 0
        assists = 0
    end
end

function watermark()
    if (engine_client:is_in_game() and engine_client:is_connected()) then

        local x = screen_size.x / 2
        local y = 35
       
        if (effect_time < global_vars.curtime) then
            render:text(font, x + 1, y + 1, "fatality", csgo.color(0, 0, 255, 255))
            render:text(font, x - 1, y - 1, "fatality", csgo.color(255, 0, 0, 255))
            effect_time = global_vars.curtime + 0.01
        end
       
        render:text(font, x, y, "fatality", csgo.color(255, 255, 255, 255))
        render:text(font, x - main_advert_size.x / 0.75, y + 15, "ping: " .. engine_client:get_ping() .. " fps: " .. get_fps() .. " tickrate: " .. get_tickrate(), csgo.color(255, 255, 255, 255))
        render:text(font, x - main_advert_size.x / 0.55, y + 30, "kills: " .. kills .. " deaths: " .. deaths .. " spree: " .. spree .. " assists: " .. assists, csgo.color(255, 255, 255, 255))
    end
end

game_events:add_event("player_death")
game_events:add_event("player_say")
game_events:add_event("round_announce_match_start")
game_events:add_event("round_announce_warmup")

callbacks:add("paint", watermark)
callbacks:add("events", events)