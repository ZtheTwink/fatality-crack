-- https://fatality.win/threads/fake-duck-indicator-smoothly-animated-hands-06-02-2019.923/

-- Fake-duck indicator by eslipe v.1

-- interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar()
local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars()



-- menu reference
local fakeduck = menu:get_reference( "rage", "aimbot", "aimbot", "fake duck" )



-- convar variables
local cvar = {

    viewmodel_z = cvar:find_var("viewmodel_offset_z")

}



-- sets value from menu to "Z" viewmodel cvar
function on_paint()

    -- delay of animation
     local delay = math.floor(math.sin(global_vars.realtime * 15) / 2 * 3)

     -- in-game check
     if not engine_client:is_in_game() then
    return end

     -- localplayer variable
    local local_player = entity_list:get_localplayer()

    -- alive check
    if not local_player:is_alive() then
    return end

        -- fakeduck check
        if fakeduck:get_bool() then

               -- changes "Z" viewmodel of hands
                cvar.viewmodel_z:set_int(delay)

        end
end



-- callback
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)

-- end of the code