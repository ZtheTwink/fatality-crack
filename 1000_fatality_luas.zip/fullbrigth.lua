-- Fatality interfaces.
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar()

-- String functions.
local string_find, string_format, string_rep, string_gsub, string_len, string_gmatch, string_dump, string_match, string_reverse, string_byte, string_char, string_upper, string_lower, string_sub = string.find, string.format, string.rep, string.gsub, string.len, string.gmatch, string.dump, string.match, string.reverse, string.byte, string.char, string.upper, string.lower, string.sub 

-- Math functions.
local math_ceil, math_tan, math_log10, math_randomseed, math_cos, math_sinh, math_random, math_huge, math_pi, math_max, math_atan2, math_ldexp, math_floor, math_sqrt, math_deg, math_atan, math_fmod = math.ceil, math.tan, math.log10, math.randomseed, math.cos, math.sinh, math.random, math.huge, math.pi, math.max, math.atan2, math.ldexp, math.floor, math.sqrt, math.deg, math.atan, math.fmod 
local math_acos, math_pow, math_abs, math_min, math_sin, math_frexp, math_log, math_tanh, math_exp, math_modf, math_cosh, math_asin, math_rad = math.acos, math.pow, math.abs, math.min, math.sin, math.frexp, math.log, math.tanh, math.exp, math.modf, math.cosh, math.asin, math.rad 

-- Table functions.
local table_maxn, table_foreach, table_sort, table_remove, table_foreachi, table_move, table_getn, table_concat, table_insert = table.maxn, table.foreach, table.sort, table.remove, table.foreachi, table.move, table.getn, table.concat, table.insert 

-- Menu and config entries.
fullbright_item = config:add_item("fullbright", 0)
fullbright_checkbox = menu:add_checkbox("Fullbright", "visuals", "misc", "various", fullbright_item)

-- Cached variables.
local cache = {
    old_fullbright = false
}

-- ConVars.
local cvars = {
    mat_fullbright = cvar:find_var("mat_fullbright")
}

function on_paint()
	if cache.old_fullbright ~= fullbright_item:get_bool() then
		cache.old_fullbright = fullbright_item:get_bool()

		if fullbright_item:get_bool() then
			cvars.mat_fullbright:set_int(1)
		else
			cvars.mat_fullbright:set_int(0)
		end
	end
end

local callbacks = fatality.callbacks
callbacks:add("paint", "on_paint")