-- https://fatality.win/threads/different-hitsound-for-head-and-body-lua.1111/

local engine_client        = csgo.interface_handler:get_engine_client()
local menu                = fatality.menu
local config            = fatality.config

local hs_sound_item = config:add_item("p9_hs_sound", 0)
local body_sound_item = config:add_item("p9_body_sound", 0)

local sounds =
{
    { name = "Bubble", sound = "bubble.wav" },
    { name = "Cod", sound = "cod.wav" },
    { name = "Fatality", sound = "fatality.wav" },
    { name = "Arena switch", sound = "buttons\\arena_switch_press_02" }
}

local hs_sound_ref = menu:add_combo("Headshot hitsound", "VISUALS", "MISC", "Various", hs_sound_item)
local body_sound_ref = menu:add_combo("Body hitsound", "VISUALS", "MISC", "Various", body_sound_item)

for i = 1, #sounds do
    hs_sound_ref:add_item(sounds[i].name, hs_sound_item)
    body_sound_ref:add_item(sounds[i].name, body_sound_item)
end

fatality.callbacks:add("registered_shot", function(e)  
    if(e.hurt) then
        if(e.hit_hitgroup == 1) then
            local sound = sounds[config:get_item("p9_hs_sound"):get_int() + 1].sound
            engine_client:client_cmd("play " .. sound)
        else
            local sound = sounds[config:get_item("p9_body_sound"):get_int() + 1].sound
            engine_client:client_cmd("play " .. sound)
        end
    end  
end)