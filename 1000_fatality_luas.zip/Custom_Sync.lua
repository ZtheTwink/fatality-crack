-- https://fatality.win/threads/customsync-random-custom-fake-amount.2245/

local menu = fatality.menu;
local callbacks = fatality.callbacks;
local custom = {
    56,59,56};
callbacks:add( "paint", customsync );
function customsync( )
    customsync = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount");
    customsync2 = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake amount");
    customsync3 = menu:get_reference( "RAGE", "ANTI-AIM", "Air", "Fake amount");
    for sync=1,2,3 do
        math.randomseed(os.clock()*1000)
        customsync:set_float( math.random( 0, custom[sync] ) );
        customsync2:set_float( math.random( 0, custom[sync] ) );
        customsync3:set_float( math.random( 0, custom[sync] ) );
    end
end