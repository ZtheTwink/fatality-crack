-- https://fatality.win/threads/gamesense-tag-like-real-one.4319/

require "clantag_api"

local timing_switch = 60
local cur_mode = 0
local timing = timing_switch

local clantag_timing = {
    [1]  = function() return "           " end,
    [2]  = function() return "          g" end,
    [3]  = function() return "        gam" end,
    [4]  = function() return "       game" end,
    [5]  = function() return "      games" end,
    [6]  = function() return "     gamese" end,
    [7]  = function() return "    gamesen" end,
    [8]  = function() return "   gamesens" end,
    [9]  = function() return " gamesense " end,
    [10] = function() return " gamesense " end,
    [11] = function() return " gamesense " end,
    [12] = function() return " gamesense " end,
    [13] = function() return " gamesense " end,
    [14] = function() return " gamesense " end,
    [15] = function() return " gamesense " end,
    [16] = function() return " gamesense " end,
    [17] = function() return " gamesense " end,
    [18] = function() return " gamesense " end,
    [19] = function() return " gamesense " end,
    [20] = function() return " gamesense " end,
    [21] = function() return " gamesense " end,
    [22] = function() return " gamesense " end,
    [23] = function() return " gamesense " end,
    [24] = function() return " gamesense " end,
    [25] = function() return "amesense   " end,
    [26] = function() return "mesense    " end,
    [27] = function() return "esense     " end,
    [28] = function() return "sense      " end,
    [29] = function() return "ense       " end,
    [30] = function() return "nse        " end,
    [31] = function() return "se         " end,
