-- viewmodel changer by eslipe v.1

-- interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar()


-- menu features
local x_value_item = config:add_item("viemodelX", 0)
local x_slider = menu:add_slider("viemodel X", "visuals", "misc", "local", x_value_item, -3 , 3, 1)
local y_value_item = config:add_item("viewmodelY", 0)
local y_slider = menu:add_slider("viemodel Y", "visuals", "misc", "local", y_value_item, -3, 3, 1 )
local z_value_item = config:add_item("viewmodelZ", 0)
local z_slider = menu:add_slider("viemodel Z", "visuals", "misc", "local", z_value_item, -3, 3, 1 )



-- convar variables
local cvar = {

    viewmodel_x = cvar:find_var("viewmodel_offset_x"),
    viewmodel_y = cvar:find_var("viewmodel_offset_y"),
    viewmodel_z = cvar:find_var("viewmodel_offset_z")

}



-- sets value from menu to viewmodel cvar
function on_paint()
 
    local getslidervalue_x = x_value_item:get_int() * 1
    local getslidervalue_y = y_value_item:get_int() * 1
    local getslidervalue_z = z_value_item:get_int() * 1

    cvar.viewmodel_x:set_int(getslidervalue_x)
    cvar.viewmodel_y:set_int(getslidervalue_y)
    cvar.viewmodel_z:set_int(getslidervalue_z)

end



-- callback
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)

-- end of the code