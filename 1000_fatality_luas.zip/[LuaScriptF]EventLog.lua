-- Animated event-log by eslipe v.1.5 (current version of 10.03.2019)
 
--[[ Updatelog:
 
(10.03.2019)
- Added final version of colour-picker
- Added access to enable/disable additional console logs
- Added customizable fonts
- Added smooth transition
- Added editable watermark in logs
- Compiled all themes in one combo-box ( Now easier to use )
- Change the code ( Now more readable )
- Now script automatically disables fatality's event-log
- Fixed bug with "fatality" theme
- Changed acceptable value of "Custom X" & "Custom Y" functions
- Removed "Background" function
- Removed old colour-picker


(20.02.2019)
Fixed critical error


(17.02.2019)
Added fatality mode ( fatality theme for event-log )
Added coloured logs to the console log (green == hit, red == accuracy problem, blue == resolver problem)
Renamed some stuff to make logs more understandable
Added smooth transition of transparency for the text
Removed indicator width, because it was uncontrolable
 

(17.02.2019)
Added RGB colour changer
Background now is customizable
Changed fonts to make them look better
Alpha is changing itself at the start and at the end of animation
 
 
(16.02.2019)
Fixed amination bug
Added indicator of miss due to resolver
Added developer 0/1 control function
 
 
(16.02.2019)
Release
 
 
]]
 
 
 
-- interfaces
local cvar = csgo.interface_handler:get_cvar( )
local render = fatality.render
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
 
-- config & menu access
local menu = fatality.menu
local config = fatality.config 
 
-- adding checboxes & slider in menu to customize the script --
local advanced_logs_item = config:add_item( "advanced_logs_item", 1 )
local advanced_logs_checkbox = menu:add_checkbox( "Advanced event-log", "visuals", "esp", "world", advanced_logs_item )
----
local addSetts_item = config:add_item("al_addSetts_item", 1)
local addSetts_combo = menu:add_combo("Watermark in logs", "visuals", "esp", "world", addSetts_item)
addSetts_combo:add_item("Disabled", font_item)
addSetts_combo:add_item("Enabled", font_item)
----
local font_item = config:add_item("al_font_item", 0)
local font_combo = menu:add_combo("Choose the font:", "visuals", "esp", "world", font_item)
font_combo:add_item("Smallest Pixel-7", font_item)
font_combo:add_item("Small Fonts", font_item)
----
local colGrabber_item = config:add_item("al_colGrabber_item", 2)
local colGrabber_combo = menu:add_combo("Grab colour from:", "visuals", "esp", "world", colGrabber_item)
colGrabber_combo:add_item("Colour-picker", colGrabber_item)
colGrabber_combo:add_item("Chroma theme", colGrabber_item)
colGrabber_combo:add_item("Fatality theme", colGrabber_item)
----
local colour_item = config:add_item( "al_colour_item", 0 )
local colour_slider = menu:add_slider( "Logs colour-picker", "visuals", "esp", "world", colour_item, 0, 20, 1 )
----
local customX_item = config:add_item( "customX_item", 0 )
local customX_slider = menu:add_slider( "Custom X", "visuals", "esp", "world", customX_item, 0, 10, 1 )
local customY_item = config:add_item( "customY_item", 5 )
local customY_slider = menu:add_slider( "Custom Y", "visuals", "esp", "world", customY_item, 0, 15, 1 )
----
local additionalLogs_item = config:add_item( "al_additionalLogs_item", 1 )
local additionalLogs_checkbox = menu:add_checkbox( "Additional console-log", "visuals", "esp", "world", additionalLogs_item )
-- adding checboxes & slider in menu to customize the script -- 

-- deactivating fatality's event log and console log
local eventLog = menu:get_reference( "visuals", "misc", "various", "Hurt log" )
local addEventLog = menu:get_reference( "visuals", "misc", "various", "Additional info" )
eventLog:set_bool(false)
addEventLog:set_bool(false)

-- adding developer cvar to set it to 0 in future
local developer = cvar:find_var("developer")
 
-- setting cvar to 0
developer:set_int(0)
 
-- creating logs variable to place the logs there
local logs = {}
 
-- creating function to take logs from on shot function
function add_log(text)
    table.insert(logs, {text = text, expiration = 5, fadein = 0})
end
 
-- needed variables
local sPixel7 = render:create_font( "Smallest Pixel-7", 11, 100, false );
local sFontsClassic = render:create_font( "Small Fonts", 12, 400, false );
local screensize = render:screen_size();

 
 
-- on pain function
function on_paint()
 
    -- variables to be able to use chroma colour change
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
 
    -- changes float value to the int value
    local colourValue_value = colour_item:get_float( ) * 1
    local customX_value = customX_item:get_float() * 1
    local customY_value = customY_item:get_float() * 1
 
 
    -- event log
    for i = 1, #logs do
 
        -- nil check
        if (logs[i] ~= nil) then
 
            -- variable of ratio
            local ratio = 1
 
            -- setting the time of animation
            if (logs[i].expiration <= 1) then
                ratio = (logs[i].expiration) / 1
            end

            -- smooth fade in
            local step = 255 / 0.9 * global_vars.frametime
            if logs[i].expiration >= 4 then
            logs[i].fadein = 0
            else
                logs[i].fadein = logs[i].fadein + step
            end

            -- maximum value of alpha
            if logs[i].fadein > 244 then
                logs[i].fadein = 255
            end

            -- colour changer (final version)
            if colourValue_value == 0 then
                colour = csgo.color(255, 255, 255, math.floor(logs[i].fadein)) --< white
                elseif colourValue_value == 1 then
                colour = csgo.color(0, 0, 0, math.floor(logs[i].fadein)) --< black
                elseif colourValue_value == 2 then
                colour = csgo.color(255, 0, 0, math.floor(logs[i].fadein)) --< deep-red
                elseif colourValue_value == 3 then
                colour = csgo.color(244,67,54, math.floor(logs[i].fadein)) --< red
                elseif colourValue_value == 4 then
                colour = csgo.color(255,87,34, math.floor(logs[i].fadein)) --< light-red
                elseif colourValue_value == 5 then
                colour = csgo.color(255,152,0, math.floor(logs[i].fadein)) --< deep-orange
                elseif colourValue_value == 6 then
                colour = csgo.color(255,193,7, math.floor(logs[i].fadein)) --< orange
                elseif colourValue_value == 7 then
                colour = csgo.color(255,235,59, math.floor(logs[i].fadein)) --< yellow
                elseif colourValue_value == 8 then
                colour = csgo.color(205,220,57, math.floor(logs[i].fadein)) --< lime
                elseif colourValue_value == 9 then
                colour = csgo.color(139,195,74, math.floor(logs[i].fadein)) --< light-green
                elseif colourValue_value == 10 then
                colour = csgo.color(76,175,80, math.floor(logs[i].fadein)) --< green
                elseif colourValue_value == 11 then
                colour = csgo.color(0,150,136, math.floor(logs[i].fadein)) --< teal
                elseif colourValue_value == 12 then
                colour = csgo.color(0,188,212, math.floor(logs[i].fadein)) --< cyan
                elseif colourValue_value == 13 then
                colour = csgo.color(3,169,244, math.floor(logs[i].fadein)) --< ligh-blue
                elseif colourValue_value == 14 then
                colour = csgo.color(33,150,243, math.floor(logs[i].fadein)) --< blue
                elseif colourValue_value == 15 then
                colour = csgo.color(63,81,181, math.floor(logs[i].fadein)) --< indigo
                elseif colourValue_value == 16 then
                colour = csgo.color(103,58,183, math.floor(logs[i].fadein)) --< deep-purple
                elseif colourValue_value == 17 then
                colour = csgo.color(156,39,176, math.floor(logs[i].fadein)) --< purple
                elseif colourValue_value == 18 then
                colour = csgo.color(126,87,194, math.floor(logs[i].fadein)) --< -light-purple
                elseif colourValue_value == 19 then
                colour = csgo.color(233,30,99, math.floor(logs[i].fadein)) --< deep-pink
                elseif colourValue_value == 20 then
                colour = csgo.color(236,64,122, math.floor(logs[i].fadein)) --< light-pink
                else
                colour = csgo.color(255, 255, 255, math.floor(logs[i].fadein)) --< default
            end
 
                -- [ RGB ON ] --
                if colGrabber_item:get_int() == 0 then
 
                    -- background
                    render:rect_filled( customX_value + 0 - ((1 - ratio) * 300), customY_value +  12 * (i - 1) * 2 - 5, 395, 24, colour)
                    render:rect_filled( customX_value + 0 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 - 5, 380, 24, csgo.color(12,12,12,math.floor(logs[i].fadein)))
                
                    -- text
                    render:text(sPixel7, customX_value + 5 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  "[ fatality ] -", colour)
                    render:text(sPixel7, customX_value + 72 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  logs[i].text, csgo.color(255,255,255,math.floor(logs[i].fadein)))
        
                -- [ RGB OFF ] --   


                -- [ CHROMA MODE ON ] --
                elseif colGrabber_item:get_int() == 1 then
 
                    -- background ( rainbow )
                    render:rect_filled( customX_value + 0 - ((1 - ratio) * 300), customY_value + 12 * (i - 1) * 2 - 5, 395, 24, csgo.color(r, g, b,math.floor(logs[i].fadein)))
                    render:rect_filled( customX_value + 0 - ((1 - ratio) * 600),  customY_value + 12 * (i - 1) * 2 - 5, 380, 24, csgo.color(12,12,12,math.floor(logs[i].fadein)))
 
                    -- logs
                    render:text(sPixel7, customX_value + 5 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  "[ fatality ] -", csgo.color(r, g, b,math.floor(logs[i].fadein)))
                    render:text(sPixel7, customX_value + 72 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  logs[i].text, csgo.color(255,255,255,math.floor(logs[i].fadein)))

                -- [ CHROMA MODE OFF ] --
                 

                -- [ FATALITY MODE ON ] -- 
                elseif colGrabber_item:get_int() == 2 then

                    -- background
                    render:rect_filled( customX_value + 0 - ((1 - ratio) * 300), customY_value +  12 * (i - 1) * 2 - 5, 395, 24, csgo.color(255, 21, 73,math.floor(logs[i].fadein)))
                    render:rect_filled( customX_value + 0 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 - 5, 380, 24, csgo.color(33,27,70,math.floor(logs[i].fadein)))

                    -- text
                    if font_item:get_int() == 0 then

                        if addSetts_item:get_int() == 0 then --< Without watermark
                            render:text(sPixel7, customX_value + 10 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  logs[i].text, csgo.color(255,255,255,math.floor(logs[i].fadein)))
                        elseif addSetts_item:get_int() == 1 then --< With watermark
                            render:text(sPixel7, customX_value + 5 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  "[ fatality ] -", csgo.color(255, 21, 73,math.floor(logs[i].fadein)))
                            render:text(sPixel7, customX_value + 72 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  logs[i].text, csgo.color(255,255,255,math.floor(logs[i].fadein)))
                        end

                    elseif font_item:get_int() == 1 then

                        if addSetts_item:get_int() == 0 then --< Without watermark
                            render:text(sFontsClassic, customX_value + 10 - ((1 - ratio) * 600), customY_value - 2 +  12 * (i - 1) * 2 + 3,  logs[i].text:lower(), csgo.color(255,255,255,math.floor(logs[i].fadein)))
                        elseif addSetts_item:get_int() == 1 then --< With watermark
                            render:text(sFontsClassic, customX_value + 5 - ((1 - ratio) * 600), customY_value - 2 +  12 * (i - 1) * 2 + 3,  "[  Fatality  ]   -", csgo.color(255, 21, 73,math.floor(logs[i].fadein)))
                            render:text(sFontsClassic, customX_value + 68 - ((1 - ratio) * 600), customY_value - 2 +  12 * (i - 1) * 2 + 3,  logs[i].text:lower(), csgo.color(255,255,255,math.floor(logs[i].fadein)))
                        end

                    end

                end
                -- [ FATALITY MODE OFF ] -- 
               
            -- removes log if time is expired
            logs[i].expiration = logs[i].expiration - 0.01
            if (logs[i].expiration <= -1) then
                table.remove(logs, i)
            end
 
        end
 
    end
 
end
 
 
 
 
-- on shot function
function on_registered_shot( shot )
 
    -- enabled check
    if not advanced_logs_item:get_bool( ) then
        return
    end
 
    -- creating a variable of the enemy
    local enemy = entity_list:get_player( shot.victim )
 
    -- nil check
    if enemy == nil then
        return
    end
 
    -- getting shot info
    local shot_info_t = shot.shot_info
 
    -- returns the function if something goes wrong
    if not shot_info_t.has_info then
        return
    end
 
    -- creating a variable of default hitgroup
    local hitgroup=0
 
    -- if we did a hit
    if shot.hurt then
 
        -- putting all hitgroups in one variable
        hitgroup=shot.hit_hitgroup
 
        -- hitgroup renaming from int to string
        if hitgroup == 1 then
            hitgroup = "head"
            elseif hitgroup == 2 then
            hitgroup = "chest"
            elseif hitgroup == 3 then
            hitgroup = "stomach"
            elseif hitgroup == 4 then
            hitgroup = "hand"
            elseif hitgroup == 5 then
            hitgroup = "arm"
            elseif hitgroup == 6 then
            hitgroup = "leg"
            elseif hitgroup == 7 then
            hitgroup = "leg"
            elseif hitgroup == 8 then
            hitgroup = "neck"
            else
            hitgroup = "unknown"
        end
 
         -- if the cheat did a hit, then render this line
        add_log("hit to the player " .. enemy:get_name( ) .. " in " .. hitgroup .. " for " .. shot.hit_damage .. " damage")
 
        -- creating variables to add them to the console
        local log_prefix = "[ FATALITY ] "
        local name_info = "hit player " .. enemy:get_name( ):lower() .. " in"
        local hitgroup_info = " " .. hitgroup:lower() .. " "
        local for_text = "for "
        local damage_info = shot.hit_damage
        local damage_postfix = " damage\n"
 
        if additionalLogs_item:get_bool() then
        -- adding those variables to the console-log
        cvar:print_console( log_prefix, csgo.color(120,255,70,255) )
        cvar:print_console( name_info, csgo.color(255,255,255,255) )
        cvar:print_console( hitgroup_info, csgo.color(120,255,70,255) )
        cvar:print_console( for_text, csgo.color(255,255,255,255) )
        cvar:print_console( damage_info, csgo.color(120,255,70,255) )
        cvar:print_console( damage_postfix, csgo.color(255,255,255,255) )
        end
 
    -- if the cheat did a miss because of the resolver problem  
    elseif not shot.hurt and shot.hit then
       
        -- log that shows if cheat did a miss due to resolver
        add_log("missed shot due to resolver")
 
        -- creating variables to add them to the console
        local resolver_log_prefix = "[ FATALITY ] "
        local resolver_name_info = "missed shot, "
        local resolver_reason_prefix = "reason "
        local resolver_reason_text = "resolver\n"
 
        if additionalLogs_item:get_bool() then
        -- adding those variables to the console-log
        cvar:print_console( resolver_log_prefix, csgo.color(0,0,255,255) )
        cvar:print_console( resolver_name_info, csgo.color(255,255,255,255) )
        cvar:print_console( resolver_reason_prefix, csgo.color(255,255,255,255) )
        cvar:print_console( resolver_reason_text, csgo.color(0,0,255,255) )
        end
       
    -- if we did a miss because of the bad accuracy  
    else
        -- log that shows if we did a miss
        add_log("missed shot due to spread")
 
          -- creating variables to add them to the console
          local accuracy_log_prefix = "[ FATALITY ] "
          local accuracy_name_info = "missed shot, "
          local accuracy_reason_prefix = "reason "
          local accuracy_reason_text = "accuracy\n"
 
          if additionalLogs_item:get_bool() then
          -- adding those variables to the console-log
          cvar:print_console( accuracy_log_prefix, csgo.color(255,0,0,255) )
          cvar:print_console( accuracy_name_info, csgo.color(255,255,255,255) )
          cvar:print_console( accuracy_reason_prefix, csgo.color(255,255,255,255) )
          cvar:print_console( accuracy_reason_text, csgo.color(255,0,0,255) )  
          end
 
    end
 
end
 
 
 
-- callbacks
local callbacks = fatality.callbacks
callbacks:add( "registered_shot", on_registered_shot )
callbacks:add( "paint", on_paint )
 
-- end of the code