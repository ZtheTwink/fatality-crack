local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local entity_list = csgo.interface_handler:get_entity_list()
local global_vars = csgo.interface_handler:get_global_vars()
local screen_size = render:screen_size()
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )

local hitchance = menu:get_reference("RAGE", "AIMBOT", "Misc", "ZEUS hitchance")

local cfg_ground = config:add_item( "walking_zeus", 0.0 )
local cfg_air = config:add_item( "air_zeus", 0.0 )
local wave_check = config:add_item( "wave_check", 0.0 )

local tickcount = 0
local lastground = false
local local_player
local duke = menu:add_checkbox( "Zeus Hitchance", "RAGE", "AIMBOT", "MISC", wave_check)
local ground = menu:add_slider( "Ground Hitchance", "RAGE", "AIMBOT", "MISC", cfg_ground, 0, 100, 0 )
local air = menu:add_slider( "Jumping Hitchance", "RAGE", "AIMBOT", "MISC", cfg_air, 0, 100, 0 )
local ZeusIndicator_Item = config:add_item( "ZEUS_INDICATOR", 0.0 )
local ZeusIndicator_Checkbox = menu:add_checkbox( "Zeus Indicator", "RAGE", "AIMBOT", "MISC", ZeusIndicator_Item )
local height = 0
function on_paint()
  local_player = entity_list:get_localplayer()
  if (local_player ~= nil and local_player:is_alive()) then	
		local velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
		if (wave_check:get_bool()) then
			local onground = velocity.z == 0
			if not onground then
				tickcount = global_vars.curtime + .25;
				hitchance:set_int(cfg_air:get_int())
			end
			if onground then
				if global_vars.curtime > tickcount  then
					hitchance:set_int(cfg_ground:get_int())
				else
					hitchance:set_int(cfg_air:get_int())
				end
			end
		end
	end
			    if not engine_client:is_in_game( ) then
       return end
	   
    if not local_player:is_alive( ) then
        return end
      
    local get_screen_size = render:screen_size( )
    local get_velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
    local get_is_onground = get_velocity.z == 0
    local get_is_space = 0x20
    local was_in_air = false
  
    if height>75 then
        height = 75
    end

    if ZeusIndicator_Item:get_bool( ) then
        if not get_is_onground then
            tickcount = global_vars.realtime + .25
            render:indicator( 10, get_screen_size.y/1.74, "In Air", true, -1 )
            height = 0
			hitchance:set_int(cfg_air:get_int())
        else
            if global_vars.realtime > tickcount then
                render:indicator( 10, get_screen_size.y/1.74, "On Ground", false, -1 )
                height = 0
                was_in_air = false 
				hitchance:set_int(cfg_ground:get_int())
            else
                render:indicator( 10, get_screen_size.y/1.769, "Linger", true, -1 ) 
                render:rect_fade( 11, get_screen_size.y/1.69, 75, 4, csgo.color( 0, 0, 0, 150 ), csgo.color( 0, 0, 0, 150 ), false )
                render:rect_fade( 11, get_screen_size.y/1.69, height, 3, csgo.color( 131, 181, 0, 255 ), csgo.color( 0, 0, 0, 150 ), false )
                height = height + (1.69 * 1.25)
				hitchance:set_int(cfg_air:get_int())
            end
		end

	end		
end

local callbacks = fatality.callbacks

callbacks:add( "paint", on_paint )