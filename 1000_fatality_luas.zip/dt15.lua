local callbacks = fatality.callbacks
local config = fatality.config
local autosniper_doubletap = config:get_weapon_setting("autosniper", "double_tap_speed")
local cvar = csgo.interface_handler:get_cvar()
local clock_cor = cvar:find_var("cl_clock_correction")

function on_paint() 
    autosniper_doubletap:set_int(15)
	clock_cor::set_int(0)
end

callbacks:add("paint", on_paint)