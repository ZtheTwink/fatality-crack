-- Custom hitmarker by eslipe v.1.2 (Current version of: 06.03.2019)

--[[ Updatelog:

(06.03.2019)
- Imporved UI (Now easier to use)
- Removed old colour-picker
- Removed customizable opacity of 2d-himarker
- Added final version of colour-picker
- Added new types of animation
- Fixed bugs in the code


(14.02.2019)
- Improved UI
- Added animations for  hitmarker
- Added chroma mode
- Fixed some bugs in the code

(14.02.2019)
- Release

]]



-- getting needed variables
local render = fatality.render --< to render text effects
local callbacks = fatality.callbacks --< to be albe to make callbacks
local menu = fatality.menu --< to get access to the menu
local config = fatality.config --< to get access to the configs

-- getting all interfaces
local engine_client = csgo.interface_handler:get_engine_client() --< engine client
local entity_list = csgo.interface_handler:get_entity_list() --< entity list
local global_vars = csgo.interface_handler:get_global_vars() --< global vars
local events = csgo.interface_handler:get_events() --< game events

-- adding checkboxes/sliders to the menu
local hitmarker_item = config:add_item("2Dhm_hitmarker_item", 0)
local hitmarker_checkbox = menu:add_checkbox("Advanced 2D-hitmarker", "visuals", "misc", "various", hitmarker_item)


local colour_item = config:add_item("2Dhm_colour_item", 0)
local colour_slider = menu:add_slider("Hitmarker colour", "visuals", "misc", "various", colour_item, 0 , 20, 1)
local rainbow_item = config:add_item("rainbow_item", 0)
local rainbow_checkbox = menu:add_checkbox("Chroma", "visuals", "misc", "various", rainbow_item)
local animation_item = config:add_item("animation_item", 0)
local animation_checkbox = menu:add_checkbox("Animated", "visuals", "misc", "various", animation_item)

local animationSwitch_item = config:add_item("2Dhm_animationSwitch_item", 0)
local animationSwitch_combo = menu:add_combo( "Animation type", "visuals", "misc", "various", animationSwitch_item):add_item( "- Animation #1", animationSwitch_item):add_item( "- Animation #2", animationSwitch_item):add_item( "- Animation #3", animationSwitch_item)
local delay_item = config:add_item( "delay_item", 1.0 )
local delay_slider = menu:add_slider( "Delay .Ms", "visuals", "misc", "various", delay_item, 0.1, 2.0, 0.1 )

-- needed variables
local alpha = 0
local hurt_time = 0
local pos8 = 0
local pos7 = 0
local pos6 = 0



function on_shot( shot )

    -- getting the victim of the shot
    player = entity_list:get_player( shot.victim )

    -- nil check
    if player == nil then
    return end

    -- if we did a hit, then add realtime to the hurt time variable
    if shot.hurt then
    hurt_time = global_vars.realtime
    end
    
return end      



-- variables for on_pait function
local local_player = entity_list:get_localplayer() --< creating local player variable  
local screen_size = render:screen_size( ); --< getting personal screen size
--

-- rendering hitmarker
function on_paint( )

    -- checbox check
    if hitmarker_item:get_bool() then

        -- rainbow RGB
        local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
        local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
        local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );

        -- changing values from float to int
        local delay = delay_item:get_float() * 1 
        local colour_value = colour_item:get_float( ) * 1

        -- smooth fade out
        local step = 255 / 0.6 * global_vars.frametime
        if hurt_time + delay > global_vars.realtime then
        alpha = 255
        else
        alpha = alpha - step
        end

    
        
        -- delay for animation of first rect
        local step8 = 8 / 0.1 * global_vars.frametime
        if hurt_time + 0.7 > global_vars.realtime then
        pos8 = 8
        else
        pos8 = pos8 - step8
        end

        -- delay for animation of second rect
        local step7 = 7 / 0.1 * global_vars.frametime
        if hurt_time + 0.6 > global_vars.realtime then
        pos7 = 7
        else
        pos7 = pos7 - step7
        end

         -- delay for animation of third rect
         local step6 = 6 / 0.1 * global_vars.frametime
         if hurt_time + 0.5 > global_vars.realtime then
         pos6 = 6
         else
         pos6 = pos6 - step6
         end


         -- colour changer (final version)
        if colour_value == 0 then
            colour_picker = csgo.color(255, 255, 255, math.floor(alpha)) --< white
            elseif colour_value == 1 then
            colour_picker = csgo.color(0, 0, 0, math.floor(alpha)) --< black
            elseif colour_value == 2 then
            colour_picker = csgo.color(255, 0, 0, math.floor(alpha)) --< deep-red
            elseif colour_value == 3 then
            colour_picker = csgo.color(244,67,54, math.floor(alpha)) --< red
            elseif colour_value == 4 then
            colour_picker = csgo.color(255,87,34, math.floor(alpha)) --< light-red
            elseif colour_value == 5 then
            colour_picker = csgo.color(255,152,0, math.floor(alpha)) --< deep-orange
            elseif colour_value == 6 then
            colour_picker = csgo.color(255,193,7, math.floor(alpha)) --< orange
            elseif colour_value == 7 then
            colour_picker = csgo.color(255,235,59, math.floor(alpha)) --< yellow
            elseif colour_value == 8 then
            colour_picker = csgo.color(205,220,57, math.floor(alpha)) --< lime
            elseif colour_value == 9 then
            colour_picker = csgo.color(139,195,74, math.floor(alpha)) --< light-green
            elseif colour_value == 10 then
            colour_picker = csgo.color(76,175,80, math.floor(alpha)) --< green
            elseif colour_value == 11 then
            colour_picker = csgo.color(0,150,136, math.floor(alpha)) --< teal
            elseif colour_value == 12 then
            colour_picker = csgo.color(0,188,212, math.floor(alpha)) --< cyan
            elseif colour_value == 13 then
            colour_picker = csgo.color(3,169,244, math.floor(alpha)) --< ligh-blue
            elseif colour_value == 14 then
            colour_picker = csgo.color(33,150,243, math.floor(alpha)) --< blue
            elseif colour_value == 15 then
            colour_picker = csgo.color(63,81,181, math.floor(alpha)) --< indigo
            elseif colour_value == 16 then
            colour_picker = csgo.color(103,58,183, math.floor(alpha)) --< deep-purple
            elseif colour_value == 17 then
            colour_picker = csgo.color(156,39,176, math.floor(alpha)) --< purple
            elseif colour_value == 18 then
            colour_picker = csgo.color(126,87,194, math.floor(alpha)) --< -light-purple
            elseif colour_value == 19 then
            colour_picker = csgo.color(233,30,99, math.floor(alpha)) --< deep-pink
            elseif colour_value == 20 then
            colour_picker = csgo.color(236,64,122, math.floor(alpha)) --< light-pink
            else
            colour_picker = csgo.color(255, 255, 255, math.floor(alpha)) --< default
        end


        -- alpha check
        if alpha > 0 then

            -- [ RAINBOW MODE ] --
            if rainbow_item:get_bool() then


                -- [ ANIMATED MODE ] --
                if animation_item:get_bool() then

                    if animationSwitch_item:get_int() == 0 then

                        -- [top] left-side
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos6, screen_size.y / 2 - pos6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos7, screen_size.y / 2 - pos7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos8, screen_size.y / 2 - pos8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                        -- [top] right-side
                        render:rect_filled(screen_size.x / 2 + pos6, screen_size.y / 2 - pos6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + pos7, screen_size.y / 2 - pos7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + pos8, screen_size.y / 2 - pos8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    
                        -- [bottom] left-side
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos6, screen_size.y / 2 + pos6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos7, screen_size.y / 2 + pos7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos8, screen_size.y / 2 + pos8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                        -- [bottom] right-side
                        render:rect_filled(screen_size.x / 2 + pos6, screen_size.y / 2 + pos6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + pos7, screen_size.y / 2 + pos7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + pos8, screen_size.y / 2 + pos8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        -- [ ANIMATED MODE ] --     

                        
                        elseif animationSwitch_item:get_int() == 1 then

                        -- [top] left-side
                        render:rect_filled(screen_size.x / 2 + 0.5 + 6, screen_size.y / 2 - pos6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + 0.5 + 7, screen_size.y / 2 - 7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos8, screen_size.y / 2 - pos8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                        -- [top] right-side
                        render:rect_filled(screen_size.x / 2 - 6, screen_size.y / 2 - pos6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - 7, screen_size.y / 2 - 7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - pos8, screen_size.y / 2 - pos8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    
                        -- [bottom] left-side
                        render:rect_filled(screen_size.x / 2 + 0.5 + 6, screen_size.y / 2 + pos6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + 0.5 + 7, screen_size.y / 2 + 7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos8, screen_size.y / 2 + pos8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                        -- [bottom] right-side
                        render:rect_filled(screen_size.x / 2 - 6, screen_size.y / 2 + pos6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - 7, screen_size.y / 2 + 7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - pos8, screen_size.y / 2 + pos8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                
                        elseif animationSwitch_item:get_int() == 2 then

                        -- [top] left-side
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos6, screen_size.y / 2 - 8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + 0.5 + 7, screen_size.y / 2 - pos7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos8, screen_size.y / 2 - 6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                        -- [top] right-side
                        render:rect_filled(screen_size.x / 2 - pos6, screen_size.y / 2 - 8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - 7, screen_size.y / 2 - pos7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - pos8, screen_size.y / 2 - 6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    
                        -- [bottom] left-side
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos6, screen_size.y / 2 + 8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + 0.5 + 7, screen_size.y / 2 + pos7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos8, screen_size.y / 2 + 6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                        -- [bottom] right-side
                        render:rect_filled(screen_size.x / 2 - pos6, screen_size.y / 2 + 8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - 7, screen_size.y / 2 + pos7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        render:rect_filled(screen_size.x / 2 - pos8, screen_size.y / 2 + 6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                        -- [ ANIMATED MODE ] --     

                        end  



                    -- [ ORDINARY MODE ] --
                else
                    -- [top] left-side
                    render:rect_filled(screen_size.x / 2 - 0.5 - 5, screen_size.y / 2 - 5, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 - 0.5 - 6, screen_size.y / 2 - 6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 - 0.5 - 7, screen_size.y / 2 - 7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 - 0.5 - 8, screen_size.y / 2 - 8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                    -- [top] right-side
                    render:rect_filled(screen_size.x / 2 + 5, screen_size.y / 2 - 5, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 + 6, screen_size.y / 2 - 6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 + 7, screen_size.y / 2 - 7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 + 8, screen_size.y / 2 - 8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                    -- [bottom] left-side
                    render:rect_filled(screen_size.x / 2 - 0.5 - 5, screen_size.y / 2 + 5, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 - 0.5 - 6, screen_size.y / 2 + 6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 - 0.5 - 7, screen_size.y / 2 + 7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 - 0.5 - 8, screen_size.y / 2 + 8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));

                    -- [bottom] right-side
                    render:rect_filled(screen_size.x / 2 + 5, screen_size.y / 2 + 5, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 + 6, screen_size.y / 2 + 6, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 + 7, screen_size.y / 2 + 7, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    render:rect_filled(screen_size.x / 2 + 8, screen_size.y / 2 + 8, 2, 2, csgo.color( r, g, b, math.floor(alpha)));
                    -- [ ORDINARY MODE ] --

                end



            -- [ STATIC COLOUR MODE ] --
            else   
                    -- [ ANIMATED MODE ] --
                    if animation_item:get_bool() then

                        if animationSwitch_item:get_int() == 0 then

                        -- [top] left-side
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos6, screen_size.y / 2 - pos6, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos7, screen_size.y / 2 - pos7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos8, screen_size.y / 2 - pos8, 2, 2, colour_picker);

                        -- [top] right-side
                        render:rect_filled(screen_size.x / 2 + pos6, screen_size.y / 2 - pos6, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + pos7, screen_size.y / 2 - pos7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + pos8, screen_size.y / 2 - pos8, 2, 2, colour_picker);
                    
                        -- [bottom] left-side
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos6, screen_size.y / 2 + pos6, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos7, screen_size.y / 2 + pos7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - 0.5 - pos8, screen_size.y / 2 + pos8, 2, 2, colour_picker);

                        -- [bottom] right-side
                        render:rect_filled(screen_size.x / 2 + pos6, screen_size.y / 2 + pos6, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + pos7, screen_size.y / 2 + pos7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + pos8, screen_size.y / 2 + pos8, 2, 2, colour_picker);
                        -- [ ANIMATED MODE ] --     


                        elseif animationSwitch_item:get_int() == 1 then

                        -- [top] left-side
                        render:rect_filled(screen_size.x / 2 + 0.5 + 6, screen_size.y / 2 - pos6, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + 0.5 + 7, screen_size.y / 2 - 7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos8, screen_size.y / 2 - pos8, 2, 2, colour_picker);

                        -- [top] right-side
                        render:rect_filled(screen_size.x / 2 - 6, screen_size.y / 2 - pos6, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - 7, screen_size.y / 2 - 7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - pos8, screen_size.y / 2 - pos8, 2, 2, colour_picker);
                    
                        -- [bottom] left-side
                        render:rect_filled(screen_size.x / 2 + 0.5 + 6, screen_size.y / 2 + pos6, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + 0.5 + 7, screen_size.y / 2 + 7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos8, screen_size.y / 2 + pos8, 2, 2, colour_picker);

                        -- [bottom] right-side
                        render:rect_filled(screen_size.x / 2 - 6, screen_size.y / 2 + pos6, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - 7, screen_size.y / 2 + 7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - pos8, screen_size.y / 2 + pos8, 2, 2, colour_picker);



                        elseif animationSwitch_item:get_int() == 2 then

                        -- [top] left-side
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos6, screen_size.y / 2 - 8, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + 0.5 + 7, screen_size.y / 2 - pos7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos8, screen_size.y / 2 - 6, 2, 2, colour_picker);

                        -- [top] right-side
                        render:rect_filled(screen_size.x / 2 - pos6, screen_size.y / 2 - 8, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - 7, screen_size.y / 2 - pos7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - pos8, screen_size.y / 2 - 6, 2, 2, colour_picker);
                    
                        -- [bottom] left-side
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos6, screen_size.y / 2 + 8, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + 0.5 + 7, screen_size.y / 2 + pos7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 + 0.5 + pos8, screen_size.y / 2 + 6, 2, 2, colour_picker);

                        -- [bottom] right-side
                        render:rect_filled(screen_size.x / 2 - pos6, screen_size.y / 2 + 8, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - 7, screen_size.y / 2 + pos7, 2, 2, colour_picker);
                        render:rect_filled(screen_size.x / 2 - pos8, screen_size.y / 2 + 6, 2, 2, colour_picker);
                        -- [ ANIMATED MODE ] --     

                        end


                    -- [ ORDINARY MODE ] --
                    else
                    -- [top] left-side
                    render:rect_filled(screen_size.x / 2 - 0.5 - 5, screen_size.y / 2 - 5, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 - 0.5 - 6, screen_size.y / 2 - 6, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 - 0.5 - 7, screen_size.y / 2 - 7, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 - 0.5 - 8, screen_size.y / 2 - 8, 2, 2, colour_picker);

                    -- [top] right-side
                    render:rect_filled(screen_size.x / 2 + 5, screen_size.y / 2 - 5, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 + 6, screen_size.y / 2 - 6, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 + 7, screen_size.y / 2 - 7, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 + 8, screen_size.y / 2 - 8, 2, 2, colour_picker);
                
                    -- [bottom] left-side
                    render:rect_filled(screen_size.x / 2 - 0.5 - 5, screen_size.y / 2 + 5, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 - 0.5 - 6, screen_size.y / 2 + 6, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 - 0.5 - 7, screen_size.y / 2 + 7, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 - 0.5 - 8, screen_size.y / 2 + 8, 2, 2, colour_picker);

                    -- [bottom] right-side
                    render:rect_filled(screen_size.x / 2 + 5, screen_size.y / 2 + 5, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 + 6, screen_size.y / 2 + 6, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 + 7, screen_size.y / 2 + 7, 2, 2, colour_picker);
                    render:rect_filled(screen_size.x / 2 + 8, screen_size.y / 2 + 8, 2, 2, colour_picker);
                    -- [ ORDINARY MODE ] --

                    

                    end
                    
            end

        end

    end

end



-- callbacks
callbacks:add( "registered_shot", on_shot )
callbacks:add("paint", on_paint)

-- end of the code