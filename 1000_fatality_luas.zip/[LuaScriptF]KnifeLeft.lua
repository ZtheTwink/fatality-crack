--ALL credits goes to user called "you"
--this was only fixed by johnyy177 so nothing added only fixed
-- Fatality interfaces.
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar()
local entity_list = csgo.interface_handler:get_entity_list( )
local engine_client = csgo.interface_handler:get_engine_client( )
local game_events = csgo.interface_handler:get_events();
-- Menu and config entries.
local knifehands_item = config:add_item("lefthandedknife", 0)
local knifehands_checkbox = menu:add_checkbox("knife in lefthand", "visuals", "misc", "various", knifehands_item)
function get_player_weapon( )
    local local_player = entity_list:get_localplayer( );
    if ( local_player == nil or not local_player:is_alive( ) ) then
        return end
    local player_weapon = entity_list:get_from_handle( local_player:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) );
    return player_weapon and not player_weapon:is_player( ) and player_weapon:get_class_id( );
end
function is_knife( weapon_name )
    knife = { 107, 108 };
    for i=1,#knife do
      if ( knife[i] == weapon_name ) then
         return true;
      end
   end
end
function on_paint()
        if not engine_client:is_in_game( ) then
        return end
        if knifehands_item:get_bool() then
            if ( is_knife( get_player_weapon( ) ) ) then       
            engine_client:client_cmd_unrestricted("cl_righthand 0")
            else
            engine_client:client_cmd_unrestricted("cl_righthand 1")
            end
        end
end
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)