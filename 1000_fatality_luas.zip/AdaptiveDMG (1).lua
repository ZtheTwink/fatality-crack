local globals = csgo.interface_handler:get_global_vars( );

local menu = fatality.menu;
local config = fatality.config;
local input = fatality.input;

local options = config:add_item( "options", 0 );
local options_combo = menu:add_combo( "Min-damage bind option", "Rage", "Aimbot", "Misc", options );
options_combo:add_item( "Hold", options );
options_combo:add_item( "Toggle", options );

local auto_cfg, awp_cfg, pistols_cfg, scout_cfg, heavyp_cfg, other_cfg =
    config:add_item( "auto_cfg", 0 ),
    config:add_item( "awp_cfg", 0 ),
    config:add_item( "pistols_cfg", 0 ),
    config:add_item( "scout_cfg", 0 ),
    config:add_item( "heavyp_cfg", 0 ),
    config:add_item( "other_cfg", 0 );

local auto_menu, awp_menu, pistols_menu, scout_menu, heavyp_menu, other_menu =
       menu:add_slider( "Min-damage bind", "Rage", "Weapons", "Auto", auto_cfg, 0, 100, 0 ),
       menu:add_slider( "Min-damage bind", "Rage", "Weapons", "AWP", awp_cfg, 0, 100, 0 ),
       menu:add_slider( "Min-damage bind", "Rage", "Weapons", "Pistols", pistols_cfg, 0, 100, 0 ),
       menu:add_slider( "Min-damage bind", "Rage", "Weapons", "Scout", scout_cfg, 0, 100, 0 ),
       menu:add_slider( "Min-damage bind", "Rage", "Weapons", "Heavy pistols", heavyp_cfg, 0, 100, 0 ),
       menu:add_slider( "Min-damage bind", "Rage", "Weapons", "Other", other_cfg, 0, 100, 0 );

local backups = {
    auto_mindmg = menu:get_reference( "Rage", "Weapons", "Auto", "Min-damage" ):get_int( );
    awp_mindmg = menu:get_reference( "Rage", "Weapons", "AWP", "Min-damage" ):get_int( );
    pistols_mindmg = menu:get_reference( "Rage", "Weapons", "Pistols", "Min-damage" ):get_int( );
    scout_mindmg = menu:get_reference( "Rage", "Weapons", "Scout", "Min-damage" ):get_int( );
    heavyp_mindmg = menu:get_reference( "Rage", "Weapons", "Heavy pistols", "Min-damage" ):get_int( );
    other_mindmg = menu:get_reference( "Rage", "Weapons", "Other", "Min-damage" ):get_int( );
};

function manage_menu( toggle )
    if ( toggle ) then
        menu:get_reference( "Rage", "Weapons", "Auto", "Min-damage" ):set_int( auto_cfg:get_int( ) );
        menu:get_reference( "Rage", "Weapons", "AWP", "Min-damage" ):set_int( awp_cfg:get_int( ) );
        menu:get_reference( "Rage", "Weapons", "Pistols", "Min-damage" ):set_int( pistols_cfg:get_int( ) );
        menu:get_reference( "Rage", "Weapons", "Scout", "Min-damage" ):set_int( scout_cfg:get_int( ) );
        menu:get_reference( "Rage", "Weapons", "Heavy pistols", "Min-damage" ):set_int( heavyp_cfg:get_int( ) );
        menu:get_reference( "Rage", "Weapons", "Other", "Min-damage" ):set_int( other_cfg:get_int( ) );
    else
        menu:get_reference( "Rage", "Weapons", "Auto", "Min-damage" ):set_int( backups.auto_mindmg );
        menu:get_reference( "Rage", "Weapons", "AWP", "Min-damage" ):set_int( backups.awp_mindmg );
        menu:get_reference( "Rage", "Weapons", "Pistols", "Min-damage" ):set_int( backups.pistols_mindmg );
        menu:get_reference( "Rage", "Weapons", "Scout", "Min-damage" ):set_int( backups.scout_mindmg );
        menu:get_reference( "Rage", "Weapons", "Heavy pistols", "Min-damage" ):set_int( backups.heavyp_mindmg );
        menu:get_reference( "Rage", "Weapons", "Other", "Min-damage" ):set_int( backups.other_mindmg );
    end
end

local key = 0xBF; -- change here
local last_timer = globals.tickcount;

function on_paint( )
    local hold = options:get_int( ) == 0;
    if ( hold ) then
        if ( input:is_key_down( key ) ) then
            manage_menu( true );
        else
            manage_menu( false );
        end
    else
        if ( input:is_key_down( key ) and globals.tickcount - last_timer > 20 ) then
            toggled = not toggled;
            last_timer = globals.tickcount;
        end
        if ( toggled ) then
            manage_menu( true );
        else
            manage_menu( false );
        end
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );