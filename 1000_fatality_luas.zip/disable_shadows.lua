local engine_client = csgo.interface_handler:get_engine_client()
local cvar = csgo.interface_handler:get_cvar()
local config = fatality.config
local menu = fatality.menu

local noshadows1 = cvar:find_var( "r_shadows");
local noshadows2 = cvar:find_var( "cl_csm_static_prop_shadows");
local noshadows3 = cvar:find_var( "cl_csm_shadows");
local noshadows4 = cvar:find_var( "cl_csm_world_shadows");
local noshadows5 = cvar:find_var( "cl_foot_contact_shadows");
local noshadows6 = cvar:find_var( "cl_csm_viewmodel_shadows");
local noshadows7 = cvar:find_var( "cl_csm_rope_shadows");
local noshadows8 = cvar:find_var( "cl_csm_sprite_shadows");

fatality.callbacks:add("paint", function()
    if(not engine_client:is_in_game()) then
        return
    else
        noshadows1:set_int(0)
        noshadows2:set_int(0)
        noshadows3:set_int(0)
        noshadows4:set_int(0)
        noshadows5:set_int(0)
        noshadows6:set_int(0)
        noshadows7:set_int(0)
        noshadows8:set_int(0)
    end
end)