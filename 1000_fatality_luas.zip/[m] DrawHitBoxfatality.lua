-- render
local render = fatality.render

-- interfaces
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )
local global_vars = csgo.interface_handler:get_global_vars( )



function on_shot( shot )

    
    player = entity_list:get_player( shot.victim )

    -- player check
    if player == nil then
    return end


    -- colours
    local col_red = csgo.color( 255, 255, 255, 255 )
    local col_green = csgo.color( 255, 255, 255, 255 )
    local col_blue = csgo.color( 255, 255, 255, 255 )
      
    -- draw hitgroups
    if shot.hurt then
        
        render:draw_hitgroup( player, shot.record.matrix, - 1, 1.5, col_green )
    else
        
        render:draw_hitgroup( player, shot.record.matrix, - 1, 1.5, col_red )
    end
      
end




-- callbacks
local callbacks = fatality.callbacks
callbacks:add( "registered_shot", on_shot )