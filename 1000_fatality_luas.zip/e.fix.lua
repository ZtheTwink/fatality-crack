-- https://fatality.win/threads/e-slide-fix-kinda.5739/

local poop = csgo.interface_handler:get_cvar()
local i = csgo.interface_handler
local shitgine = i:get_engine_client( )
  bind = 0x45
  a = 0x41
  d = 0x44
  s = 0x53
  w = 0x57


cl_sidespeed = poop:find_var("cl_sidespeed")
cl_forwardspeed = poop:find_var("cl_forwardspeed")
cl_backspeed = poop:find_var("cl_backspeed")

function set_speed(new_speed)
    if (cl_sidespeed:get_int() == 450 and new_speed == 450) then
        return
    end
    cl_sidespeed:set_float(new_speed)
    cl_forwardspeed:set_float(new_speed)
    cl_backspeed:set_float(new_speed)
end

function efix()
    local is_down = fatality.input:is_key_down(bind)
    if not (is_down) then
        set_speed(450)
    else
        local final_val = 1
        set_speed(final_val)
        shitgine:client_cmd( "+forward" )
    end
end


fatality.callbacks:add("paint", efix)