-- SET YOUR KEYBIND
-- AND SCROLL ALL THE WAY DOWN AND SET YOUR FAKELAG
-- KEYBIND LIST (USE THE 0x00's)
-- https://docs.microsoft.com/en-us/windows/desktop/inputdev/virtual-key-codes
local switch_key = 0x56 --edit this

--Edited by presumehvh (cherry#5549)
--Original 

--reference
local engine 	                = csgo.interface_handler:get_engine_client()
local callbacks                 = fatality.callbacks
local menu 			            = fatality.menu
local config                    = fatality.config
local input                     = fatality.input
--reference

--config items
local header                    = "ant_on_key_fakelag_"
local standing_fakelag          = config:add_item(header.."standing_fakelag", 2)
local moving_fakelag            = config:add_item(header.."moving_fakelag", 6)
local air_fakelag               = config:add_item(header.."air_fakelag", 8)
--config items

--menu items
local m_standing_fakelag        = menu:add_combo("Standing fake lag", "Rage", "Anti-Aim", "General", standing_fakelag)
local m_moving_fakelag          = menu:add_combo("Moving fake lag", "Rage", "Anti-Aim", "General", moving_fakelag)
local m_air_fakelag             = menu:add_combo("Air fake lag", "Rage", "Anti-Aim", "General", air_fakelag)

local m_ref_standing_fakelag    = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake lag")
local m_ref_moving_fakelag 	    = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake lag")
local m_ref_air_fakelag 	    = menu:get_reference("RAGE", "ANTI-AIM", "Air", "Fake lag")

--CHANGE THESE TO YOUR LIKING
m_standing_fakelag:add_item("Off", standing_fakelag)	
m_standing_fakelag:add_item("Always on", standing_fakelag)
m_standing_fakelag:add_item("On enemy visible", standing_fakelag)
m_standing_fakelag:add_item("While enemy visible", standing_fakelag)

m_moving_fakelag:add_item("Off", moving_fakelag)
m_moving_fakelag:add_item("Always on", moving_fakelag)
m_moving_fakelag:add_item("On enemy visible", moving_fakelag)
m_moving_fakelag:add_item("While enemy visible", moving_fakelag)

m_air_fakelag:add_item("Off", air_fakelag)
m_air_fakelag:add_item("Always on", air_fakelag)
m_air_fakelag:add_item("On enemy visible", air_fakelag)
m_air_fakelag:add_item("While enemy visible", air_fakelag)
--menu items



callbacks:add("paint", function()
    if(engine:is_in_game()) then
	    if input:is_key_down(switch_key) then
			m_ref_standing_fakelag:set_int(0)
			m_ref_moving_fakelag:set_int(0)
			m_ref_air_fakelag:set_int(0)
        else
		    m_ref_standing_fakelag:set_int(standing_fakelag:get_int())
            m_ref_moving_fakelag:set_int(moving_fakelag:get_int())
            m_ref_air_fakelag:set_int(air_fakelag:get_int())
		end
    end
end)