-- https://fatality.win/threads/fake-amount-indicator.4099/

----------------------------------------------------------------------Fake-Amount-By-Jewls----------------------------------------------------------------------
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local global_vars = csgo.interface_handler:get_global_vars( )
local color2 = csgo.color(45,45,45,255)
local colW = csgo.color(255,255,255,255)

local screen_size = render:screen_size()

local fontM = render:create_font( " ", 20, 400, false );

local background_item = config:add_item("bg",0)
local background_checkbox = menu:add_checkbox("Background Toggle","MISC", " ", "Movement", background_item)

local x_item = config:add_item("x coord", 0)
local y_item = config:add_item("y coord", 0)
local x_slider = menu:add_slider("X Coord", "MISC", " ", "Movement", x_item, 3, screen_size.x-153, 1)
local y_slider = menu:add_slider("Y Coord", "MISC", " ", "Movement", y_item, 3, screen_size.y-58, 1)

--local custom_rbg_item = config:add_item("custom rbg toggle",0)
--local custom_rgb_checkbox = menu:add_checkbox("Toggle Custom RGB Slider", "MISC", " ", "Movement", custom_rbg_item)


-------------------------------------------ColorPicker-------------------------------------------
local color_pick_item = config:add_item("color pick", 0)
local color_pick_combo = menu:add_combo("Border Color", "MISC", " ", "Movement", color_pick_item)
color_pick_combo:add_item("No Border",color_pick_item)
color_pick_combo:add_item("Rainbow - Overused",color_pick_item)
color_pick_combo:add_item("White",color_pick_item)
color_pick_combo:add_item("Red",color_pick_item)
color_pick_combo:add_item("Blue",color_pick_item)
color_pick_combo:add_item("Sky Blue",color_pick_item)
color_pick_combo:add_item("Pink",color_pick_item)
color_pick_combo:add_item("Hot Pink",color_pick_item)
color_pick_combo:add_item("Purple",color_pick_item)
color_pick_combo:add_item("Orange",color_pick_item)
color_pick_combo:add_item("Brown - Weirdo",color_pick_item)
color_pick_combo:add_item("Custom",color_pick_item)
------------------------------------------Custom-RBG-Slider------------------------------------------
local custom_r_item = config:add_item("custom r",0)
local custom_g_item = config:add_item("custom g",0)
local custom_b_item = config:add_item("custom b",0)
local custom_r_slider = menu:add_slider("Custom R", "MISC", " ", "Movement", custom_r_item, 0,255, 1)
local custom_r_slider = menu:add_slider("Custom G", "MISC", " ", "Movement", custom_g_item, 0,255, 1)
local custom_r_slider = menu:add_slider("Custom B", "MISC", " ", "Movement", custom_b_item, 0,255, 1)
    
function on_paint()
-------------------------------------RBG-------------------------------------
local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 )

local x = x_item:get_int()
local y = y_item:get_int()

local color = csgo.color(255,255,255,255)

if      color_pick_item:get_float() == 0 then
        color = csgo.color(255,255,255,0) -- no border
    elseif color_pick_item:get_float() == 1 then
        color = csgo.color(r,g,b,255) -- rainbow
    elseif color_pick_item:get_float() == 3 then
        color = csgo.color(255,0,0,255) -- red
    elseif color_pick_item:get_float() == 4 then
        color = csgo.color(0,0,255,255) -- blue
    elseif color_pick_item:get_float() == 5 then
        color = csgo.color(107,215,255,255) -- sky blue
    elseif color_pick_item:get_float() == 6 then
        color = csgo.color(255,192,203,255) -- pink
    elseif color_pick_item:get_float() == 7 then
        color = csgo.color(255,0,193,255) -- hot pink 
    elseif color_pick_item:get_float() == 8 then
        color = csgo.color(128,0,128,255) -- purple
    elseif color_pick_item:get_float() == 9 then
        color = csgo.color(255,141,0,255) -- orange
    elseif color_pick_item:get_float() == 10 then
        color = csgo.color(118,71,0,255) -- brown ew
    elseif color_pick_item:get_float() == 11 then
        color = csgo.color(custom_r_item:get_int(),custom_g_item:get_int(),custom_b_item:get_int(),255) -- custom
end

    --------------Border----------------
    render:rect_filled(x,y-3,150,3,color)
    render:rect_filled(x,y+55,150,3,color)
    render:rect_filled(x-3,y-3,3,61,color)
    render:rect_filled(x+150,y-3,3,61,color)

    -------------Background---------------
 if background_item:get_bool() then
        render:rect_filled(x,y,150,55,color2)
    end

    --------------Fake-Ref----------------
    local fake_stand = menu:get_reference("RAGE", "ANTI-AIM","Standing", "Fake amount")
    local fake_move = menu:get_reference("RAGE", "ANTI-AIM","Moving", "Fake amount")
    local fake_air = menu:get_reference("RAGE", "ANTI-AIM","Air", "Fake amount")

    --------------------Fake-Write----------------------
    render:text(fontM, x+75, y+2,fake_stand:get_int(), colW)
    render:text(fontM, x+5, y+2,"Standing", colW)
    render:text(fontM, x+70, y+17,fake_move:get_int(), colW)
    render:text(fontM, x+5, y+17,"Moving", colW)
    render:text(fontM, x+55, y+32,fake_air:get_int(), colW)
    render:text(fontM, x+4, y+32,"In Air", colW)
end


local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )