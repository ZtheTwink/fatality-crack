-- More Advanced Fake Direction Lua by johnyy177
--[24.8.2019] - fixed lua for latest fatality update
--[23.12.2019] - added jitter setting back
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local input = fatality.input

local sides = false

local more_afd_item = config:add_item( "fake_direction_lua", 1.0 )
local more_afd_checkbox = menu:add_checkbox( "More Advanced Fake Direction", "RAGE", "ANTI-AIM", "General", more_afd_item )

local more_afd_slider_item_st = config:add_item( "fake_direction_combo_st_lua", 1.0 )
local more_afd_slider_item_mv = config:add_item( "fake_direction_combo_mv_lua", 1.0 )
local more_afd_slider_item_jp = config:add_item( "fake_direction_combo_jp_lua", 1.0 )

local more_afd_multicombo_item = config:add_item( "more_afd_multicombo_lua", 1.0 )
local more_afd_multicombo_standing = config:add_item( "more_afd_multicombo_lua_st", 1.0 )
local more_afd_multicombo_moving = config:add_item( "more_afd_multicombo_lua_mv", 1.0 )
local more_afd_multicombo_jumping = config:add_item( "more_afd_multicombo_lua_jp", 1.0 )
local more_afd_multicombo = menu:add_multi_combo( "Stand/Move/Air", "RAGE", "ANTI-AIM", "General", more_afd_multicombo_item, 0.0, 100.0, 1.0 )
more_afd_multicombo:add_item( "Standing", more_afd_multicombo_standing )

local more_afd_st_slider = menu:add_slider( "Standing fake amount", "RAGE", "ANTI-AIM", "General", more_afd_slider_item_st, 0.0, 100.0, 1.0 )

more_afd_multicombo:add_item( "Moving", more_afd_multicombo_moving )

local more_afd_mv_slider = menu:add_slider( "Moving fake amount", "RAGE", "ANTI-AIM", "General", more_afd_slider_item_mv, 0.0, 100.0, 1.0 )

more_afd_multicombo:add_item( "Air", more_afd_multicombo_jumping )

local more_afd_jp_slider = menu:add_slider( "Air fake amount", "RAGE", "ANTI-AIM", "General", more_afd_slider_item_jp, 0.0, 100.0, 1.0 )

local more_afd_jitty_item = config:add_item( "fake_direction_lua_jittersetting", 0.0 )
local more_afd_jitty_checkbox = menu:add_checkbox( "Use fake jitter", "RAGE", "ANTI-AIM", "General", more_afd_jitty_item )

local standing_fakeamm = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
local moving_fakeamm = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake amount" )
local jumping_fakeamm = menu:get_reference( "RAGE", "ANTI-AIM", "Air", "Fake amount" )

local left_side_mouse_btn = 0x05 --if you want to change this, use this site : http://asger-p.dk/info/virtualkeycodes.php
local screensize = render:screen_size()

local jitter_switch = false
local jitter_tickcount = 0


function on_paint()
    if not engine_client:is_in_game( ) then
        return end
        
    local local_player = entity_list:get_localplayer( )

    if not local_player:is_alive( ) then
        return end
        
    if input:is_key_pressed( left_side_mouse_btn ) then
        sides = not sides
    end    
            
    if more_afd_jitty_item:get_bool( ) then
        if global_vars.tickcount > ( jitter_tickcount + 2 ) then
            jitter_tickcount = global_vars.tickcount
            jitter_switch = not jitter_switch
        end
    end

    if more_afd_item:get_bool( ) then
        if more_afd_multicombo_standing:get_bool( ) then
            if more_afd_jitty_item:get_bool( ) then
                if sides then
                    if jitter_switch then
                        standing_fakeamm:set_float( more_afd_slider_item_st:get_float( ) )
                    else
                        standing_fakeamm:set_float( -more_afd_slider_item_st:get_float( ) )
                    end    
                else 
                    if jitter_switch then
                        standing_fakeamm:set_float( -more_afd_slider_item_st:get_float( ) )    
                    else
                        standing_fakeamm:set_float( more_afd_slider_item_st:get_float( ) )
                    end    
                end    
                render:indicator( 10, screensize.y/1.85, "FAKE JITTER", false, -1 )
            else
                if sides then
                    standing_fakeamm:set_float( -more_afd_slider_item_st:get_float( ) )
                    render:indicator( 10, screensize.y/1.85, "FAKE LEFT", false, -1 )
                else 
                    standing_fakeamm:set_float( more_afd_slider_item_st:get_float( )  )
                    render:indicator( 10, screensize.y/1.85, "FAKE RIGHT", false, -1 )
                end
            end    
        end
        if more_afd_multicombo_moving:get_bool( ) then
            if more_afd_jitty_item:get_bool( ) then
                if sides then
                    if jitter_switch then
                        moving_fakeamm:set_float( more_afd_slider_item_mv:get_float( ) )
                    else
                        moving_fakeamm:set_float( -more_afd_slider_item_mv:get_float( ) )
                    end
                else 
                    if jitter_switch then
                        moving_fakeamm:set_float( -more_afd_slider_item_mv:get_float( ) )
                    else
                        moving_fakeamm:set_float( more_afd_slider_item_mv:get_float( ) )            
                    end    
                end
                render:indicator( 10, screensize.y/1.85, "FAKE JITTER", false, -1 )
            else
                if sides then
                    moving_fakeamm:set_float( -more_afd_slider_item_mv:get_float( ) )
                    render:indicator( 10, screensize.y/1.85, "FAKE LEFT", false, -1 )
                else 
                    moving_fakeamm:set_float( more_afd_slider_item_mv:get_float( ) )
                    render:indicator( 10, screensize.y/1.85, "FAKE RIGHT", false, -1 )
                end
            end    
        end
        if more_afd_multicombo_jumping:get_bool( ) then
            if more_afd_jitty_item:get_bool( ) then
                if sides then
                    if jitter_switch then
                        jumping_fakeamm:set_float( more_afd_slider_item_jp:get_float( ) )
                    else
                        jumping_fakeamm:set_float( -more_afd_slider_item_jp:get_float( ) )
                    end
                else 
                    if jitter_switch then
                        jumping_fakeamm:set_float( -more_afd_slider_item_jp:get_float( ) )
                    else
                        jumping_fakeamm:set_float( more_afd_slider_item_jp:get_float( ) )            
                    end
                end
                render:indicator( 10, screensize.y/1.85, "FAKE JITTER", false, -1 )
            else    
                if sides then
                    jumping_fakeamm:set_float( -more_afd_slider_item_jp:get_float( ) )
                    render:indicator( 10, screensize.y/1.85, "FAKE LEFT", false, -1 )
                else 
                    jumping_fakeamm:set_float( more_afd_slider_item_jp:get_float( ) )
                    render:indicator( 10, screensize.y/1.85, "FAKE RIGHT", false, -1 )
                end
            end    
        end
    end
end

local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )