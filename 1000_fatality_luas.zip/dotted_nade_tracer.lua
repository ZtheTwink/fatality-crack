--main instances
-- https://fatality.win/threads/visual-dotted-nade-tracer.5262/
local render = fatality.render

local menu = fatality.menu

local config = fatality.config

local callbacks = fatality.callbacks

local input = fatality.input

local fatalMath = fatality.math

local engine_client = csgo.interface_handler:get_engine_client()

local debugOverlay = csgo.interface_handler:get_debug_overlay()

local global_vars = csgo.interface_handler:get_global_vars()

local entity_list = csgo.interface_handler:get_entity_list()

local screen_size = render:screen_size()

local font = render:create_font('', 23, 0, false)

local font2 = render:create_font('', 17, 0, false)

local font3 = render:create_font('', 16, 0, false)

local white = csgo.color(255,255,255,255)

local red = csgo.color(255,0,0,255)

--main instances

local toggle = config:add_item( 'nade tracer toggle', 1 )

local size = config:add_item( 'nade size', 3 )

local dur = config:add_item( 'nade duration', 1 )

local r = config:add_item( 'nade red', 255 )

local g = config:add_item( 'nade green', 255 )

local b = config:add_item( 'nade blue', 255 )

local a = config:add_item( 'nade alpha', 255 )



menu:add_checkbox( 'Nade Tracer', 'visuals', 'misc', 'various', toggle )

menu:add_slider( 'Nade Tracer Size', 'visuals', 'misc', 'various', size, 1, 10, 1 )

menu:add_slider( 'Nade Tracer Duration', 'visuals', 'misc', 'various', dur, 0.1, 5, 0.1 )

menu:add_slider( 'Nade Tracer Red', 'visuals', 'misc', 'various', r, 0, 255, 1 )

menu:add_slider( 'Nade Tracer Green', 'visuals', 'misc', 'various', g, 0, 255, 1 )

menu:add_slider( 'Nade Tracer Blue', 'visuals', 'misc', 'various', b, 0, 255, 1 )

menu:add_slider( 'Nade Tracer Alpha', 'visuals', 'misc', 'various', a, 0, 255, 1 )



function drawNadeTracer(entity)

    if entity ~= nil and ((entity:get_class_id() == 9 or entity:get_class_id() == 48 or entity:get_class_id() == 113 or entity:get_class_id() == 156)) then

        entPos = entity:get_var_vector('CBaseEntity->m_vecOrigin')

        debugOverlay:add_box_overlay(entPos, csgo.vector3(0,0,0), csgo.vector3(size:get_int(),size:get_int(),size:get_int()), csgo.angle(0,0,0), csgo.color(r:get_int(),g:get_int(), b:get_int(), a:get_int()), dur:get_float())

     end

end



function paint()

    for i = 1, entity_list:get_max_entities() do

        entity = entity_list:get_entity(i)

        if toggle:get_bool() then

            drawNadeTracer(entity)

        end

   end

end





callbacks:add( 'paint', paint )