local callbacks = fatality.callbacks
local menu = fatality.menu
local config = fatality.config
local render = fatality.render
local globalVars = csgo.interface_handler:get_global_vars()
local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()
local font = render:create_font( 'smallest pixel-7', 30, 1, true )


glitch = config:add_item( 'glitchBackground', 1 )
local KDR_config = config:add_item("KDRratio", 0);
local KDR_slider = menu:add_slider("KD Ratio", "RAGE","AIMBOT","Aimbot", KDR_config, 0.1,10,0.1);

local int killCount = 0
local int deathCount = 0

local function say(message)
	local message = string.gsub(message, ";", ";")
	engine_client:client_cmd("say " .. message)
end

local function player_connect(e)
	joined_user_userid = e:get_int("userid")
	joined_user = joined_user_userid
	local_userid = entity_list:get_localplayer()
	if(local_userid == joined_user) then
	killCount = 0
	deathCount = 0
	kdrUPDATED = 0
	end
	print("you connected, reset score")
end

local function match_start()
		killCount = 0
	deathCount = 0
	KDRratioUPDATED = 0
	print("match started, reset score")
end

local function player_death(e)

	local victim_userid = e:get_int("userid")
	local attacker_userid = e:get_int("attacker")
	if victim_userid == nil or attacker_userid == nil then
		return
	end

	local local_ent = entity_list:get_localplayer()
	local victim_ent = entity_list:get_player_from_id(victim_userid)
	local attacker_ent = entity_list:get_player_from_id(attacker_userid)

	if local_ent == nil or victim_ent == nil or attacker_ent == nil then
		return
	end
    
	


		if attacker_ent:get_index() == local_ent:get_index() then
		--on kill
			killCount = killCount + 1
			print("added kill")
			print("kills: " .. killCount)
		end


		if victim_ent:get_index() == local_ent:get_index() then
		--on death
			deathCount = deathCount + 1
			print("added death")
			print("deaths: " .. deathCount)
			if(killCount == 0) and (deathCount > 0) then
				say("!rs")
				killCount = 0
				deathCount = 0
				print("reset score")
				return
			end
			if(killCount ~= 0) and (deathCount == 0)then
				return
			end
			if(killCount ~= 0) and (deathCount ~= 0)then
				if((killCount/deathCount) < KDR_config:get_int())  then
					say("!rs")
					killCount = 0
					deathCount = 0
					print("reset score")
					
					return
				end
			end
			
		end
	
end

local pos = csgo.vector2(10,800)

local glitch = {
    glitch = csgo.vector2(10,800),
    realtime = globalVars.realtime,
    bool = true,
    range = 3,
}

function updateGlitch()
    if glitch.realtime + 0.08 > globalVars.realtime then
        if glitch.bool then
            glitch.glitch = csgo.vector2(math.random(pos.x - glitch.range, pos.x + glitch.range), math.random(pos.y - glitch.range, pos.y + glitch.range))
            glitch.bool = false
        end
    else
        glitch.bool = true
        glitch.realtime = globalVars.realtime
    end
end


local int kdrUPDATED = 0

function on_paint()


	if(killCount > 0) and (deathCount > 0) then
		 kdrUPDATED = killCount/deathCount
		 kdrUPDATED = math.floor(kdrUPDATED * 10) / 10

		elseif (deathCount >= 0) and (killCount == 0) then
			kdrUPDATED = 0
		elseif (deathCount == 0) and (killCount > 0) then
			kdrUPDATED = killCount/1
			end
    if not engine_client:is_in_game() or entity_list:get_localplayer() == nil then
        return end
    updateGlitch()
  
	render:text(font, glitch.glitch.x, glitch.glitch.y, "KDR: " .. kdrUPDATED , csgo.color(255, 0, 238, 255))
	render:text(font, pos.x, pos.y, "KDR: " .. kdrUPDATED , csgo.color(255, 255, 255, 255))

end
fatality.callbacks:add('paint', on_paint)


local function on_event(e)

	local event_name = e:get_name()

	
	if event_name == "round_start" then
		-- on_round_start()
	elseif event_name == "player_death" then
		player_death(e)
	elseif event_name == "player_connect_full" then
		player_connect(e)
	elseif event_name == "round_announce_match_start"then
		match_start()
	end
	
end

events:add_event( "round_start" )
events:add_event( "player_death" )
events:add_event( "other_death" )
events:add_event( "round_announce_match_start" )
events:add_event( "player_connect_full" )

callbacks:add( "events", on_event )