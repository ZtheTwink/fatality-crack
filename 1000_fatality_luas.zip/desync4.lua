-- https://fatality.win/threads/updated-ragesu-anti-aim-desync-automated.5127/

-- config

local invert_key = 0x5

-- dependencies

local csgo_globals = csgo.interface_handler:get_global_vars()
function tick() return csgo_globals.tickcount end

local function get_item(index, value)
    local f_value = fatality.config:get_item(index)
    if type(f_value) == "nil" then return fatality.config:add_item(index, value) end

    return f_value
end

local rage_antiaim_fakeamounts = {
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake amount"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake amount"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Air", "Fake amount")
}

local rage_antiaim_faketypes = {
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake type"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake type"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Air", "Fake type")
}

local rage_antiaim_fakelag = {
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Base amount"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Base amount"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Air", "Base amount")
}

local enums = {
    antiaim = {
        sway = 0,
        match = 1,
        lag = 2
    },

    lby_type = {
        none = 0,
        match = 1,
        invert = 2,
        auto = 3
    },

    direction = {
        left = 1,
        right = 2
    },

    doubletap = {
        off = 0,
        on = 1
    }
}

local config_items = {
    enabled = get_item("ragesu_enabled", 0),
    lby_type = get_item("ragesu_lby_type_option", enums.lby_type.invert),
    antiaim = get_item("ragesu_antiaim_option", enums.antiaim.match),
    direction = get_item("ragesu_current_direction", enums.direction.left),
    direction_min = get_item("ragesu_current_direction_minimum", 0),
    direction_max = get_item("ragesu_current_direction_maximum", 100),
    speed = get_item("ragesu_speed", 1),
    doubletap = get_item("ragesu_doubletap", enums.doubletap.off),

    current_fakeamount = get_item("ragesu_current_fakeamount", 100),
    current_match_direction = get_item("ragesu_current_match_direction", enums.direction.left),
    current_lag_values = {
        fakeamount = get_item("ragesu_current_lagsync_fakeamount", 0),
        fakelag = get_item("ragesu_current_lagsync_fakelag", 0)
    }
}

local menu_items = {
    enabled = fatality.menu:add_checkbox("RageSu - Enable", "RAGE", "ANTI-AIM", "General", config_items.enabled),
   
    lby_type = fatality.menu:add_combo("LBY Type", "RAGE", "ANTI-AIM", "General", config_items.lby_type),
    antiaim = fatality.menu:add_combo("Mode", "RAGE", "ANTI-AIM", "General", config_items.antiaim),

    direction_min = fatality.menu:add_slider("Direction Minimum", "RAGE", "ANTI-AIM", "General", config_items.direction_min, 0, 100, config_items.direction_min:get_float()),
    direction_max = fatality.menu:add_slider("Direction Maximum", "RAGE", "ANTI-AIM", "General", config_items.direction_max, 0, 100, config_items.direction_max:get_float()),
    speed = fatality.menu:add_slider("Speed", "RAGE", "ANTI-AIM", "General", config_items.speed, 0, 5, config_items.speed:get_float())
}

menu_items.lby_type:add_item("None", config_items.lby_type)
menu_items.lby_type:add_item("Match", config_items.lby_type)
menu_items.lby_type:add_item("Invert", config_items.lby_type)
menu_items.lby_type:add_item("Auto", config_items.lby_type)

menu_items.antiaim:add_item("Sway", config_items.antiaim)
menu_items.antiaim:add_item("Match", config_items.antiaim)
menu_items.antiaim:add_item("Lag", config_items.antiaim)

-- main

local function clamp(value, minimum, maximum)
    if value > maximum then
        value = maximum
    elseif value < minimum then
        value = minimum
    end

    return value
end

local function abs(value)
    return (0 > value and -(value)) or value
end

local function set_fakeamounts(value)
    for _, fatality_value in pairs(rage_antiaim_fakeamounts) do
        fatality_value:set_int(value)
    end

    config_items.current_fakeamount:set_int(value)
end

local function set_faketype(value)
    for _, fatality_value in pairs(rage_antiaim_faketypes) do
        fatality_value:set_int(value)
    end
end

local function set_fakelag(value)
    for _, fatality_value in pairs(rage_antiaim_fakelag) do
        fatality_value:set_int(value)
    end
end

local function rand(min, max, guarantee, previous)
    local result;
    if min > max then
        result = math.random(max, min)
    else
        result = math.random(min, max)
    end

    if guarantee and result == previous then
        repeat result = rand(min, max, guarantee, previous) until not (result == previous)
    end

    return result
end

local last_tick = tick()
local input_tick = tick()

function on_paint_callback()
    if config_items.enabled:get_bool() == false then return end

    local min_dir, max_dir, current_dir = config_items.direction_min:get_int(), config_items.direction_max:get_int(), config_items.direction:get_int()
    local speed = config_items.speed:get_int()

    local inverted = false
    if tick() - input_tick > 10 then
        input_tick = tick()
       
        if fatality.input:is_key_down(invert_key) then
            inverted = true
            config_items.current_match_direction:set_int((config_items.current_match_direction:get_int() == enums.direction.left and enums.direction.right) or enums.direction.left)
            config_items.direction:set_int(config_items.current_match_direction:get_int())
        end
    end

    if config_items.antiaim:get_int() == enums.antiaim.sway then
        if tick() - last_tick > 0.01 then
            local current_amount = config_items.current_fakeamount:get_int()
            local determined_speed = ((current_dir == enums.direction.left and -speed) or speed)

            -- clamp
            if abs(current_amount) <= abs(min_dir) then
                if current_dir == enums.direction.right then
                    current_amount = abs(min_dir) + 2
                else
                    current_amount = -abs(min_dir) - 2
                end

                current_amount = current_amount + determined_speed
            end
            
            current_amount = current_amount + determined_speed

            -- switch sides
            if abs(current_amount) > max_dir then
                current_dir = (current_dir == enums.direction.left and enums.direction.right) or enums.direction.left               
                config_items.direction:set_int(current_dir)
            end

            set_fakeamounts(clamp(current_amount, -100, 100))

            last_tick = tick()
        end
    elseif config_items.antiaim:get_int() == enums.antiaim.match then
        if tick() - last_tick > 0.01 then
            local current_amount = config_items.current_fakeamount:get_int()
            local determined_speed = ((current_dir == enums.direction.left and -speed) or speed)
            local current_match_dir = config_items.current_match_direction:get_int()
            
            -- clamp
            if abs(current_amount) <= abs(min_dir) or inverted == true then
                if current_match_dir == enums.direction.left then
                    current_amount = -abs(min_dir) - 2
                else
                    current_amount = abs(min_dir) + 2
                end

                current_amount = current_amount + determined_speed
            end

            current_amount = current_amount + determined_speed

            -- switch sides
            if abs(current_amount) > max_dir or abs(current_amount) <= abs(min_dir) then
                current_dir = (current_dir == enums.direction.left and enums.direction.right) or enums.direction.left               
                config_items.direction:set_int(current_dir)
            end

            set_fakeamounts(clamp(current_amount, -100, 100))

            last_tick = tick()
        end
    elseif config_items.antiaim:get_int() == enums.antiaim.lag then
        -- some credits to previous posters, at this point lagsync is universally used in lua's it shouldn't need credits
        -- i tried this out and its pretty bad, i do better with the other two options
        if tick() - last_tick > (5.01 - speed) then
            local fakelag_rand, fakeamount_rand = rand(6, 14, true, config_items.current_lag_values.fakelag:get_int()), rand(-abs(max_dir), abs(max_dir), true, config_items.current_lag_values.fakeamount:get_int())
        
            -- clamp
            while 5 > abs(fakeamount_rand) do
                fakeamount_rand = rand(-abs(max_dir), abs(max_dir), true, config_items.current_lag_values.fakeamount:get_int())
            end

            -- automate fake type
            if fakeamount_rand >= 0 then
                set_faketype(enums.lby_type.invert)
            else
                set_faketype(enums.lby_type.match)
            end

            set_fakeamounts(fakeamount_rand)
            set_fakelag(fakelag_rand)

            -- update config
            config_items.current_lag_values.fakelag:set_int(fakelag_rand)
            config_items.current_lag_values.fakeamount:set_int(fakeamount_rand)

            last_tick = tick()
        end
    end

    set_faketype(config_items.lby_type:get_int())
end

fatality.callbacks:add("paint", on_paint_callback)