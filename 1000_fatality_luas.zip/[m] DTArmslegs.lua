--interfaces
local render = fatality.render;
local menu = fatality.menu
local input = fatality.input
local config = fatality.config
local screensize = render:screen_size();
--func
local WEAPONS_Auto_limbs = menu:get_reference( "RAGE", "WEAPONS", "Auto", "ignore limbs when target moving" )
local keybind_type_item = config:add_item("keybind_type_item", 0)
local key_combo = menu:add_combo("limbs keybind type", "RAGE", "AIMBOT", "Misc", keybind_type_item)
key_combo:add_item("Hold", keybind_type_item)
key_combo:add_item("Toggle", keybind_type_item)

local key = 0x04 --this is M3 change the virtual key code to change bind https://docs.microsoft.com/en-us/windows/desktop/inputdev/virtual-key-codes

--callbacks
fatality.callbacks:add("paint", function()
if keybind_type_item:get_int() == 0 then
if(input:is_key_down(key)) then
render:indicator( 10, screensize.y -120, "LIMBS", true , -1)
WEAPONS_Auto_limbs:set_bool(true)
else
WEAPONS_Auto_limbs:set_bool(false)
end
end
if keybind_type_item:get_int() == 1 then
if(input:is_key_pressed(key)) then
WEAPONS_Auto_limbs:set_bool(not WEAPONS_Auto_limbs:get_bool())
end
end
end)