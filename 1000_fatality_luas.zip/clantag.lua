--Synced clantag changer LUA by johnyy177
--clantag api by ducarii

--inputs
require "clantag_api"
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local input = fatality.input

--menu controls
local clantag_item = config:add_item( "misc_movement_clantag", 0.0 )
local clantag_checkbox = menu:add_checkbox( "Synced clantag changer", "MISC", "", "Movement", clantag_item )
local clantag_speed_item = config:add_item( "misc_movement_clantag_speed", 1.0 )
local clantag_speed_slider = menu:add_slider( "Speed", "MISC", "", "Movement", clantag_speed_item, 0.1, 8.0, 0.1 )

--get screensize
local screensize = render:screen_size( )

--variables
local last_current_time = 0 --this is for clantag sync
local timer = 0 --timer so we can animate our clantag later
local do_once = false --do once boolean for later

--on paint
function on_paint()
    --if you arent in game, return
    --if not engine_client:is_in_game( ) then
    --   return end
        
    --get local player even tho its not needed now
    --local local_player = entity_list:get_localplayer( )
    
    --get cvar
    local clan_id = cvar:find_var( "cl_clanid" )
    
    --if clantag changer is on
    if clantag_item:get_bool( ) then
        
        if math.floor( global_vars.curtime * clantag_speed_item:get_float( ) ) == last_current_time then
            --do nothing
        else
            --start counting
            timer = timer + 1
            last_current_time = math.floor( global_vars.curtime * clantag_speed_item:get_float( ) )
        end
        
        --here you will have to do something like this, you can edit the hackerman thingy to anything you want in any style you want (UPPERCASE, lowercase, etc...)
        if timer == 0 then
            SET_CLANTAG_MADE_BY_DUCARII( "f" )
        elseif timer == 1 then
            SET_CLANTAG_MADE_BY_DUCARII( "fa" )
        elseif timer == 2 then
            SET_CLANTAG_MADE_BY_DUCARII( "fat" )
        elseif timer == 3 then
            SET_CLANTAG_MADE_BY_DUCARII( "fata" )
        elseif timer == 4 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatal" )
        elseif timer == 5 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatali" )
        elseif timer == 6 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatalit" )
        elseif timer == 7 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatality" )
        elseif timer == 8 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatality" )
        elseif timer == 9 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatality" )
        elseif timer == 10 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatality" )
        elseif timer == 11 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatalit" )
        elseif timer == 12 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatali" )
        elseif timer == 13 then
            SET_CLANTAG_MADE_BY_DUCARII( "fatal" )
        elseif timer == 14 then
            SET_CLANTAG_MADE_BY_DUCARII( "fata" )
        elseif timer == 15 then
            SET_CLANTAG_MADE_BY_DUCARII( "fat" )
        elseif timer == 16 then
            SET_CLANTAG_MADE_BY_DUCARII( "fa" )
        elseif timer == 17 then
            SET_CLANTAG_MADE_BY_DUCARII( "f" )
        elseif timer == 18 then
            SET_CLANTAG_MADE_BY_DUCARII( " " )

        end
        
        --then we will take last number from our else if
        --then if timer is bigger than 25, reset it to 0 so our clantag can go again from 0
        if timer > 18 then
            timer = 0
        end
        
        --do once boolean, as i said in the upper part of the code, it will be for restoring our clantag
        do_once = false
    else
        if not do_once then
            SET_CLANTAG_MADE_BY_DUCARII( "fatality" )
            clan_id:set_int( 0 )
            do_once = true
        end
    end
end --end

--callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )