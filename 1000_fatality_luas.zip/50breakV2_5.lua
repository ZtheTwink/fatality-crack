﻿--Yes im new to making luas
--Yes this is messy asf
--Yes some parts are pasted
--Also this is made for my configs
--To change any of the keybinds go to: https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes & find the one you want.

-- shitty locals & there are some useless but i cant be asked to fix them
local input = fatality.input
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks
local global = csgo.interface_handler:get_global_vars( );
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local standDesync = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount')
local stand_yaw, stand_yaw_add = menu:get_reference("Rage", "Anti-aim", "Standing", "Yaw add"),	menu:get_reference("Rage", "Anti-aim", "Standing", "Add")
local fakelag, flmove = menu:get_reference ("rage", "anti-aim", "standing", "base amount"), menu:get_reference("rage", "anti-aim", "moving", "base amount")
local moveDesync = menu:get_reference ("rage", "anti-aim", "moving", "fake amount")
local move_yaw, move_yaw_add = menu:get_reference("Rage", "Anti-aim", "moving", "Yaw add"),	menu:get_reference("Rage", "Anti-aim", "moving", "Add")
local global_vars = csgo.interface_handler:get_global_vars()
local screen_size = render:screen_size( )
local engine = csgo.interface_handler:get_engine_client()
local spinbot = menu:get_reference ("rage", "anti-aim", "standing", "Spin")
local jittering = menu:get_reference ("rage", "anti-aim", "standing", "Jitter")
local standFree = menu:get_reference ("rage", "anti-aim", "standing", "Freestand Fake")
local Freestanding = menu:get_reference ("rage", "anti-aim", "standing", "Freestand")
local flstand = menu:get_reference ("rage", "anti-aim", "standing", "Fake lag")
local faketype = menu:get_reference ("rage", "anti-aim", "standing", "fake type")
local faketypemove = menu:get_reference ("rage", "anti-aim", "moving", "fake type")
local Autism = config:add_item("AA type box", 1)
local AACombo = menu:add_combo("Break Type","misc", "", "Buy Bot", Autism)
local faketypeair = menu:get_reference("rage", "anti-aim", "air", "fake type")
local fakelagair = menu:get_reference("rage", "anti-aim", "air", "base amount")
local headshot = menu:get_reference("rage", "aimbot", "aimbot", "headshot only")
local doubletapstyle = config:get_weapon_setting("autosniper", "double_tap")
local autostopstyle = config:get_weapon_setting("autosniper", "autostop")


-- adds items to the menu
AACombo:add_item("Beste", Autism)
AACombo:add_item("Onetap", Autism)
AACombo:add_item("Skeet & Aimware", Autism)
AACombo:add_item("Autism", Autism)
AACombo:add_item("test", Autism)

-- buttons to change antiaim types easily (i recommend using this method since it might break if you change them from the menu)
local fatal =  0x27 -- right arrow
local onetap = 0x25	--left arrow
local skeet = 0x26 --up arrow
local test = 0x28	--down arrow

-- just so you cant use wrong shit on the lua :D
function on_paint() 
    spinbot:set_bool(false)
    stand_yaw:set_bool(true)
    jittering:set_bool(false)
    standFree:set_bool(false)
    Freestanding:set_bool(false)
    flstand:set_int(1)
	move_yaw:set_bool(true)
	faketypemove:set_int(2)
end
callbacks:add("paint", on_paint)

--changes autostop on doubletap
function on_paint()
	if doubletapstyle:get_int() == 2 then
		autostopstyle:set_int(2)
	elseif doubletapstyle:get_int() == 1 then
		autostopstyle:set_int(2)
	elseif doubletapstyle:get_int() == 0 then
		autostopstyle:set_int(1)
	end
end
callbacks:add("paint", on_paint)


-- extended backtrack toggle on/off
local extendBT = menu:get_reference ( "rage", "aimbot", "aimbot", "Extended backtrack")
local bt = 0x43
local bt2 = 0x5A
function on_paint()
    if input:is_key_down(bt) then
        extendBT:set_bool(true)
    elseif input:is_key_down(bt2) then
        extendBT:set_bool(false)
    end
end
callbacks:add("paint", on_paint)


-- all antiaim settings (make sure that if you change eg: -5 to -2 so you can remove 2 multiple times & to get -80 from -50
standDesync:set_float(0)
local invert = true
function on_paint()
    if Autism:get_int() == 0 then																				--1 (fata)
        faketype:set_int(2)
        if invert then
            if standDesync:get_int() == -80 then
                invert = false
            else
                standDesync:set_float(standDesync:get_float() - 5)
            end
        end
        if not invert then
            if standDesync:get_int() == -50 then
                invert = true
            else
                standDesync:set_float(standDesync:get_float() + 10)
            end
        end
    end
    if Autism:get_int() == 1 then																				--2 (ot)
        faketype:set_int(2)
        if invert then
            if standDesync:get_int() == - 85 then
                invert = false
            else
                standDesync:set_float(standDesync:get_float() - 5)
            end
        end
        if not invert then
            if standDesync:get_int() == - 25 then
                invert = true
            else
                standDesync:set_float(standDesync:get_float() + 15)
            end
        end
    end
    if Autism:get_int() == 2 then																				--3 (skeet)
        faketype:set_int(1)
        if invert then
            if standDesync:get_int() == 100 then
                invert = false
            else
                standDesync:set_float(standDesync:get_float() + 50)
            end
        end
        if not invert then
            if standDesync:get_int() == 50 then
                invert = true
            else
                standDesync:set_float(standDesync:get_float() - 50)
            end
        end
    end
    if Autism:get_int() == 3 then																				--4(random test)
        faketype:set_int(2)
        if invert then
            if standDesync:get_int() == - 80 then
                invert = false
            else
                standDesync:set_float(standDesync:get_float() + 1)
            end
        end
        if not invert then
            if standDesync:get_int() == - 50 then
                invert = true
            else
                standDesync:set_float(standDesync:get_float() - 2)
            end
        end
    end
    if Autism:get_int() == 4 then																				--5 (test)
        faketype:set_int(2)
        if invert then
            if standDesync:get_int() == -100 then
                invert = false
            else
                standDesync:set_float(standDesync:get_float() - 2)
            end
        end
        if not invert then
            if standDesync:get_int() == -80 then
                invert = true
            else
                standDesync:set_float(standDesync:get_float() + 2)
            end
        end
    end
end
callbacks:add("paint", on_paint)


print "Fucking shit ass fucking bitch ass lua made by banda#6448 with ♥"
-- input key values to not break the antiaim
function on_paint()
    if input:is_key_down(fatal) then
        standDesync:set_int(-50)
        Autism:set_int(0)
        fakelag:set_int(8)
		stand_yaw_add:set_int(5)
    elseif input:is_key_down(onetap) then
        standDesync:set_int(-25)
        Autism:set_int(1)
        fakelag:set_int(12)
    elseif input:is_key_down(skeet) then
        stand_yaw_add:set_int(-10)
        standDesync:set_int(50)
        Autism:set_int(2)
        fakelag:set_int(8)
    elseif input:is_key_down(test) then
        standDesync:set_int(-90)
        Autism:set_int(4)
        fakelag:set_int(8)
	    stand_yaw_add:set_int(20)	
    end
end
callbacks:add("paint", on_paint)



-- fakelag settings to different antiaim types
function on_paint()
    if Autism:get_int() == 0 then
        if fakelag:get_int() == 8 then
            fakelag:set_int(9)
        elseif fakelag:get_int() == 9 then
            fakelag:set_int(8)
        end
    end
    if Autism:get_int() == 1 then
        if fakelag:get_int() == 12 then
            fakelag:set_int(14)
        elseif fakelag:get_int() == 14 then
            fakelag:set_int(12)
        end
    end
    if Autism:get_int() == 2 then
        if fakelag:get_int() == 8 then
            fakelag:set_int(9)
        elseif fakelag:get_int() == 9 then
            fakelag:set_int(8)
        end
    end
    if Autism:get_int() == 4 then
        if fakelag:get_int() == 8 then
            fakelag:set_int(9)
        elseif fakelag:get_int() == 9 then
            fakelag:set_int(8)
        end
    end
end
callbacks:add("paint", on_paint)


--checkboxes for indicators & trashtalk
local Show_Indicators = config:add_item ( "misc_movement_Indicators", 0.0)
local Indicators_checkbox = menu:add_checkbox ( "Show Indicators", "misc", "", "Movement", Show_Indicators )
local Indicators = menu:get_reference ( "Show Fakelag", "misc", "", "Movement", Show_Indicators )

local Trash_talk = config:add_item ( "misc_movement_Trashtalk", 0.0)
local Trashtalk_checkbox = menu:add_checkbox ( "Trashtalk", "misc", "", "Movement", Trash_talk )
local Trashtalk = menu:get_reference ( "Trashtalk", "misc", "", "Movement", Trash_talk )
local screensize = render:screen_size()


-- fonts & colors
local font4 = render:create_font('Helvetica', 20, 700, true)
local color3 = csgo.color(255, 153, 204, 120)
local font2 = render:create_font('Arial', 29, 700, true)
local color5 = csgo.color(185, 255, 60, 120)

--drawing headshot indicators
function on_paint()
    if(engine:is_in_game()) then
	local entity_list = csgo.interface_handler:get_entity_list()
	local local_player = entity_list:get_localplayer()
	if(local_player:is_alive())then	--alive check
	else return end
	if headshot:get_bool() then
	render:text(font2, 10, 619, "HS", color5)
end
end
end
callbacks:add("paint", on_paint)


-- indicates on which antiaim you are using (might make it better later on)

function on_paint()
    if Show_Indicators:get_bool() then
        if Autism:get_int() == 0 then
            render:text(font4, 15, 15, "Beste", color3)
        elseif Autism:get_int() == 1 then
            render:text(font4, 15, 15, "onetap", color3)
        elseif Autism:get_int() == 2 then
            render:text(font4, 15, 15, "skeet & aimware", color3)
        elseif Autism:get_int() == 3 then
            render:text(font4, 15, 15, "autism", color3)
        elseif Autism:get_int() == 4 then
            render:text(font4, 15, 15, "test", color3)
        end
    end
end
callbacks:add("paint", on_paint)

--new antiaim shit based on timing
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local delay = 0.3 * 1
local swtich = false

function on_paint()
	if(engine:is_in_game()) then
        local entity_list = csgo.interface_handler:get_entity_list()
        local local_player = entity_list:get_localplayer()
	if local_player:is_alive()then
		switch = true
	end
end
end
callbacks:add("paint", on_paint)


function on_paint()
	if(engine:is_in_game()) then
        local entity_list = csgo.interface_handler:get_entity_list()
        local local_player = entity_list:get_localplayer()
	if local_player:is_alive()then
	if global.curtime % delay > delay - 0.1 then  switch = false end
	if switch then
		moveDesync:set_int(80)
		faketypemove:set_int(1)
		move_yaw_add:set_int(5)
	else
		moveDesync:set_int(-60)
		faketypemove:set_int(2)
		move_yaw_add:set_int(-3)
			end
		end
	end
end

callbacks:add("paint", on_paint)
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- just a nice thing to have (clears blood & bulletholes)
function on_paint() 
if(engine:is_in_game()) then
	local entity_list = csgo.interface_handler:get_entity_list()
	local local_player = entity_list:get_localplayer()
if(local_player:is_alive())then	--alive check
 engine_client:client_cmd("r_cleardecals")
 end
end
end
 callbacks:add("paint", on_paint)

-- pasted trashtalk 
function on_shot(shot)
    if Trash_talk:get_bool() then
        player = entity_list:get_player( shot.victim )
        if player == nil then
            return end
        if (shot.hurt and player:get_var_int("CBasePlayer->m_iHealth") <= 0) then
            engine_client:client_cmd("say monkey down") -- edit ("monkey down") to something you like lmao
        end
    end
end

callbacks:add( "registered_shot", on_shot )
callbacks:add("paint", on_paint)