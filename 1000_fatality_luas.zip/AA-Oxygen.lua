local globals          = csgo.interface_handler:get_global_vars()
local engine_client    = csgo.interface_handler:get_engine_client()
local menu             = fatality.menu
local config           = fatality.config
local callbacks        = fatality.callbacks
local math             = fatality.math
local render           = fatality.render
local screensize       = render:screen_size()
local buttonPres = menu:add_button('< Oxygen AA >', 'rage', 'anti-aim', 'general')
local buttonPres = menu:add_button('< Version: Beta >', 'rage', 'anti-aim', 'general')

local yawadd_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Yaw Add" )
local yawadd_stand_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
local fakeamount_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )

local yawadd_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Yaw Add" )
local yawadd_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Yaw Add" )

local yawadd_stand_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
local yawadd_move_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Add" )

local fakeamount_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
local fakeamount_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake amount" )
local indicators = fatality.config:add_item( "indicators_desync", 0 )
local menu = fatality.menu:add_checkbox( "Oxygen Enabled", "RAGE", "ANTI-AIM", "General", indicators )
local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )
local faketype_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake type" )

local freestandfake_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Freestand fake" )
local freestandfake_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Freestand fake" )

--call indicators
local indicators = fatality.config:add_item( "indicators_desync", 0 )

--Menu stuff
local aa_type_gay = fatality.config:add_item( "aa_type_gay", 4 )
local aa_type_gay_add = fatality.menu:add_combo( "AA Presets:", "RAGE", "ANTI-AIM", "General", aa_type_gay )
aa_type_gay_add:add_item("Off", aa_type_gay)
aa_type_gay_add:add_item("Experimental ", aa_type_gay)
aa_type_gay_add:add_item("Jitter Breaker ", aa_type_gay)
aa_type_gay_add:add_item("Backwords FJitter ", aa_type_gay)
aa_type_gay_add:add_item("Desync Breaker", aa_type_gay)

--Font
local Cambria = fatality.render:create_font( "Cambria", 50, 255, 255 )
local change_x = fatality.config:add_item( "pos_x", 0 )
local change_y = fatality.config:add_item( "pos_y", 0 )
local cursor_pos = fatality.input:get_mouse_pos( )



--render indicators
function render_indicators(pos_x, pos_y, width, height)

    if fatality.input:is_key_down(0x2E) then --fucking retarded shit need to remake

        change_x:set_int( fatality.input:get_mouse_pos( ).x )
        change_y:set_int( fatality.input:get_mouse_pos( ).y )
        fatality.render:rect_fade(  pos_x + change_x:get_int() - 5 - 1, pos_y + change_y:get_int() - 5 - 1, width + 10 + 2, height + 10 + 2, csgo.color(255, 0, 0, 255), csgo.color(255, 0, 255, 255))
     end
	  

end


local side = false
function paint()

--Antiaim standing
if (indicators:get_bool( )) then 

    render_indicators(0, 0, 200, 150) 
    side = not side
	
	  if (aa_type_gay:get_int() == 1 ) then 
	
        yawadd_stand:set_bool( true )
        if (side) then
		
		--move
	    yawadd_move_amount:set_float( 25 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )
		
        --standing
        yawadd_stand_amount:set_float( -15 )
		fakeamount_stand:set_float( -80 )
	
        else
		
		--moving
		yawadd_move_amount:set_float( -15 )
        fakeamount_move:set_float( -65 )
		
		--standing
        yawadd_stand_amount:set_float( -25 )
		fakeamount_stand:set_float( -65 )
		faketype_stand:set_int( 2 )
		
	
		
    end
	
  end

	  if (aa_type_gay:get_int() == 2 ) then
	
        yawadd_stand:set_bool( true )
        
        if (side) then
		
		--move
	    yawadd_move_amount:set_float( 25 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )
		
        --standing
        yawadd_stand_amount:set_float( 24 )
		fakeamount_stand:set_float( -100 )
		faketype_stand:set_int( 2 )
 
        else
		
		--moving
		yawadd_move_amount:set_float( -15 )
        fakeamount_move:set_float( -65 )
		
		--standing
        yawadd_stand_amount:set_float( 0 )
		fakeamount_stand:set_float( 20 )
		faketype_stand:set_int( 3 )
		
		
    end
	
  end
  
  	  if (aa_type_gay:get_int() == 3 ) then 
	
        yawadd_stand:set_bool( true )
        
        if (side) then
	
		--move
	    yawadd_move_amount:set_float( 25 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )
		
		--standing
        yawadd_stand_amount:set_float( 0 )
		fakeamount_stand:set_float( -76 )
		faketype_stand:set_int( 2 )
 
        else
		
		--moving
		yawadd_move_amount:set_float( -15 )
        fakeamount_move:set_float( -65 )
		
		--standing
        yawadd_stand_amount:set_float( -7 )
		fakeamount_stand:set_float( -88 )
		
	end
	
  end
  
  	  if (aa_type_gay:get_int() == 4 ) then 
        yawadd_stand:set_bool( true )
        
        if (side) then
	
	    --move
	    yawadd_move_amount:set_float( 25 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )
		
		--standing
        yawadd_stand_amount:set_float( 25 )
		fakeamount_stand:set_float( -70 )
		faketype_stand:set_int( 2 )
 
        else
		
		--moving
		yawadd_move_amount:set_float( -15 )
        fakeamount_move:set_float( -65 )
		
		--standing
        yawadd_stand_amount:set_float( -15 )
		fakeamount_stand:set_float( -65 )
		
    end
   end	
  end
 end



fatality.callbacks:add( "paint", paint)







local yawadd_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Yaw Add" )
local yawadd_move_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Add" )
local fakeamount_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake amount" )
local faketype_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake type" )



--call indicators
local indicators = fatality.config:add_item( "indicators_desync", 0 )




--moving stuff
local aa_type_moving = fatality.config:add_item( "aa_type_moving", 3 )
local aa_type_moving_add = fatality.menu:add_combo( "Moving Antiaim", "RAGE", "ANTI-AIM", "General", aa_type_moving )
aa_type_moving_add:add_item("None", aa_type_moving)
aa_type_moving_add:add_item("TJitter", aa_type_moving)
aa_type_moving_add:add_item("Jitter", aa_type_moving)
aa_type_moving_add:add_item("FJitter", aa_type_moving)

--standing stuff
local aa_type_stand = fatality.config:add_item( "aa_type_stand", 3 )
local aa_type_stand_add = fatality.menu:add_combo( "Old Anti-Aims", "RAGE", "ANTI-AIM", "General", aa_type_stand )
aa_type_stand_add:add_item("None", aa_type_stand)
aa_type_stand_add:add_item("Fake", aa_type_stand)
aa_type_stand_add:add_item("TFake", aa_type_stand)
aa_type_stand_add:add_item("Fakeedge", aa_type_stand)





--Font
local arial = fatality.render:create_font( "Cambria", 20, 255, 255 )
local change_x = fatality.config:add_item( "pos_x", 0 )
local change_y = fatality.config:add_item( "pos_y", 0 )
local cursor_pos = fatality.input:get_mouse_pos( )



--render indicators
function render_indicators(pos_x, pos_y, width, height)

    if fatality.input:is_key_down(0x2E) then --fucking retarded shit need to remake

        change_x:set_int( fatality.input:get_mouse_pos( ).x )
        change_y:set_int( fatality.input:get_mouse_pos( ).y )
        fatality.render:rect_fade(  pos_x + change_x:get_int() - 5 - 1, pos_y + change_y:get_int() - 5 - 1, width + 10 + 2, height + 10 + 2, csgo.color(255, 0, 0, 255), csgo.color(255, 0, 255, 255))
     end
      
      
      
--Watermark
fatality.render:text( arial, pos_x + change_x:get_int() + 2, pos_y + change_y:get_int() + 415, "Moving mode:", csgo.color(255, 255, 255, 255) )
--fatality.render:text( arial, pos_x + change_x:get_int() + 2, pos_y + change_y:get_int() + 415, "desync", csgo.color(173, 255, 047, 255) )




 
--Antiaim System    
if (aa_type_moving:get_int() == 1) then
        fatality.render:text( arial, pos_x + change_x:get_int() + 2, pos_y + change_y:get_int() + 430, "TJitter", csgo.color(173, 255, 047, 255) ) 
    
elseif (aa_type_moving:get_int() == 2) then
        fatality.render:text( arial, pos_x + change_x:get_int() + 2, pos_y + change_y:get_int() + 430, "Jitter", csgo.color(173, 255, 047, 255) )
        
elseif (aa_type_moving:get_int() == 3) then
        fatality.render:text( arial, pos_x + change_x:get_int() + 2 , pos_y + change_y:get_int() + 430, "FJitter", csgo.color(173, 255, 047, 255) ) 
        
    end


fatality.render:text( arial, pos_x + change_x:get_int() + 2, pos_y + change_y:get_int() + 450, "Standing mode:", csgo.color(255, 255, 255, 255) )
--fatality.render:text( arial, pos_x + change_x:get_int() + 2, pos_y + change_y:get_int() + 415, "desync", csgo.color(173, 255, 047, 255) )




 
--Antiaim System    
if (aa_type_stand:get_int() == 1) then
        fatality.render:text( arial, pos_x + change_x:get_int() + 2, pos_y + change_y:get_int() + 465, "Fake", csgo.color(173, 255, 047, 255) ) 
    
elseif (aa_type_stand:get_int() == 2) then
        fatality.render:text( arial, pos_x + change_x:get_int() + 2, pos_y + change_y:get_int() + 465, "TFake", csgo.color(173, 255, 047, 255) )
        
elseif (aa_type_stand:get_int() == 3) then
        fatality.render:text( arial, pos_x + change_x:get_int() + 2 , pos_y + change_y:get_int() + 465, "Fakeedge", csgo.color(173, 255, 047, 255) ) 
        
    end
end


local side = false
function paint()


   --moving antiaim
    if (indicators:get_bool( )) then 

    render_indicators(0, 0, 200, 150) 
    side = not side
    
      if (aa_type_moving:get_int() == 1 ) then --backwards jitter
    
       
        yawadd_move:set_bool( true )
        if (side) then
        
        --moving
      
        yawadd_move_amount:set_float( -20 )
        fakeamount_move:set_float( -100 )
        faketype_move:set_int( 2 )
 
        else
        
        --moving
        
        yawadd_move_amount:set_float( -0 )
        fakeamount_move:set_float( 100 )
        
    end
    
  end

      if (aa_type_moving:get_int() == 2 ) then --desync breaker
    
        
        yawadd_move:set_bool( true )
        if (side) then
        
        --moving
        yawadd_move_amount:set_float( -14 )
        fakeamount_move:set_float( 100 )
        faketype_move:set_int( 1 )
 
        else
        
        --moving
        fakeamount_move:set_float( 60 )
        
      
        
    end
    
  end
  end
  
      if (aa_type_moving:get_int() == 3 ) then --crooked
    
        
        yawadd_move:set_bool( true )
        if (side) then
    
        --moving
        yawadd_move_amount:set_float( 24 )
        fakeamount_move:set_float( -80 )
        faketype_move:set_int( 2 )
 
        else
        
        --moving
        yawadd_move_amount:set_float( 17 )
        fakeamount_move:set_float( 20 )
        faketype_move:set_int( 3 )
    end
   end  
  end
  

fatality.callbacks:add( "paint", paint)




















---




--call
local yawadd_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Yaw Add" )
local yawadd_stand_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
local fakeamount_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )

--call indicators
local indicators = fatality.config:add_item( "indicators_desync", 0 )





--Menu stuff
local aa_type_stand = fatality.config:add_item( "aa_type_stand", 3 )
local aa_type_stand_add = fatality.menu:add_combo( "Old Anti-Aims", "RAGE", "ANTI-AIM", "General", aa_type_stand )
aa_type_stand_add:add_item("None", aa_type_stand)
aa_type_stand_add:add_item("Backwards Breaker", aa_type_stand)
aa_type_stand_add:add_item("Desync Breaker", aa_type_stand)
aa_type_stand_add:add_item("Desync Breaker V2", aa_type_stand)



--Font
local arial = fatality.render:create_font( "Cambria", 20, 255, 255 )
local change_x = fatality.config:add_item( "pos_x", 0 )
local change_y = fatality.config:add_item( "pos_y", 0 )
local cursor_pos = fatality.input:get_mouse_pos( )



--render indicators
function render_indicators(pos_x, pos_y, width, height)

    if fatality.input:is_key_down(0x2E) then --fucking retarded shit need to remake

        change_x:set_int( fatality.input:get_mouse_pos( ).x )
        change_y:set_int( fatality.input:get_mouse_pos( ).y )
        fatality.render:rect_fade(  pos_x + change_x:get_int() - 5 - 1, pos_y + change_y:get_int() - 5 - 1, width + 10 + 2, height + 10 + 2, csgo.color(255, 0, 0, 255), csgo.color(255, 0, 255, 255))
     end
	  
end





local side = false
function paint()

--Antiaim standing
if (indicators:get_bool( )) then 

    render_indicators(0, 0, 200, 150) 
    side = not side
	
	  if (aa_type_stand:get_int() == 1 ) then --backwards breaker
	
        yawadd_stand:set_bool( true )
        if (side) then
		
        --standing
        yawadd_stand_amount:set_float( -14 )
		fakeamount_stand:set_float( -60 )
		faketype_stand:set_int( 3 )
 
        else
		
		--standing
        yawadd_stand_amount:set_float( -12 )
		fakeamount_stand:set_float( -60 )
		
    end
	
  end

	  if (aa_type_stand:get_int() == 2 ) then --desync breaker
	
        yawadd_stand:set_bool( true )
        
        if (side) then
		
        --standing
        yawadd_stand_amount:set_float( 24 )
		fakeamount_stand:set_float( -100 )
		faketype_stand:set_int( 2 )
 
        else
		
		--standing
        yawadd_stand_amount:set_float( 0 )
		fakeamount_stand:set_float( 20 )
		faketype_stand:set_int( 3 )
		
    end
	
  end
  
  	  if (aa_type_stand:get_int() == 3 ) then --Desync Breaker v2
	
        yawadd_stand:set_bool( true )
        
        if (side) then
	
        --standing
        yawadd_stand_amount:set_float( 24 )
		fakeamount_stand:set_float( -80 )
		faketype_stand:set_int( 2 )
 
        else
		
		--standing
        yawadd_stand_amount:set_float( 17 )
		fakeamount_stand:set_float( 20 )
		faketype_stand:set_int( 3 ) 
    end
   end	
  end
 end



fatality.callbacks:add( "paint", paint)

local cvar = csgo.interface_handler:get_cvar( );
local config = fatality.config
local menu = fatality.menu
local input = fatality.input;

cl_sidespeed = cvar:find_var( "cl_sidespeed" );
cl_forwardspeed = cvar:find_var( "cl_forwardspeed" );
cl_backspeed = cvar:find_var( "cl_backspeed" );

function set_speed( new_speed )
    if ( cl_sidespeed:get_int( ) == 450 and new_speed == 450 ) then
        return;
    end
     cl_sidespeed:set_float( new_speed );
     cl_forwardspeed:set_float( new_speed );
     cl_backspeed:set_float( new_speed );
end

local slowwalk_item = config:add_item( "slowwalk_rage", 0.0 )
local slowwalk_slider = menu:add_slider( "Slow walk", "rage", "ANTI-AIM", "general", slowwalk_item, 1, 100, 1 )

function on_paint( )
local is_down = input:is_key_down( 16 );
if not ( is_down ) then
set_speed( 450 )
else
local final_val = 250 * slowwalk_item:get_float( ) / 100
set_speed( final_val )
end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );