
-- https://fatality.win/threads/custom-killsound-remake.4898/
local menu = fatality.menu
local input = fatality.input
local config = fatality.config
local render = fatality.render
local callbacks = fatality.callbacks
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )
local global_vars = csgo.interface_handler:get_global_vars( )
local game_events = csgo.interface_handler:get_events( )
local events = csgo.interface_handler:get_events()
local cvar = csgo.interface_handler:get_cvar( )
local loopback = cvar:find_var("voice_loopback")
local fileinput = cvar:find_var("voice_inputfromfile")
local sound_exists = function(name)
    return (function(filename) return package.searchpath("", filename) == filename end)("./" .. name)
end
local switch_key = 0x58     -- FORCE SAY KEY BY DEFAULT ITS "X"  // CHANGE IT HERE https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes
local currentTime = 0
local timer, enabled, snd_time = 0, true, 1.5 -- set sound file lenght default f12 sound = 0.6 .
local handler = nil
handler = function()
    currentTime = global_vars.realtime
    if currentTime >= timer then
        timer = global_vars.realtime + snd_time
        if enabled then
            print("script loaded")
            loopback:unlock()
            fileinput:unlock()
            loopback:set_int(0)
            fileinput:set_int(0)
            engine_client:client_cmd_unrestricted("-voicerecord")
            enabled = false
            
        end
    end
end
callbacks:add("paint", handler)
local killsound = config:add_item("KillSound", 1.0)
local killsound_button = menu:add_checkbox("KillSound", "Misc", "Misc", "Movement", killsound)
local killsound_slider = menu:add_slider("KillSound Time", "Misc", "Misc", "Movement", killsound, 0, 10, 1)
local killsound_check = menu:get_reference("Misc", "Misc", "Movement", "KillSound")
local killsound_time_check = menu:get_reference("Misc", "Misc", "Movement", "KillSound Time")



local function on_player_death(e)
    if killsound_check:get_bool() then
    local victim_userid = e:get_int("userid")
    local attacker_userid = e:get_int("attacker")
    if victim_userid == nil or attacker_userid == nil then
        return
    end
    
    
    local local_ent = entity_list:get_localplayer()
    local victim_ent = entity_list:get_player_from_id(victim_userid)
    local attacker_ent = entity_list:get_player_from_id(attacker_userid)
    if local_ent == nil or victim_ent == nil or attacker_ent == nil then
        return
    end
    if (attacker_ent:get_index() == local_ent:get_index()) then
        loopback:unlock()
        fileinput:unlock()
        loopback:set_int(1)
        fileinput:set_int(1)
        engine_client:client_cmd_unrestricted("+voicerecord")
        timer, enabled = global_vars.realtime + killsound_time_check:get_int(), true
    end
end
        return
    end
local function on_event(e)
    local event_name = e:get_name()
    if(input:is_key_down(switch_key)) then
        loopback:unlock()
        fileinput:unlock()
        loopback:set_int(1)
        fileinput:set_int(1)
        engine_client:client_cmd_unrestricted("+voicerecord")
        timer, enabled = global_vars.realtime + killsound_time_check:get_int(), true
    end
    if event_name == "player_death" then
        on_player_death(e)
    end
end

events:add_event("player_death")
callbacks:add("events", on_event)
handler()