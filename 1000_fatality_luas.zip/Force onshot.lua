-- pseudo-force on shot lua - written by swoopae --

local entity_list = csgo.interface_handler:get_entity_list();
local engine = csgo.interface_handler:get_engine_client();
local global_vars = csgo.interface_handler:get_global_vars()

local render = fatality.render;
local config = fatality.config;
local menu = fatality.menu;
local input = fatality.input;

local key = 0x04; -- change me. default is MOUSE3. ref @ https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes
local toggle = 0;
local force_onshot = false;
local interval = 0;

local autoshoot = menu:get_reference( "RAGE", "AIMBOT", "Aimbot", "Autofire" );
local headonly = menu:get_reference( "RAGE", "AIMBOT", "Aimbot", "Headshot only" );

local last_known_tick = 0;

function on_paint_callback()
  if(engine:is_in_game() == false) and (engine:is_connected() == false) then
    return
  end

  local localplayer = entity_list:get_localplayer();

  if(localplayer == nil) then
    return;
  end

  local weapon = entity_list:get_from_handle(localplayer:get_var_handle("CBaseCombatCharacter->m_hActiveWeapon"));

  if(weapon == nil) then
    return;
  end

  -- to check if players are enemies
  local local_team = localplayer:get_var_int("CBaseEntity->m_iTeamNum");

  local class_id = weapon:get_class_id();

  -- do this only if the tick is new
  if ( global_vars.tickcount ~= last_known_tick ) then
    last_known_tick = global_vars.tickcount;

    -- best distance means probably what entity the ragebot will target
    local best_distance_from_center = 99999.9;
    local screen_center = csgo.vector3(render:screen_size().x / 2, render:screen_size().y / 2, 0);

    -- scroll thru entities
    -- i'm unsure of this but if i recall correctly fatality picks targets by fov, so to replicate this in an easy way i'll just use vector3:to_screen on their get_eye_pos()
    -- NOTE: this is incorrect, philip does this in a different way, still seems decent enough
    for i=1,64,1 do (function()
      local player = entity_list:get_player(i);

      if(player == nil) then
        return;
      end

      if(player:is_dormant()) then
        return;
      end

      if(player:is_alive() == false) then
        return;
      end

      local player_team = player:get_var_int("CBaseEntity->m_iTeamNum");
      if(player_team == local_team) then
        return;
      end

      local eye_pos = player:get_eye_pos();
      local eye_pos_w2s = eye_pos:to_screen();

      if(eye_pos_w2s == false) then
        return;
      end

      local aprox_dist = math.abs(eye_pos.x - screen_center.x) + math.abs(eye_pos.y - screen_center.y);

      if(aprox_dist < best_distance_from_center) then
        best_distance_from_center = aprox_dist;
        force_onshot = false;

        -- check their pitch
        -- TODO: replace with "CWeaponCSBase->m_fLastShotTime" check like a proper animfix would do so legits or people with +use won't trigger our onshot check
        local angs = player:get_var_angle("CCSPlayer->m_angEyeAngles[0]")

        if (angs.x < 80.0) and (angs.x > -80.0) then
          force_onshot = true;
        end
      end
    end)() end
  end

  if input:is_key_pressed(key) then
   toggle = toggle + 1;
  end

  if ( toggle % 2 == 1 ) then
    -- draw indicator
    render:indicator( render:screen_size().x * 2.33 / 450, render:screen_size().y * 1.1 / 2 - 40, "ONSHOT", true , -1);
    render:indicator( render:screen_size().x * 2.33 / 450, render:screen_size().y * 1.1 / 2 - 60, "ENFORCING", force_onshot , -1);

    -- force on shot if possible
    if force_onshot then
      -- enable autoshoot and head only
      autoshoot:set_bool(true);
      headonly:set_bool(true);
    else
      -- disable autoshoot and head only
      autoshoot:set_bool(false);
      headonly:set_bool(false);
    end
  else
    -- draw indicator
    render:indicator( render:screen_size().x * 2.33 / 450, render:screen_size().y * 1.1 / 2 - 40, "ONSHOT", false , -1);

    -- force normal values
    autoshoot:set_bool(true);
    headonly:set_bool(false);
  end
end

local callbacks = fatality.callbacks;
callbacks:add('paint', on_paint_callback);