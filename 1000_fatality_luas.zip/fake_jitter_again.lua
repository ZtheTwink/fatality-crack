-- https://fatality.win/threads/fake-jitter.844/

local render = fatality.render
local input = fatality.input
local menu = fatality.menu
local config = fatality.config
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()
local entity_list = csgo.interface_handler:get_entity_list( )

local fake_MaN_value_item = config:add_item( "jitter_fake", 0 );
local fake_MaN_checkbox = menu:add_checkbox( "Jitter Fake", "rage", "anti-aim", "general", fake_MaN_value_item );

local stand_fake = menu:get_reference( "rage", "anti-aim", "standing", "fake direction" )
local mov_fake = menu:get_reference( "rage", "anti-aim", "moving", "fake direction" )
local air_fake = menu:get_reference( "rage", "anti-aim", "air", "fake direction" )

function on_paint()
    if not engine_client:is_in_game() then
    return end
 
    local local_player = entity_list:get_localplayer()

    if not local_player:is_alive() then
    return end

    rand = math.random(2,3)

    if fake_MaN_value_item:get_bool() then
            stand_fake:set_int(rand)
            mov_fake:set_int(rand)
            air_fake:set_int(rand)
    end
 
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )