local entity_list = csgo.interface_handler:get_entity_list()

local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local input = fatality.input

local scarmindmg = config:get_weapon_setting("autosniper", "mindmg")
local scoutmindmg = config:get_weapon_setting("scout", "mindmg")
local awpmindmg = config:get_weapon_setting("awp", "mindmg")
local heavymindmg = config:get_weapon_setting("heavy_pistol", "mindmg")
local pistolmindmg = config:get_weapon_setting("pistol", "mindmg")

local toggle = 1

local items = {

    autoH = config:add_item('autoH',0),
    awpH = config:add_item('awpH',0),
    scoutH = config:add_item('scoutH',0),
    heavyPistolH = config:add_item('heavyPistolH',0),
    pistolsH = config:add_item('pistolH',0),

    autoF = config:add_item('autoF', config:get_weapon_setting('autosniper','mindmg'):get_int()),
    awpF = config:add_item('awpF', config:get_weapon_setting( 'awp' , 'mindmg' ):get_int()),
    scoutF = config:add_item('scoutF', config:get_weapon_setting( 'scout' , 'mindmg' ):get_int()),
    heavyPistolsF = config:add_item('heavyPistolsF', config:get_weapon_setting( 'heavy_pistol' , 'mindmg' ):get_int()),
    pistolsF = config:add_item('pistolsF', config:get_weapon_setting( 'pistol' , 'mindmg' ):get_int()),
}

local toggles = {

    autoH = menu:add_slider('min++ Auto','rage', 'aimbot', 'aimbot',items.autoH, 0, 100, 1),
    awpH = menu:add_slider('min++ AWP','rage', 'aimbot','aimbot',items.awpH, 0, 100, 1),
    scoutH = menu:add_slider('min++ Scout', 'rage', 'aimbot','aimbot',items.scoutH, 0, 100, 1),
    heavyPistolH = menu:add_slider('min++ Heavy', 'rage', 'aimbot', 'aimbot',items.heavyPistolH, 0, 100, 1),
    pistolsH = menu:add_slider('min++ Pistols', 'rage', 'aimbot', 'aimbot',items.pistolsH, 0, 100, 1),

    autoF = menu:add_slider('def min Auto','rage', 'aimbot','aimbot', items.autoF,0,100,1),
    awpF = menu:add_slider('def min Awp','rage', 'aimbot', 'aimbot', items.awpF,0,100,1),
    scoutF = menu:add_slider('def min Scout','rage', 'aimbot', 'aimbot', items.scoutF,0,100,1),
    heavyPistolsF = menu:add_slider('def min Heavy Pistol', 'rage', 'aimbot', 'aimbot', items.heavyPistolsF,0,100,1),
    pistolsF = menu:add_slider('def min Pistol','rage', 'aimbot', 'aimbot', items.pistolsF,0,100,1),

}

local key = 0x62

function bean()

        local localplayer = entity_list:get_localplayer()
    if(localplayer == nil) then
        return
    end
    local weapon = entity_list:get_from_handle(localplayer:get_var_handle("CBaseCombatCharacter->m_hActiveWeapon"))
    if(weapon == nil) then
        return
    end
    local activedamage = 0
    local classid = weapon:get_class_id()

    if(classid == 241 or classid == 260) then
        activedamage = scarmindmg:get_int()
        render:indicator( render:screen_size().x * 2.33 / 450, render:screen_size().y * 1.06 / 2, "" .. activedamage, false , -1);
    end
    if(classid == 266) then
        activedamage = scoutmindmg:get_int()
        render:indicator( render:screen_size().x * 2.33 / 450, render:screen_size().y * 1.06 / 2, "" .. activedamage, false , -1);
    end
    if(classid == 232) then
        activedamage = awpmindmg:get_int()
        render:indicator( render:screen_size().x * 2.33 / 450, render:screen_size().y * 1.06 / 2, "" .. activedamage, false , -1);
    end
    if(classid == 46) then
        activedamage = heavymindmg:get_int()
        render:indicator( render:screen_size().x * 2.33 / 450, render:screen_size().y * 1.06 / 2, "" .. activedamage, false , -1);
    end
    if(classid == 244 or classid == 238 or classid == 271 or classid == 245 or classid == 257 or classid == 240 or classid == 268) then
        activedamage = pistolmindmg:get_int()
        render:indicator( render:screen_size().x * 2.33 / 450, render:screen_size().y * 1.06 / 2, "" .. activedamage, false , -1);
    end

    local damageRef = {
        autoG = items.autoF:get_int(),
        awpG = items.awpF:get_int(),
        scoutG = items.scoutF:get_int(),
        heavyPistolG = items.heavyPistolsF:get_int(),
        pistolsG = items.pistolsF:get_int(),

        auto = menu:get_reference('rage', 'weapons', 'auto', 'min-damage'),
        awp = menu:get_reference('rage', 'weapons', 'awp', 'min-damage'),
        scout = menu:get_reference('rage', 'weapons', 'scout', 'min-damage'),
        heavyPistol = menu:get_reference('rage', 'weapons', 'heavy pistols', 'min-damage'),
        pistols = menu:get_reference('rage', 'weapons', 'pistols', 'min-damage'),
}

    if input:is_key_pressed(key) then
        toggle = toggle + 1
    end

    if(toggle%2 == 1) then
        config:get_weapon_setting("autosniper", "mindmg"):set_int( items.autoF:get_int() );
        config:get_weapon_setting("awp", "mindmg"):set_int( items.awpF:get_int() );
        config:get_weapon_setting("scout", "mindmg"):set_int( items.scoutF:get_int() );
        config:get_weapon_setting("heavy_pistol", "mindmg"):set_int( items.heavyPistolsF:get_int() );
        config:get_weapon_setting("pistol", "mindmg"):set_int( items.pistolsF:get_int() );

    elseif(toggle%2 == 0) then
        config:get_weapon_setting("autosniper", "mindmg"):set_int( items.autoH:get_int() );
        config:get_weapon_setting("awp", "mindmg"):set_int( items.awpH:get_int() );
        config:get_weapon_setting("scout", "mindmg"):set_int( items.scoutH:get_int(0) );
        config:get_weapon_setting("heavy_pistol", "mindmg"):set_int( items.heavyPistolH:get_int() );
        config:get_weapon_setting("pistol", "mindmg"):set_int( items.pistolsH:get_int() );
        render:indicator( render:screen_size().x * 2.33 / 450, render:screen_size().y * 1.1 / 2, "DMG", true , -1);
    end

end

local callbacks = fatality.callbacks
callbacks:add('paint', bean)