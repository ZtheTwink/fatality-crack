-- https://fatality.win/threads/epic-bomb-timer-bar-epic-pastedfromducariibutimadeitbettersoitsokay.668/

-- Fatality interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu

-- Interfaces
local globals = csgo.interface_handler:get_global_vars( )
local engine = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local events = csgo.interface_handler:get_events( )
local cvar = csgo.interface_handler:get_cvar( )

local classid =
{
    planted_c4 = 126
}
local screen_size = render:screen_size( )

local data =
{
    col = csgo.color( 108, 255, 10, 70 ),
    back_col = csgo.color( 0, 0, 0, 90 ),
    bomb_time = cvar:find_var( "mp_c4timer" ),
    bar_height = 18
}

--font
local verdana = render:create_font("verdana", 28, 650, false)



local function on_paint( )
    for i = 1, entity_list:get_max_entities( ), 1 do
            local ent = entity_list:get_entity(i)
            if ent == nil or ent:get_class_id( ) ~= classid.planted_c4 then
                goto continue end
        
            local bar_size = screen_size.x
            local bar_h = screen_size.y
            local factor = ( ent:get_var_float( "CPlantedC4->m_flC4Blow" ) - globals.curtime ) / data.bomb_time:get_float( )
            local bombtimetotext = ( ent:get_var_float( "CPlantedC4->m_flC4Blow" ) - globals.curtime )
            local numDecimalPlaces = 1
            function round(bombtimetotext, numDecimalPlaces) -- pasted from the interwebz >_<
                local mult = 10^(numDecimalPlaces or 0)
                return math.floor(bombtimetotext * mult + 0.5) / mult
            end

            local bombcol 
            local textcol
            if (bombtimetotext < 5) then
                bombcol = csgo.color(255, 10, 10, 100)
                textcol = csgo.color(255, 10, 10, 255)
            else
                bombcol = data.col
                textcol = csgo.color(124, 183, 0, 255)
            end

            if factor <= 0 then
                goto continue end

            local pos = csgo.vector2( screen_size.x - bar_size , -1  );
            render:rect_filled( pos.x, pos.y, data.bar_height, bar_size, data.back_col )
            render:rect_filled( pos.x, pos.y,  data.bar_height ,  factor * ( bar_h - 4 ) , bombcol )
            render:text(verdana, pos.x + 21,  factor * ( bar_h - 23 ), tostring(round(bombtimetotext, numDecimalPlaces)) .. "s" , csgo.color( 0, 0, 0, 255 )) 
            render:text(verdana, pos.x + 20,  factor * ( bar_h - 24 ), tostring(round(bombtimetotext, numDecimalPlaces)) .. "s" , textcol) 
 
    
            ::continue::
        end
end

-- Register callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )