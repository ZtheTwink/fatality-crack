-- https://fatality.win/threads/update-delay-doubletap-with-indicator.3784/

local config = fatality.config
local menu = fatality.menu
local render = fatality.render
local screen_size = render:screen_size( )
local engine = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()
local dtdelay = config:add_item("rage_dtdelay", 0)
local dtdelaycheckbox = menu:add_checkbox("Delay double tap", "rage", "aimbot", "aimbot", dtdelay)
local delaytime = config:add_item("rage_delaytime", 0)
local delaytimeslider = menu:add_slider("Delay by (sec)", "rage", "aimbot", "aimbot", delaytime, 1, 6, 1)
local switchto = config:add_item("rage_dtmode", 0)
local dtmode = menu:add_combo("Dt mode after delay", "rage", "aimbot", "aimbot", switchto):add_item("no teleport", switchto):add_item("teleport", switchto)
local entity_list = csgo.interface_handler:get_entity_list( )
local dt1 = menu:get_reference("rage", "weapons", "auto", "double tap")
local dt2 = menu:get_reference("rage", "weapons", "Pistols", "double tap")
local dt3 = menu:get_reference("rage", "weapons", "Other", "double tap")
local dt4 = menu:get_reference("rage", "weapons", "Heavy Pistols", "double tap")
print("Delay double tap lua is loaded. by anti#2528 (anti)")
local indicatorfont = render:create_font( "Tahoma", 16, 550, false );
local dtshot = false

function on_registered_shot( shot )

    -- creating a variable of the enemy
    local enemy = entity_list:get_player( shot.victim )

    -- nil check
    if enemy == nil then
        return
    end

    -- getting shot info
    local shot_info_t = shot.shot_info

    -- returns the function if something goes wrong
    if not shot_info_t.has_info then
        return
    end
    local local_player = entity_list:get_localplayer()
    local weapon_handle = local_player:get_var_handle("CBaseCombatCharacter->m_hActiveWeapon")
    local weapon_entity = entity_list:get_from_handle(weapon_handle)

    if(weapon_entity ~= nil)then
    if (dt1:get_int() ~= 0 and (weapon_entity:get_class_id() == 260 or weapon_entity:get_class_id() == 241) or (dt2:get_int() ~= 0 and (weapon_entity:get_class_id() == 238 or weapon_entity:get_class_id() == 244 or weapon_entity:get_class_id() == 271)) or (dt4:get_int() ~= 0 and (weapon_entity:get_class_id() == 64 or weapon_entity:get_class_id() == 46)))then
    dtshot = true
end
end
end


function on_paint()

if(engine:is_in_game()) then
        local entity_list = csgo.interface_handler:get_entity_list()
        local local_player = entity_list:get_localplayer()
if local_player:is_alive()then

local delayby = delaytime:get_float( ) * 1
if(dtdelay:get_bool())then
if global_vars.curtime % delayby > delayby - 0.1 then dtshot = false end


    if(dtshot)then
    render:indicator(screen_size.x / 175, screen_size.y / 1 - 365, "DLY", true, -1)

    dt1:set_int(0)
    dt2:set_int(0)
    dt3:set_int(0)
    dt4:set_int(0)
    else
    render:indicator(screen_size.x / 175, screen_size.y / 1 - 365, "DLY", false, -1)
    if(switchto:get_int() == 1)then
    dt1:set_int(2)
    dt2:set_int(2)
    dt3:set_int(2)
    dt4:set_int(2)
    elseif(switchto:get_int() == 0)then
    dt1:set_int(1)
    dt2:set_int(1)
    dt3:set_int(1)
    dt4:set_int(1)
end

end
end
end
end
end


local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)
callbacks:add( "registered_shot", on_registered_shot )