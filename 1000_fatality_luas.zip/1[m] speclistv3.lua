-- _markjelo luas + cfg

print("speclist V3 LUA for my cfg _markjelo#9266")

-- interfaces
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local cvar = csgo.interface_handler:get_cvar( )
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local onetap_speclist_item = config:add_item( "speclist_onetap", 0 )
local onetap_speclist_speclist_checkbox = menu:add_checkbox( "Spectator list", "visuals", "misc", "various", onetap_speclist_item )
local onetap_item = config:add_item("onetap_col", 0)
local onetap_bar_combobox = menu:add_combo( "rainbow mode", "visuals", "misc", "various", onetap_item):add_item( "rainbow", onetap_item):add_item( "gradient rainbow", onetap_item)
local screensize = render:screen_size();
local x_value_item = config:add_item("xvalue_onetap", 0)
local x_slider = menu:add_slider("x slider", "visuals", "misc", "various", x_value_item, 0 , screensize.x, 1)
local y_value_item = config:add_item("yvalue_onetap", 0)
local y_slider = menu:add_slider("y slider", "visuals", "misc", "various", y_value_item, 0, screensize.y, 1 )
local tahoma = render:create_font( "Tahoma", 13, 500, true );
function draw_container_onetap( x, y, w, h, title )
    local c = {10, 60, 40, 40, 40, 60, 20};
    
    render:rect_filled(x + 10, y + 6, 180, 20, csgo.color(0,0,0,50))
    render:text(tahoma, x + w / 3, y + 9, title, csgo.color(255,255,255,230))
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
    local r1 = math.floor( math.sin( global_vars.realtime * 2.3) * 127 + 128 );
    local g1 =  math.floor( math.sin( global_vars.realtime * 2.3 + 2 ) * 127 + 128 );
    local b1 = math.floor( math.sin( global_vars.realtime * 2.3 + 4 ) * 127 + 128 );
    if onetap_item:get_int() == 1 then
        render:rect_fade( x + 10, y + 2, 180, 5, csgo.color(r,g,b,250), csgo.color(r1, g1, b1, 250), true );
        render:rect( x + 10, y + 2, 180, 5, csgo.color( 0, 0, 0, 250 ) );
    elseif onetap_item:get_int() == 0 then
        render:rect_filled( x + 10, y + 2, 180, 5, csgo.color( r,g,b, 250 ) );
        render:rect( x + 10, y + 2, 180, 5, csgo.color( 0, 0, 0, 250 ) );
    end
end
function on_paint()
    if not engine_client:is_in_game( ) then
    return end
    local local_player = entity_list:get_localplayer()
    local getslidervalue_x = x_value_item:get_float() * 1
    local getslidervalue_y = y_value_item:get_float() * 1
    -- Set position where the list will be drawn
    local spec_list_pos = csgo.vector2( getslidervalue_x, getslidervalue_y )
    local spec_names = { }
    local total_spectators = 0
    if onetap_speclist_item:get_bool() then
  
        for i = 1, entity_list:get_max_players( ), 1 do
            player = entity_list:get_player( i )
            if player == nil or player:is_alive( ) or player:is_dormant( ) then
            goto continue end

            spec_handle = player:get_var_handle( "CBasePlayer->m_hObserverTarget" )
            spec_player = entity_list:get_from_handle( spec_handle )
            if spec_player == nil then
            goto continue end

            -- If the player is spectating us - add him/her to the list
            if spec_player:get_index( ) == local_player:get_index( ) then
                spec_names[ total_spectators ] = player:get_name( )
                total_spectators = total_spectators + 1;
            end
            ::continue::
        end
        draw_container_onetap(spec_list_pos.x, spec_list_pos.y, 200, total_spectators * 16 + 45, "  spectators")
        -- Go through all registered spectators and draw the names
        for i = 0, total_spectators, 1 do
            if spec_names[ i ] == nil then break end
                render:text( tahoma, spec_list_pos.x + 16, spec_list_pos.y + 30 + i * 16, spec_names[ i ], csgo.color(220,220,220,255) )   
        end
    end
end
local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )