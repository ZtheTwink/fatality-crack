--[[
    -- BETA Legitbot LUA created by PuL9!!
    -- fatality.win

    -- Thanks to PuL9 , Quit ,  reahly
]]

-- https://fatality.win/threads/chicken-aimbot.3645/

local global_vars       = csgo.interface_handler:get_global_vars()
local engine_client     = csgo.interface_handler:get_engine_client()
local entity_list       = csgo.interface_handler:get_entity_list()
local globals = csgo.interface_handler:get_global_vars() -- im too lazy to rename first variable
local cvars = csgo.interface_handler:get_cvar( );
local render            = fatality.render
local menu              = fatality.menu
local input             = fatality.input
local config            = fatality.config
local fmath             = fatality.math

local render = fatality.render;

local small_12 = render:create_font( "Verdana", 12, 200, true )


local local_player = nil

function aimbot(player)

        local local_player = entity_list:get_localplayer()

    if(input:is_key_down(0x01)) then
        local rcs_x = 2
        local rcs_y = 2
        local rcs_offset = 2
    
        local angle = fmath:calc_angle(local_player:get_eye_pos(), player:get_var_vector("CBaseEntity->m_vecOrigin"))
        local aimpunch_angle = local_player:get_var_vector("CBasePlayer->m_aimPunchAngle")
        
        angle.x = angle.x - aimpunch_angle.x * rcs_x + rcs_offset - 3.6
        angle.y = angle.y - aimpunch_angle.y * rcs_y
    
        engine_client:client_cmd("setang " .. angle.x .. " " .. angle.y )
    end

end

function on_paint( )
local r = math.floor( math.sin( globals.realtime * 0.5) * 127 + 128 )
    local g =  math.floor( math.sin( globals.realtime* 0.5 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( globals.realtime* 0.5 + 4 ) * 127 + 128 )
    for i = 1, entity_list:get_max_entities( ), 1 do
        all_entity = entity_list:get_entity( i );
        if ( all_entity and all_entity:get_class_id( ) == 36 ) then
            origin = all_entity:get_var_vector( "CBaseEntity->m_vecOrigin" );
            origin:to_screen( );
            render:text( small_12, origin.x, origin.y, "gay choocken", csgo.color( r,g,b,255 ) );
            aimbot(all_entity)
        end
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );