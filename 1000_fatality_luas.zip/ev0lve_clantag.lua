-- https://fatality.win/threads/working-ev0lve-clantag-syncs.4632/

require "clantag_api"

local timing_switch = 80
local cur_mode = 1
local timing = timing_switch

local clantag_timing = {
       [1]  = function() return "           " end,
    [2]  = function() return "         e" end,
    [3]  = function() return "        ev" end,
    [4]  = function() return "       ev0" end,
    [5]  = function() return "      ev0l" end,
    [6]  = function() return "     ev0lv" end,
    [7]  = function() return "    ev0lve" end,
    [8]  = function() return "   ev0lve." end,
    [9]  = function() return "  ev0lve.x " end,
    [10] = function() return " ev0lve.xy " end,
    [11] = function() return " ev0lve.xyz " end,
    [12] = function() return " ev0lve.xyz " end,
    [13] = function() return " ev0lve.xyz " end,
    [14] = function() return " ev0lve.xyz " end,
    [15] = function() return " ev0lve.xyz " end,
    [16] = function() return " ev0lve.xyz " end,
    [17] = function() return " ev0lve.xyz " end,
    [18] = function() return " ev0lve.xyz " end,
    [19] = function() return " ev0lve.xyz " end,
    [20] = function() return " ev0lve.xyz " end,
    [21] = function() return " ev0lve.xyz " end,
    [22] = function() return " v0lve.xyz " end,
    [23] = function() return " 0lve.xyz " end,
    [24] = function() return " lve.xyz " end,
    [25] = function() return "ve.xyz   " end,
    [26] = function() return "e.xyz    " end,
    [27] = function() return ".xyz     " end,
    [28] = function() return "xyz      " end,
    [29] = function() return "yz       " end,
    [30] = function() return "z        " end,
}

local function on_paint()
timing = timing + 1

    if timing >= timing_switch then
        cur_mode = cur_mode + 1

        if cur_mode > #clantag_timing then
            cur_mode = 1
        end
      
        SET_CLANTAG_MADE_BY_DUCARII(clantag_timing[cur_mode]())
        timing = 1
    end

end


local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )