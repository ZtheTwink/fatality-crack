-- More Advanced Fake Direction Lua by johnyy177
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local input = fatality.input
 
local sides = false
 
local more_afd_item = config:add_item( "fake_direction_lua", 1.0 )
local more_afd_checkbox = menu:add_checkbox( "More Advanced Fake Direction", "RAGE", "ANTI-AIM", "General", more_afd_item )
 
local more_afd_combo_item_st = config:add_item( "fake_direction_combo_st_lua", 1.0 )
local more_afd_combo_item_mv = config:add_item( "fake_direction_combo_mv_lua", 1.0 )
local more_afd_combo_item_jp = config:add_item( "fake_direction_combo_jp_lua", 1.0 )
 
 
local more_afd_multicombo_item = config:add_item( "more_afd_multicombo_lua", 1.0 )
local more_afd_multicombo_standing = config:add_item( "more_afd_multicombo_lua_st", 1.0 )
local more_afd_multicombo_moving = config:add_item( "more_afd_multicombo_lua_mv", 1.0 )
local more_afd_multicombo_jumping = config:add_item( "more_afd_multicombo_lua_jp", 1.0 )
local more_afd_multicombo = menu:add_multi_combo( "Stand/Move/Air", "RAGE", "ANTI-AIM", "General", more_afd_multicombo_item, 0.0, 100.0, 1.0 )
more_afd_multicombo:add_item( "Standing", more_afd_multicombo_standing )
 
local more_afd_combo_stand = menu:add_combo( "Standing Type", "RAGE", "ANTI-AIM", "General", more_afd_combo_item_st )
more_afd_combo_stand:add_item( "Normal", more_afd_combo_item_st )
more_afd_combo_stand:add_item( "Switch", more_afd_combo_item_st )
 
more_afd_multicombo:add_item( "Moving", more_afd_multicombo_moving )
 
local more_afd_combo_move = menu:add_combo( "Moving Type", "RAGE", "ANTI-AIM", "General", more_afd_combo_item_mv )
more_afd_combo_move:add_item( "Normal", more_afd_combo_item_mv )
more_afd_combo_move:add_item( "Switch", more_afd_combo_item_mv )
 
more_afd_multicombo:add_item( "Air", more_afd_multicombo_jumping )
 
local more_afd_combo_jump = menu:add_combo( "Air Type", "RAGE", "ANTI-AIM", "General", more_afd_combo_item_jp )
more_afd_combo_jump:add_item( "Normal", more_afd_combo_item_jp )
more_afd_combo_jump:add_item( "Switch", more_afd_combo_item_jp )
 
local standing_fakedir = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake direction" )
local moving_fakedir = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake direction" )
local jumping_fakedir = menu:get_reference( "RAGE", "ANTI-AIM", "Air", "Fake direction" )
 
local jitterfake = menu:get_reference( "RAGE", "ANTI-AIM", "General", "Jitter Fake" )
 
local left_side_mouse_btn = 0x05 --if you want to change this, use this site : http://asger-p.dk/info/virtualkeycodes.php
local screensize = render:screen_size()
 
function on_paint()
    if not engine_client:is_in_game( ) then
        return end
       
    local local_player = entity_list:get_localplayer( )
 
    if not local_player:is_alive( ) then
        return end
       
    if input:is_key_pressed( left_side_mouse_btn ) then
        sides = not sides
    end  
           
    if more_afd_item:get_bool( ) then
        if more_afd_multicombo_standing:get_bool( ) then
            if more_afd_combo_item_st:get_int( ) == 0 then
                if sides then
                    standing_fakedir:set_int( 3 )
                    render:indicator( 10, screensize.y/1.85, "FAKE LEFT", false, -1 )
                else
                    standing_fakedir:set_int( 2 )
                    render:indicator( 10, screensize.y/1.85, "FAKE RIGHT", false, -1 )
                end
            elseif more_afd_combo_item_st:get_int( ) == 1 then
                standing_fakedir:set_int( math.random(2,3) )
            end  
        end
        if more_afd_multicombo_moving:get_bool( ) then
            if more_afd_combo_item_mv:get_int( ) == 0 then
                if sides then
                    moving_fakedir:set_int( 3 )
                    render:indicator( 10, screensize.y/1.85, "FAKE LEFT", false, -1 )
                else
                    moving_fakedir:set_int( 2 )
                    render:indicator( 10, screensize.y/1.85, "FAKE RIGHT", false, -1 )
                end
            elseif more_afd_combo_item_mv:get_int( ) == 1 then
                moving_fakedir:set_int( math.random(2,3) )
            end  
        end
        if more_afd_multicombo_jumping:get_bool( ) then
            if more_afd_combo_item_jp:get_int( ) == 0 then
                if sides then
                    jumping_fakedir:set_int( 3 )
                    render:indicator( 10, screensize.y/1.85, "FAKE LEFT", false, -1 )
                else
                    jumping_fakedir:set_int( 2 )
                    render:indicator( 10, screensize.y/1.85, "FAKE RIGHT", false, -1 )
                end
            elseif more_afd_combo_item_jp:get_int( ) == 1 then
                jumping_fakedir:set_int( math.random(2,3) )
            end  
        end
       
        if jitterfake:get_bool( ) then
            jitterfake:set_bool( false )
        end
    end
end
 
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)