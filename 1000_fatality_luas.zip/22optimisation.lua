local engine_client = csgo.interface_handler:get_engine_client()
local cvar = csgo.interface_handler:get_cvar()
local config = fatality.config
local menu = fatality.menu
local interface_cvar = csgo.interface_handler:get_cvar( )
local var = interface_cvar:find_var( "sv_cheats" )

local noshadows1 = cvar:find_var( "r_shadows");
local noshadows2 = cvar:find_var( "cl_csm_static_prop_shadows");
local noshadows3 = cvar:find_var( "cl_csm_shadows");
local noshadows4 = cvar:find_var( "cl_csm_world_shadows");
local noshadows5 = cvar:find_var( "cl_foot_contact_shadows");
local noshadows6 = cvar:find_var( "cl_csm_viewmodel_shadows");
local noshadows7 = cvar:find_var( "cl_csm_rope_shadows");
local noshadows8 = cvar:find_var( "cl_csm_sprite_shadows");
local r_dynamic = cvar:find_var( "r_dynamic");
local cl_help = cvar:find_var( "cl_showhelp");
local cl_autohelp = cvar:find_var( "cl_autohelp");
--local draw_particles = cvar:find_var( "r_drawparticles");
local r_eye = cvar:find_var( "r_eyesize");
local r_eyez = cvar:find_var( "r_eyeshift_z");
local r_eyey = cvar:find_var( "r_eyeshift_y");
local r_eyex = cvar:find_var( "r_eyeshift_x");
local r_eyemove = cvar:find_var( "r_eyemove");
local r_eyegloss = cvar:find_var( "r_eyegloss");
local drawtracers = cvar:find_var( "r_drawtracers_firstperson");
local drawtracersgen = cvar:find_var( "r_drawtracers");
local water_fog = cvar:find_var( "fog_enable_water_fog");
local ppros = cvar:find_var( "mat_postprocess_enable");
local freezecam = cvar:find_var( "cl_disablefreezecam");
local freezepos = cvar:find_var( "cl_freezecampanel_position_dynamic");
local drawdecals = cvar:find_var( "r_drawdecals");
local muzzleflash = cvar:find_var( "muzzleflash_light");
local drawrain = cvar:find_var( "r_drawrain");
local drawrope = cvar:find_var( "r_drawropes");
local drawspirtes = cvar:find_var ( "r_drawsprites");
local disablehtml = cvar:find_var( "cl_disablehtmlmotd");
local freezecameffects = cvar:find_var( "cl_freezecameffects_showholiday");
local gameinstructor = cvar:find_var( "gameinstructor_enable");
local matqueue = cvar:find_var( "mat_queue_mode");
local fpsmax = cvar:find_var( "fps_max");
local fpsmaxmenu = cvar:find_var( "fps_max_menu");
local rawimput = cvar:find_var( "m_rawinput");
local bob1 = cvar:find_var( "cl_bob_lower_amt");
local detail = cvar:find_var( "cl_detail_multiplier");
local drawWater = cvar:find_var( "mat_drawwater");
--local matres = cvar:find_var ( "mat_showlowresimage");  

if var:get_int( ) == 0 then
    var:unlock( )
    var:set_int( 1 )
end

fatality.callbacks:add("paint", function()
    if(not engine_client:is_in_game()) then
        return
    else
	    drawWater:set_int(0)
	    detail:set_int(0)
	    bob1:set_int(0)
	    rawimput:set_int(1)
	    fpsmax:set_int(0)
		fpsmaxmenu:set_int(0)
        noshadows1:set_int(0)
        noshadows2:set_int(0)
        noshadows3:set_int(0)
        noshadows4:set_int(0)
        noshadows5:set_int(0)
        noshadows6:set_int(0)
        noshadows7:set_int(0)
        noshadows8:set_int(0)
		r_dynamic:set_int(0)
		cl_help:set_int(0)
		cl_autohelp:set_int(0)
		--draw_particles:set_int(0)
		r_eye:set_int(0)
		r_eyez:set_int(0)
		r_eyey:set_int(0)
		r_eyex:set_int(0)
		r_eyemove:set_int(0)
		r_eyegloss:set_int(0)
		drawtracers:set_int(0)
		drawrope:set_int(0)
		drawtracersgen:set_int(0)
		drawspirtes:set_int(0)
		water_fog:set_int(0)
		ppros:set_int(0)
		freezecam:set_int(0)
		freezepos:set_int(0)
		drawdecals:set_int(0)
		muzzleflash:set_int(0)
		drawrain:set_int(0)
		disablehtml:set_int(0)
		freezecameffects:set_int(0)
		gameinstructor:set_int(0)
		matqueue:set_int(-1)
	--  matres:set_int(1) 
    end
end)