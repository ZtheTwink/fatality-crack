--script by
--cherry#5549
 
--no credits because this is a self code ;) (jk thanks painless for the support on the way to making it)
 
--spacebar
local key = 0x20
 
--stuff
local engine = csgo.interface_handler:get_engine_client()
local callbacks = fatality.callbacks
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
 
--config
local cfg_ground = config:add_item( "walking_zeus", 0.0 )
local cfg_air = config:add_item( "air_zeus", 0.0 )
local cfg_await = config:add_item( "zeus_switch_time", 0.0 )
 
--menu
local ground = menu:add_slider( "Ground Hitchance", "RAGE", "AIMBOT", "MISC", cfg_ground, 0, 100, 0 )
local air = menu:add_slider( "Jumping Hitchance", "RAGE", "AIMBOT", "MISC", cfg_air, 0, 100, 0 )
 
--references
local hitchance = menu:get_reference("RAGE", "AIMBOT", "Misc", "ZEUS hitchance")
 
callbacks:add("paint", function()
    if(engine:is_in_game()) then
        if input:is_key_down(key) then
            hitchance:set_int(cfg_air:get_int())
        else
            hitchance:set_int(cfg_ground:get_int())
        end
    end
end)
 
--callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )