-- https://fatality.win/threads/extensive-shot-logs.578/

local config = fatality.config
local menu = fatality.menu

local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local cvar = csgo.interface_handler:get_cvar( )

-- Add item to config and display on menu.
local extensive_logs = config:add_item( "extensive_logs", 0.0 )
local logs_checkbox = menu:add_checkbox( "Show Extensive Shot Logs", "visuals", "misc", "various", extensive_logs )

print( "Extensive Shot Logs 1.0 by mage loaded.")

local white = csgo.color(255,255,255,255)

-- Called on shot being registered by the server.
function on_registered_shot( shot )
    -- Check if the item is enabled in config.
    if not extensive_logs:get_bool( ) then
        return
    end

    -- Get the intended victim of the shot.
    local enemy = entity_list:get_player( shot.victim )

    if enemy == nil then
        return
    end

    -- Make sure shot has been initialized.
    local shot_info_t = shot.shot_info

    if not shot_info_t.has_info then

        cvar:print_console( " FATALITY | ERROR: SHOT HAS NOT BEEN INITIALIZED" )
        return
    end

    -- Check if the shot hit the enemy and display shot information.
    if shot.hurt then
        -- Get the shots lag record for easier readability.
        local lag_record = shot.record

        -- Preprepare the information about the shot for readability.
        local general_info = "| FATALITY | Shot at " .. enemy:get_name( ) .. " | Targeted hitgroup " .. shot.target_hitgroup .. " | Targeted damage " .. shot.target_damage .. " | Hit hitgroup " .. shot.hit_hitgroup .. " | Dealt damage " .. shot.hit_damage .. " | Shot hitchance " .. shot.hitchance .. "%\n"
        local lag_info = "| FATALITY | LAG_INFO | Backtracked " .. shot_info_t.backtrack_ticks .. " ticks | Shot simtime " .. lag_record.sim_time .. " \n"
        local shot_info = "| FATALITY | SHOT_INFO | Extrapolated " .. tostring(shot_info_t.extrapolated) .. " | LC " .. tostring(shot_info_t.breaking_lc) .. " | Delayed " .. tostring(shot_info_t.delayed_shot) .. "\n\n"

        cvar:print_console( general_info, white )
        cvar:print_console( lag_info, white )
        cvar:print_console( shot_info, white )
    else
       
        -- Get the shots lag record for easier readability.
        local lag_record = shot.record

        -- Preprepare the information about the shot for readability.
        local general_info = "| FATALITY | Shot at " .. enemy:get_name( ) .. " | Targeted hitgroup " .. shot.target_hitgroup .. " | Targeted damage " .. shot.target_damage .. " | Hit hitgroup " .. shot.hit_hitgroup .. " | Dealt damage " .. shot.hit_damage .. " | Shot hitchance " .. shot.hitchance .. "%\n"
        local lag_info = "| FATALITY | LAG_INFO | Attempted to backtrack " .. shot_info_t.backtrack_ticks .. " ticks | Shot simtime " .. lag_record.sim_time .. " \n"
        local shot_info = "| FATALITY | SHOT_INFO | Extrapolated " .. tostring(shot_info_t.extrapolated) .. " | LC " .. tostring(shot_info_t.breaking_lc) .. " | Delayed " .. tostring(shot_info_t.delayed_shot) .. "\n\n"

        cvar:print_console( general_info, white )
        cvar:print_console( lag_info, white )
        cvar:print_console( shot_info, white )
    end
end

-- Register our callback.
local callbacks = fatality.callbacks
callbacks:add( "registered_shot", on_registered_shot )