local globals   = csgo.interface_handler:get_global_vars()
local engine    = csgo.interface_handler:get_engine_client()
local menu      = fatality.menu
local config    = fatality.config
local input     = fatality.input
local callbacks = fatality.callbacks
local last_tick_stand = globals.realtime
local last_tick_move = globals.realtime
local last_tick_air = globals.realtime


local in_use_stand = false
local in_use_move = false
local in_use_air = false

local fake_jitter_stand_checkbox_item = config:add_item('aa_fake_jitter_stand_checkbox', 0);
local fake_jitter_stand_checkbox = menu:add_checkbox('Fake Jitter Stand', 'Rage', 'Anti-Aim', 'Standing', fake_jitter_stand_checkbox_item);
local fake_jitter_stand_min_slider_item = config:add_item( "aa_fake_jitter_stand_min_slider", 0 );
local fake_jitter_stand_min_slider = menu:add_slider( "Fake Jitter Stand Min", "Rage", "Anti-Aim", "Standing", fake_jitter_stand_min_slider_item, -100, 99, 1 );
local fake_jitter_stand_max_slider_item = config:add_item( "aa_fake_jitter_max_stand_slider", 0 );
local fake_jitter_stand_max_slider = menu:add_slider( "Fake Jitter Stand Max", "Rage", "Anti-Aim", "Standing", fake_jitter_stand_max_slider_item, -99, 100, 1 );
local fake_jitter_stand_delay_slider_item = config:add_item( "aa_fake_jitter_stand_delay_slider", 0 );
local fake_jitter_stand_delay_slider = menu:add_slider( "Jitter Delay", "Rage", "Anti-Aim", "Standing", fake_jitter_stand_delay_slider_item, 0, 60, 0.1 );

local fake_jitter_move_checkbox_item = config:add_item('aa_fake_jitter_move_checkbox', 0);
local fake_jitter_move_checkbox = menu:add_checkbox('Fake Jitter Move', 'Rage', 'Anti-Aim', 'Moving', fake_jitter_move_checkbox_item);
local fake_jitter_move_min_slider_item = config:add_item( "aa_fake_jitter_move_min_slider", 0 );
local fake_jitter_move_min_slider = menu:add_slider( "Fake Jitter Moving Min", "Rage", "Anti-Aim", "Moving", fake_jitter_move_min_slider_item, -100, 99, 1 );
local fake_jitter_move_max_slider_item = config:add_item( "aa_fake_jitter_max_move_slider", 0 );
local fake_jitter_move_max_slider = menu:add_slider( "Fake Jitter Moving Max", "Rage", "Anti-Aim", "Moving", fake_jitter_move_max_slider_item, -99, 100, 1 );
local fake_jitter_move_delay_slider_item = config:add_item( "aa_fake_jitter_move_delay_slider", 0 );
local fake_jitter_move_delay_slider = menu:add_slider( "Jitter Delay", "Rage", "Anti-Aim", "Moving", fake_jitter_move_delay_slider_item, 0, 60, 0.1 );

local fake_jitter_air_checkbox_item = config:add_item('aa_fake_jitter_air_checkbox', 0);
local fake_jitter_air_checkbox = menu:add_checkbox('Fake Jitter Air', 'Rage', 'Anti-Aim', 'Air', fake_jitter_air_checkbox_item);
local fake_jitter_air_min_slider_item = config:add_item( "aa_fake_jitter_air_min_slider", 0 );
local fake_jitter_air_min_slider = menu:add_slider( "Fake Jitter Air Min", "Rage", "Anti-Aim", "Air", fake_jitter_air_min_slider_item, -100, 99, 1 );
local fake_jitter_air_max_slider_item = config:add_item( "aa_fake_jitter_max_air_slider", 0 );
local fake_jitter_air_max_slider = menu:add_slider( "Fake Jitter Air Max", "Rage", "Anti-Aim", "Air", fake_jitter_air_max_slider_item, -99, 100, 1 );
local fake_jitter_air_delay_slider_item = config:add_item( "aa_fake_jitter_air_delay_slider", 0 );
local fake_jitter_air_delay_slider = menu:add_slider( "Jitter Delay", "Rage", "Anti-Aim", "Air", fake_jitter_air_delay_slider_item, 0, 60, 0.1 );

local backups = {
    fake_stand = menu:get_reference( "Rage", "Anti-Aim", "Standing", "Fake amount" ):get_int( );
    fake_move = menu:get_reference( "Rage", "Anti-Aim", "Moving", "Fake amount" ):get_int( );
    fake_air = menu:get_reference( "Rage", "Anti-Aim", "Air", "Fake amount" ):get_int( );
};


local function switch()
    if fake_jitter_stand_checkbox_item:get_bool() then
        if last_tick_stand + fake_jitter_stand_delay_slider_item:get_float() < globals.realtime then
            if in_use_stand then
                menu:get_reference( "Rage", "Anti-Aim", "Standing", "Fake amount" ):set_int( fake_jitter_stand_min_slider_item:get_int() );
                in_use_stand = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Standing", "Fake amount" ):set_int( fake_jitter_stand_max_slider_item:get_int() );
                in_use_stand = true;
            end
            last_tick_stand = globals.realtime;
        end
    end

    if fake_jitter_move_checkbox_item:get_bool() then
        if last_tick_move + fake_jitter_move_delay_slider_item:get_float() < globals.realtime then
            if in_use_move then
                menu:get_reference( "Rage", "Anti-Aim", "Moving", "Fake amount" ):set_int( fake_jitter_move_min_slider_item:get_int() );
                in_use_move = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Moving", "Fake amount" ):set_int( fake_jitter_move_max_slider_item:get_int() );
                in_use_move = true;
            end
            last_tick_move = globals.realtime;
        end
    end

    if fake_jitter_air_checkbox_item:get_bool() then
        if last_tick_air + fake_jitter_air_delay_slider_item:get_float() < globals.realtime then
            if in_use_air then
                menu:get_reference( "Rage", "Anti-Aim", "Air", "Fake amount" ):set_int( fake_jitter_air_min_slider_item:get_int() );
                in_use_air = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Air", "Fake amount" ):set_int( fake_jitter_air_max_slider_item:get_int() );
                in_use_air = true;
            end
            last_tick_air = globals.realtime;
        end
    end
end

callbacks:add("paint", switch)