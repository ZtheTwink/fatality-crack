local iHandle   = csgo.interface_handler;

local menu      = fatality.menu;
local config    = fatality.config;
local input     = fatality.input;
local callbacks = fatality.callbacks;
local input     = fatality.input;
local render    = fatality.render;

local globals       = iHandle:get_global_vars();
local engine        = iHandle:get_engine_client();
local screen_size   = render:screen_size();

local last_timer        = globals.tickcount;
local last_tick_stand   = globals.realtime;
local last_tick_move    = globals.realtime;
local last_tick_air     = globals.realtime;




local key = 0x12; -- change the key here https://docs.microsoft.com/en-us/windows/desktop/inputdev/virtual-key-codes

local in_use_stand  = false;
local in_use_move   = false;
local in_use_air    = false;

local fake_jitter_stand_checkbox_item = config:add_item('aa_fake_jitter_stand_checkbox', 0);
local fake_jitter_stand_checkbox = menu:add_checkbox('Fake Jitter Stand', 'Rage', 'Anti-Aim', 'Standing', fake_jitter_stand_checkbox_item);
local fake_jitter_stand_invert_checkbox_item = config:add_item('fake_jitter_stand_invert_checkbox', 0);
local fake_jitter_stand_invert_checkbox = menu:add_checkbox('Fake Jitter Standing Invertible', 'Rage', 'Anti-Aim', 'Standing', fake_jitter_stand_invert_checkbox_item);
local fake_jitter_stand_min_slider_item = config:add_item( "aa_fake_jitter_stand_min_slider", 0 );
local fake_jitter_stand_min_slider = menu:add_slider( "Fake Jitter Stand Min", "Rage", "Anti-Aim", "Standing", fake_jitter_stand_min_slider_item, -100, 99, 1 );
local fake_jitter_stand_max_slider_item = config:add_item( "aa_fake_jitter_max_stand_slider", 0 );
local fake_jitter_stand_max_slider = menu:add_slider( "Fake Jitter Stand Max", "Rage", "Anti-Aim", "Standing", fake_jitter_stand_max_slider_item, -99, 100, 1 );
local fake_jitter_stand_delay_slider_item = config:add_item( "aa_fake_jitter_stand_delay_slider", 0 );
local fake_jitter_stand_delay_slider = menu:add_slider( "Jitter Delay", "Rage", "Anti-Aim", "Standing", fake_jitter_stand_delay_slider_item, 0, 60, 0.1 );

local fake_jitter_move_checkbox_item = config:add_item('aa_fake_jitter_move_checkbox', 0);
local fake_jitter_move_checkbox = menu:add_checkbox('Fake Jitter Move', 'Rage', 'Anti-Aim', 'Moving', fake_jitter_move_checkbox_item);
local fake_jitter_move_invert_checkbox_item = config:add_item('fake_jitter_move_invert_checkbox', 0);
local fake_jitter_move_invert_checkbox = menu:add_checkbox('Fake Jitter Moving Invertible', 'Rage', 'Anti-Aim', 'Moving', fake_jitter_move_invert_checkbox_item);
local fake_jitter_move_min_slider_item = config:add_item( "aa_fake_jitter_move_min_slider", 0 );
local fake_jitter_move_min_slider = menu:add_slider( "Fake Jitter Moving Min", "Rage", "Anti-Aim", "Moving", fake_jitter_move_min_slider_item, -100, 99, 1 );
local fake_jitter_move_max_slider_item = config:add_item( "aa_fake_jitter_max_move_slider", 0 );
local fake_jitter_move_max_slider = menu:add_slider( "Fake Jitter Moving Max", "Rage", "Anti-Aim", "Moving", fake_jitter_move_max_slider_item, -99, 100, 1 );
local fake_jitter_move_delay_slider_item = config:add_item( "aa_fake_jitter_move_delay_slider", 0 );
local fake_jitter_move_delay_slider = menu:add_slider( "Jitter Delay", "Rage", "Anti-Aim", "Moving", fake_jitter_move_delay_slider_item, 0, 60, 0.1 );

local fake_jitter_air_checkbox_item = config:add_item('aa_fake_jitter_air_checkbox', 0);
local fake_jitter_air_checkbox = menu:add_checkbox('Fake Jitter Air', 'Rage', 'Anti-Aim', 'Air', fake_jitter_air_checkbox_item);
local fake_jitter_air_invert_checkbox_item = config:add_item('fake_jitter_air_invert_checkbox', 0);
local fake_jitter_air_invert_checkbox = menu:add_checkbox('Fake Jitter Air Invertible', 'Rage', 'Anti-Aim', 'Air', fake_jitter_air_invert_checkbox_item);
local fake_jitter_air_min_slider_item = config:add_item( "aa_fake_jitter_air_min_slider", 0 );
local fake_jitter_air_min_slider = menu:add_slider( "Fake Jitter Air Min", "Rage", "Anti-Aim", "Air", fake_jitter_air_min_slider_item, -100, 99, 1 );
local fake_jitter_air_max_slider_item = config:add_item( "aa_fake_jitter_max_air_slider", 0 );
local fake_jitter_air_max_slider = menu:add_slider( "Fake Jitter Air Max", "Rage", "Anti-Aim", "Air", fake_jitter_air_max_slider_item, -99, 100, 1 );
local fake_jitter_air_delay_slider_item = config:add_item( "aa_fake_jitter_air_delay_slider", 0 );
local fake_jitter_air_delay_slider = menu:add_slider( "Jitter Delay", "Rage", "Anti-Aim", "Air", fake_jitter_air_delay_slider_item, 0, 60, 0.1 );


function swap()

    local backups = {
        fake_stand_min = menu:get_reference( "Rage", "Anti-Aim", "Standing", "Fake Jitter Stand Min" ):get_int( );
        fake_stand_max = menu:get_reference( "Rage", "Anti-Aim", "Standing", "Fake Jitter Stand Max" ):get_int( );

        fake_move_min = menu:get_reference( "Rage", "Anti-Aim", "Moving", "Fake Jitter Moving Min" ):get_int( );
        fake_move_max = menu:get_reference( "Rage", "Anti-Aim", "Moving", "Fake Jitter Moving Max" ):get_int( );

        fake_air_min = menu:get_reference( "Rage", "Anti-Aim", "Air", "Fake Jitter Air Min" ):get_int( );
        fake_air_max = menu:get_reference( "Rage", "Anti-Aim", "Air", "Fake Jitter Air Max" ):get_int( );
    };

    if fake_jitter_stand_invert_checkbox_item:get_bool() then
        menu:get_reference( "Rage", "Anti-Aim", "Standing", "Fake Jitter Stand Min" ):set_int( backups.fake_stand_max);
        menu:get_reference( "Rage", "Anti-Aim", "Standing", "Fake Jitter Stand Max" ):set_int( backups.fake_stand_min);
    end
    if fake_jitter_move_invert_checkbox_item:get_bool() then
        menu:get_reference( "Rage", "Anti-Aim", "Moving", "Fake Jitter Moving Min" ):set_int( backups.fake_move_max);
        menu:get_reference( "Rage", "Anti-Aim", "Moving", "Fake Jitter Moving Max" ):set_int( backups.fake_move_min);
    end
    if fake_jitter_air_invert_checkbox_item:get_bool() then
        menu:get_reference( "Rage", "Anti-Aim", "Air", "Fake Jitter Air Min" ):set_int( backups.fake_air_max);
        menu:get_reference( "Rage", "Anti-Aim", "Air", "Fake Jitter Air Max" ):set_int( backups.fake_air_min);
    end

end

local function switch()
    if fake_jitter_stand_checkbox_item:get_bool() then
        if last_tick_stand + fake_jitter_stand_delay_slider_item:get_float() < globals.realtime then
            if in_use_stand then
                menu:get_reference( "Rage", "Anti-Aim", "Standing", "Fake amount" ):set_int( fake_jitter_stand_min_slider_item:get_int() );
                in_use_stand = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Standing", "Fake amount" ):set_int( fake_jitter_stand_max_slider_item:get_int() );
                in_use_stand = true;
            end
            last_tick_stand = globals.realtime;
        end
    end

    if fake_jitter_move_checkbox_item:get_bool() then
        if last_tick_move + fake_jitter_move_delay_slider_item:get_float() < globals.realtime then
            if in_use_move then
                menu:get_reference( "Rage", "Anti-Aim", "Moving", "Fake amount" ):set_int( fake_jitter_move_min_slider_item:get_int() );
                in_use_move = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Moving", "Fake amount" ):set_int( fake_jitter_move_max_slider_item:get_int() );
                in_use_move = true;
            end
            last_tick_move = globals.realtime;
        end
    end

    if fake_jitter_air_checkbox_item:get_bool() then
        if last_tick_air + fake_jitter_air_delay_slider_item:get_float() < globals.realtime then
            if in_use_air then
                menu:get_reference( "Rage", "Anti-Aim", "Air", "Fake amount" ):set_int( fake_jitter_air_min_slider_item:get_int() );
                in_use_air = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Air", "Fake amount" ):set_int( fake_jitter_air_max_slider_item:get_int() );
                in_use_air = true;
            end
            last_tick_air = globals.realtime;
        end
    end

    if ( input:is_key_down( key ) and globals.tickcount - last_timer > 20 ) then
        swap();
        inverted = not inverted;
        last_timer = globals.tickcount;
    end

end

callbacks:add("paint", switch)