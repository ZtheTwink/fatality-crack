-- Light event-log by eslipe v.1.0 (23.03.2019)
 
--[[ Updatelog:
 
(23.03.2019)
- Release
 
]]
 
-- interfaces
local cvar = csgo.interface_handler:get_cvar( )
local render = fatality.render
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
 
-- config & menu access
local menu = fatality.menu
local config = fatality.config
 
-- adding developer cvar to set it to 0 in future
local developer = cvar:find_var("developer")
 
-- setting cvar to 0
developer:set_int(0)
 
-- creating logs variable to place the logs there
local logs = {}
 
-- creating function to take logs from on shot function
function add_log(text)
    table.insert(logs, {text = text, expiration = 10, fadein = 0})
end
 
-- needed variables
local normal_font = render:create_font( "Lucida Console", 10, 0, true );
local screensize = render:screen_size();
 
 
-- on pain function
function on_paint()
 
 
 
    -- event log
    for i = 1, #logs do
 
        -- nil check
        if (logs[i] ~= nil) then
 
            -- variable of ratio
            local ratio = 1.5
 
            -- setting the time of animation
            if (logs[i].expiration <= 1.5) then
                ratio = (logs[i].expiration) / 1
            end
 
 
            -- smoothly animated alpha
            if (logs[i].expiration <= 2.5) then
                alpha = 240
            elseif (logs[i].expiration <= 2.4) then
                alpha = 180
            elseif (logs[i].expiration <= 2.3) then
                alpha = 140
            elseif (logs[i].expiration <= 2.2) then
                alpha = 120
            elseif (logs[i].expiration <= 2.1) then
                alpha = 100
            elseif (logs[i].expiration <= 2.0) then
                alpha = 60
            elseif (logs[i].expiration <= 1.9) then
                alpha = 0
            elseif (logs[i].expiration <= 1.8) then
                alpha = 80
            elseif (logs[i].expiration <= 1.7) then
                alpha = 60
            elseif (logs[i].expiration <= 1.6) then
                alpha = 40
            elseif (logs[i].expiration <= 1.5) then
                alpha = 20
            elseif (logs[i].expiration <= 1.4) then
                alpha = 0
            else
                alpha = 255
            end
 
 
 
 
            render:text(normal_font, 7, 7 * (i - 1) * 2 - ((1 - ratio) * 15),  logs[i].text, csgo.color(255,255,255, alpha))
 
     
            -- removes log if time is expired
            logs[i].expiration = logs[i].expiration - 0.01
            if (logs[i].expiration <= 1.2) then
                table.remove(logs, i)
            end
 
        end
 
 
    end
 
end
 
 
 
 
-- on shot function
function on_registered_shot( shot )
 
 
    -- creating a variable of the enemy
    local enemy = entity_list:get_player( shot.victim )
 
    -- nil check
    if enemy == nil then
        return
    end
 
    -- getting shot info
    local shot_info_t = shot.shot_info
 
    -- returns the function if something goes wrong
    if not shot_info_t.has_info then
        return
    end
 
    -- creating a variable of default hitgroup
    local hitgroup=0
 
    -- if we did a hit
    if shot.hurt then
 
        local getHealth = enemy:get_var_int("CBasePlayer->m_iHealth")
 
        --
        hitgroup=shot.hit_hitgroup
 
        -- hitgroup renaming from int to string
        if hitgroup == 1 then
            hitgroup = "head"
            elseif hitgroup == 2 then
            hitgroup = "chest"
            elseif hitgroup == 3 then
            hitgroup = "stomach"
            elseif hitgroup == 4 then
            hitgroup = "hand"
            elseif hitgroup == 5 then
            hitgroup = "Arm"
            elseif hitgroup == 6 then
            hitgroup = "Leg"
            elseif hitgroup == 7 then
            hitgroup = "Leg"
            elseif hitgroup == 8 then
            hitgroup = "Neck"
            else
            hitgroup = "Unknown"
        end
 
         -- if the cheat did a hit, then render this line
        add_log("Hit " .. enemy:get_name( ) .. " in " .. "the " .. hitgroup .. " for " .. shot.hit_damage .. " damage" .. " (" .. getHealth .. " health remaining)")
 
    -- if the cheat did a miss because of the resolver problem  
    elseif not shot.hurt and shot.hit then
 
        -- log that shows if we did a miss
        add_log("Missed shot due to resolver")
       
    -- miss due to accuracy
    else
        -- log that shows if we did a miss
        add_log("Missed shot due to spread")
 
    end
 
end
 
 
 
-- callbacks
local callbacks = fatality.callbacks
callbacks:add( "registered_shot", on_registered_shot )
callbacks:add( "paint", on_paint )
 
-- end of the code