-- https://fatality.win/threads/lua-esp-filled-box-release.3186/

-- Fatality interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local input = fatality.input

-- Interfaces
local globals = csgo.interface_handler:get_global_vars()
local engine = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()
local cvar = csgo.interface_handler:get_cvar()

-- Fonts
local fonts =
{
    main = render:create_font( "Verdana", 12, 600, true ),
    small = render:create_font( "Smallest Pixel-7", 10, 400, true )
}

local local_player = entity_list:get_localplayer()

function is_enemy(enemy)
    if(enemy ~= nil and enemy:is_alive() and (enemy:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum"))) then
        return true
    end
    return false
end

function draw_name(x, y, dst, text, color)
    local width = 450 / dst
    local height = 500 / dst
    --render:rect(x - (width / 2), y - height, width, height, csgo.color(255,0,0,255))
    --name
    render:text(fonts.main, x - (width / 2) * 1.1, y - height * 0.6, text, color)
end
local width
local height


function draw_distance(x, y, dst, text, color)
    local width = 450 / dst
    local height = 500 / dst
    --render:rect(x - (width / 2), y - height, width, height, csgo.color(255,0,0,255))
   
    --distance
    render:text(fonts.small,x - (width / 2) * 0.6, y - height * -2.4, text, color)
end

function draw_box(x, y, dst, color, color)
    local width = 650 / dst
    local height = 1350 / dst
    render:rect_fade(x - (width / 2), y - height / 10, width, height , color , color , false)
    local width
local height

if local_player:get_var_bool("CCSPlayer->m_bIsScoped") == true then
       width = 1900 / dst
        height = 3810 / dst
else
        width = 650 / dst
        height = 1350 / dst
end

render:rect_fade(x - (width / 2), y - height / 10, width, height , color , color , false)
if local_player:get_var_bool("CWeaponCSBaseGun->m_zoomLevel") == true then
   width = 6000 / dst
    height = 10000 / dst
else
       width = 1700 / dst
        height = 3200 / dst
    end

end

function on_paint()

    -- Trash
    local screensize = render:screen_size()

    if(engine:is_in_game()) then

    for i = 1, entity_list:get_max_players(), 1 do
        local player = entity_list:get_player(i)

        if player == nil or not is_enemy(player) then
            goto continue end

            local pos = player:get_eye_pos()
            local localpos = local_player:get_eye_pos()

        if pos:to_screen() then
            local textsize = render:text_size(fonts.main , player:get_name())

            local name = player:get_name()

            if string.len( name ) > 7 then
                name = string.sub( name, 0, 7) .. "..."
            end

            local alpha
            local time = 0
            alpha = 127 + (127 * math.floor(math.sin(time)))
           
            local localorigin = local_player:get_var_vector("CBaseEntity->m_vecOrigin")
            local origin = player:get_var_vector("CBaseEntity->m_vecOrigin")

            local distance = math.sqrt(math.pow(localorigin.x - origin.x, 2) + math.pow(localpos.y - origin.y, 2) +  math.pow(localpos.z - origin.z, 2)) * 0.0254

            local distance2 = math.sqrt(math.pow(localorigin.x - origin.x, 2) + math.pow(localpos.y - origin.y, 2) +  math.pow(localpos.z - origin.z, 2)) * 0.0254

            if string.len( distance ) > 2 then
                distance = string.sub( distance, 0, 2) .. "FT"
            end

            local width = 300 / distance2
            local height = 200 / distance2

            if not player:is_dormant() then
                draw_name(pos.x , pos.y , distance2 , name, csgo.color(255,255,255,255))
                draw_distance(pos.x , pos.y , distance2, distance, csgo.color(255,255,255,255))
                draw_box(pos.x , pos.y , distance2, csgo.color(0,255,0,150), csgo.color(0, 174, 255,150))
            else
                draw_name(pos.x , pos.y , distance2 , name, csgo.color(60,60,60,alpha))
                draw_distance(pos.x , pos.y , distance2, distance, csgo.color(60,60,60,alpha))
                draw_box(pos.x , pos.y , distance2, csgo.color(60,60,60,80), csgo.color(60,60,60,80))
            end
        end
        ::continue::
    end
end
end

-- Register callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )