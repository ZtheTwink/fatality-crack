--[[
    -- BETA Legitbot LUA created by PuL9
    -- fatality.win
]]
 
local global_vars       = csgo.interface_handler:get_global_vars()
local engine_client     = csgo.interface_handler:get_engine_client()
local entity_list       = csgo.interface_handler:get_entity_list()
local render            = fatality.render
local menu              = fatality.menu
local input             = fatality.input
local config            = fatality.config
local fmath             = fatality.math
 
local font = render:create_font("Tahoma", 24, 1, false)
 
local rcs_x_item = config:add_item("p9_lb_rcs_x", 1.5)
local rcs_y_item = config:add_item("p9_lb_rcs_y", 2)
local target_x_offset_item = config:add_item("p9_lb_target_x_offset", 1.5)
local distance_item = config:add_item("p9_lb_distance", 200)
 
local rcs_x_ref = menu:add_slider("RCS X", "LEGIT", "", "Aim assist", rcs_x_item, 0, 2, 0.1)
local rcs_y_ref = menu:add_slider("RCS Y", "LEGIT", "", "Aim assist", rcs_y_item, 0, 2, 0.1)
local rcs_distance_ref = menu:add_slider("RCS distance", "LEGIT", "", "Aim assist", distance_item, 0, 1000, 1)
 
function spotted(player)
    local local_player = entity_list:get_localplayer()
    local bspotted = player:get_var_int("CBaseEntity->m_bSpotted")
    bspotted = (bspotted << (local_player:get_index() - 1))
    return bspotted == 1
end
 
local local_player = nil
local closest_hitbox = nil
local enemies = {}
 
function is_enemy(enemy)
    if(enemy ~= nil and enemy:is_alive() and spotted(enemy) and (enemy:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum"))) then
        return true
    end
    return false
end
 
function calc_hitbox_distance(hitbox)
    if(hitbox == nil) then
        return 100000
    end
    local screen_size = render:screen_size()
    local hitbox_screen = csgo.vector3(hitbox.x, hitbox.y, hitbox.z)
   
    if(hitbox_screen:to_screen()) then
        return math.sqrt(math.pow(screen_size.x / 2 - hitbox_screen.x, 2) + math.pow(screen_size.y / 2 - hitbox_screen.y, 2))
    end
   
    return 100000
end
 
function get_closest_hitbox()
    local rcs_distance = config:get_item("p9_lb_distance"):get_int()
    closest_hitbox = nil
   
    for i = 1, #enemies do
        for j = 1, #enemies[i].hitboxes do
            local hitbox = enemies[i].hitboxes[j]
           
            if(closest_hitbox == nil) then
                closest_hitbox = hitbox
            end
           
            if(calc_hitbox_distance(hitbox) < calc_hitbox_distance(closest_hitbox)) then
                closest_hitbox = hitbox
            end
        end
    end
   
    if(calc_hitbox_distance(closest_hitbox) >= rcs_distance) then
        return nil
    end
   
    return closest_hitbox
end
 
function update_enemies()  
    enemies = {}
   
    for i = 1, 33 do
        local enemy = entity_list:get_player(i)
        if(is_enemy(enemy)) then
            local hitboxes = {}
           
            for j = 0, 17 do
                table.insert(hitboxes, enemy:get_hitbox_pos(j))
            end
           
            table.insert(enemies, { enemy = enemy, hitboxes = hitboxes })
        end
    end
   
    closest_hitbox = get_closest_hitbox()
end
 
function aimbot()
    if(closest_hitbox ~= nil) then
        local angle = fmath:calc_angle(local_player:get_eye_pos(), closest_hitbox)
        local aimpunch_angle = local_player:get_var_vector("CBasePlayer->m_aimPunchAngle")
       
        local rcs_x = config:get_item("p9_lb_rcs_x"):get_float()
        local rcs_y = config:get_item("p9_lb_rcs_y"):get_float()
       
        engine_client:client_cmd("setang " .. angle.x - aimpunch_angle.x * rcs_x .. " " .. angle.y - aimpunch_angle.y * rcs_y)
    end
end
 
fatality.callbacks:add("paint", function(e)
    if(engine_client:is_in_game()) then
        local_player = entity_list:get_localplayer()
       
        if(input:is_key_down(0x01)) then
            aimbot()
        else
            update_enemies()
        end
    end
end)