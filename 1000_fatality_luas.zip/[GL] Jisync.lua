﻿--ORIGINAL LUA MADE BY https://fatality.win/members/jewls.2668/ : https://fatality.win/threads/sway-desync-type.4493/#post-38680

--pasted & modified by banda#6448 :D

--Alandi#2131 helped with the fakelag shit

--Jisynced by Rebirator aka GLadiator



local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks



-----------------------------------DESYNC AMOUNT MOVING

local moveDesync = menu:get_reference('rage', 'anti-aim', 'moving', 'fake amount')
local invert = true

moveDesync:set_float(0)

function on_paint()
    if invert then
        if moveDesync:get_int() == -100 then
            invert = false
        else
        moveDesync:set_float(moveDesync:get_float() - 0.5)
    end
end

    if not invert then
        if moveDesync:get_int() == -70 then
            invert = true
        else
        moveDesync:set_float(moveDesync:get_float() + 1.0)
        end
    end
end

callbacks:add('paint', on_paint)



----------------------------DESYNC AMOUNT STANDING

local standDesync = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount')
local invert = true

standDesync:set_float(0)

function on_paint()
    if invert then
        if standDesync:get_int() == -100 then
            invert = false
          else
          standDesync:set_float(standDesync:get_float() - 0.1)
        end
    end

    if not invert then
        if standDesync:get_int() == -60 then -- -50
        invert = true
      else
          standDesync:set_float(standDesync:get_float() + 0.3)
        end
    end
end

callbacks:add('paint', on_paint)



------------------------------------FAKELAG STANDING

local standFakelag = menu:get_reference('rage', 'anti-aim', 'standing', 'base amount')
local invert = true

standFakelag:set_float(0)

function on_paint()
    if invert then
        if standFakelag:get_int() == 14 then
            invert = false
    else
        standFakelag:set_float(standFakelag:get_float() + 0.9) --change values here
        end
    end

    if not invert then
        if standFakelag:get_int() ==  1 then
            invert = true
    else
        standFakelag:set_float(standFakelag:get_float() - 0.2) --change values here
        end
    end
end

callbacks:add('paint', on_paint)


----------------------------------FAKELAG MOVING

local moveingFakelag = menu:get_reference('rage', 'anti-aim', 'moving', 'base amount')
local invert = true

moveingFakelag:set_float(0)

function on_paint()
    if invert then
        if moveingFakelag:get_int() == 12 then
            invert = false
    else
            moveingFakelag:set_float(moveingFakelag:get_float() + 0.1) --change values here
        end
    end

    if not invert then
        if moveingFakelag:get_int() ==  8 then
            invert = true
    else
        moveingFakelag:set_float(moveingFakelag:get_float() - 0.03) --change values here
        end
    end
end

callbacks:add('paint', on_paint)


----------------------------------FAKELAG AIR

local airingFakelag = menu:get_reference('rage', 'anti-aim', 'air', 'base amount')
local invert = true

airingFakelag:set_float(0)

function on_paint()
    if invert then
        if airingFakelag:get_int() == 14 then
            invert = false
    else
            airingFakelag:set_float(airingFakelag:get_float() + 0.1) --change values here
        end
    end

    if not invert then
        if airingFakelag:get_int() ==  11 then
            invert = true
    else
        airingFakelag:set_float(airingFakelag:get_float() - 0.05) --change values here
        end
    end
end

callbacks:add('paint', on_paint)