local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local entity_list = csgo.interface_handler:get_entity_list()
local global_vars = csgo.interface_handler:get_global_vars()

local screen_size = render:screen_size()

local fake_mode_item = config:add_item("p9_fake_mode", 0)
local fake_mode_randomize_item = config:add_item("p9_fake_mode_randomize", 0)

local fake_mode_combo = menu:add_combo("AA Mode", "RAGE", "ANTI-AIM", "General", fake_mode_item)
local fake_mode_checkbox = menu:add_checkbox("AA Randomize", "RAGE", "ANTI-AIM", "General", fake_mode_randomize_item)

local fake_direction_stand = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake direction")
local fake_direction_move = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake direction")

local stand_yaw_add = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Yaw add")
local moving_yaw_add = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Yaw add")

local stand_add = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Add")
local moving_add = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Add")

local hotkey = 0x58
local side = false
local tickcount = 0

local local_player

local colors =
{
    blue = csgo.color(0, 100, 255, 255),
    green = csgo.color(0, 255, 100, 255)
}

fake_mode_combo:add_item("Manual", fake_mode_item)
fake_mode_combo:add_item("Jitter", fake_mode_item)

-- left true, right false
function draw_arrow(x, y, size, color, side)
    if(side) then
        for i = 0, (size - 1) do
            render:rect(x - i, y + (i / 2) + 1, 1, size - i, color)
        end
    else
        for i = 0, (size - 1) do
            render:rect(x + i, y + (i / 2) + 1, 1, size - i, color)
        end
    end
end

function set_direction(dir)
    fake_direction_stand:set_int(dir)
    fake_direction_move:set_int(dir)
end

function set_add(val)
    stand_add:set_int(val)
    moving_add:set_int(val)
end

fatality.callbacks:add("events", function(e)
    if(e:get_name() == "player_hurt" and fake_mode_randomize_item:get_bool()) then
        local hurted_player = entity_list:get_player_from_id(e:get_int("userid"))
        local localplayer = entity_list:get_localplayer()
        
        if(hurted_player:get_index() == local_player:get_index()) then
            side = not side
        end
    end
end)

fatality.callbacks:add("paint", function()
    if(tickcount > global_vars.tickcount) then tickcount = 0 end
    
    local_player = entity_list:get_localplayer()
    
    if(local_player ~= nil and local_player:is_alive()) then
        
        if(input:is_key_pressed(hotkey)) then
            side = not side
        end
        
        if(fake_mode_item:get_int() == 0) then
            if(side) then -- left
                draw_arrow(screen_size.x / 2 - 10 - 30, screen_size.y / 2 - 10, 20, colors.green, side)
                set_direction(2)
            else -- right
                draw_arrow(screen_size.x / 2 + 10 + 30, screen_size.y / 2 - 10, 20, colors.green, side)
                set_direction(3)
            end
            
        elseif(fake_mode_item:get_int() == 1) then
            if(global_vars.tickcount > (tickcount + 1)) then
                tickcount = global_vars.tickcount
                
                stand_yaw_add:set_bool(false)
                moving_yaw_add:set_bool(false)
                
                side = not side
                if(side) then
                    set_direction(2)
                else
                    set_direction(3)
                end
            end
        end
    end
end)