-- https://fatality.win/threads/disable-anti-aim-on-grenade.590/

local entity_list = csgo.interface_handler:get_entity_list( );

local menu = fatality.menu
local config = fatality.config;

local main_item = config:add_item( "aa_disablenade", 0.0 );
local aa_disable_on_nade = config:add_item( "aa_disable_on_nade", 0.0 );
local aa_disable_on_nade_pulled = config:add_item( "aa_disable_on_nade_pulled", 0.0 );
local aa_combobox = menu:add_combo( "Disable AA", "rage", "anti-aim", "general", main_item );

aa_combobox:add_item( "on nade", aa_disable_on_nade );
aa_combobox:add_item( "on nade pulled", aa_disable_on_nade_pulled );

function get_player_weapon( )
    local local_player = entity_list:get_localplayer( );
    if ( local_player == nil or not local_player:is_alive( ) ) then
        return end
    local player_weapon = entity_list:get_from_handle( local_player:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) );
    return player_weapon and not player_weapon:is_player( ) and player_weapon:get_class_id( );
end

function nade_pulled( )
   local local_player = entity_list:get_localplayer( );
    if ( local_player == nil or not local_player:is_alive( ) ) then
        return end
    local player_weapon = entity_list:get_from_handle( local_player:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) );
    return player_weapon and not player_weapon:is_player( ) and player_weapon:get_var_bool( "CBaseCSGrenade->m_bPinPulled" );
end

function is_grenade( weapon_id )
    grenades = { 94, 45, 110, 152, 97, 75 };
    for i=1,#grenades do
      if ( grenades[i] == weapon_id ) then
         return true;
      end
   end
end

function on_paint( )
    if ( is_grenade( get_player_weapon( ) ) ) then
        if ( main_item:get_int( ) == 1 and nade_pulled( ) ) then
            config:get_item( "aa.enabled" ):set_bool( false );
        else if ( main_item:get_int( ) == 0 ) then
            config:get_item( "aa.enabled" ):set_bool( false );
            end
        end
    else
        config:get_item( "aa.enabled" ):set_bool( true );
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );