﻿--50brake remake lua 

--thanks for banda to giving this 


local render = fatality.render

local menu = fatality.menu

local config = fatality.config

local callbacks = fatality.callbacks




-----------------------------------DESYNC AMOUNT MOVING-----------------------------------

local moveDesync = menu:get_reference('rage', 'anti-aim', 'moving', 'fake amount')



local invert = true



moveDesync:set_float(0)



function on_paint()

    

    if invert then

        if moveDesync:get_int() == -87 then

            invert = false

        else

        moveDesync:set_float(moveDesync:get_float() -15)

    end

end

    if not invert then

        if moveDesync:get_int() == 95 then

            invert = true

        else

        moveDesync:set_float(moveDesync:get_float() + 13)

        end

    end

end





callbacks:add('paint', on_paint)



----------------------------DESYNC AMOUNT STANDING

local standDesync = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount')



local invert = true



standDesync:set_float(0)



function on_paint()

    

    if invert then

        if standDesync:get_int() == -100 then

            invert = false

          else

          standDesync:set_float(standDesync:get_float() - 5)

        end

    end

    if not invert then

        if standDesync:get_int() == -50 then

        invert = true

      else

          standDesync:set_float(standDesync:get_float() + 5)

        end

    end

end

callbacks:add('paint', on_paint)







------------------------------------FAKELAG STANDING

local standFakelag = menu:get_reference('rage', 'anti-aim', 'standing', 'base amount')



local invert = true



standFakelag:set_float(0)



function on_paint()

    

    if invert then

        if standFakelag:get_int() == 8 then

            invert = false

    else

        standFakelag:set_float(standFakelag:get_float() + 0.1) --change values here

        end

    end

    if not invert then

        if standFakelag:get_int() ==  4 then

            invert = true

    else

        standFakelag:set_float(standFakelag:get_float() - 0.2) --change values here

        end

    end

end

callbacks:add('paint', on_paint)



----------------------------------FAKELAG MOVING

local moveingFakelag = menu:get_reference('rage', 'anti-aim', 'moving', 'base amount')



local invert = true



moveingFakelag:set_float(0)



function on_paint()

    if invert then

        if moveingFakelag:get_int() == 10 then

            invert = false

    else

            moveingFakelag:set_float(moveingFakelag:get_float() + 0.1) --change values here

        end

    end

    if not invert then

        if moveingFakelag:get_int() ==  7 then

            invert = true

    else

        moveingFakelag:set_float(moveingFakelag:get_float() - 0.01) --change values here

        end

    end

end

callbacks:add('paint', on_paint)

-------------------------------------------Slow walk------------------------
local cvar = csgo.interface_handler:get_cvar( );
local config = fatality.config
local menu = fatality.menu
local input = fatality.input;

cl_sidespeed = cvar:find_var( "cl_sidespeed" );
cl_forwardspeed = cvar:find_var( "cl_forwardspeed" );
cl_backspeed = cvar:find_var( "cl_backspeed" );

function set_speed( new_speed )
    if ( cl_sidespeed:get_int( ) == 450 and new_speed == 450 ) then
        return;
    end
     cl_sidespeed:set_float( new_speed );
     cl_forwardspeed:set_float( new_speed );
     cl_backspeed:set_float( new_speed );
end

local slowwalk_item = config:add_item( "slowwalk_rage", 0.0 )
local slowwalk_slider = menu:add_slider( "Slow walk", "rage", "aimbot", "aimbot", slowwalk_item, 1, 100, 1 )

function on_paint( )
local is_down = input:is_key_down( 16 );
if not ( is_down ) then
set_speed( 450 )
else
local final_val = 250 * slowwalk_item:get_float( ) / 100
set_speed( final_val )
end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );