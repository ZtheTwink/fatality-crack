-- https://fatality.win/threads/disable-fakelag-on-r8.601/

local entity_list = csgo.interface_handler:get_entity_list( );

local menu = fatality.menu;

function get_player_weapon( )
    local local_player = entity_list:get_localplayer( );
    if ( local_player == nil or not local_player:is_alive( ) ) then
        return end
    local player_weapon = entity_list:get_from_handle( local_player:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) );
    if ( player_weapon ) then
        item_definition = player_weapon:get_var_short( "CBaseAttributableItem->m_iItemDefinitionIndex" );
    end
    return item_definition;
end

local fakelag_standbackup = menu:get_reference( "rage", "anti-aim", "standing", "fake lag" ):get_int( );
local fakelag_movebackup = menu:get_reference( "rage", "anti-aim", "moving", "fake lag" ):get_int( );

function on_paint( )
   if ( get_player_weapon( ) == 64 and menu:get_reference( "rage", "anti-aim", "moving", "fake lag" ):get_bool( ) or menu:get_reference( "rage", "anti-aim", "standing", "fake lag" ):get_bool( ) ) then
       menu:get_reference( "rage", "anti-aim", "standing", "fake lag" ):set_int( 0 );
       menu:get_reference( "rage", "anti-aim", "moving", "fake lag" ):set_int( 0 );
    else if ( get_player_weapon( ) ~= 64 and not menu:get_reference( "rage", "anti-aim", "standing", "fake lag" ):get_bool( ) or not not menu:get_reference( "rage", "anti-aim", "moving", "fake lag" ):get_bool( ) ) then
        menu:get_reference( "rage", "anti-aim", "standing", "fake lag" ):set_int( fakelag_standbackup );
        menu:get_reference( "rage", "anti-aim", "moving", "fake lag" ):set_int( fakelag_movebackup );
       end
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );