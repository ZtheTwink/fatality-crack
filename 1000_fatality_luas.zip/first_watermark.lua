-- https://fatality.win/threads/watermark.553/

local renderer = fatality.render;
local global_vars = csgo.interface_handler:get_global_vars( );

local callback = fatality.callbacks;

local tahoma = renderer:create_font("Tahoma", 20, 500, true);

--thanks reahly or whoever
local frame_rate = 0.0;

function get_abs_fps( )
    frame_rate = 0.9 * frame_rate + ( 1.0 - 0.9 ) * global_vars.frametime;
    return math.floor( ( 1.0 / frame_rate ) + 0.5 );
end


function on_paint()

local screen_size = renderer:screen_size();

local x = screen_size.x / 2 + 740; --ugly coz fuck proper maths
local y = screen_size.y / 2 - 530; --ugly coz fuck proper maths

    renderer:rect_fade( x, y, 210, 20, csgo.color(0, 50, 225, 200), csgo.color(120, 0, 230, 255), false);

    renderer:text(tahoma, x + 5, y, "fatality.win", csgo.color(255, 255, 255, 255));
    renderer:text(tahoma, x + 80, y, " | ", csgo.color(255, 255, 255, 255));
    renderer:text(tahoma, x + 95, y, tostring(get_abs_fps()), csgo.color(255, 255, 255, 255));
    renderer:text(tahoma, x + 125, y, os.date("fps | %H:%M"), csgo.color(255, 255, 255, 255));

end

callback:add("paint", "on_paint");