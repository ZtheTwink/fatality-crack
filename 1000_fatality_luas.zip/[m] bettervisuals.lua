-- june's lua megapack
-- this config was free at: discord.gg/XhMvwqr

-- interfaces
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local entity_list = csgo.interface_handler:get_entity_list()
local global_vars = csgo.interface_handler:get_global_vars()
 
 
-- getting reference of menu features
local aa_back = menu:get_reference( "rage", "anti-aim", "general", "back" )
local aa_right = menu:get_reference( "rage", "anti-aim", "general", "right" )
local aa_left = menu:get_reference( "rage", "anti-aim", "general", "left" )
print("better visuals LUA by _markjelo💀#9266")


-- adding features to the menu
local manualAA_item = config:add_item( "manual_arrows", 0 )
local manualAA_checkbox = menu:add_checkbox( "Manual arrows", "visuals", "misc", "local", manualAA_item )

local customDesign_item	 = config:add_item("Ma_customDesign_item", 0)
local customDesign_combo = menu:add_combo("Arrows design", "visuals", "misc", "local", customDesign_item)
customDesign_combo:add_item("- Centre (Icon)", customDesign_item)
customDesign_combo:add_item("- Centre (Font-Light)", customDesign_item)
customDesign_combo:add_item("- Centre (Font-Bold)", customDesign_item)
customDesign_combo:add_item("- Bottom (Icon)", customDesign_item)
customDesign_combo:add_item("- Bottom (Icon&BG)", customDesign_item)


local size_item = config:add_item( "size_item", 18 )
local size_slider = menu:add_slider( "Size of arrows", "visuals", "misc", "local", size_item, 15, 23, 1 )

local thickness_item = config:add_item( "thickness_item", 1 )
local thickness_slider = menu:add_slider( "Width of arrows", "visuals", "misc", "local", thickness_item, 1, 4, 1 )

local colour_item = config:add_item("Ma_colour_item", 14)
local colour_slider = menu:add_slider("Arrows colour", "visuals", "misc", "local", colour_item, 0 , 20, 1)

local chroma_item = config:add_item( "Ma_chroma_item", 0 )
local chroma_checkbox = menu:add_checkbox( "Chroma mode for enabled arrows", "visuals", "misc", "local", chroma_item )

local darkmode_item = config:add_item( "Ma_darkmode_item", 0 )
local darkmode_checkbox = menu:add_checkbox( "Dark mode for disabled arrows", "visuals", "misc", "local", darkmode_item )


-- fonts
local light_font = render:create_font( "Verdana Bold", 25, 400, false );
local bold_font = render:create_font( "Verdana Bold", 25, 800, false );


-- needed variables
local side = false
local back = false


-- left and right arrows
function draw_side_arrow(x, y, size, color, side)
    if(side) then
        for i = 0, (size - 1) do
            render:rect(x + i, y + (i / 2) + 1, 1, size - i, color)
        end
        
    else
        for i = 0, (size - 1) do
            render:rect(x - i, y + (i / 2) + 1, 1, size - i, color)
        end 
    end  
end


-- back arrow
function draw_back_arrow(x, y, size, color, side)
    if(back) then
        for i = 0, (size - 1) do
            render:rect(x - 0.5 - (i / 2), y - i / 50 + 30, 1, size - i, color)
        end
        for i = 0, (size - 1) do
            render:rect(x + (i / 2), y - i / 50 + 30, 1, size - i, color)
        end
        
    else
        for i = 0, (size - 1) do
            render:rect(x - i, y + (i / 2) + 1, 1, size - i, color)
        end 
    end  
end



-- rendering arrows
function on_paint()

    -- changing values from float to int
    local size_slider = size_item:get_float() * 1 
    local colour_value = colour_item:get_float( ) * 1

    -- colours
    local white_colour = csgo.color(100, 100, 100, 100)
    local black_colour = csgo.color(0, 0, 0, 100)

    -- rainbow RGB
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );


    -- colour changer (final version)
    if colour_value == 0 then
        custom_colour = csgo.color(255, 255, 255, 255) --< white
        elseif colour_value == 1 then
        custom_colour = csgo.color(0, 0, 0, 255) --< black
        elseif colour_value == 2 then
        custom_colour = csgo.color(255, 0, 0, 255) --< deep-red
        elseif colour_value == 3 then
        custom_colour = csgo.color(244,67,54, 255) --< red
        elseif colour_value == 4 then
        custom_colour = csgo.color(255,87,34, 255) --< light-red
        elseif colour_value == 5 then
        custom_colour = csgo.color(255,152,0, 255) --< deep-orange
        elseif colour_value == 6 then
        custom_colour = csgo.color(255,193,7, 255) --< orange
        elseif colour_value == 7 then
        custom_colour = csgo.color(255,235,59, 255) --< yellow
        elseif colour_value == 8 then
        custom_colour = csgo.color(205,220,57, 255) --< lime
        elseif colour_value == 9 then
        custom_colour = csgo.color(139,195,74, 255) --< light-green
        elseif colour_value == 10 then
        custom_colour = csgo.color(76,175,80, 255) --< green
        elseif colour_value == 11 then
        custom_colour = csgo.color(0,150,136, 255) --< teal
        elseif colour_value == 12 then
        custom_colour = csgo.color(0,188,212, 255) --< cyan
        elseif colour_value == 13 then
        custom_colour = csgo.color(3,169,244, 255) --< ligh-blue
        elseif colour_value == 14 then
        custom_colour = csgo.color(33,150,243, 255) --< blue
        elseif colour_value == 15 then
        custom_colour = csgo.color(63,81,181, 255) --< indigo
        elseif colour_value == 16 then
        custom_colour = csgo.color(103,58,183, 255) --< deep-purple
        elseif colour_value == 17 then
        custom_colour = csgo.color(156,39,176, 255) --< purple
        elseif colour_value == 18 then
        custom_colour = csgo.color(126,87,194, 255) --< -light-purple
        elseif colour_value == 19 then
        custom_colour = csgo.color(233,30,99, 255) --< deep-pink
        elseif colour_value == 20 then
        custom_colour = csgo.color(236,64,122, 255) --< light-pink
        else
        custom_colour = csgo.color(255, 255, 255, 255) --< default
    end

    if chroma_item:get_bool() then
        custom_colour = csgo.color(r, g, b, 255) --< chroma mode
    end

    if darkmode_item:get_bool() then
        white_colour = black_colour --< dark mode
    end

    -- getting localplayer variable
    local local_player = entity_list:get_localplayer()

    -- getting screen size
    local screen_size = render:screen_size()

      -- check box check
      if manualAA_item:get_bool() then

        -- local player check
        if(local_player ~= nil and local_player:is_alive()) then
       
                -- Centre (Icon)
                if customDesign_item:get_int() == 0 then

                        -- [ DISABLED ARROWS ] --
                        -- right 
                        side = true;
                        draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y / 2 - 10, size_slider, white_colour, side)
                       
                        -- left 
                        side = false;
                        draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y / 2 - 10, size_slider, white_colour, side)
            
                        -- back 
                        back = true;
                        draw_back_arrow(screen_size.x / 2, screen_size.y / 2 + 10, size_slider, white_colour, back)
                       
                        -- [ DISABLED ARROWS ] --



                        -- [ ENABLED ARROWS ] --
                        -- right activated
                        if aa_right:get_bool() then
                            side = true;
                            draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y / 2 - 10, size_slider, custom_colour, side)

                        -- left activated
                        elseif aa_left:get_bool() then
                            side = false;
                            draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y / 2 - 10, size_slider, custom_colour, side)

                        -- back activated
                        elseif aa_back:get_bool() then
                            back = true;
                            draw_back_arrow(screen_size.x / 2, screen_size.y / 2 + 10, size_slider, custom_colour, back)
                        -- [ ENABLED ARROWS ] --
                        end

                end    
                
               -- Font (Lights)
                if customDesign_item:get_int() == 1 then

                    -- [ DISABLED ARROWS ] --
                    -- right 
                    side = true;
                    render:text(light_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 11,  ">", white_colour)

                    -- left 
                    side = false;
                    render:text(light_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", white_colour)

                    -- back 
                    back = true;
                    render:text(light_font, screen_size.x / 2 - 5, screen_size.y / 2 + 25,  "v", white_colour)
                    -- [ DISABLED ARROWS ] --



                    -- [ ENABLED ARROWS ] --
                    -- right activated
                    if aa_right:get_bool() then
                    side = true;
                    render:text(light_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 11,  ">", custom_colour)

                    -- left activated
                    elseif aa_left:get_bool() then
                    side = false;
                    render:text(light_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", custom_colour)

                    -- back activated
                    elseif aa_back:get_bool() then
                    back = true;
                    render:text(light_font, screen_size.x / 2 - 5, screen_size.y / 2 + 25,  "v", custom_colour)
                    -- [ ENABLED ARROWS ] --
                    end
            end

            -- Font (Bold)
            if customDesign_item:get_int() == 2 then

                -- [ DISABLED ARROWS ] --
                -- right 
                side = true;
                render:text(bold_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 11,  ">", white_colour)

                -- left 
                side = false;
                render:text(bold_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", white_colour)

                -- back 
                back = true;
                render:text(bold_font, screen_size.x / 2 - 5, screen_size.y / 2 + 25,  "v", white_colour)
                -- [ DISABLED ARROWS ] --



                -- [ ENABLED ARROWS ] --
                -- right activated
                if aa_right:get_bool() then
                side = true;
                render:text(bold_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 11,  ">", custom_colour)

                -- left activated
                elseif aa_left:get_bool() then
                side = false;
                render:text(bold_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", custom_colour)

                -- back activated
                elseif aa_back:get_bool() then
                back = true;
                render:text(bold_font, screen_size.x / 2 - 5, screen_size.y / 2 + 25,  "v", custom_colour)
                -- [ ENABLED ARROWS ] --
                end
        end
            
                -- Bottom
                if customDesign_item:get_int() == 3 then
                        -- [ DISABLED ARROWS ] --
                        -- right 
                        side = true;
                        draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y - 50, size_slider, white_colour, side)

                        -- left 
                        side = false;
                        draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y - 50, size_slider, white_colour, side)

                        -- back 
                        back = true;
                        draw_back_arrow(screen_size.x / 2, screen_size.y - 77, size_slider, white_colour, back)
                        -- [ DISABLED ARROWS ] --



                        -- [ ENABLED ARROWS ] --
                        -- right activated
                        if aa_right:get_bool() then
                        side = true;
                        draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y - 50, size_slider, custom_colour, side)

                        -- left activated
                        elseif aa_left:get_bool() then
                        side = false;
                        draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y - 50, size_slider, custom_colour, side)

                        -- back activated
                        elseif aa_back:get_bool() then
                        back = true;
                        draw_back_arrow(screen_size.x / 2, screen_size.y - 77, size_slider, custom_colour, back)
                        -- [ ENABLED ARROWS ] --
                        end

                end

                -- Bottom (Background)
                if customDesign_item:get_int() == 4 then

                        -- [ BACKGROUND ] --
                        render:rect( screen_size.x / 2 - 100, screen_size.y - 70, 200, 60, csgo.color(100, 100, 100, 255))

                        -- outline of the background
                        render:rect_filled( screen_size.x / 2 - 100, screen_size.y - 70, 200, 60, csgo.color(0, 0, 0, 120))
                        -- [ BACKGROUND ] --
                    



                        -- [ DISABLED ARROWS ] --
                        -- right 
                        side = true;
                        draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y - 50, size_slider, white_colour, side)

                        -- left 
                        side = false;
                        draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y - 50, size_slider, white_colour, side)

                        -- back 
                        back = true;
                        draw_back_arrow(screen_size.x / 2, screen_size.y - 77, size_slider, white_colour, back)
                        -- [ DISABLED ARROWS ] --



                        -- [ ENABLED ARROWS ] --
                        -- right activated
                        if aa_right:get_bool() then
                        side = true;
                        draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y - 50, size_slider, custom_colour, side)

                        -- left activated
                        elseif aa_left:get_bool() then
                        side = false;
                        draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y - 50, size_slider, custom_colour, side)

                        -- back activated
                        elseif aa_back:get_bool() then
                        back = true;
                        draw_back_arrow(screen_size.x / 2, screen_size.y - 77, size_slider, custom_colour, back)
                        -- [ ENABLED ARROWS ] --
                        end
                end

            end  

        end

end



-- callbacks
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)

-- end of the code

local a=fatality.render;local b=fatality.config;local c=fatality.menu;local d=fatality.input;local e={}local f=csgo.interface_handler:get_cvar()local g=0x42;local h=0x28;local i=0x56;local j=b:add_item("indicator",1)local k=csgo.interface_handler:get_global_vars()local l=csgo.interface_handler:get_debug_overlay()local m=csgo.interface_handler:get_events()local n=a:screen_size()local o=csgo.interface_handler:get_engine_client()local p=csgo.interface_handler:get_engine_client()local q=csgo.interface_handler:get_entity_list()local r={"Head","Chest","Stomach","Hand","Arm","Leg","Leg","Neck"}local s=0;local t=a:create_font("Tahoma",12,100,true)local u=a:create_font("Josefin Sans",16,0,true)local v=a:create_font("Josefin Sans",25,550,true)function round(w,x)local y=10^(x or 0)return math.floor(w*y+0.5)/y end;local z=b:add_item("vis_wb",1)local A=b:add_item("colorpicker1_red",0)local B=b:add_item("colorpicker1_green",0)local C=b:add_item("colorpicker1_blue",0)local e={}local D=b:add_item("xvalue_onetap",0)local E=b:add_item("yvalue_onetap",0)local F=c:get_reference("RAGE","AIMBOT","Aimbot","Double tap")local G=c:get_reference("RAGE","AIMBOT","Aimbot","Double tap")local H=c:get_reference("RAGE","AIMBOT","Aimbot","Double tap")local I=c:get_reference("RAGE","AIMBOT","Aimbot","Double tap")local J=c:get_reference("RAGE","AIMBOT","Aimbot","Double tap")local K=c:get_reference("RAGE","AIMBOT","Aimbot","Double tap")local L=c:get_reference("RAGE","AIMBOT","Aimbot","Double tap")local M=c:get_reference("RAGE","AIMBOT","Aimbot","Double tap")local N=c:get_reference("RAGE","AIMBOT","Aimbot","Force fallback")local O=c:get_reference("RAGE","AIMBOT","Aimbot","Silent")local P=c:get_reference("RAGE","AIMBOT","Aimbot","Silent")local Q=c:get_reference("RAGE","AIMBOT","Aimbot","Silent")local R=c:get_reference("RAGE","AIMBOT","Aimbot","Silent")local S=c:get_reference("RAGE","AIMBOT","Aimbot","Silent")local T=c:get_reference("RAGE","AIMBOT","Aimbot","Silent")local U=c:get_reference("Rage","AIMBOT","Aimbot","Slide")local V=c:get_reference("rage","anti-aim","general","right")local W=c:get_reference("rage","anti-aim","general","left")local X=c:get_reference("rage","anti-aim","general","Shot Antiaim")local Y=c:get_reference("rage","anti-aim","general","back")local Z=c:get_reference("RAGE","AIMBOT","Aimbot","Fake duck")local E=b:add_item("yvalue_keybinds",0)local _=c:add_checkbox("Keybinds indicator","visuals","misc","various",onetap_keybind)local a0=b:add_item("vis_keybindscol",0)local n=a:screen_size()local D=b:add_item("xvalue_keybinds",0)local a1={palette=csgo.color(16,22,29,160),table_size=7,size_x=300,size_y=40}function draw_container_onetap(a2,a3,a4,a5,a6)local a7={10,60,40,40,40,60,20}local a8=a1.table_size;local a9=-50;local aa=139;local width_s,ab=0,{["none"]=0,["predict"]=0,["breaking"]=0,["backtrack"]=0}local ac=math.floor(math.sin(k.realtime*2)*127+128)local ad=math.floor(math.sin(k.realtime*2+2)*127+128)local ae=math.floor(math.sin(k.realtime*2+4)*127+128)width_s=150;a:rect_filled(a2+a4/3,a3+6,width_s,15,csgo.color(22,20,26,100))a:rect_filled(a2+a4/3,a3+6,width_s,15,a1.palette)a:rect_filled(a2+a4/3,a3+6,width_s,2,csgo.color(ac,ad,ae,160))a:text(t,a2+a4/3+35,a3+9,a6,csgo.color(255,255,255,255))end;function clear()s=0;e={}spec_table={}end;local af={watermark={FatalMark=b:add_item("local.watermark.FatalMark",0),info=b:add_item("local.watermark.info",1),time=b:add_item("local.watermark.time",1),hitlist=b:add_item("local.watermark.hitlist",0),speclist=b:add_item("local.watermark.speclist",0),rainbow=b:add_item("local.watermark.rainbow",0),speedmenu=b:add_item("local.watermark.speedmenu",1),pingmenu=b:add_item("local.watermark.pingmenu",1),fpsmenu=b:add_item("local.watermark.fpsmenu",1),tickmenu=b:add_item("local.watermark.tickmenu",1),x_value=b:add_item("local.watermark.xvalue",0),y_value=b:add_item("local.watermark.yvalue",0),keybinds=b:add_item("local.watermark.keybinds",0),theme1=b:add_item("local.watermark.theme1",0),oneway=b:add_item("local.watermark.oneway",0)}}c:add_multi_combo("Features","misc","","Buy Bot"):add_item("Spectator's List",af.watermark.speclist):add_item("Hit List",af.watermark.hitlist):add_item("Keybinds",af.watermark.keybinds):add_item("Oneway Helper",af.watermark.oneway)local ag=c:add_combo("Theme","misc","","Buy Bot",af.watermark.theme1):add_item("Default",af.watermark.theme1):add_item("Fatality",af.watermark.theme1)local ah=c:add_slider("Red","Misc","Buy bot","Buy bot",A,1,255,1)local ai=c:add_slider("Green","Misc","Buy bot","Buy bot",B,1,255,1)local aj=c:add_slider("Blue","Misc","Buy bot","Buy bot",C,1,255,1)c:add_button("Draw Markers","misc","","buy bot",z)c:add_button("Clear Hit-list","misc","","buy bot",clear)local ak={watermark_FatalMark=a:create_font("smallest pixel-7",11,100,true),watermark_small=a:create_font("smallest pixel-7",11,100,true)}local al=0.0;function get_fps()al=0.9*al+(1.0-0.9)*k.frametime;return math.floor(1.0/al+0.5)end;local function am()if not o:is_connected()then return 0 end;return math.abs(o:get_ping())end;local function an()if not o:is_connected()then return 0 end;return math.floor(1.0/k.interval_per_tick)end;function draw_container(a2,a3,a4,a5,ao)local a7={10,60,40,40,40,60,20}for ap=0,6,1 do a:rect_filled(a2+ap,a3+ap,a4-ap*2,a5-ap*2,csgo.color(a7[ap+1],a7[ap+1],a7[ap+1],255))end end;local aq=a:screen_size()local ar={watermark_pos=csgo.vector2(aq.x,10),watermark_size=csgo.vector2(0,16)}local function as()width_s=198;local at=math.floor(math.sin(k.realtime*2)*127+128)local au=math.floor(math.sin(k.realtime*2+2)*127+128)local av=math.floor(math.sin(k.realtime*2+4)*127+128)local ac=math.floor(math.sin(k.realtime*2)*127+128)local ad=math.floor(math.sin(k.realtime*2+2)*127+128)local ae=math.floor(math.sin(k.realtime*2+4)*127+128)local a8=a1.table_size;local a2,a3,aw=a1.size_x,a1.size_y,0;local aa=25;if af.watermark.theme1:get_int()==0 then a:rect_filled(ar.watermark_pos.x-125,ar.watermark_pos.y-3,width_s,25,csgo.color(22,20,26,100))a:rect_filled(ar.watermark_pos.x-125,ar.watermark_pos.y-3,width_s,15,a1.palette)a:rect_filled(ar.watermark_pos.x-125,ar.watermark_pos.y-3,width_s,2,csgo.color(ac,ad,ae,160))elseif af.watermark.theme1:get_int()==1 then a:rect_filled(a2+1440-2,a3-38,198,aa+7,csgo.color(25,20,30,150))a:rect_filled(a2+1440-1,a3-37,196,aa+5,csgo.color(60,53,93,150))a:rect_fade(a2+1440,a3-33,width_s,2,csgo.color(at,au,av,190),csgo.color(av,au,at,190),true)end end;function on_registered_shot(ax)local ay=q:get_player(ax.victim)local az=ax.shot_info;if ay==nil then return end;local aA=ay:get_name()local aB=az.backtrack_ticks;for ap=a1.table_size,2,-1 do e[ap]=e[ap-1]end;if aB==0 then aB="-"else aB=aB.." ticks"end;local aC=0;local aD=0;local aE=0;local aF=0;if ax.hurt then aC=1;aE=ax.hit_damage;aF=ax.hit_hitgroup;aD="-"local aG=0,255,255 elseif not ax.hurt and ax.hit then aC=0;aE="--"aF=ax.target_hitgroup elseif not ax.hit then aC=-1;aE="-"aF=ax.target_hitgroup end;if ax.hurt then aC=1;aE=ax.hit_damage;aF=ax.hit_hitgroup elseif not ax.hurt and ax.hit then aC=0;aD="resolver"local aG=255,0,0;aF=ax.target_hitgroup elseif not ax.hit then aC=-1;aD="spread"local aG=255,0,0;aF=ax.target_hitgroup end;s=s+1;e[1]={["id"]=s,["hit"]=aC,["player"]=string.sub(aA,0,14),["dmg"]=aE,["bt"]=aB,["box"]=r[aF],["rs"]=aD}end;local function aH(aI,a2,a3,aJ)if aJ then local a3=a3+4;local aK=a2+10;local a9=a3+15+aI*16;local ac,ad,ae=0,0,0;if aJ.hit==1 then ac,ad,ae=94,230,75 elseif aJ.hit==0 then ac,ad,ae=178,13,70 else ac,ad,ae=178,13,70 end;a:text(t,a2+8,a9+1-4,">",csgo.color(ac,ad,ae,255))a:text(t,aK+20,a9+1-2,tostring(aJ.player),csgo.color(255,255,255,255))a:text(t,aK+65,a9+1-2,tostring(aJ.dmg),csgo.color(0,255,0,255))a:text(t,aK+90,a9+1-2,tostring(aJ.box),csgo.color(255,255,255,255))return aI+1 end end;local function aL()local at=math.floor(math.sin(k.realtime*2)*127+128)local au=math.floor(math.sin(k.realtime*2+2)*127+128)local av=math.floor(math.sin(k.realtime*2+4)*127+128)local a2,a3,aw=a1.size_x,a1.size_y,0;local a8=a1.table_size;local aa=16+16*(#e>a8 and a8 or#e)local width_s,ab=0,{["none"]=0,["predict"]=0,["breaking"]=0,["backtrack"]=0}local ac=math.floor(math.sin(k.realtime*2)*127+128)local ad=math.floor(math.sin(k.realtime*2+2)*127+128)local ae=math.floor(math.sin(k.realtime*2+4)*127+128)width_s=150;if af.watermark.theme1:get_int()==0 then a:rect_filled(a2+1270,a3-33,width_s,aa,csgo.color(22,20,26,100))a:rect_filled(a2+1270,a3-33,width_s,15,a1.palette)a:rect_filled(a2+1270,a3-33,width_s,2,csgo.color(ac,ad,ae,160))a:text(t,a2+7+118+1205,a3+3-33,"hitlist",csgo.color(255,255,255,255))elseif af.watermark.theme1:get_int()==1 then a:rect_filled(a2+1282-2,a3-38,154,aa+7,csgo.color(25,20,30,150))a:rect_filled(a2+1282-1,a3-37,152,aa+5,csgo.color(60,53,93,150))local aM=math.floor(math.sin(k.realtime*10)*1+1)a:rect_fade(a2+1282,a3-33,width_s,2,csgo.color(at,au,av,190),csgo.color(av,au,at,190),true)a:text(u,a2+1323+16+aM,a3-66+34-aM,"Hit List",csgo.color(255,0,0,255))a:text(u,a2+1323+14-aM,a3-66+32+aM,"Hit List",csgo.color(0,100,255,255))a:text(u,a2+1323+15,a3-66+33,"Hit List",csgo.color(255,255,255,255))end;for ap=1,a1.table_size,1 do aw=aH(aw,a2+1282,a3-33,e[ap])end end;function watermark_speclist1(a2,a3,a4,a5,a6)local a8=a1.table_size;local a9=-50;local aa=16;local width_s,ab=0,{["none"]=0,["predict"]=0,["breaking"]=0,["backtrack"]=0}local ac=math.floor(math.sin(k.realtime*2)*127+128)local ad=math.floor(math.sin(k.realtime*2+2)*127+128)local ae=math.floor(math.sin(k.realtime*2+4)*127+128)width_s=150;local a2,a3,aw=140,40,0;local at=math.floor(math.sin(k.realtime*2)*127+128)local au=math.floor(math.sin(k.realtime*2+2)*127+128)local av=math.floor(math.sin(k.realtime*2+4)*127+128)if af.watermark.theme1:get_int()==0 then a:rect_filled(1400,7,width_s,15,csgo.color(22,20,26,100))a:rect_filled(1400,7,width_s,15,a1.palette)a:rect_filled(1400,7,width_s,2,csgo.color(ac,ad,ae,160))a:text(t,1400+50,10,"spectators",csgo.color(255,255,255,255))elseif af.watermark.theme1:get_int()==1 then a:rect_filled(a2+1284-2,a3-38,154,aa+7,csgo.color(25,20,30,150))a:rect_filled(a2+1284-1,a3-37,152,aa+5,csgo.color(60,53,93,150))local aM=math.floor(math.sin(k.realtime*10)*1+1)a:rect_fade(a2+1284,a3-33,width_s,2,csgo.color(at,au,av,190),csgo.color(av,au,at,190),true)a:text(u,a2+1318+16+aM,a3-66+34-aM,"Spectators",csgo.color(255,0,0,255))a:text(u,a2+1318+14-aM,a3-66+32+aM,"Spectators",csgo.color(0,100,255,255))a:text(u,a2+1318+15,a3-66+33,"Spectators",csgo.color(255,255,255,255))end end;function watermark_speclist()local aN=D:get_float()*1;local aO=E:get_float()*1;local aP=q:get_localplayer()local aQ=csgo.vector2(aN,aO)width_s=150;local aR={}local aS=0;local a2,a3,aw=140,40,0;for ap=1,q:get_max_players(),1 do player=q:get_player(ap)if player==nil or player:is_alive()or player:is_dormant()then goto aT end;spec_handle=player:get_var_handle("CBasePlayer->m_hObserverTarget")spec_player=q:get_from_handle(spec_handle)if spec_player==nil then goto aT end;if spec_player:get_index()==aP:get_index()then aR[aS]=player:get_name()aS=aS+1 end::aT::end;watermark_speclist1(aQ.x,aQ.y,215,aS*16+45,"spectators")for ap=0,aS,1 do if aR[ap]==nil then break end;if af.watermark.theme1:get_int()==0 then a:rect_filled(1400,7+10*ap+15,150,10,csgo.color(22,20,26,100))a:text(t,1400+49,7+15+ap*10,aR[ap],csgo.color(255,255,255,255))elseif af.watermark.theme1:get_int()==1 then a:text(t,1400+65,7+18+ap*10,aR[ap],csgo.color(255,255,255,255))end end end;local function aU()if not p:is_in_game()then return end;local ac=math.floor(math.sin(k.realtime*4+1)*127+128)local aP=q:get_localplayer()local aV=aP:get_var_vector("CBaseEntity->m_vecOrigin")if not aP:is_alive()then return end;local aW=math.floor(A:get_float())local aX=math.floor(B:get_float())local aY=math.floor(C:get_float())local aZ=round(aV.x,0)local a_=round(aV.y,0)local b0=round(aV.z,0)local b1=csgo.color(230,20,20,255)local b2=csgo.color(255,128,0,255)local b3=csgo.color(57,230,0,255)local b4=0x20;is_inside=false;if d:is_key_down(b4)then return end;if a_>-815 and a_<-730 and aZ>-740 and aZ<-675 then a:text(v,aq.x/2-25,aq.y/2-330,"Under stairs",b3)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside1=true end;if a_>255 and a_<330 and aZ>-1035 and aZ<-965 and b0==-368 then a:text(v,aq.x/2-25,aq.y/2-330,"B apartment",b2)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside2=true end;if a_>426 and a_<481 and aZ>-495 and aZ<-466 then a:text(v,aq.x/2-25,aq.y/2-330,"T apartment",b3)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside3=true end;if a_>-576 and a_<-539 and aZ>-234 and aZ<-176 then a:text(v,aq.x/2-25,aq.y/2-330,"Top Middle",b2)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside4=true end;if a_>-2070 and a_<-2016 and aZ>-234 and aZ<-180 then a:text(v,aq.x/2-25,aq.y/2-330,"CT",b3)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside5=true end;if a_>-1319 and a_<-1308 and aZ>-1009 and aZ<-991 then a:text(v,aq.x/2-40,aq.y/2-350,"CROUCH",csgo.color(200,50,50,ac))is_inside6=true end;if a_>-1410 and a_<-1394 and aZ>-553 and aZ<-534 then a:text(v,aq.x/2-25,aq.y/2-330,"Palace",b2)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside7=true end;if a_>-1199 and a_<-1151 and aZ>-809 and aZ<-760 then a:text(v,aq.x/2-25,aq.y/2-330,"Palace",b2)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside8=true end;if a_>-2120 and a_<-2075 and aZ>-316 and aZ<-274 and b0==-101 then a:text(v,aq.x/2-25,aq.y/2-330,"Ramp",b3)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside9=true end;if a_>765 and a_<873 and aZ>306 and aZ<364 or a_>765 and a_<873 and aZ>198 and aZ<255 then a:text(v,aq.x/2-40,aq.y/2-350,"Top Middle",b3)is_inside10=true end;if a_>-359 and a_<-325 and aZ>-406 and aZ<-219 then a:text(v,aq.x/2-40,aq.y/2-350,"Top Middle",b1)is_inside11=true end;if a_>-1612 and a_<-1569 and aZ>753 and aZ<816 then a:text(v,aq.x/2-25,aq.y/2-330,"Ramp",b3)a:text(v,aq.x/2-40,aq.y/2-350,"CROUCH",csgo.color(200,50,50,ac))is_inside12=true end;if a_>665 and a_<735 and aZ>-2289 and aZ<-2240 then a:text(v,aq.x/2-25,aq.y/2-330,"Kitchen",b2)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside13=true end;if a_>-1562 and a_<-1525 and aZ>-496 and aZ<-460 then a:text(v,aq.x/2-25,aq.y/2-330,"Ramp",b2)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside14=true end;if a_>-1748 and a_<-1735 and aZ>-38 and aZ<-3 then a:text(v,aq.x/2-25,aq.y/2-330,"Palace",b2)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside15=true end;if a_>203 and a_<222 and aZ>1103 and aZ<1186 then a:text(v,aq.x/2-25,aq.y/2-330,"T Spawn",b3)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside16=true end;if a_>314 and a_<376 and aZ>1190 and aZ<1358 then a:text(v,aq.x/2-25,aq.y/2-330,"T Spawn/T Roof",b3)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside17=true end;if a_>200 and a_<287 and aZ>1190 and aZ<1360 then a:text(v,aq.x/2-25,aq.y/2-330,"T to Ramp",b2)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside18=true end;if a_>-719 and a_<-704 and aZ>1232 and aZ<1241 then a:text(v,aq.x/2-25,aq.y/2-330,"T Spawn",b1)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside19=true end;if a_>-849 and a_<-795 and aZ>-1469 and aZ<-1437 then a:text(v,aq.x/2-25,aq.y/2-330,"Jungle",b3)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside20=true end;if a_>-1697 and a_<-1662 and aZ>-1475 and aZ<-1472 then a:text(v,aq.x/2-25,aq.y/2-330,"A to CT",b1)is_inside21=true end;if a_>-1223 and a_<-1207 and aZ>-1712 and aZ<-1685 then a:text(v,aq.x/2-25,aq.y/2-330,"Kitchen",b3)a:text(v,aq.x/2-40,aq.y/2-350,"FAKEDUCK",csgo.color(200,50,50,ac))is_inside22=true end;if a_>718 and a_<756 and aZ>-465 and aZ<-395 then a:text(v,aq.x/2-25,aq.y/2-330,"B apartment",b3)is_inside23=true end;if a_>287 and a_<298 and aZ>-1146 and aZ<-1099 then a:text(v,aq.x/2-25,aq.y/2-330,"B underpass",b1)is_inside24=true end;if a_>333 and a_<362 and aZ>330 and aZ<441 then a:text(v,aq.x/2-25,aq.y/2-330,"T Spawn cross",b2)is_inside25=true end;local b5=csgo.color(aW,aX,aY,255)if z:get_bool()then z:set_bool(false)l:add_line_overlay(csgo.vector3(-735,-814,-261),csgo.vector3(-676,-760,-261),b5,false,90000)l:add_line_overlay(csgo.vector3(-676,-814,-261),csgo.vector3(-735,-760,-261),b5,false,90000)l:add_line_overlay(csgo.vector3(-735,-760,-261),csgo.vector3(-676,-760,-261),b5,false,90000)l:add_line_overlay(csgo.vector3(-676,-814,-261),csgo.vector3(-735,-814,-261),b5,false,90000)l:add_line_overlay(csgo.vector3(-735,-814,-261),csgo.vector3(-735,-760,-261),b5,false,90000)l:add_line_overlay(csgo.vector3(-676,-814,-261),csgo.vector3(-676,-760,-261),b5,false,90000)l:add_line_overlay(csgo.vector3(-970,332,-367),csgo.vector3(-1034,269,-366),b5,false,90000)l:add_line_overlay(csgo.vector3(-1034,332,-367),csgo.vector3(-970,269,-366),b5,false,90000)l:add_line_overlay(csgo.vector3(-970,332,-367),csgo.vector3(-970,269,-366),b5,false,90000)l:add_line_overlay(csgo.vector3(-1034,332,-367),csgo.vector3(-1034,269,-366),b5,false,90000)l:add_line_overlay(csgo.vector3(-970,332,-367),csgo.vector3(-1034,332,-367),b5,false,90000)l:add_line_overlay(csgo.vector3(-1034,269,-366),csgo.vector3(-970,269,-366),b5,false,90000)l:add_line_overlay(csgo.vector3(-466,491,-150),csgo.vector3(-495,428,-166),b5,false,90000)l:add_line_overlay(csgo.vector3(-495,491,-166),csgo.vector3(-466,427,-150),b5,false,90000)l:add_line_overlay(csgo.vector3(-466,491,-150),csgo.vector3(-466,427,-150),b5,false,90000)l:add_line_overlay(csgo.vector3(-495,491,-166),csgo.vector3(-495,428,-166),b5,false,90000)l:add_line_overlay(csgo.vector3(-466,491,-150),csgo.vector3(-495,491,-166),b5,false,90000)l:add_line_overlay(csgo.vector3(-495,428,-166),csgo.vector3(-466,427,-150),b5,false,90000)l:add_line_overlay(csgo.vector3(-817,-1139,-120),csgo.vector3(-776,-1191,-120),b5,false,90000)l:add_line_overlay(csgo.vector3(-824,-1185,-120),csgo.vector3(-771,-1144,-120),b5,false,90000)l:add_line_overlay(csgo.vector3(-817,-1139,-120),csgo.vector3(-771,-1144,-120),b5,false,90000)l:add_line_overlay(csgo.vector3(-824,-1185,-120),csgo.vector3(-776,-1191,-120),b5,false,90000)l:add_line_overlay(csgo.vector3(-817,-1139,-120),csgo.vector3(-824,-1185,-120),b5,false,90000)l:add_line_overlay(csgo.vector3(-776,-1191,-120),csgo.vector3(-771,-1144,-120),b5,false,90000)l:add_line_overlay(csgo.vector3(199,767,-135),csgo.vector3(254,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(254,766,-135),csgo.vector3(199,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(199,767,-135),csgo.vector3(199,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(254,766,-135),csgo.vector3(254,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(199,767,-135),csgo.vector3(254,766,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(254,872,-135),csgo.vector3(199,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(363,766,-135),csgo.vector3(313,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(307,766,-135),csgo.vector3(363,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(363,766,-135),csgo.vector3(363,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(307,766,-135),csgo.vector3(313,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(363,766,-135),csgo.vector3(307,766,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(313,872,-135),csgo.vector3(363,872,-135),b5,false,90000)l:add_line_overlay(csgo.vector3(-174,-523.2,-232),csgo.vector3(-238,-547,-246),b5,false,90000)l:add_line_overlay(csgo.vector3(-238,-525,-246),csgo.vector3(-174,-552,-232),b5,false,90000)l:add_line_overlay(csgo.vector3(-174,-523.2,-232),csgo.vector3(-174,-552,-232),b5,false,90000)l:add_line_overlay(csgo.vector3(-238,-525,-246),csgo.vector3(-238,-547,-246),b5,false,90000)l:add_line_overlay(csgo.vector3(-174,-523.2,-232),csgo.vector3(-238,-525,-246),b5,false,90000)l:add_line_overlay(csgo.vector3(-238,-547,-246),csgo.vector3(-174,-552,-232),b5,false,90000)l:add_line_overlay(csgo.vector3(820,-1611,-108),csgo.vector3(761,-1570,-108),b5,false,90000)l:add_line_overlay(csgo.vector3(761,-1611,-108),csgo.vector3(820,-1570,-108),b5,false,90000)l:add_line_overlay(csgo.vector3(820,-1611,-108),csgo.vector3(820,-1570,-108),b5,false,90000)l:add_line_overlay(csgo.vector3(761,-1611,-108),csgo.vector3(761,-1570,-108),b5,false,90000)l:add_line_overlay(csgo.vector3(820,-1611,-108),csgo.vector3(761,-1611,-108),b5,false,90000)l:add_line_overlay(csgo.vector3(761,-1570,-108),csgo.vector3(820,-1570,-108),b5,false,90000)l:add_line_overlay(csgo.vector3(-1727,-1200,-254),csgo.vector3(-1665,-1222,-254),b5,false,90000)l:add_line_overlay(csgo.vector3(-1665,-1200,-254),csgo.vector3(-1727,-1222,-254),b5,false,90000)l:add_line_overlay(csgo.vector3(-1727,-1200,-254),csgo.vector3(-1727,-1222,-254),b5,false,90000)l:add_line_overlay(csgo.vector3(-1665,-1200,-254),csgo.vector3(-1665,-1222,-254),b5,false,90000)l:add_line_overlay(csgo.vector3(-1727,-1200,-254),csgo.vector3(-1665,-1200,-254),b5,false,90000)l:add_line_overlay(csgo.vector3(-1665,-1222,-254),csgo.vector3(-1727,-1222,-254),b5,false,90000)l:add_line_overlay(csgo.vector3(-2224,719,-39),csgo.vector3(-2302,665,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-2288,734,-39),csgo.vector3(-2235,653,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-2224,719,-39),csgo.vector3(-2235,653,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-2288,734,-39),csgo.vector3(-2302,665,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-2224,719,-39),csgo.vector3(-2288,734,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-2302,665,-39),csgo.vector3(-2235,653,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-495,-1518,-39),csgo.vector3(-455,-1565,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-455,-1518,-39),csgo.vector3(-495,-1565,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-495,-1518,-39),csgo.vector3(-495,-1565,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-455,-1518,-39),csgo.vector3(-455,-1565,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-495,-1518,-39),csgo.vector3(-455,-1518,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(-455,-1565,-39),csgo.vector3(-495,-1565,-39),b5,false,90000)l:add_line_overlay(csgo.vector3(1198,220,-231),csgo.vector3(1095,199,-219),b5,false,90000)l:add_line_overlay(csgo.vector3(1095,220,-226),csgo.vector3(1198,199,-223),b5,false,90000)l:add_line_overlay(csgo.vector3(1198,220,-231),csgo.vector3(1198,199,-223),b5,false,90000)l:add_line_overlay(csgo.vector3(1095,220,-226),csgo.vector3(1095,199,-219),b5,false,90000)l:add_line_overlay(csgo.vector3(1198,220,-231),csgo.vector3(1095,220,-226),b5,false,90000)l:add_line_overlay(csgo.vector3(1095,199,-219),csgo.vector3(1198,199,-223),b5,false,90000)l:add_line_overlay(csgo.vector3(-300,-2065,-100),csgo.vector3(-308,-2117,-100),b5,false,90000)l:add_line_overlay(csgo.vector3(-324,-2076,-100),csgo.vector3(-282,-2105,-100),b5,false,90000)l:add_line_overlay(csgo.vector3(-300,-2065,-100),csgo.vector3(-282,-2105,-100),b5,false,90000)l:add_line_overlay(csgo.vector3(-324,-2076,-100),csgo.vector3(-308,-2117,-100),b5,false,90000)l:add_line_overlay(csgo.vector3(-300,-2065,-100),csgo.vector3(-324,-2076,-100),b5,false,90000)l:add_line_overlay(csgo.vector3(-308,-2117,-100),csgo.vector3(-282,-2105,-100),b5,false,90000)l:add_line_overlay(csgo.vector3(-4,-1759,-167),csgo.vector3(-30,-1740,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-30,-1759,-167),csgo.vector3(-4,-1740,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-30,-1759,-167),csgo.vector3(-30,-1740,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-4,-1759,-167),csgo.vector3(-4,-1740,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-4,-1759,-167),csgo.vector3(-30,-1759,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-30,-1740,-167),csgo.vector3(-4,-1740,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-455,753,-83),csgo.vector3(-405,719,-83),b5,false,90000)l:add_line_overlay(csgo.vector3(-456,715,-83),csgo.vector3(-405,755,-83),b5,false,90000)l:add_line_overlay(csgo.vector3(-455,753,-83),csgo.vector3(-405,755,-83),b5,false,90000)l:add_line_overlay(csgo.vector3(-456,715,-83),csgo.vector3(-405,719,-83),b5,false,90000)l:add_line_overlay(csgo.vector3(-455,753,-83),csgo.vector3(-456,715,-83),b5,false,90000)l:add_line_overlay(csgo.vector3(-405,719,-83),csgo.vector3(-405,755,-83),b5,false,90000)l:add_line_overlay(csgo.vector3(1245,-723,-229),csgo.vector3(1233,-701,-227),b5,false,90000)l:add_line_overlay(csgo.vector3(1245,-701,-227),csgo.vector3(1233,-723,-230),b5,false,90000)l:add_line_overlay(csgo.vector3(1245,-723,-229),csgo.vector3(1233,-723,-230),b5,false,90000)l:add_line_overlay(csgo.vector3(1245,-701,-227),csgo.vector3(1233,-701,-227),b5,false,90000)l:add_line_overlay(csgo.vector3(1245,-723,-229),csgo.vector3(1245,-701,-227),b5,false,90000)l:add_line_overlay(csgo.vector3(1233,-701,-227),csgo.vector3(1233,-723,-230),b5,false,90000)l:add_line_overlay(csgo.vector3(-1145,305,-159),csgo.vector3(-1109,290,-159),b5,false,90000)l:add_line_overlay(csgo.vector3(-1110,310,-159),csgo.vector3(-1145,288,-159),b5,false,90000)l:add_line_overlay(csgo.vector3(-1145,305,-159),csgo.vector3(-1145,288,-159),b5,false,90000)l:add_line_overlay(csgo.vector3(-1110,310,-159),csgo.vector3(-1109,290,-159),b5,false,90000)l:add_line_overlay(csgo.vector3(-1145,305,-159),csgo.vector3(-1110,310,-159),b5,false,90000)l:add_line_overlay(csgo.vector3(-1109,290,-159),csgo.vector3(-1145,288,-159),b5,false,90000)l:add_line_overlay(csgo.vector3(-386,-349,-163),csgo.vector3(-334,-338,-163),b5,false,90000)l:add_line_overlay(csgo.vector3(-334,-351,-163),csgo.vector3(-386,-338,-163),b5,false,90000)l:add_line_overlay(csgo.vector3(-386,-349,-163),csgo.vector3(-386,-338,-163),b5,false,90000)l:add_line_overlay(csgo.vector3(-334,-351,-163),csgo.vector3(-334,-338,-163),b5,false,90000)l:add_line_overlay(csgo.vector3(-386,-349,-163),csgo.vector3(-334,-351,-163),b5,false,90000)l:add_line_overlay(csgo.vector3(-334,-338,-163),csgo.vector3(-386,-338,-163),b5,false,90000)l:add_line_overlay(csgo.vector3(-1440,-848,-167),csgo.vector3(-1471,-796,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-1471,-848,-167),csgo.vector3(-1440,-796,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-1440,-848,-167),csgo.vector3(-1440,-796,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-1471,-848,-167),csgo.vector3(-1471,-796,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-1440,-848,-167),csgo.vector3(-1471,-848,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-1471,-796,-167),csgo.vector3(-1440,-796,-167),b5,false,90000)l:add_line_overlay(csgo.vector3(-530,-1418,-106),csgo.vector3(-550,-1385,-132),b5,false,90000)l:add_line_overlay(csgo.vector3(-532,-1384,-132),csgo.vector3(-550,-1418,-106),b5,false,90000)l:add_line_overlay(csgo.vector3(-530,-1418,-106),csgo.vector3(-550,-1418,-106),b5,false,90000)l:add_line_overlay(csgo.vector3(-532,-1384,-132),csgo.vector3(-550,-1385,-132),b5,false,90000)l:add_line_overlay(csgo.vector3(-530,-1418,-106),csgo.vector3(-532,-1384,-132),b5,false,90000)l:add_line_overlay(csgo.vector3(-550,-1385,-132),csgo.vector3(-550,-1418,-106),b5,false,90000)end end;local function b6()ar.watermark_size.x=a:text_size(ak.watermark_FatalMark,text).x+10;ar.watermark_pos.x=aq.x-16-ar.watermark_size.x-10;local b7=get_fps()local b8=am()local b9=an()local aP=q:get_localplayer()if aP==nil then return end;local ba=aP:get_var_vector("CBasePlayer->m_vecVelocity[0]")local bb=math.ceil(math.sqrt(math.abs(ba.x)*math.abs(ba.x)+math.abs(ba.y)*math.abs(ba.y)))local ac=math.sin(k.realtime/8*3)*127+128;local ad=math.sin(k.realtime/8*5)*127+128;local ae=math.sin(k.realtime/8*7)*127+128;local a2;if bb==0 then a2=ar.watermark_pos.x+13 elseif bb<=99 then a2=ar.watermark_pos.x+13 else a2=ar.watermark_pos.x+9 end;local bc;if b7<=9 then bc=ar.watermark_pos.x-111 elseif b7<=59 then bc=ar.watermark_pos.x-111 else bc=ar.watermark_pos.x-110 end;local bd;if b7<=9 then bd=csgo.color(255,255,255,255)elseif b7<=59 then bd=csgo.color(255,255,255,255)else bd=csgo.color(0,255,0,255)end;local be;if b8==0 then be=ar.watermark_pos.x-73 elseif b8<=99 then be=ar.watermark_pos.x-76 else be=ar.watermark_pos.x-78 end;local bf;if b9<=64 then bf=ar.watermark_pos.x+44 else bf=ar.watermark_pos.x+44 end;if af.watermark.fpsmenu:get_bool()then a:text(ak.watermark_small,ar.watermark_pos.x-110,ar.watermark_pos.y,"fps",csgo.color(255,255,255,255))a:text(ak.watermark_FatalMark,bc,ar.watermark_pos.y+11,b7,csgo.color(0,255,0,255))else end;if af.watermark.pingmenu:get_bool()then a:text(ak.watermark_FatalMark,be,ar.watermark_pos.y+11,b8,csgo.color(0,255,0,255))a:text(ak.watermark_small,ar.watermark_pos.x-80,ar.watermark_pos.y,"ping",csgo.color(255,255,255,255))else end;if af.watermark.speedmenu:get_bool()then a:text(ak.watermark_FatalMark,a2,ar.watermark_pos.y+11,bb,csgo.color(0,255,0,255))a:text(ak.watermark_small,ar.watermark_pos.x+3,ar.watermark_pos.y,"speed",csgo.color(255,255,255,255))else end;if af.watermark.tickmenu:get_bool()then a:text(ak.watermark_FatalMark,bf,ar.watermark_pos.y+11,b9,csgo.color(0,255,0,255))a:text(ak.watermark_small,ar.watermark_pos.x+40,ar.watermark_pos.y,"tick",csgo.color(255,255,255,255))else end end;local function bg()ar.watermark_size.x=a:text_size(ak.watermark_FatalMark,text).x+11;ar.watermark_pos.x=aq.x-16-ar.watermark_size.x-10;if af.watermark.rainbow:get_bool()then a:text(ak.watermark_FatalMark,ar.watermark_pos.x-45,ar.watermark_pos.y+11,os.date("%H:%M:%S"),csgo.color(0,161,255,255))else a:text(ak.watermark_FatalMark,ar.watermark_pos.x-45,ar.watermark_pos.y+11,os.date("%I:%M:%S"),csgo.color(0,161,255,255))end;a:text(ak.watermark_small,ar.watermark_pos.x-38,ar.watermark_pos.y,"time",csgo.color(255,255,255,255))end;function on_paint()if not p:is_in_game()then return end;local aP=q:get_localplayer()local aN=D:get_float()*1;local aO=E:get_float()*1;local aQ=csgo.vector2(aN,aO)local bh;if dt then bh=aQ.y+35 else bh=aQ.y+25 end;local bi;if silent and dt then bi=aQ.y+45 elseif dt then bi=aQ.y+35 elseif silent then bi=aQ.y+35 elseif Z:get_bool()then bi=aQ.y+35 else bi=aQ.y+35 end;if af.watermark.FatalMark:get_bool()then as()end;if af.watermark.info:get_bool()then b6()end;if af.watermark.time:get_bool()then bg()end;if af.watermark.hitlist:get_bool()then aL()end;if af.watermark.oneway:get_bool()then aU()end;if af.watermark.speclist:get_bool()then watermark_speclist()end;if af.watermark.keybinds:get_bool()then if J:get_int()==1 then fatality.render:indicator(10,620,"Teleport",false,-1)elseif J:get_int()==2 then fatality.render:indicator(10,620,"Teleport",true,-1)elseif J:get_int()==0 then end;if O:get_bool()then silent=true;fatality.render:indicator(10,597,"SILENT",silent,-1)end;if U:get_int()==1 then fatality.render:indicator(10,574,"SLIDE",U,-1)end end end;function event(bj)if bj:get_name()=="round_start"then clear()end end;m:add_event("round_start")local bk=fatality.callbacks;bk:add("paint",on_paint)bk:add("registered_shot",on_registered_shot)bk:add("events",event)bk:add("paint",function()if d:is_key_down(g)then J:set_int(1)M:set_int(1)L:set_int(1)K:set_int(1)elseif d:is_key_down(i)then J:set_int(2)K:set_int(2)L:set_int(2)M:set_int(2)elseif d:is_key_down(h)then J:set_int(0)M:set_int(0)L:set_int(0)K:set_int(0)end end)

--end

--LUA MADE by anti#2528 (Zel9) SHOUTOUT TO TEAMINFO++ CREATOR
-- grab fatality_interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu

-- grab csgo_interfaces
local globals = csgo.interface_handler:get_global_vars( )
local entity_list = csgo.interface_handler:get_entity_list( )
local events = csgo.interface_handler:get_events( )
local cvar = csgo.interface_handler:get_cvar( )
local engine = csgo.interface_handler:get_engine_client()

--define font
local font_main = render:create_font( "Verdana", 12, 500, true );
local weapon_name = "none"
local name = config:add_item("vis_nameesp", 0)
local nameesp = menu:add_checkbox("Name ESP", "Visuals", "ESP", "Player", name)
local colorpickerR_item = config:add_item( "colorpicker_red", 0 )
local colorpickerG_item = config:add_item( "colorpicker_green", 0 )
local colorpickerB_item = config:add_item( "colorpicker_blue", 0 )
local colorpickerR_slider = menu:add_slider( "Red", "VISUALS", "ESP", "Player", colorpickerR_item, 1, 255, 1 )
local colorpickerG_slider = menu:add_slider( "Green", "VISUALS", "ESP", "Player", colorpickerG_item, 1, 255, 1 )
local colorpickerB_slider = menu:add_slider( "Blue", "VISUALS", "ESP", "Player", colorpickerB_item, 1, 255, 1 )

local function on_paint( )


    --if you arent in game, return
    if not engine:is_in_game( ) then
       return end
if(name:get_bool())then
    --local player
    --has to be outside of max entity list
    local local_player = entity_list:get_localplayer( )

    --i is 1 in get_max_players
    for i = 1, entity_list:get_max_players( ), 1 do

         --player needs to be defined under becuase of get_max_players
         local player = entity_list:get_player( i )

         --checking if our qualifications meet to draw the info
         if player == nil or not player:is_alive( ) or player:get_var_int( "CBaseEntity->m_iTeamNum" ) == local_player:get_var_int( "CBaseEntity->m_iTeamNum" ) or player:get_index( ) == local_player:get_index( ) then
         --if these checks work then we continue
         goto continue end

             --distance credit to https://www.varsitytutors.com/hotmath/hotmath_help/topics/distance-formula-in-3d && DR4X
             local localorigin = local_player:get_var_vector("CBaseEntity->m_vecOrigin")

             local origin = player:get_var_vector("CBaseEntity->m_vecOrigin")

             local localpos = local_player:get_eye_pos()


             local r_col = math.floor(colorpickerR_item:get_float( ))
             local g_col = math.floor(colorpickerG_item:get_float( ))
             local b_col = math.floor(colorpickerB_item:get_float( ))
             if(player:is_dormant())then
              alpha = 80
            else
              alpha = 255
            end

             local distance = math.sqrt(math.pow(localorigin.x - origin.x, 2) + math.pow(localpos.y - origin.y, 2) +  math.pow(localpos.z - origin.z, 2)) * 0.0254


             --pos definition
             local pos = player:get_eye_pos( )

             --define pos refrence to world
             pos = csgo.vector3( pos.x, pos.y, pos.z + 4 )

            -- making it so all text draws in game
            if pos:to_screen( ) then

               --defining string info
               local getname = player:get_name( )
               --clamping name size
               if string.len( getname ) > 7 then
                getname = string.sub( getname, 0, 7) .. "..."
               end



               --putting string info together
               local mainstring = getname
               color_name = csgo.color(r_col, g_col, b_col, alpha);

                --makes textsize dynamic based off of the font size and length of string
                local text_size_main = render:text_size( font_main, mainstring )

                render:text( font_main, pos.x - 1 - text_size_main.x * 0.5, pos.y - text_size_main.y * 1.35, mainstring, color_name)

            end
            
            ::continue::
          end
    end
  end
-- Register callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )

--end
local cvar = csgo.interface_handler:get_cvar( );
local config = fatality.config;
local menu = fatality.menu;

local skyboxes = {
    [0] = "cern",
    [1] = "extreme_glaciation_",
    [2] = "persistent_fog_",
    [3] = "polluted_atm_",
    [4] = "toxic_atm_",
    [5] = "sky_oblako_01",
    [6] = "Clear_night_sky",
    [7] = "pink",
    [8] = "sky105",
    [9] = "glorious_morning",
    [10] = "cruel_night_ovl_hq",
    [11] = "sky100",
    [12] = "marslike01",
    [13] = "blood1_"
}

local skybox_bool_item, skybox_value_item = config:add_item( "skybox_bool", 1 ), config:add_item( "skybox_values", 0 )
local skybox_bool_checkbox, skybox_value_combobox = menu:add_checkbox( "Custom Skyboxes", "visuals", "misc", "various", skybox_bool_item ), menu:add_combo( "Skyboxes", "visuals", "misc", "various", skybox_value_item )
for i = 0, #skyboxes, 1 do
    skybox_value_combobox:add_item( skyboxes[ i ], skybox_value_item );
end

local sv_skyname = cvar:find_var( "sv_skyname" );
local needs_reset = true
local old_val = -1;

function on_paint( )
    if needs_reset and skybox_bool_item:get_bool( ) then
        sv_skyname:set_string( skyboxes[ skybox_value_item:get_int( ) ] )
        needs_reset = false
    end

    if old_var == skybox_value_item:get_int( ) then
        return
    end

    old_var = skybox_value_item:get_int( )
    needs_reset = true
end

local function on_level_init( )
    needs_reset = true
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );
callbacks:add( "level_init", on_level_init );

--end

local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar()
local r_aspectratio = cvar:find_var("r_aspectratio")

local function set_aspect_ratio(multiplier)
    local screen_width = render:screen_size().x
    local screen_height = render:screen_size().y

    local value = (screen_width * multiplier) / screen_height

    if multiplier == 1 then
        value = 0
    end
    
    r_aspectratio:set_float(value)
end

local function gcd(m, n)
    while m ~= 0 do
        m, n = math_fmod(n, m), m;
    end

    return n
end

-- Menu entries.
local aspect_ratio_item = config:add_item( "aspect_ratio", 0.0 )
local aspect_ratio_slider = menu:add_slider( "Aspect ratio", "visuals", "misc", "various", aspect_ratio_item, 1, 200, 1 )

-- Doing it every frame because there is currently no item value update callback, and I'm lazy. I'll fix this later.
function on_paint( )
    local aspect_ratio = aspect_ratio_item:get_float() * 0.01
    aspect_ratio = 2 - aspect_ratio

    set_aspect_ratio(aspect_ratio)
end

-- Register all callback functions that should be called
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )

-- end

--main instances
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks
local fatalMath = fatality.math
--main instances

local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()

local silent = csgo.color(255,105,180,255)
local doubletap = csgo.color(255,105,180,255)
local fallback = csgo.color(255,105,180,255)

local blue = csgo.color(220,20,60,255)

local screensize = render:screen_size()

local x = config:add_item( 'x', 0 )
local y = config:add_item( 'y', 0 )

local xS = menu:add_slider( 'Silent/Dt/Lethal X', 'visuals', 'misc', 'various', x, 0, screensize.x - screensize.x/24, 1 )
local xS = menu:add_slider( 'Silent/Dt/Lethal Y', 'visuals', 'misc', 'various', y, 0, screensize.y - screensize.y/19.6, 1 )

local font = render:create_font( 'Noto Sans Bold', 14, 100, true )

--Original Font: Verdana Bold

local autoSilent = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Silent' )
local autoDoubletap = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Double tap' )
local autoFallback = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Force fallback' )

local awpSilent = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Silent' )
local awpDoubletap = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Double tap' )
local awpFallback = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Force fallback' )

local scoutSilent = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Silent' )
local scoutDoubletap = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Double tap' )
local scoutFallback = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Force fallback' )

local heavyPistolSilent = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Silent' )
local heavyPistolDoubletap = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Double tap' )
local heavyPistolFallback = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Force fallback' )

local pistolSilent = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Silent' )
local pistolDoubletap = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Double tap' )
local pistolFallback = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Force fallback' )

local otherSilent = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Silent' )
local otherDoubletap = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Double tap' )
local otherFallback = menu:get_reference( 'RAGE', 'AIMBOT', 'Aimbot', 'Force fallback' )

local function paint()

local localPlayer = entity_list:get_localplayer()

if localPlayer == nil then
    return end

local weapon = csgo.interface_handler:get_entity_list():get_from_handle(localPlayer:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) )

if weapon == nil then
    return end

local currentWeapon = weapon:get_class_id()

    if currentWeapon == 244 or currentWeapon == 238 or currentWeapon == 257 or currentWeapon == 268  or currentWeapon == 245 or currentWeapon == 257 or currentWeapon == 240 then
        currentWeapon = 'pistol'
    elseif  currentWeapon == 46 then
        currentWeapon = 'heavy pistol'
    elseif currentWeapon == 266 then
        currentWeapon = 'scout'
    elseif currentWeapon == 260 or currentWeapon == 241 then
        currentWeapon = 'auto'
    elseif currentWeapon == 232 then
        currentWeapon = 'awp'
    elseif currentWeapon == 107 then
        currentWeapon = 'knife'
    else
        currentWeapon = 'other'
    end

if currentWeapon == 'auto' then
        if autoSilent:get_bool() then
            silent = csgo.color(147,112,219,255)
        else
            silent = csgo.color(255,105,180,255)
        end

        if autoDoubletap:get_int() == 1 or autoDoubletap:get_int() == 2 then
            doubletap = csgo.color(0,115,255,255)
        else
            doubletap = csgo.color(255,105,180,255)
        end
        if autoFallback:get_int() == 1 or autoFallback:get_int() == 2 then
            fallback = csgo.color(220,20,60,255)
        else
            fallback = csgo.color(255,105,180,255)
        end
    elseif currentWeapon == 'awp' then
        if awpSilent:get_bool() then
            silent = csgo.color(147,112,219,255)
        else
            silent = csgo.color(255,105,180,255)
        end
        doubletap = csgo.color(255,105,180,255)       
        if awpFallback:get_int() == 1 or awpFallback:get_int() == 2 then
            fallback = csgo.color(220,20,60,255)
        else
            fallback = csgo.color(255,105,180,255)
        end
    elseif currentWeapon == 'scout' then
        if scoutSilent:get_bool() then
            silent = csgo.color(147,112,219,255)
        else
            silent = csgo.color(255,105,180,255)
        end
        doubletap = csgo.color(255,105,180,255)     
        if scoutFallback:get_int() == 1 or scoutFallback:get_int() == 2 then
            fallback = csgo.color(220,20,60,255)
        else
            fallback = csgo.color(255,105,180,255)
        end
    elseif currentWeapon == 'pistol' then
        if pistolSilent:get_bool() then
            silent = csgo.color(147,112,219,255)
        else
            silent = csgo.color(255,105,180,255)
        end
        if pistolDoubletap:get_int() == 1 or pistolDoubletap:get_int() == 2 then
            doubletap = csgo.color(0,115,255,255)
        else
            doubletap = csgo.color(255,105,180,255)
        end
        if awpFallback:get_int() == 1 or awpFallback:get_int() == 2 then
            fallback = csgo.color(220,20,60,255)
        else
            fallback = csgo.color(255,105,180,255)
        end
        if pistolFallback:get_int() == 1 or pistolFallback:get_int() == 2 then
            fallback = csgo.color(220,20,60,255)
        else
            fallback = csgo.color(255,105,180,255)
        end
    elseif currentWeapon == 'heavy pistol' then
        if heavyPistolSilent:get_bool() then
            silent = csgo.color(147,112,219,255)
        else
            silent = csgo.color(255,105,180,255)
        end

        if heavyPistolDoubletap:get_int() == 1 or heavyPistolDoubletap:get_int() == 2 then
            doubletap = csgo.color(255,105,180,255)
        else
            doubletap = csgo.color(255,105,180,255)
        end
        if heavyPistolFallback:get_int() == 1 or heavyPistolFallback:get_int() == 2 then
            fallback = csgo.color(255,105,180,255)
        else
            fallback = csgo.color(255,105,180,255)
        end
    elseif currentWeapon == 'knife' then
        silent = csgo.color(255,105,180,255)
        doubletap = csgo.color(255,105,180,255)
        fallback = csgo.color(255,105,180,255)
    else
        if otherSilent:get_bool() then
            silent = csgo.color(255,105,180,255)
        else
            silent = csgo.color(255,105,180,255)
        end

        if otherDoubletap:get_int() == 1 or otherDoubletap:get_int() == 2 then
            doubletap = csgo.color(255,105,180,255)
        else
            doubletap = csgo.color(255,105,180,255)
        end
        if otherFallback:get_int() == 1 or otherFallback:get_int() == 2 then
            fallback = csgo.color(255,105,180,255)
        else
            fallback = csgo.color(255,105,180,255)
        end
    end

    
    render:text( font, x:get_int() + 18, y:get_int(), 'SILENT', silent)
    render:text( font, x:get_int() + 5 , y:get_int() + 19, 'DOUBLE-TAP', doubletap )
    render:text( font, x:get_int() + 9, y:get_int() + 38, 'FALLBACK', fallback )
end

callbacks:add('paint', paint)

--end

