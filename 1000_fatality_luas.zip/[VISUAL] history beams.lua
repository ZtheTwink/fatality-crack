local render = fatality.render
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )
local global_vars = csgo.interface_handler:get_global_vars( )
local config = fatality.config
local menu = fatality.menu

local hitbox_item = config:add_item( "hitbox", 0.0 )
local hitbox_checkbox = menu:add_checkbox( "Draw hitbox on hit", "VISUALS", "MISC", "Beams", hitbox_item )

local hit_line_item = config:add_item( "hit_line", 0.0 )
local hit_line_checkbox = menu:add_checkbox( "Draw hit line", "VISUALS", "MISC", "Beams", hit_line_item )

local rh_slider_item = config:add_item( "rh_slider", 0.0 )
local rh_slider = menu:add_slider( "Red", "VISUALS", "MISC", "Beams", rh_slider_item, 1.0, 100.0, 100.0 )

local gh_slider_item = config:add_item( "gh_slider", 0.0 )
local gh_slider = menu:add_slider( "Green", "VISUALS", "MISC", "Beams", gh_slider_item, 1.0, 100.0, 100.0 )

local bh_slider_item = config:add_item( "bh_slider", 0.0 )
local bh_slider = menu:add_slider( "Blue", "VISUALS", "MISC", "Beams", bh_slider_item, 1.0, 100.0, 100.0 )

local opacity_slider_item = config:add_item( "opacity_slider", 0.0 )
local opacity_slider = menu:add_slider( "Opacity", "VISUALS", "MISC", "Beams", opacity_slider_item, 1.0, 100.0, 100.0 )

local duration_slider_item = config:add_item( "duration_slider_item_slider", 0.0 )
local duration_slider = menu:add_slider( "Duration", "VISUALS", "MISC", "Beams", duration_slider_item, 1.0, 10.0, 1.0 )


function on_shot( shot )
    local opacity = math.floor(opacity_slider_item:get_float( ) * 2.55)
    local r = math.floor(rh_slider_item:get_float( ) * 2.55)
    local g = math.floor(gh_slider_item:get_float( ) * 2.55)
    local b = math.floor(bh_slider_item:get_float( ) * 2.55) ------ why u looking through the code noggis
    local coloring = csgo.color(r, g, b, opacity)
 
    player = entity_list:get_player( shot.victim )

    if not engine_client:is_in_game( ) then
       return end

    local local_player = entity_list:get_localplayer( )

    if not local_player:is_alive( ) then
        return end

    if player == nil then
        return end

    if shot.hurt then
        if hitbox_item:get_bool() then
            render:draw_hitgroup( player, shot.record.matrix, - 1, duration_slider_item:get_int(), coloring )
        end
        if hit_line_item:get_bool() then
            debug_overlay:add_line_overlay( shot.shotpos, shot.hitpos, coloring, true, duration_slider_item:get_int() )
        end
    end   
end


local callbacks = fatality.callbacks
callbacks:add( "registered_shot", on_shot )