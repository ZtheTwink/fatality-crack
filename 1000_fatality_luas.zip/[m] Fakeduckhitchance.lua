-- grab config interface to config
local config = fatality.config
-- grab menu interface to menu
local menu = fatality.menu

local auto_old_fakeduck_hitchance = menu:get_reference("rage", "weapons", "auto", "hitchance"):get_float( ) 
local scout_old_fakeduck_hitchance = menu:get_reference("rage", "weapons", "scout", "hitchance"):get_float( ) 
local awp_old_fakeduck_hitchance = menu:get_reference("rage", "weapons", "awp", "hitchance"):get_float( ) 
local heavypistol_old_fakeduck_hitchance = menu:get_reference("rage", "weapons", "heavy pistols", "hitchance"):get_float( ) 
local pistols_old_fakeduck_hitchance = menu:get_reference("rage", "weapons", "pistols", "hitchance"):get_float( ) 
local other_old_fakeduck_hitchance = menu:get_reference("rage", "weapons", "other", "hitchance"):get_float( ) 

local fakeduck = menu:get_reference( "rage", "aimbot", "aimbot", "fake duck" );

local auto_new_htc_fakeducking_item = config:add_item( "auto_old_htc_while_fakeduck_auto", 0 );
local auto_new_htc_fakeducking_slider = menu:add_slider( "hitchance whilst fakeduck", "rage", "weapons", "auto", auto_new_htc_fakeducking_item, 0, 100, 0 );

local scout_new_htc_fakeducking_item = config:add_item( "scout_old_htc_while_fakeduck_auto", 0 );
local scout_new_htc_fakeducking_slider = menu:add_slider( "hitchance whilst fakeduck", "rage", "weapons", "scout", scout_new_htc_fakeducking_item, 0, 100, 0 );

local awp_new_htc_fakeducking_item = config:add_item( "awp_old_htc_while_fakeduck_auto", 0 );
local awp_new_htc_fakeducking_slider = menu:add_slider( "hitchance whilst fakeduck", "rage", "weapons", "awp", awp_new_htc_fakeducking_item, 0, 100, 0 );

local heavypistol_new_htc_fakeducking_item = config:add_item( "heavypistol_old_htc_while_fakeduck_auto", 0 );
local heavypistol_new_htc_fakeducking_slider = menu:add_slider( "hitchance whilst fakeduck", "rage", "weapons", "heavy pistols", heavypistol_new_htc_fakeducking_item, 0, 100, 0 );

local pistols_new_htc_fakeducking_item = config:add_item( "pistols_old_htc_while_fakeduck_auto", 0 );
local pistols_new_htc_fakeducking_slider = menu:add_slider( "hitchance whilst fakeduck", "rage", "weapons", "pistols", pistols_new_htc_fakeducking_item, 0, 100, 0 );

local other_new_htc_fakeducking_item = config:add_item( "other_old_htc_while_fakeduck_auto", 0 );
local other_new_htc_fakeducking_slider = menu:add_slider( "hitchance whilst fakeduck", "rage", "weapons", "other", other_new_htc_fakeducking_item, 0, 100, 0 );


function on_paint( )

if fakeduck:get_bool( ) == true then
menu:get_reference( "rage", "weapons", "auto", "hitchance" ):set_float( auto_new_htc_fakeducking_item:get_float( ) )
menu:get_reference( "rage", "weapons", "scout", "hitchance" ):set_float( scout_new_htc_fakeducking_item:get_float( ) )
menu:get_reference( "rage", "weapons", "awp", "hitchance" ):set_float( awp_new_htc_fakeducking_item:get_float( ) )
menu:get_reference( "rage", "weapons", "heavy pistols", "hitchance" ):set_float( heavypistol_new_htc_fakeducking_item:get_float( ) )
menu:get_reference( "rage", "weapons", "pistols", "hitchance" ):set_float( pistols_new_htc_fakeducking_item:get_float( ) )
menu:get_reference( "rage", "weapons", "other", "hitchance" ):set_float( other_new_htc_fakeducking_item:get_float( ) )
else
menu:get_reference( "rage", "weapons", "auto", "hitchance" ):set_float( auto_old_fakeduck_hitchance )
menu:get_reference( "rage", "weapons", "scout", "hitchance" ):set_float( scout_old_fakeduck_hitchance )
menu:get_reference( "rage", "weapons", "awp", "hitchance" ):set_float( awp_old_fakeduck_hitchance )
menu:get_reference( "rage", "weapons", "heavy pistols", "hitchance" ):set_float( heavypistol_old_fakeduck_hitchance )
menu:get_reference( "rage", "weapons", "pistols", "hitchance" ):set_float( pistols_old_fakeduck_hitchance )
menu:get_reference( "rage", "weapons", "other", "hitchance" ):set_float( other_old_fakeduck_hitchance )
end

end

-- Register callbacks
local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );