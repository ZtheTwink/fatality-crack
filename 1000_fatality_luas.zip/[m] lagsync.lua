
--call
 local yawadd_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Yaw Add" )
 local yawadd_stand_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
 local fakeamount_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
 local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )

 local yawadd_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Yaw Add" )
 local yawadd_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Yaw Add" )

 local yawadd_stand_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
 local yawadd_move_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Add" )

 local fakeamount_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
 local fakeamount_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake amount" )
 local indicators = fatality.config:add_item( "indicators_desync", 0 )
 local menu = fatality.menu:add_checkbox( "Lagsync", "RAGE", "ANTI-AIM", "General", indicators )
 local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )
 local faketype_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake type" )

 local freestandfake_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Freestand fake" )
 local freestandfake_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Freestand fake" )

--call indicators
 local indicators = fatality.config:add_item( "indicators_desync", 0 )

--menu stuff
 local aa_type_stand = fatality.config:add_item( "aa_type_stand", 4 )
 local aa_type_stand_add = fatality.menu:add_combo( "Lagsync Mode:", "RAGE", "ANTI-AIM", "General", aa_type_stand )
 aa_type_stand_add:add_item("Off", aa_type_stand)
 aa_type_stand_add:add_item("Lagsync V1", aa_type_stand)
 aa_type_stand_add:add_item("Lagsync V2", aa_type_stand)
 aa_type_stand_add:add_item("Lagsync V3", aa_type_stand)

--font
 local Cambria = fatality.render:create_font( "Cambria", 50, 255, false )

--render indicators
 function render_indicators()

--get entity list
  local entity_list = csgo.interface_handler:get_entity_list()

--get localplayer variable
  local local_player = entity_list:get_localplayer()

  if(local_player ~= nil and local_player:is_alive()) then

--get screen size
   local screen_size = fatality.render:screen_size()

   fatality.render:text( Cambria, screen_size.x / 2 - 50, screen_size.y - 50, "LA", csgo.color(0, 0, 0, 255) )
   fatality.render:text( Cambria, screen_size.x / 2, screen_size.y - 50, "GSY", csgo.color(230, 0, 0, 255) )
   fatality.render:text( Cambria, screen_size.x / 2 + 74, screen_size.y - 50, "NC", csgo.color(255, 255, 255, 255) )

   end
 end


local side = false
function paint()

--antiaim standing
if (indicators:get_bool( )) then 

    render_indicators() 
    side = not side
	
	  if (aa_type_stand:get_int() == 1 ) then --lagsync v1

        yawadd_stand:set_bool( true )

        if (side) then

	    --move
	    yawadd_move_amount:set_float( 25 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )

		--standing
        yawadd_stand_amount:set_float( -30 )
		fakeamount_stand:set_float( -70 )
		faketype_stand:set_int( 2 )

        else

		--moving
		yawadd_move_amount:set_float( -25 )
        fakeamount_move:set_float( -65 )

		--standing
        yawadd_stand_amount:set_float( -25 )
		fakeamount_stand:set_float( -65 )

		
    end
  end

  	  if (aa_type_stand:get_int() == 2 ) then --lagsync V2
	
        yawadd_stand:set_bool( true )
     
        if (side) then
	
	    --move
	    yawadd_move_amount:set_float( 25 )
        fakeamount_move:set_float( 100 )
		faketype_move:set_int( 2 )
		
		--standing
        yawadd_stand_amount:set_float( 19 )
		fakeamount_stand:set_float( 80 )
		

        else
		
		--standing
        yawadd_stand_amount:set_float( - 10 )
		fakeamount_stand:set_float( - 60 )
		faketype_stand:set_int( 3 )
		--moving
		yawadd_move_amount:set_float( -15 )
        fakeamount_move:set_float( 100 )
		
	end
  end

  	  if (aa_type_stand:get_int() == 3 ) then --lagsync V3
	
        yawadd_stand:set_bool( true )
      
        if (side) then
	
	    --move
	    yawadd_move_amount:set_float( 25 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )
	
		--standing
        yawadd_stand_amount:set_float( 25 )
		fakeamount_stand:set_float( -70 )
		faketype_stand:set_int( 2 )
 
        else
	
		--standing
        yawadd_stand_amount:set_float( -5 )
		fakeamount_stand:set_float( -65 )
	
		--moving
		yawadd_move_amount:set_float( -15 )
        fakeamount_move:set_float( -65 )
		
    end
   end	
  end
 end
 


fatality.callbacks:add( "paint", paint)