-- https://fatality.win/threads/forward-manual-anti-aim.640/

local globals = csgo.interface_handler:get_global_vars( );

local input = fatality.input;
local render = fatality.render;
local menu = fatality.menu;
local config = fatality.config;

local manualaa_item = config:add_item( "manual_aa", 0.0 );
local manualaa_checkbox = menu:add_checkbox( "Forward", "rage", "anti-aim", "general", manualaa_item );

local forward_key = 0x26; --change keybind here, get all keys number: https://docs.microsoft.com/en-us/windows/desktop/inputdev/virtual-key-codes

local last_timer = globals.tickcount;
function manage_key( )
    if ( input:is_key_down( forward_key ) and globals.tickcount - last_timer > 20 ) then
        forward_toggled = not forward_toggled;
        last_timer = globals.tickcount;
    end
    local forward_enabled = forward_toggled;
    manualaa_item:set_bool( forward_enabled );
end

local yawaddstand_backup = menu:get_reference( "rage", "anti-aim", "Standing", "Yaw Add" ):get_bool( );
local yawaddvaluestand_backup = menu:get_reference( "rage", "anti-aim", "Standing", "Add" ):get_float( );

local yawaddmoving_backup = menu:get_reference( "rage", "anti-aim", "Moving", "Yaw Add" ):get_bool( );
local yawaddvaluemoving_backup = menu:get_reference( "rage", "anti-aim", "Moving", "Add" ):get_float( );

local freestandstanding_backup = menu:get_reference( "rage", "anti-aim", "Standing", "Freestand" ):get_bool( );
local freestandmoving_backup = menu:get_reference( "rage", "anti-aim", "Moving", "Freestand" ):get_bool( );
function on_paint( )
    manage_key( );
    if ( manualaa_item:get_bool( ) ) then
        menu:get_reference( "rage", "anti-aim", "Standing", "Yaw Add" ):set_bool( true );
        menu:get_reference( "rage", "anti-aim", "Standing", "Add"):set_float( 180 );

        menu:get_reference( "rage", "anti-aim", "Moving", "Yaw Add" ):set_bool( true );
        menu:get_reference( "rage", "anti-aim", "Moving", "Add"):set_float( 180 );
        
        menu:get_reference( "rage", "anti-aim", "Standing", "Freestand" ):set_bool( false );
        menu:get_reference( "rage", "anti-aim", "Moving", "Freestand" ):set_bool( false );
    else
        menu:get_reference( "rage", "anti-aim", "Standing", "Yaw Add" ):set_bool( yawaddstand_backup );
        menu:get_reference( "rage", "anti-aim", "Standing", "Add"):set_float( yawaddvaluestand_backup );

        menu:get_reference( "rage", "anti-aim", "Moving", "Yaw Add" ):set_bool( yawaddmoving_backup );
        menu:get_reference( "rage", "anti-aim", "Moving", "Add"):set_float( yawaddvaluemoving_backup );
        
        menu:get_reference( "rage", "anti-aim", "Standing", "Freestand" ):set_bool( freestandstanding_backup );
        menu:get_reference( "rage", "anti-aim", "Moving", "Freestand" ):set_bool( freestandmoving_backup );
    end
    --indicator
    if ( config:get_item( "aa.indicator"):get_int( ) == 1 and
     manualaa_item:get_bool( ) and
      menu:get_reference( "rage", "anti-aim", "general", "Back" ):get_int( ) == 0 and
       menu:get_reference( "rage", "anti-aim", "general", "Left" ):get_int( ) == 0 and
        menu:get_reference( "rage", "anti-aim", "general", "Right" ):get_int( ) == 0 ) then

        local screen_size = render:screen_size( );
        render:indicator( screen_size.x / 110, screen_size.y / 2 - 32, "FORWARD", true, -1 );
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );