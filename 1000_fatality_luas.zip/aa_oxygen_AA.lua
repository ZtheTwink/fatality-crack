--call
local yawadd_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Yaw Add" )
local yawadd_stand_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
local fakeamount_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )

local yawadd_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Yaw Add" )
local yawadd_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Yaw Add" )

local yawadd_stand_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
local yawadd_move_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Add" )

local fakeamount_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
local fakeamount_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake amount" )
local indicators = fatality.config:add_item( "indicators_desync", 0 )
local menu = fatality.menu:add_checkbox( "Slumpys Enabled", "RAGE", "ANTI-AIM", "General", indicators )
local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )
local faketype_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake type" )

local freestandfake_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Freestand fake" )
local freestandfake_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Freestand fake" )

--call indicators
local indicators = fatality.config:add_item( "indicators_desync", 0 )

--Menu stuff
local aa_type_stand = fatality.config:add_item( "aa_type_stand", 4 )
local aa_type_stand_add = fatality.menu:add_combo( "AA Mode:", "RAGE", "ANTI-AIM", "General", aa_type_stand )
aa_type_stand_add:add_item("Off", aa_type_stand)
aa_type_stand_add:add_item("Experimental ", aa_type_stand)
aa_type_stand_add:add_item("Jitter Breaker ", aa_type_stand)
aa_type_stand_add:add_item("Backwords Jitter ", aa_type_stand)
aa_type_stand_add:add_item("Desync Breaker", aa_type_stand)

--Font
local Cambria = fatality.render:create_font( "Cambria", 50, 255, 255 )
local change_x = fatality.config:add_item( "pos_x", 0 )
local change_y = fatality.config:add_item( "pos_y", 0 )
local cursor_pos = fatality.input:get_mouse_pos( )



--render indicators
function render_indicators(pos_x, pos_y, width, height)

    if fatality.input:is_key_down(0x2E) then --fucking retarded shit need to remake

        change_x:set_int( fatality.input:get_mouse_pos( ).x )
        change_y:set_int( fatality.input:get_mouse_pos( ).y )
        fatality.render:rect_fade(  pos_x + change_x:get_int() - 5 - 1, pos_y + change_y:get_int() - 5 - 1, width + 10 + 2, height + 10 + 2, csgo.color(255, 0, 0, 255), csgo.color(255, 0, 255, 255))
     end
	  

end


local side = false
function paint()

--Antiaim standing
if (indicators:get_bool( )) then 

    render_indicators(0, 0, 200, 150) 
    side = not side
	
	  if (aa_type_stand:get_int() == 1 ) then 
	
        yawadd_stand:set_bool( true )
        if (side) then
		
		--move
	    yawadd_move_amount:set_float( 25 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )
		
        --standing
        yawadd_stand_amount:set_float( -15 )
		fakeamount_stand:set_float( -80 )
	
        else
		
		--moving
		yawadd_move_amount:set_float( -15 )
        fakeamount_move:set_float( -65 )
		
		--standing
        yawadd_stand_amount:set_float( -25 )
		fakeamount_stand:set_float( -65 )
		faketype_stand:set_int( 2 )
		
	
		
    end
	
  end

	  if (aa_type_stand:get_int() == 2 ) then
	
        yawadd_stand:set_bool( true )
        
        if (side) then
		
		--move
	    yawadd_move_amount:set_float( 25 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )
		
        --standing
        yawadd_stand_amount:set_float( 24 )
		fakeamount_stand:set_float( -100 )
		faketype_stand:set_int( 2 )
 
        else
		
		--moving
		yawadd_move_amount:set_float( -15 )
        fakeamount_move:set_float( -65 )
		
		--standing
        yawadd_stand_amount:set_float( 0 )
		fakeamount_stand:set_float( 20 )
		faketype_stand:set_int( 3 )
		
		
    end
	
  end
  
  	  if (aa_type_stand:get_int() == 3 ) then 
	
        yawadd_stand:set_bool( true )
        
        if (side) then
	
		--move
	    yawadd_move_amount:set_float( 30 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )
		
		--standing
        yawadd_stand_amount:set_float( 0 )
		fakeamount_stand:set_float( -76 )
		faketype_stand:set_int( 2 )
 
        else
		
		--moving
		yawadd_move_amount:set_float( -20 )
        fakeamount_move:set_float( -65 )
		
		--standing
        yawadd_stand_amount:set_float( -12 )
		fakeamount_stand:set_float( -88 )
		
	end
	
  end
  
  	  if (aa_type_stand:get_int() == 4 ) then 
        yawadd_stand:set_bool( true )
        
        if (side) then
	
	    --move
	    yawadd_move_amount:set_float( 23 )
        fakeamount_move:set_float( -70 )
		faketype_move:set_int( 2 )
		
		--standing
        yawadd_stand_amount:set_float( 23 )
		fakeamount_stand:set_float( -70 )
		faketype_stand:set_int( 2 )
 
        else
		
		--moving
		yawadd_move_amount:set_float( -20 )
        fakeamount_move:set_float( -65 )
		
		--standing
        yawadd_stand_amount:set_float( -20 )
		fakeamount_stand:set_float( -65 )
		
    end
   end	
  end
 end



fatality.callbacks:add( "paint", paint)