-- Customizable hitlogs by eslipe v.1.2 (Current version of: 23.03.2019)


--[[ Updatelog:

(23.03.2019)
- Added Combo-box to switch between 3D-hitmarker/3D-hitdamage
- Added 3D-hitmarker
- Added new fonts
- Added "Add shadow" function
- Changed name of functions ( To make then more understandable )
- Removed "Outlined text" doesn't work anymore ( Because since the last update cheat adds shadow instead of outline )


(27.02.2019)
- Added static mode for animation
- Added new fonts (Smallest pixel-7, Arial). (Smallest Pixel-7 is not a windows font. You have to download it)
- Added final version of colour-changer (Read the description)
- Removed "background" function
- Changed animation & opacity speed (x2 faster)
- Added dropshadow to the text. "Shadowed font" funtcion.

------------------------------------------------------------------------------------------------------------ 
                                                (Description)
                                  Why did I rework colour-changer? (Reason):

            Old colour-changer had 3 sliders for: Red, Green and Blue colours. 
            Yes, it was the best way to let user customize the colour for function, 
            but it used too much space in the menu and that's a problem, 
            because menu has a limited space for fucntions (Fact).
            Imagine having 3-4 luas with old colour-changer, let's look at the example.                            

            [OLDD COLOUR-PICKERS (EXAMPLE)]          VS           [ NEW COLOUR-PICKERS (EXAMPLE)]

            (3d-hitmarkers)                                       (3d-hitmarkers) 
            Red   ----------------- (0 - 255)                     Mixed-colours ----------------- (0 - 20)
            Green ----------------- (0 - 255)                                  
            Blue  ----------------- (0 - 255)
------------------------------------------------------------------------------------------------------------                                                       
   

                                        

(22.02.2019)
- Release

]]


-- menu
local menu = fatality.menu

-- config
local config = fatality.config

-- render
local render = fatality.render

-- global vars
local global_vars = csgo.interface_handler:get_global_vars( )

-- entity list
local entity_list = csgo.interface_handler:get_entity_list( )


-- engine client
local engine_client = csgo.interface_handler:get_engine_client( )



-- [ MENU FUNCTIONS ] --

    local hitlog_item  = config:add_item("3Dhm_hitlog_item", 0)
    local hitlog_combo = menu:add_combo("Hitmarker type", "visuals", "esp", "world", hitlog_item)
    hitlog_combo:add_item("Hitdamage", hitlog_item)
    hitlog_combo:add_item("Hitmarker", hitlog_item)
    hitlog_combo:add_item("Both", hitlog_item)

    -- colour picker
    local colour_item = config:add_item("3Dhm_colour_item", 0)
    local colour_slider = menu:add_slider("3D-hitmarker colour", "visuals", "esp", "world", colour_item, 0 , 20, 1)

    -- fonts with shadow
    local outlined_item = config:add_item( "3Dhm_outlined_item", 0 )
    local outlined_checkbox = menu:add_checkbox( "Add shadow", "visuals", "esp", "world", outlined_item )
    

    -- animation type
    local animSide_item	 = config:add_item("3Dhm_animSide_item", 0)
    local animSide_combo = menu:add_combo("Animations", "visuals", "esp", "world", animSide_item)
    animSide_combo:add_item("S static", animSide_item)
    animSide_combo:add_item("| top", animSide_item)
    animSide_combo:add_item("< left", animSide_item)
    animSide_combo:add_item("> right", animSide_item)
    animSide_combo:add_item("v bottom", animSide_item)

    -- animation speed
    local animSpeed_item = config:add_item("3Dhm_animSpeed_item", 30)
    local animSpeed_slider = menu:add_slider("Animation speed", "visuals", "esp", "world", animSpeed_item, 25 , 150, 1)

    -- font switcher
    local font_item	 = config:add_item("3Dhm_font_item", 0)
    local font_combo = menu:add_combo("Fonts", "visuals", "esp", "world", font_item)
    font_combo:add_item("Courier New", font_item)
    font_combo:add_item("Verdana", font_item)
    font_combo:add_item("Verdana Bold", font_item)
    font_combo:add_item("Smallest Pixel-7 / DL", font_item)
    font_combo:add_item("Arial", font_item)
    font_combo:add_item("Tahoma", font_item)
    font_combo:add_item("Comic-sans", font_item)
    font_combo:add_item("Comic-sans Bold", font_item)

    -- show hitboxes
    local hitbox_item = config:add_item( "3Dhm_hitbox_item", 0 )
    local hitbox_checkbox = menu:add_checkbox( "Show hitboxes", "visuals", "esp", "world", hitbox_item )

    -- hitbox type
    local hitboxType_item = config:add_item("3Dhm_hitboxType_item", 0)
    local hitboxType_combo = menu:add_combo("Hitbox type", "visuals", "esp", "world", hitboxType_item)
    hitboxType_combo:add_item("Only hitted part", hitboxType_item)
    hitboxType_combo:add_item("Full hitbox", hitboxType_item)

    -- colour picker
    local hitboxesCol_item = config:add_item("3Dhm_hitboxesCol_item", 0)
    local hitboxesCol_slider = menu:add_slider("Hitbox colour", "visuals", "esp", "world", hitboxesCol_item, 0 , 20, 1)

-- [ MENU FUNCTIONS ] --   



-- [ FONTS ] -- 

    -- outlined
    local courier14_outl = render:create_font( "Courier new", 14, 400, true );
    local verdana12_outl = render:create_font( "Verdana", 12, 400, true );
    local verdanaBold12_outl = render:create_font( "Verdana Bold", 12, 600, true );
    local sPixel7_outl = render:create_font( "Smallest Pixel-7", 11, 100, true );
    local arial12_outl = render:create_font( "Arial", 12, 400, true );
    local tahoma12_outl = render:create_font( "Tahoma", 12, 400, true );
    local comicSans12_outl = render:create_font( "Comic Sans", 12, 700, true );
    local comicSansBold20_outl = render:create_font( "Comic Sans", 20, 700, true );

    -- without otline
    local courier14 = render:create_font( "Courier new", 14, 400, false );
    local verdana12 = render:create_font( "Verdana", 12, 400, false );
    local verdanaBold12 = render:create_font( "Verdana Bold", 12, 600, false );
    local sPixel7 = render:create_font( "Smallest Pixel-7", 11, 100, false );
    local arial12 = render:create_font( "Arial", 12, 400, false );
    local tahoma12 = render:create_font( "Tahoma", 12, 400, false );
    local comicSans12 = render:create_font( "Comic Sans", 12, 700, false );
    local comicSansBold20 = render:create_font( "Comic Sans", 20, 700, false );

-- [ FONTS ] -- 



-- adding logs to this variable
local logs = { }

-- getting personal screen size
local screensize = render:screen_size( )



-- on paint function
function on_paint( )

    -- in-game check
    if(not engine_client:is_in_game()) then
        return
    end
    
    -- counting logs
    for c = 1, #logs do
            
        -- nil check
        if(logs[ c ] == nil) then
            return 
        end
                
        -- rewriting positions from world to screen
        local pos = csgo.vector3(logs[ c ].pos.x, logs[ c ].pos.y, logs[ c ].pos.z)
        local posHitmarker = csgo.vector3(logs[ c ].posHitmarker.x, logs[ c ].posHitmarker.y, logs[ c ].posHitmarker.z)
        logs[ c ].posHitmarker.z = logs[ c ].posHitmarker.z
            
        -- rewriting value from float to int
        local animSpeed_value = animSpeed_item:get_float( ) * 1
        local colour_value = colour_item:get_float( ) * 1
            
        -- animated opacity
        local opacity = math.floor(255 * (global_vars.realtime - logs[ c ].rTime) / 2)

        if(global_vars.realtime - logs[ c ].rTime > 1.5) then
            opacity = math.floor(255 - 255 * (global_vars.realtime - logs[ c ].rTime))
        end

            -- customizable animations
            if animSide_item:get_int( ) == 0 then
                logs[ c ].pos.z = logs[ c ].pos.z
            elseif animSide_item:get_int( ) == 1 then
                logs[ c ].pos.z = logs[ c ].pos.z + ((global_vars.realtime - logs[ c ].fTime) * animSpeed_value)
            elseif animSide_item:get_int( ) == 2 then
                logs[ c ].pos.x = logs[ c ].pos.x - ((global_vars.realtime - logs[ c ].fTime) * animSpeed_value)
            elseif animSide_item:get_int( ) == 3 then
                logs[ c ].pos.x = logs[ c ].pos.x + ((global_vars.realtime - logs[ c ].fTime) * animSpeed_value)
            elseif animSide_item:get_int( ) == 4 then
                logs[ c ].pos.z = logs[ c ].pos.z - ((global_vars.realtime - logs[ c ].fTime) * animSpeed_value)
            end
            logs[ c ].fTime = global_vars.realtime

            -- colour changer (final version)
            if colour_value == 0 then
                colour_picker = csgo.color(255, 255, 255, opacity) --< white
                elseif colour_value == 1 then
                colour_picker = csgo.color(0, 0, 0, opacity) --< black
                elseif colour_value == 2 then
                colour_picker = csgo.color(255, 0, 0, opacity) --< deep-red
                elseif colour_value == 3 then
                colour_picker = csgo.color(244,67,54, opacity) --< red
                elseif colour_value == 4 then
                colour_picker = csgo.color(255,87,34, opacity) --< light-red
                elseif colour_value == 5 then
                colour_picker = csgo.color(255,152,0, opacity) --< deep-orange
                elseif colour_value == 6 then
                colour_picker = csgo.color(255,193,7, opacity) --< orange
                elseif colour_value == 7 then
                colour_picker = csgo.color(255,235,59, opacity) --< yellow
                elseif colour_value == 8 then
                colour_picker = csgo.color(205,220,57, opacity) --< lime
                elseif colour_value == 9 then
                colour_picker = csgo.color(139,195,74, opacity) --< light-green
                elseif colour_value == 10 then
                colour_picker = csgo.color(76,175,80, opacity) --< green
                elseif colour_value == 11 then
                colour_picker = csgo.color(0,150,136, opacity) --< teal
                elseif colour_value == 12 then
                colour_picker = csgo.color(0,188,212, opacity) --< cyan
                elseif colour_value == 13 then
                colour_picker = csgo.color(3,169,244, opacity) --< ligh-blue
                elseif colour_value == 14 then
                colour_picker = csgo.color(33,150,243, opacity) --< blue
                elseif colour_value == 15 then
                colour_picker = csgo.color(63,81,181, opacity) --< indigo
                elseif colour_value == 16 then
                colour_picker = csgo.color(103,58,183, opacity) --< deep-purple
                elseif colour_value == 17 then
                colour_picker = csgo.color(156,39,176, opacity) --< purple
                elseif colour_value == 18 then
                colour_picker = csgo.color(126,87,194, opacity) --< -light-purple
                elseif colour_value == 19 then
                colour_picker = csgo.color(233,30,99, opacity) --< deep-pink
                elseif colour_value == 20 then
                colour_picker = csgo.color(236,64,122, opacity) --< light-pink
                else
                colour_picker = csgo.color(255, 255, 255, opacity) --< default
            end
        
            -- screen check
            if(posHitmarker:to_screen( )) then

                if hitlog_item:get_int( ) == 1 or hitlog_item:get_int( ) == 2 then
                    -- [top] left-side
                    render:rect_filled(posHitmarker.x - 0.5 - 5, posHitmarker.y - 5, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x - 0.5 - 6, posHitmarker.y - 6, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x - 0.5 - 7, posHitmarker.y - 7, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x - 0.5 - 8, posHitmarker.y - 8, 2, 2, colour_picker);

                    -- [top] right-side
                    render:rect_filled(posHitmarker.x + 5, posHitmarker.y - 5, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x + 6, posHitmarker.y - 6, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x + 7, posHitmarker.y - 7, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x + 8, posHitmarker.y - 8, 2, 2, colour_picker);

                    -- [bottom] left-side
                    render:rect_filled(posHitmarker.x - 0.5 - 5, posHitmarker.y + 5, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x - 0.5 - 6, posHitmarker.y + 6, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x - 0.5 - 7, posHitmarker.y + 7, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x - 0.5 - 8, posHitmarker.y + 8, 2, 2, colour_picker);

                    -- [bottom] right-side
                    render:rect_filled(posHitmarker.x + 5, posHitmarker.y + 5, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x + 6, posHitmarker.y + 6, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x + 7, posHitmarker.y + 7, 2, 2, colour_picker);
                    render:rect_filled(posHitmarker.x + 8, posHitmarker.y + 8, 2, 2, colour_picker);
                end

            end

            -- screen check
            if(pos:to_screen( )) then
                
                -- if hitlogs were activated
                if hitlog_item:get_int( ) == 0 or hitlog_item:get_int( ) == 2 then

                    -- if outlined text was activated
                    if outlined_item:get_bool( ) then

                        -- swithcing fonts
                        if font_item:get_int( ) == 0 then 
                            render:text(courier14_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 1 then
                            render:text(verdana12_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 2 then
                            render:text(verdanaBold12_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 3 then
                            render:text(sPixel7_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 4 then
                            render:text(arial12_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 5 then
                            render:text(tahoma12_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 6 then
                            render:text(comicSans12_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 7 then
                            render:text(comicSansBold20_outl, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        end

                    else

                        -- swithcing fonts
                        if font_item:get_int( ) == 0 then 
                            render:text(courier14, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 1 then
                            render:text(verdana12, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 2 then
                            render:text(verdanaBold12, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 3 then
                            render:text(sPixel7, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 4 then
                            render:text(arial12, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 5 then
                            render:text(tahoma12, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 6 then
                            render:text(comicSans12, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        elseif font_item:get_int( ) == 7 then
                            render:text(comicSansBold20, pos.x - 8, pos.y - 8,  "-" .. logs[ c ].dmg, colour_picker)
                        end

                        end

                    end

                end
            
            if(global_vars.realtime - logs[ c ].rTime > 2.0) then
                table.remove(logs, c)
            end

        end



    
end



-- on shot function
function on_shot( shot )

    -- in-game check
    if(not engine_client:is_in_game()) then
        return
    end

    -- getting hitted player
    player = entity_list:get_player( shot.victim )

    -- player check
    if player == nil then
    return end

    local hitBoxesColour_value = hitboxesCol_item:get_float( ) * 1

    -- colour changer (final version)
    if hitBoxesColour_value == 0 then
        box_col = csgo.color(255, 255, 255, 25) --< white
        elseif hitBoxesColour_value == 1 then
        box_col = csgo.color(0, 0, 0, 25) --< black
        elseif hitBoxesColour_value == 2 then
        box_col = csgo.color(255, 0, 0, 25) --< deep-red
        elseif hitBoxesColour_value == 3 then
        box_col = csgo.color(244,67,54, 25) --< red
        elseif hitBoxesColour_value == 4 then
        box_col = csgo.color(255,87,34, 25) --< light-red
        elseif hitBoxesColour_value == 5 then
        box_col = csgo.color(255,152,0, 25) --< deep-orange
        elseif hitBoxesColour_value == 6 then
        box_col = csgo.color(255,193,7, 25) --< orange
        elseif hitBoxesColour_value == 7 then
        box_col = csgo.color(255,235,59, 25) --< yellow
        elseif hitBoxesColour_value == 8 then
        box_col = csgo.color(205,220,57, 25) --< lime
        elseif hitBoxesColour_value == 9 then
        box_col = csgo.color(139,195,74, 25) --< light-green
        elseif hitBoxesColour_value == 10 then
        box_col = csgo.color(76,175,80, 25) --< green
        elseif hitBoxesColour_value == 11 then
        box_col = csgo.color(0,150,136, 25) --< teal
        elseif hitBoxesColour_value == 12 then
        box_col = csgo.color(0,188,212, 25) --< cyan
        elseif hitBoxesColour_value == 13 then
        box_col = csgo.color(3,169,244, 25) --< ligh-blue
        elseif hitBoxesColour_value == 14 then
        box_col = csgo.color(33,150,243, 25) --< blue
        elseif hitBoxesColour_value == 15 then
        box_col = csgo.color(63,81,181, 25) --< indigo
        elseif hitBoxesColour_value == 16 then
        box_col = csgo.color(103,58,183, 25) --< deep-purple
        elseif hitBoxesColour_value == 17 then
        box_col = csgo.color(156,39,176, 25) --< purple
        elseif hitBoxesColour_value == 18 then
        box_col = csgo.color(126,87,194, 25) --< -light-purple
        elseif hitBoxesColour_value == 19 then
        box_col = csgo.color(233,30,99, 25) --< deep-pink
        elseif hitBoxesColour_value == 20 then
        box_col = csgo.color(236,64,122, 25) --< light-pink
        else
        box_col = csgo.color(255, 255, 255, 25) --< default
    end
      
    -- hit
    if shot.hurt then

        table.insert(logs, {pos = csgo.vector3(shot.hitpos.x, shot.hitpos.y, shot.hitpos.z), posHitmarker = csgo.vector3(shot.hitpos.x, shot.hitpos.y, shot.hitpos.z), fTime = global_vars.realtime, rTime = global_vars.realtime, dmg = shot.hit_damage, hitgroup = shot.hit_hitgroup})

        if hitbox_item:get_bool( ) then

            if hitboxType_item:get_int( ) == 0 then
                render:draw_hitgroup( player, shot.record.matrix, shot.hit_hitgroup, 3.0, box_col )
                render:draw_hitgroup( player, shot.record.matrix, -1, 3.0, csgo.color(255, 0, 0, 2) )
            elseif hitboxType_item:get_int( ) == 1 then
                render:draw_hitgroup( player, shot.record.matrix, -1, 3.0, box_col )
            end

        end
    end

end



-- callbacks

local callbacks = fatality.callbacks
callbacks:add( "registered_shot", on_shot )
callbacks:add("paint", on_paint)

-- end of the code