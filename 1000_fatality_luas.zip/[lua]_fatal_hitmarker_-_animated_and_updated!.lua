--Fatal hitmarker LUA by johnyy177, creds to @vertical for that hit event shit
--Draggable by mouse when holding delete and mouse 2, creds to @you

--UPDATES: 
--[30.10.2019] - fixed hitmarker not showing when local player is dead (useful for changing colors/position when ure dead), added new fontflag and now hitmarker shows damage u have given to enemy (smooth box resize)

--inputs
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local input = fatality.input

--menu items
local hitmarker_item = config:add_item( "visuals_esp_world_fatalhitmarker_checkbox", 0.0 )
local hitmarker_checkbox = menu:add_checkbox( "Fatal hitmarker", "VISUALS", "ESP", "World", hitmarker_item )
local hitmarker_color_item = config:add_item( "visuals_esp_world_fatalhitmarker_combobox", 0.0 )
local hitmarker_color = menu:add_combo( "Fatal hitmarker - color", "VISUALS", "ESP", "World", hitmarker_color_item )
hitmarker_color:add_item( "Fatality color scheme", hitmarker_color_item )
hitmarker_color:add_item( "Custom color scheme", hitmarker_color_item )

--colorpicker
local colorpickerR_item = config:add_item( "custom_color_scheme_red", 0 )
local colorpickerG_item = config:add_item( "custom_color_scheme_green", 0 )
local colorpickerB_item = config:add_item( "custom_color_scheme_blue", 0 )
local colorpickerR_slider = menu:add_slider( "Fatal hitmarker - R", "VISUALS", "ESP", "World", colorpickerR_item, 1, 255, 1 )
local colorpickerG_slider = menu:add_slider( "Fatal hitmarker - G", "VISUALS", "ESP", "World", colorpickerG_item, 1, 255, 1 )
local colorpickerB_slider = menu:add_slider( "Fatal hitmarker - B", "VISUALS", "ESP", "World", colorpickerB_item, 1, 255, 1 )

--save dragged position
local fatalhitmarker_pos_x = config:add_item( "fatalhitmarker_x", 7 )
local fatalhitmarker_pos_y = config:add_item( "fatalhitmarker_y", 7 )

--hit alpha
local hit_alpha = 0

--text doing weird things, gay fakk
local text_r1 = 0
local text_r2 = 0
local text_r3 = 0

--hit - fatal
local fatal_hp = 0 --hp count

--get screensize
local screensize = render:screen_size( )

--font weight flags converted to lua
local FW_DONTCARE = 0
local FW_THIN = 100
local FW_EXTRALIGHT = 200
local FW_ULTRALIGHT = 200
local FW_LIGHT = 300
local FW_NORMAL = 400
local FW_REGULAR = 400
local FW_MEDIUM = 500
local FW_SEMIBOLD = 600
local FW_MEDIUMBOLD = 650
local FW_DEMIBOLD = 600
local FW_BOLD = 700
local FW_EXTRABOLD = 800
local FW_ULTRABOLD = 800
local FW_HEAVY = 900
local FW_BLACK = 900

--create font for hitmarker
local calibrUh = render:create_font( "Calibri", 32, FW_NORMAL, false )

--on hit
function on_hit( game_events )

	--if you arent in game, return
	if not engine_client:is_in_game( ) then
       return end
        
    local local_player = entity_list:get_localplayer( )

	--if you arent alive, return
    if not local_player:is_alive( ) then
        return end
		
	--get events name
	if game_events:get_name( ) == "player_hurt" then
		--get userid and attacker
		local userid = entity_list:get_player_from_id( game_events:get_int( "userid" ) )
		local attacker = entity_list:get_player_from_id( game_events:get_int( "attacker" ) )
		
		if not attacker then
			return end
			
		if not userid then
			return end
		
		--get colors from colorpicker
		local colorpicker_r = math.floor( colorpickerR_item:get_float( ) )
		local colorpicker_g = math.floor( colorpickerG_item:get_float( ) )
		local colorpicker_b = math.floor( colorpickerB_item:get_float( ) )
		
		if userid:get_index( ) ~= local_player:get_index( ) then
			if attacker:get_index( ) == local_player:get_index( ) then
				hit_alpha = 255
				text_r1 = 235
				text_r2 = 235
				text_r3 = 235
				fatal_hp = game_events:get_int( "dmg_health" )
			end	
		end	
	end	
end --end

--local variable to smoothly move da box
local box_size = 0

--on paint
function on_paint( )
	--if you arent in game, return
    if not engine_client:is_in_game( ) then
       return end
        
    local local_player = entity_list:get_localplayer( )
	
	--get colors from colorpicker
	local colorpicker_r = math.floor( colorpickerR_item:get_float( ) )
    local colorpicker_g = math.floor( colorpickerG_item:get_float( ) )
    local colorpicker_b = math.floor( colorpickerB_item:get_float( ) )
	
	--get correct stuff for colors
	local correct_alpha = math.floor( hit_alpha )
	
	local correct_text_r1 = math.floor( text_r1 )
	local correct_text_r2 = math.floor( text_r2 )
	local correct_text_r3 = math.floor( text_r3 )
	
	--get correct screen position from screen size
	local screensize_x = screensize.x
	local screensize_y = screensize.y
	
	--get screen midle
	local middle_x = screensize_x / 2
	local middle_y = screensize_y / 2
	
	if hitmarker_item:get_bool( ) then
	--do the box with empty text
	
	--if hit_alpha > 0 then
	--	box_size = box_size + ( 255 * global_vars.frametime )
	--	if box_size > 35 then
	--		box_size = 35
	--end		
	
	--	render:rect( fatalhitmarker_pos_x:get_int( ) - 5.5, fatalhitmarker_pos_y:get_int( ) - 5.5, 90 + box_size - 9, 52, csgo.color( 255, 255, 255, 5 ) )
	--	render:rect_filled( fatalhitmarker_pos_x:get_int( ) - 4.5, fatalhitmarker_pos_y:get_int( ) - 4.5, 88 + box_size - 9, 50, csgo.color( 35, 35, 35, 220 ) )
	--	render:rect( fatalhitmarker_pos_x:get_int( ) - 1, fatalhitmarker_pos_y:get_int( ) - 1, 70 + box_size, 42, csgo.color( 255, 255, 255, 5 ) )
	--	render:rect_filled( fatalhitmarker_pos_x:get_int( ), fatalhitmarker_pos_y:get_int( ), 68 + box_size, 40, csgo.color( 0, 0, 0, 220 ) )
	--	render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10, fatalhitmarker_pos_y:get_int( ) + 2, "HIT", csgo.color( 255, 255, 255, 10 ) )		
	--else
	--	render:rect( fatalhitmarker_pos_x:get_int( ) - 5.5, fatalhitmarker_pos_y:get_int( ) - 5.5, 70, 52, csgo.color( 255, 255, 255, 5 ) )
	--	render:rect_filled( fatalhitmarker_pos_x:get_int( ) - 4.5, fatalhitmarker_pos_y:get_int( ) - 4.5, 68, 50, csgo.color( 35, 35, 35, 220 ) )
	--	render:rect( fatalhitmarker_pos_x:get_int( ) - 1, fatalhitmarker_pos_y:get_int( ) - 1, 60, 42, csgo.color( 255, 255, 255, 5 ) )
	--	render:rect_filled( fatalhitmarker_pos_x:get_int( ), fatalhitmarker_pos_y:get_int( ), 58, 40, csgo.color( 0, 0, 0, 220 ) )
	--	render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10, fatalhitmarker_pos_y:get_int( ) + 2, "HIT", csgo.color( 255, 255, 255, 10 ) )
	--end	
	
	if hit_alpha > 0 then
		if fatal_hp > 99 then
			box_size = box_size + ( 255 * global_vars.frametime )
			if box_size > 45 then
				box_size = 45
			end
		else
			box_size = box_size + ( 255 * global_vars.frametime )
			if box_size > 35 then
				box_size = 35
			end
		end	
	else
		box_size = box_size - ( 255 * global_vars.frametime )
		if box_size < -10 then
			box_size = -10
		end
	end
	render:rect( fatalhitmarker_pos_x:get_int( ) - 5.5, fatalhitmarker_pos_y:get_int( ) - 5.5, 90 + box_size - 9, 52, csgo.color( 255, 255, 255, 5 ) )
	render:rect_filled( fatalhitmarker_pos_x:get_int( ) - 4.5, fatalhitmarker_pos_y:get_int( ) - 4.5, 88 + box_size - 9, 50, csgo.color( 35, 35, 35, 220 ) )
	render:rect( fatalhitmarker_pos_x:get_int( ) - 1, fatalhitmarker_pos_y:get_int( ) - 1, 70 + box_size, 42, csgo.color( 255, 255, 255, 5 ) )
	render:rect_filled( fatalhitmarker_pos_x:get_int( ), fatalhitmarker_pos_y:get_int( ), 68 + box_size, 40, csgo.color( 0, 0, 0, 220 ) )
	render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10, fatalhitmarker_pos_y:get_int( ) + 2, "HIT", csgo.color( 255, 255, 255, 10 ) )	
	
	--get dragged position
    if input:is_key_down( 0x2E ) then
		--draw hit text before hitmarker
		if hitmarker_color_item:get_int( ) == 0 then
			render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10, fatalhitmarker_pos_y:get_int( ) + 2, "H", csgo.color( 235, 5, 90, 255 ) )
			render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10 + 16, fatalhitmarker_pos_y:get_int( ) + 2, "I", csgo.color( 235, 5, 90, 255 ) )
			render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10 + 23, fatalhitmarker_pos_y:get_int( ) + 2, "T", csgo.color( 235, 5, 90, 255 ) )
		elseif hitmarker_color_item:get_int( ) == 1 then	
			render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10, fatalhitmarker_pos_y:get_int( ) + 2, "HIT", csgo.color( colorpicker_r, colorpicker_g, colorpicker_b, 255 ) )
		end
		
        if input:is_key_down( 0x02 ) then
            fatalhitmarker_pos_x:set_int( input:get_mouse_pos( ).x )
            fatalhitmarker_pos_y:set_int( input:get_mouse_pos( ).y )
        end
    end
	
	--do hitmarker
	if hit_alpha > 0 then
		if hitmarker_color_item:get_int( ) == 0 then
			--render:text( calibrUh, fatalhitmarker_pos_x:get_int( ), fatalhitmarker_pos_y:get_int( ), "HIT", csgo.color( colorpicker_r, colorpicker_g, colorpicker_b, correct_alpha ) )
			render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10, fatalhitmarker_pos_y:get_int( ) + 2, "H", csgo.color( correct_text_r1, 5, 90, correct_alpha ) )
			render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10 + 16, fatalhitmarker_pos_y:get_int( ) + 2, "I", csgo.color( correct_text_r2, 5, 90, correct_alpha ) )
			render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10 + 23, fatalhitmarker_pos_y:get_int( ) + 2, "T", csgo.color( correct_text_r3, 5, 90, correct_alpha ) )
			render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10 + 24, fatalhitmarker_pos_y:get_int( ) + 2, "   - "..fatal_hp, csgo.color( correct_text_r3, 5, 90, correct_alpha ) )
			
		elseif hitmarker_color_item:get_int( ) == 1 then
			render:text( calibrUh, fatalhitmarker_pos_x:get_int( ) + 10, fatalhitmarker_pos_y:get_int( ) + 2, "HIT - "..fatal_hp, csgo.color( colorpicker_r, colorpicker_g, colorpicker_b, correct_alpha ) )
		end
		
		text_r1 = text_r1 - ( 120 * global_vars.frametime )
		text_r2 = text_r2 - ( 140 * global_vars.frametime )
		text_r3 = text_r3 - ( 160 * global_vars.frametime )
		
		hit_alpha = hit_alpha - ( 90 * global_vars.frametime )
	end
	end
end --end

--callbacks
local callbacks = fatality.callbacks
callbacks:add( "events", on_hit )
callbacks:add( "paint", on_paint )