-- https://fatality.win/threads/lua-draw-shot-lines.3090/

--Draw shot lines LUA by johnyy177

--inputs
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local input = fatality.input
local debug_overlay = csgo.interface_handler:get_debug_overlay( )

--menu checkbox
local draw_hit_lines_item = config:add_item( "draw_hit_lines", 0.0 )
local draw_hit_lines_checkbox = menu:add_checkbox( "Draw shot lines", "VISUALS", "Misc", "Beams", draw_hit_lines_item )
local draw_hit_lines_item_slider = config:add_item( "draw_hit_lines_slider", 0.0 )
local draw_hit_lines_slider = menu:add_slider( "Duration", "VISUALS", "Misc", "Beams", draw_hit_lines_item_slider, 1.0, 10.0, 1.0)

--colorpicker
local colorpicker_item = config:add_item( "draw_hit_lines_colorpicker", 0.0 )
local colorpicker_combo = menu:add_combo( "Colours", "VISUALS", "Misc", "Beams", colorpicker_item )
colorpicker_combo:add_item( "White", colorpicker_item )
colorpicker_combo:add_item( "Dark Red", colorpicker_item )
colorpicker_combo:add_item( "Red", colorpicker_item )
colorpicker_combo:add_item( "Orange", colorpicker_item )
colorpicker_combo:add_item( "Yellow", colorpicker_item )
colorpicker_combo:add_item( "Yellow-Green", colorpicker_item )
colorpicker_combo:add_item( "Green", colorpicker_item )
colorpicker_combo:add_item( "Cyan", colorpicker_item )
colorpicker_combo:add_item( "Light Blue", colorpicker_item )
colorpicker_combo:add_item( "Blue", colorpicker_item )
colorpicker_combo:add_item( "Purple", colorpicker_item )
colorpicker_combo:add_item( "Pink", colorpicker_item )
colorpicker_combo:add_item( "Bright Pink", colorpicker_item )
colorpicker_combo:add_item( "Grey", colorpicker_item )
colorpicker_combo:add_item( "Black", colorpicker_item )

--on paint
function on_paint() --i let it here because i thought i would use it for something
    --if you arent in game, return
    if not engine_client:is_in_game( ) then
       return end
       
    local local_player = entity_list:get_localplayer( )

    --if you arent alive, return
    if not local_player:is_alive( ) then
        return end
end --end

--on shot
function on_shot( shot )
    --if you arent in game, return
    if not engine_client:is_in_game( ) then
       return end
       
    local local_player = entity_list:get_localplayer( )

    --if you arent alive, return
    if not local_player:is_alive( ) then
        return end
       
    -- get the victim of the shot
    player = entity_list:get_player( shot.victim )
    if player == local_player then
        return end        
       
    local default_color = csgo.color(255, 255, 255, 255)

    if colorpicker_item:get_float( ) == 0 then --white
        default_color = csgo.color(255, 255, 255, 255)
    elseif colorpicker_item:get_float( ) == 1 then --dark red (maroon)
        default_color = csgo.color(128, 0, 0, 255)
    elseif colorpicker_item:get_float( ) == 2 then    --red
        default_color = csgo.color(255, 0, 0, 255)
    elseif colorpicker_item:get_float( ) == 3 then    --orange
        default_color = csgo.color(255, 128, 0, 255)
    elseif colorpicker_item:get_float( ) == 4 then    --yellow
        default_color = csgo.color(255, 255, 0, 255)
    elseif colorpicker_item:get_float( ) == 5 then    --yellow-green
        default_color = csgo.color(191, 255, 0, 255)  
    elseif colorpicker_item:get_float( ) == 6 then    --green
        default_color = csgo.color(0, 255, 0, 255)
    elseif colorpicker_item:get_float( ) == 7 then    --cyan
        default_color = csgo.color(0, 255, 255, 255)
    elseif colorpicker_item:get_float( ) == 8 then    --light blue
        default_color = csgo.color(0, 191, 255, 255)
    elseif colorpicker_item:get_float( ) == 9 then    --blue
        default_color = csgo.color(0, 0, 255, 255)
    elseif colorpicker_item:get_float( ) == 10 then --purple
        default_color = csgo.color(128, 0, 255, 255)  
    elseif colorpicker_item:get_float( ) == 11 then --pink
        default_color = csgo.color(255, 0, 255, 255)  
    elseif colorpicker_item:get_float( ) == 12 then --bright pink
        default_color = csgo.color(255, 204, 255, 25)  
    elseif colorpicker_item:get_float( ) == 13 then --grey
        default_color = csgo.color(128, 128, 128, 255)  
    elseif colorpicker_item:get_float( ) == 14 then --black
        default_color = csgo.color(0, 0, 0, 255)  
    end      
       
       
    if draw_hit_lines_item:get_bool( ) then
        debug_overlay:add_line_overlay( shot.shotpos, shot.hitpos, default_color, false, draw_hit_lines_item_slider:get_int( ) )
    end  
end

--callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )
callbacks:add( "registered_shot", on_shot )