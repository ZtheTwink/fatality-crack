--main instances
local menu = fatality.menu
local config = fatality.config
local fatalMath = fatality.math
local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()
--main instances
local dist = 4

local cfgBrute = config:add_item( 'JewlzAntiBrute', 1 )
menu:add_checkbox( 'Anti-Brute', 'rage', 'anti-aim', 'general', cfgBrute )

local standRef = menu:get_reference( 'rage', 'anti-aim', 'standing', 'fake amount' )
local moveRef = menu:get_reference( 'rage', 'anti-aim', 'moving', 'fake amount' )

function didMiss(i)
    local player = i
    local localPlayer = entity_list:get_localplayer()
    if player == nil or player == localPlayer or (player:get_var_int("CBaseEntity->m_iTeamNum") == localPlayer:get_var_int("CBaseEntity->m_iTeamNum")) then
        return end
    local ang = fatalMath:calc_angle(player:get_eye_pos(), localPlayer:get_eye_pos())
    local aimPunch = player:get_var_vector('CBasePlayer->m_aimPunchAngle')
    local eyeYaw = player:get_var_float('CCSPlayer->m_angEyeAngles[1]')
    local yawAngle = ang.y - aimPunch.y * 2
  
    if (yawAngle >= eyeYaw - dist and yawAngle <= eyeYaw + dist)then
        if cfgBrute:get_bool() then
            switchAA()
        end
    end
end

function switchAA()
  
    if standRef:get_int() < 0 then
        menu:get_reference( 'rage', 'anti-aim', 'standing', 'fake amount' ):set_int(math.abs(standRef:get_int()))
        menu:get_reference( 'rage', 'anti-aim', 'moving', 'fake amount' ):set_int(math.abs(moveRef:get_int()))
    else
        menu:get_reference( 'rage', 'anti-aim', 'standing', 'fake amount' ):set_int(-standRef:get_int())
        menu:get_reference( 'rage', 'anti-aim', 'moving', 'fake amount' ):set_int(-moveRef:get_int())
    end
end

function playerShot(i)

    local userID = i:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)

    return userIDPlayer
end

function event(i)

    local event = i:get_name()

    if event == 'weapon_fire' then
        local player = playerShot(i)
        didMiss(player)
    end
  
end

events:add_event('weapon_fire')
fatality.callbacks:add( 'events', event )