local entity_list    = csgo.interface_handler:get_entity_list()
local global_vars    = csgo.interface_handler:get_global_vars()
local engine_client    = csgo.interface_handler:get_engine_client()
local events        = csgo.interface_handler:get_events()
local render        = fatality.render
local menu            = fatality.menu

local font        = render:create_font("Tahoma", 14, 400, false)
local icons        = render:create_font("undefeated", 16, 400, true)

local show_window = false

local colors =
{
    white            = csgo.color(255, 255, 255, 180),
    dark_purple        = csgo.color(32, 24, 66, 255),
    darker_purple    = csgo.color(15, 12, 42, 255),
    border_purple    = csgo.color(60, 53, 93, 255),
}

local weapons =
{
    ["ssg08"]             = "a",
    ["xm1014"]             = "b",
    ["sawedoff"]         = "c",
    ["mag7"]             = "d",
    ["nova"]             = "e",
    ["negev"]             = "f",
    ["m249"]             = "g",
    ["taser"]             = "h",
    ["flashbang"]        = "i",
    ["hegrenade"]         = "j",
    ["smokegrenade"]    = "k",
    ["molotov"]         = "l",
    ["decoy"]             = "m",
    ["incgrenade"]         = "n",
    ["kevlar"]             = "p",
    ["assaultsuit"]     = "q",
    ["defuser"]         = "r",
    ["deagle"]             = "A",
    ["elite"]             = "B",
    ["fiveseven"]        = "C",
    ["glock"]             = "D",
    ["p250"]             = "F",
    ["usp_silencer"]     = "G",
    ["tec9"]             = "H",
    ["cz75a"]             = "I",
    ["revolver"]         = "J",
    ["mac10"]             = "K",
    ["ump45"]             = "L",
    ["bizon"]             = "M",
    ["mp7"]             = "N",
    ["mp9"]             = "O",
    ["p90"]             = "P",
    ["famas"]             = "Q",
    ["m4a1"]             = "R",
    ["m4a1_silencer"]     = "S",
    ["galilar"]         = "T",
    ["aug"]             = "U",
    ["sg556"]             = "V",
    ["ak47"]             = "W",
    ["g3sg1"]             = "X",
    ["scar20"]             = "Y",
    ["awp"]             = "Z",
    ["unknown"]            = ""
}

local players = {}

function get_alpha()
    return math.floor(math.abs(math.sin(global_vars.realtime / 2) * 128) + 127)
end

function get_longest_text()
    local size = 0
    for k, v in pairs(players) do
        local weapons_string = ""
     
        for k, v in pairs(v["weapons"]) do
            weapons_string = weapons_string .. weapons[v]
        end
     
        local namesize = render:text_size(font, v["name"]).x + render:text_size(icons, weapons_string).x
        if(namesize > size) then
            size = namesize
        end
    end
    return size
end

function get_table_size(tbl)
    local ctr = 0
    for k, v in pairs(tbl) do
        ctr = ctr + 1
    end
    return ctr
end

function draw_window(x, y, w, h)
    -- main window border
    render:rect(x - 1, y - 1, w + 2, h + 2, colors.border_purple)
 
    -- window top
    render:rect_filled(x, y, w, 12, colors.dark_purple)
    render:rect_filled(x, y + 12, w, h - 12, colors.darker_purple)
    render:rect_fade(x, y + 10, w, 2, csgo.color(50, 52, 255, get_alpha()), csgo.color(255, 0, 72, get_alpha()), true)
 
    --menu content box
    render:rect(x + 14, y + 29, w - 28, h - 14 * 3, colors.border_purple)
    render:rect_filled(x + 15, y + 30, w - 28 - 2, h - 14 * 3 - 2, colors.dark_purple)
 
    local counter = 0
    for k, v in pairs(players) do
        local weapons_string = ""
        for k, v in pairs(v["weapons"]) do
            weapons_string = weapons_string .. weapons[v]
        end
     
        render:text(font, x + 24, y + 35 + counter * 15, v["name"], colors.white)
        render:text(icons, x + 30 + render:text_size(font, v["name"]).x, y + 35 + counter * 15, weapons_string, colors.white)
        counter = counter + 1
    end
 
    for i = 0, 15 do
        render:rect(x, y + 12 + i, w, 1, csgo.color(0, 0, 0, (15 - i) * 16))
    end
end

events:add_event("item_purchase")
events:add_event("round_start")
events:add_event("round_freeze_end")

fatality.callbacks:add("events", function(e)
    local local_player = entity_list:get_localplayer()
 
    if(e:get_name() == "item_purchase") then
        if e:get_int("team") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
            local purchased_weapon = e:get_string("weapon")
            purchased_weapon = string.gsub(purchased_weapon, "weapon_", "")
            purchased_weapon = string.gsub(purchased_weapon, "item_", "")
         
            local buyer = entity_list:get_player_from_id(e:get_int("userid"))
         
            if(players[buyer:get_index()] == nil) then
                players[buyer:get_index()] =
                {
                    ["name"] = buyer:get_name(),
                    ["weapons"] = { purchased_weapon }
                }
            else
                table.insert(players[buyer:get_index()]["weapons"], purchased_weapon)
            end
        end
    end
 
    if(e:get_name() == "round_freeze_end") then
        show_window = false
    end
 
    if(e:get_name() == "round_start") then
        players = {}
        show_window = true
    end
end)

fatality.callbacks:add("paint", function()
    if(show_window and engine_client:is_in_game()) then
        draw_window(1500, 500, get_longest_text() + 50, 70 + get_table_size(players) * 15 - 15)
    end
end)