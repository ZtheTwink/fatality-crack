-- https://fatality.win/threads/bigboi22s-advanced-scope-removal.963/

-- interfaces
local entity_list = csgo.interface_handler:get_entity_list()
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client()

-- menu & config references
local advanced_scope_item = config:add_item( "visuals.advanced_scope", 0 );
local advanced_scope_checkbox = menu:add_checkbox( "advanced scope removal", "visuals", "misc", "local", advanced_scope_item );
local remove_scope_ref = menu:get_reference("visuals", "misc", "local", "remove scope")

local screen_size = render:screen_size()

function Clamp( _in, low, high )
    if ( _in < low ) then return low end
    if ( _in > high ) then return high end
    return _in
end

-- convar variables
local cvar = {
    cl_drawhud_force_deathnotices = cvar:find_var("cl_drawhud_force_deathnotices"),
    cl_drawhud  = cvar:find_var("cl_drawhud"),
    cl_drawhud_force_radar = cvar:find_var("cl_drawhud_force_radar"),
}

-- weapon list
local weapontable = {
    [229] = "AWP",
    [238] = "G3SG1",
    [257] = "SCAR20",
    [261] = "SG556",
    [262] = "SSG08",
}

-- prevents setting the cvars when its disabled
local once = false

function on_paint()

    if(advanced_scope_item:get_bool()) then
        once = true
        remove_scope_ref:set_bool(true)
      
        -- in-game check
        if not engine_client:is_in_game() then
        return end
      
        if(cvar.cl_drawhud_force_deathnotices:get_int() ~= 1 or cvar.cl_drawhud_force_radar:get_int() ~= 1) then
            cvar.cl_drawhud_force_deathnotices:set_int(1)
            cvar.cl_drawhud_force_radar:set_int(1)
        end
      
        local_player = entity_list:get_localplayer()
        if(local_player ~= nil and local_player:is_alive()) then
            local scoped = local_player:get_var_bool("CCSPlayer->m_bIsScoped")
          
            if scoped then
                if(cvar.cl_drawhud:get_int() ~= 0) then
                    cvar.cl_drawhud:set_int(0)
                end

                local weapon = csgo.interface_handler:get_entity_list():get_from_handle(local_player:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) )

                -- nil value check
                if weapon == nil then
                    return
                end

                 -- weapon index
                 local weaponindex = weapon:get_class_id()
               
                 if(weaponindex == 229 or weaponindex == 238 or weaponindex == 257 or weaponindex == 262) then
                      -- calculation (reading spread is not possible, so we use velocity instead)
                      local velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
                      local vel_2d = math.ceil( math.sqrt( math.abs( velocity.x ) * math.abs( velocity.x ) + math.abs( velocity.y ) * math.abs( velocity.y ) ) )
                    
                      local height = Clamp(vel_2d, 1.0, 23.0)
                      local alpha = 255 - (height * 4.2)
          
                      -- draw lines
                      if(vel_2d > 0) then
                        remove_scope_ref:set_bool(false)
                        render:rect_filled(1, screen_size.y / 2 - (height/2), screen_size.x, height, csgo.color( 0, 0, 0, math.floor(alpha) ))
                        render:rect_filled(screen_size.x / 2 - (height/2), 0, height, screen_size.y, csgo.color( 0, 0, 0, math.floor(alpha) ))
                      end
                 end
             else
                if(cvar.cl_drawhud:get_int() ~= 1) then
                    cvar.cl_drawhud:set_int(1)
                end
            end
        else
            if(cvar.cl_drawhud_force_deathnotices:get_int() ~= 0 or cvar.cl_drawhud_force_radar:get_int() ~= 0 or cvar.cl_drawhud:get_int() ~= 1) then
                cvar.cl_drawhud_force_deathnotices:set_int(0)
                cvar.cl_drawhud_force_radar:set_int(0)
                cvar.cl_drawhud:set_int(1)
            end
        end
    else
        if once then
            if(cvar.cl_drawhud_force_deathnotices:get_int() ~= 0 or cvar.cl_drawhud_force_radar:get_int() ~= 0 or cvar.cl_drawhud:get_int() ~= 1) then
                cvar.cl_drawhud_force_deathnotices:set_int(0)
                cvar.cl_drawhud_force_radar:set_int(0)
                cvar.cl_drawhud:set_int(1)
            end
            once = false
        end
    end
end

-- callback
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )

-- end of the code