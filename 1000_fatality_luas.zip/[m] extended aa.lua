-- june's lua megapack
-- this config was free at: discord.gg/XhMvwqr


local menu = fatality.menu
local callbacks = fatality.callbacks
local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )
local faketype_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake type" )
local standDesync = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount')
local stand_yaw, stand_yaw_add = menu:get_reference("Rage", "Anti-aim", "Standing", "Yaw add"),    menu:get_reference("Rage", "Anti-aim", "Standing", "Add")
local fakelag, flmove = menu:get_reference ("rage", "anti-aim", "standing", "base amount"), menu:get_reference("rage", "anti-aim", "moving", "base amount")
local moveDesync = menu:get_reference ("rage", "anti-aim", "moving", "fake amount")
local move_yaw, move_yaw_add = menu:get_reference("Rage", "Anti-aim", "moving", "Yaw add"),    menu:get_reference("Rage", "Anti-aim", "moving", "Add")
print("extended AA LUA by _markjelo💀#9266")
local dsd = 1
local dst = 1
local oat = 1
local aa_type_stand = fatality.config:add_item( "aa_type_stand", 4 )
local aa_type_stand_add = fatality.menu:add_combo( "Anti-Aim Mode:", "RAGE", "ANTI-AIM", "General", aa_type_stand )
aa_type_stand_add:add_item("Off", aa_type_stand)
aa_type_stand_add:add_item("Break-AR's", aa_type_stand) --Algorithmic Resolvers
aa_type_stand_add:add_item("Break Onetap", aa_type_stand)
aa_type_stand_add:add_item("Break Brute Force", aa_type_stand) --Brute Force Resolvers
aa_type_stand_add:add_item("Break Brute Force 2", aa_type_stand) --Brute Force Resolvers


function on_paint()

if (aa_type_stand:get_int() == 1 ) then
    stand_yaw:set_bool(true)
    move_yaw:set_bool(true)
    if stand_yaw_add:get_int() <= 181 then
        dst = math.random(1,3)
        oat = math.random(0,3)
        dsd = math.random(2,3)
        faketype_stand:set_int(dst)
        if faketype_stand:get_int() == 1 then
        stand_yaw_add:set_int(-35)
        standDesync:set_float(100)
        fakelag:set_float(1)
        end
        if faketype_stand:get_int() == 2 then
        stand_yaw_add:set_int(10)
        standDesync:set_float(-100)    
        fakelag:set_float(3)
        end
        if faketype_stand:get_int() == 3 then
        stand_yaw_add:set_int(0)
        standDesync:set_float(20)
        fakelag:set_float(2)
        end
        
        faketype_move:set_int(dsd)
        if faketype_move:get_int() == 2 then
        move_yaw_add:set_int(10)
        moveDesync:set_float(100)
        flmove:set_float(4)
        end
        if faketype_move:get_int() == 3 then
        move_yaw_add:set_int(-10)
        moveDesync:set_float(-100)
        flmove:set_float(2)
        end
    end
end

if (aa_type_stand:get_int() == 2 ) then
    stand_yaw:set_bool(true)
    move_yaw:set_bool(true)
    if stand_yaw_add:get_int() <= 181 then
        dst = math.random(1,3)
        oat = math.random(0,3)
        dsd = math.random(2,3)
        faketype_stand:set_int(dst)
        if faketype_stand:get_int() == 1 then
        stand_yaw_add:set_int(-30)
        standDesync:set_float(70)    
        fakelag:set_float(2)
        end
        if faketype_stand:get_int() == 2 then
        stand_yaw_add:set_int(20)
        standDesync:set_float(70)    
        fakelag:set_float(1)
        end
        if faketype_stand:get_int() == 3 then
        stand_yaw_add:set_int(5)
        standDesync:set_float(-90)
        fakelag:set_float(4)
        end
        
        faketype_move:set_int(dsd)
        if faketype_move:get_int() == 2 then
        move_yaw_add:set_int(30)
        moveDesync:set_float(60)
        flmove:set_float(4)
        end
        if faketype_move:get_int() == 3 then
        move_yaw_add:set_int(-10)
        moveDesync:set_float(20)
        flmove:set_float(2)
        end
    end
end
if (aa_type_stand:get_int() == 3 ) then
    stand_yaw:set_bool(true)
    move_yaw:set_bool(true)
    if stand_yaw_add:get_int() <= 181 then
        dst = math.random(2,3)
        oat = math.random(0,3)
        dsd = math.random(2,3)
        faketype_stand:set_int(dst)
        if faketype_stand:get_int() == 2 then
        stand_yaw_add:set_int(0)
        standDesync:set_float(-100)    
        fakelag:set_float(4)
        end
        if faketype_stand:get_int() == 3 then
        stand_yaw_add:set_int(0)
        standDesync:set_float(20)
        fakelag:set_float(1)
        end
        
        faketype_move:set_int(dsd)
        if faketype_move:get_int() == 2 then
        move_yaw_add:set_int(15)
        moveDesync:set_float(-80)
        flmove:set_float(3)
        end
        if faketype_move:get_int() == 3 then
        move_yaw_add:set_int(-15)
        moveDesync:set_float(80)
        flmove:set_float(4)
        end
    end
end

if (aa_type_stand:get_int() == 4 ) then
    stand_yaw:set_bool(true)
    move_yaw:set_bool(true)
    if stand_yaw_add:get_int() <= 181 then
        dst = math.random(2,3)
        oat = math.random(0,3)
        dsd = math.random(2,3)
        faketype_stand:set_int(dst)
        if faketype_stand:get_int() == 2 then
        stand_yaw_add:set_int(10)
        standDesync:set_float(-80)    
        fakelag:set_float(4)
        end
        if faketype_stand:get_int() == 3 then
        stand_yaw_add:set_int(-5)
        standDesync:set_float(20)
        fakelag:set_float(1)
        end
        
        faketype_move:set_int(dsd)
        if faketype_move:get_int() == 2 then
        move_yaw_add:set_int(5)
        moveDesync:set_float(-100)
        flmove:set_float(2)
        end
        if faketype_move:get_int() == 3 then
        move_yaw_add:set_int(-5)
        moveDesync:set_float(100)
        flmove:set_float(3)
        end
    end
end

end
callbacks:add("paint", on_paint)


--main instances
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks
local fatalMath = fatality.math
local events = csgo.interface_handler:get_events()
local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()
--main instances
local onShotItem = config:add_item( 'onshot', 0 )
local onHurtItem = config:add_item( 'on hurt', 0 )
local onShotCheck = menu:add_checkbox( 'Flip AA On Shot', 'rage', 'anti-aim', 'general', onShotItem )
local onHurtCheck = menu:add_checkbox( 'Flip AA On Damage Taken', 'rage', 'anti-aim', 'general', onHurtItem )
local function swap()
    local standRef = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount'):get_int()
    local moveRef = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount'):get_int()
    if standRef < 0 then
        menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount'):set_int(100)--change these to what you want them to flip from
    elseif standRef > 0 then
        menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount'):set_int(-100)--change these to what you want them to flip from
    end
    if moveRef < 0 then
        menu:get_reference('rage', 'anti-aim', 'moving', 'fake amount'):set_int(100)--change these to what you want them to flip from
    elseif moveRef > 0 then
        menu:get_reference('rage', 'anti-aim', 'moving', 'fake amount'):set_int(-100)--change these to what you want them to flip from
    end
end
local function isShot(e)
    if not engine_client:is_in_game() then
        return end
    local localPlayer = entity_list:get_localplayer()
    local hurtID = e:get_int('userid')
    
    if hurtID == nil then
        return end
    local hurtIDPlayer = entity_list:get_player_from_id(hurtID)
    local hurtName = hurtIDPlayer:get_name()
    local localPlayerName = localPlayer:get_name()
    if hurtName == localPlayerName then
        if onHurtItem:get_bool() then
            swap()
        end
    end
end
local function event(e)
    local event = e:get_name()  
    if event == 'player_hurt' then
        isShot(e)
    end
end
function onShot(shot)
    if not engine_client:is_in_game() then
        return end
    local localPlayer = entity_list:get_localplayer()
    local shotInfo = shot.shot_info
    if not shotInfo.has_info then
        return end  
    if shot.hurt then
        if onShotItem:get_bool() then
        swap()
        end
    end
end
events:add_event('weapon_fire')
callbacks:add('events', event )
callbacks:add( 'registered_shot', onShot )

--local variables
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local callbacks = fatality.callbacks
local key = 0x14 -- CAPS key

--default variables
local aa_enable, aa_key = menu:get_reference("Rage", "Anti-aim", "General", "Anti-aim")
local aa_manual = menu:get_reference("Rage", "Anti-aim", "General", "Antiaim override")
-----------------------------------AA-----------------------------------]
--stand
local stand_fake_type, stand_fake_amount =
menu:get_reference("Rage", "Anti-aim", "Standing", "Fake type"),
menu:get_reference("Rage", "Anti-aim", "Standing", "Fake amount")

local stand_yaw_add, stand_yaw_add_value =
menu:get_reference("Rage", "Anti-aim", "Standing", "Yaw add"),
menu:get_reference("Rage", "Anti-aim", "Standing", "Add")

local stand_aa_jitter, stand_aa_jitter_range =
menu:get_reference("Rage", "Anti-aim", "Standing", "Jitter"),
menu:get_reference("Rage", "Anti-aim", "Standing", "Range")

--move
local move_fake_type, move_fake_amount =
menu:get_reference("Rage", "Anti-aim", "Moving", "Fake type"),
menu:get_reference("Rage", "Anti-aim", "Moving", "Fake amount")

local move_yaw_add, move_yaw_add_value =
menu:get_reference("Rage", "Anti-aim", "Moving", "Yaw add"),
menu:get_reference("Rage", "Anti-aim", "Moving", "Add")

local move_aa_jitter, move_aa_jitter_range =
menu:get_reference("Rage", "Anti-aim", "Moving", "Jitter"),
menu:get_reference("Rage", "Anti-aim", "Moving", "Range")

--air
local air_fake_type, air_fake_amount =
menu:get_reference("Rage", "Anti-aim", "Air", "Fake type"),
menu:get_reference("Rage", "Anti-aim", "Air", "Fake amount")

local air_yaw_add, air_yaw_add_value =
menu:get_reference("Rage", "Anti-aim", "Air", "Yaw add"),
menu:get_reference("Rage", "Anti-aim", "Air", "Add")

local air_aa_jitter, air_aa_jitter_range =
menu:get_reference("Rage", "Anti-aim", "Air", "Jitter"),
menu:get_reference("Rage", "Anti-aim", "Air", "Range")
------------------------------------------------------------------------]

--config variables
local desync_enable_item = config:add_item("enable_desync", 1)
local desync_type_item = config:add_item("desync_static", 0)
local desync_type_item_second = config:add_item("desync_jitter", 0)
local desync_flip = config:add_item("desync_flip", 0)

--fake angle variables
local desync_enable = menu:add_checkbox("fake angle", "Rage", "Anti-aim", "General", desync_enable_item)
local desync_type = menu:add_combo("fake angle type", "Rage", "Anti-aim", "General", desync_type_item)
desync_type:add_item("Static", desync_type_item)

callbacks:add("paint", function()
    if desync_enable_item:get_bool() then
        aa_manual:set_bool(false)

        stand_yaw_add:set_bool(true)
        move_yaw_add:set_bool(true)
        air_yaw_add:set_bool(true)

        stand_fake_type:set_int(2)
        move_fake_type:set_int(2)
        move_fake_type:set_int(2)

        if input:is_key_pressed(key) then
            desync_flip:set_bool(not desync_flip:get_bool())
        end

        local flip = desync_flip:get_bool()

        if desync_type_item:get_int() == 0 then
            stand_yaw_add_value:set_int(flip and 19 or -19)
            move_yaw_add_value:set_int(flip and 19 or -19)
            air_yaw_add_value:set_int(flip and 19 or -19)

            stand_fake_amount:set_int(flip and -100 or 100)
            move_fake_amount:set_int(flip and -100 or 100)
            air_fake_amount:set_int(flip and -100 or 100)

            stand_aa_jitter:set_bool(false)
            move_aa_jitter:set_bool(false)
            air_aa_jitter:set_bool(false)
        end
        if desync_type_item:get_int() == 1 then
            stand_yaw_add_value:set_int(flip and 90 or -90)
            move_yaw_add_value:set_int(flip and 90 or -90)
            air_yaw_add_value:set_int(flip and 90 or -90)

            stand_fake_amount:set_int(100)
            move_fake_amount:set_int(100)
            air_fake_amount:set_int(100)

            stand_aa_jitter:set_bool(true)
            move_aa_jitter:set_bool(true)
            air_aa_jitter:set_bool(true)

            stand_aa_jitter_range:set_int(120)
            move_aa_jitter_range:set_int(120)
            air_aa_jitter_range:set_int(120)
        end
    end
end)