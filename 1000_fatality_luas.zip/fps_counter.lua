-- https://fatality.win/threads/release-simple-fps-counter-v-1-1.4209/

--[[
Simple FPS counter for Fatality made by SnowyDuck

You have your normal colors.
You also have Rainbow wich is self explanatory.
You also have Fps Based wich shows green if it is OVER 60 FPS and shows red if it is UNDER 60

- - Changelog - - 
V 1.0 - Release
V 1.1 - Changed get_fps function, Moved the fps up a little so you can see what you write in chat, You can now also choose from 6 different placements.

--]]

local config = fatality.config;
local menu = fatality.menu;
local callbacks = fatality.callbacks;
local render = fatality.render;
local global_vars = csgo.interface_handler:get_global_vars( )
local screen_size = render:screen_size()
local frame_rate = 0

local text_colorpicker_item = config:add_item( "visuals_esp_player_sfc_text_colorpicker", 0.0 )
local text_colorpicker_combo = menu:add_combo( "Simple FPS Color", "VISUALS", "ESP", "Player", text_colorpicker_item )
text_colorpicker_combo:add_item("Rainbow", text_colorpicker_item)
text_colorpicker_combo:add_item("White", text_colorpicker_item)
text_colorpicker_combo:add_item("Dark Red", text_colorpicker_item)
text_colorpicker_combo:add_item("Red", text_colorpicker_item)
text_colorpicker_combo:add_item("Orange", text_colorpicker_item)
text_colorpicker_combo:add_item("Yellow", text_colorpicker_item)
text_colorpicker_combo:add_item("Yellow-Green", text_colorpicker_item)
text_colorpicker_combo:add_item("Green", text_colorpicker_item)
text_colorpicker_combo:add_item("Cyan", text_colorpicker_item)
text_colorpicker_combo:add_item("Light Blue", text_colorpicker_item)
text_colorpicker_combo:add_item("Blue", text_colorpicker_item)
text_colorpicker_combo:add_item("Purple", text_colorpicker_item)
text_colorpicker_combo:add_item("Pink", text_colorpicker_item)
text_colorpicker_combo:add_item("Bright Pink", text_colorpicker_item)
text_colorpicker_combo:add_item("Grey", text_colorpicker_item)
text_colorpicker_combo:add_item("Black", text_colorpicker_item)
text_colorpicker_combo:add_item("FPS Based", text_colorpicker_item)

local location_picker_item = config:add_item( "visuals_esp_player_sfc_location_picker", 0.0 )
local location_picker_combo = menu:add_combo( "Simple FPS Location", "VISUALS", "ESP", "Player", location_picker_item )
location_picker_combo:add_item("Bottom Left", location_picker_item)
location_picker_combo:add_item("Bottom Right", location_picker_item)
location_picker_combo:add_item("Bottom Centre", location_picker_item)
location_picker_combo:add_item("Top Left", location_picker_item)
location_picker_combo:add_item("Top Right", location_picker_item)
location_picker_combo:add_item("Top Centre", location_picker_item)


function get_fps( )
    frame_rate = global_vars.frametime / 1
    return math.floor( ( 1.0 / frame_rate ) + 0.5 )
end

local font = render:create_font( "Tahoma bold", 30, 500, false )
function fps_counter()

local x = screen_size.x / 2
local y = 10

local text_color = csgo.color(255, 255, 255, 255)

local r = math.floor( math.sin( global_vars.realtime / 2 * 3 ) * 127 + 128 )
local g = math.floor( math.sin( global_vars.realtime / 2 + 5 ) * 127 + 128 )
local b = math.floor( math.sin( global_vars.realtime / 2 + 7 ) * 127 + 128 )

    if text_colorpicker_item:get_float( ) == 0 then --rainbow
        text_color = csgo.color(r, g, b, 255)
    elseif text_colorpicker_item:get_float( ) == 1 then  -- White
        text_color = csgo.color(255, 255, 255, 255)
    elseif text_colorpicker_item:get_float( ) == 2 then  -- Dark red
        text_color = csgo.color(128, 0, 0, 255)
    elseif text_colorpicker_item:get_float( ) == 3 then  -- Red
        text_color = csgo.color(255, 0, 0, 255)
    elseif text_colorpicker_item:get_float( ) == 4 then  -- Orange
        text_color = csgo.color(255, 128, 0, 255)
    elseif text_colorpicker_item:get_float( ) == 5 then  -- Yellow
        text_color = csgo.color(255, 255, 0, 255)
    elseif text_colorpicker_item:get_float( ) == 6 then  -- Yellow-Green
        text_color = csgo.color(191, 255, 0, 255)   
    elseif text_colorpicker_item:get_float( ) == 7 then  -- Green
        text_color = csgo.color(0, 255, 0, 255)
    elseif text_colorpicker_item:get_float( ) == 8 then  -- Cyan
        text_color = csgo.color(0, 255, 255, 255)
    elseif text_colorpicker_item:get_float( ) == 9 then  --Light Blue
        text_color = csgo.color(0, 191, 255, 255)
    elseif text_colorpicker_item:get_float( ) == 10 then -- Blue
        text_color = csgo.color(0, 0, 255, 255)
    elseif text_colorpicker_item:get_float( ) == 11 then -- Purple
        text_color = csgo.color(128, 0, 255, 255)   
    elseif text_colorpicker_item:get_float( ) == 12 then -- Pink
        text_color = csgo.color(255, 0, 255, 255)   
    elseif text_colorpicker_item:get_float( ) == 13 then -- Bright pink
        text_color = csgo.color(255, 204, 255, 255)   
    elseif text_colorpicker_item:get_float( ) == 14 then -- Grey
        text_color = csgo.color(128, 128, 128, 255)   
    elseif text_colorpicker_item:get_float( ) == 15 then -- Black
        text_color = csgo.color(0, 0, 0, 255)
    elseif text_colorpicker_item:get_float( ) == 16 then -- FPS based
        if get_fps() < 60 then
        text_color = csgo.color(255, 0, 0, 255)
        else
        text_color = csgo.color(191, 255, 0, 255)
        end
    end

    if location_picker_item:get_float( ) == 0 then -- Bottom Left
        x = x / 95
        y = y * 95
    elseif location_picker_item:get_float( ) == 1 then -- Bottom Right
        x = x * 2 - 60
        y = y * 95
    elseif location_picker_item:get_float( ) == 2 then -- Bottom Centre
        x = x * 1 - 22
        y = y * 103
    elseif location_picker_item:get_float( ) == 3 then -- Top Left
        x = x / 95
        y = y * 1
    elseif location_picker_item:get_float( ) == 4 then -- Top Right
        x = x * 2 - 60
        y = y * 1
    elseif location_picker_item:get_float( ) == 5 then -- Top Centre
        x = x * 1 - 22
        y = y * 7
    end

render:text(font, x, y, get_fps(), text_color);

end

callbacks:add("paint", fps_counter);