-- Combokill sounds & effects by eslipe v.1.3 (current verison of: 18.02.2019)

--[[ Updatelog:

(18.02.2019)
- Added animation speed slider.
- Added "First blood" sound effect (Automatically activates on the first kill)
- Added "First blood" text effect (Automatically activates on the first kill)
- Removed "!" symbol at the end of combo-kill text.
- Added shadow for combo-kill text.
- Fixed overflow error.



(14.02.2019)
- Added menu support.
- Added customizable text size.
- Now you can enable/disable effects and/or sounds/

]]

-- getting needed variables
local render = fatality.render --< to render text effects
local callbacks = fatality.callbacks --< to be albe to make callbacks
local menu = fatality.menu
local config = fatality.config

-- getting all interfaces
local engine_client = csgo.interface_handler:get_engine_client() --< engine client
local entity_list = csgo.interface_handler:get_entity_list() --< entity list
local global_vars = csgo.interface_handler:get_global_vars() --< global vars
local events = csgo.interface_handler:get_events() --< game events

-- adding to the menu checkboxes/sliders
local effects_enable_item = config:add_item( "effects_enable_item", 0 )
local effects_enable_checkbox = menu:add_checkbox( "Combo-kill effects", "visuals", "misc", "various", effects_enable_item )

local font_size_item = config:add_item( "font_size_item", 35 )
local font_size_slider = menu:add_slider( "Text size", "visuals", "misc", "various", font_size_item, 10, 50, 1 )

local animation_speed_item = config:add_item( "animation_speed_item", 0.6 )
local animation_speed_slider = menu:add_slider( "Animation speed", "visuals", "misc", "various", animation_speed_item, 0.1, 0.9, 0.1 )


local sound_enable_item = config:add_item( "sound_enable_item", 0 )
local sound_enable_checkbox = menu:add_checkbox( "Combo-kill sounds", "visuals", "misc", "various", sound_enable_item )





-- variable to count kills
local kills = 0;

-- varaiable to realize script that you made a hit
local hurt_time = 0

-- start of alpha
local alpha = 0;

-- getting the round start event
events:add_event("round_start")

-- on-shot function
function on_shot( shot )

    -- sounds for kills
    local local_player = entity_list:get_localplayer()   --< creating local player variable
    local firstblood = "firstblood.wav" --< used for fisrt kill
    local doublekill = "double_kill.wav" --< used for 2 kills
    local multikill = "multikill.wav" --< used for 4 kills
    local godlike = "godlike.wav" --< used for 6 kills
    local monsterkill = "monsterkill_f.wav" --< used for 8 kills
    local unstoppable = "unstoppable.wav" --< used for 10 kills
    local whickedsick = "whickedsick.wav" --< used for 12 kills

    -- get the victim of the shot
    player = entity_list:get_player( shot.victim )
    if player == nil then
    return end

   -- counting value of kills
    if (shot.hurt and player:get_var_int("CBasePlayer->m_iHealth") <= 0) then
    hurt_time = global_vars.realtime
    kills = kills + 1;
    end

    -- sound checkbox check
    if sound_enable_item:get_bool() then

    -- if we did first kill, then play first blood sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 1) then
    engine_client:client_cmd("play " .. firstblood)
    end  

    -- if we did 2 kills, then play doublekill sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 2) then
    engine_client:client_cmd("play " .. doublekill)
    end

    -- if we did 4 kills, then play multikill sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 4) then
    engine_client:client_cmd("play " .. multikill)
    end

    -- if we did 6 kills, then play godlike sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 6) then
    engine_client:client_cmd("play " .. godlike)
    end

    -- if we did 8 kills, then play monsterkill sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 8) then
    engine_client:client_cmd("play " .. monsterkill)
    end

    -- if we did 10 kills, then play unstoppable sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 10) then
    engine_client:client_cmd("play " .. unstoppable)
    end

    -- if we did 12 kills, then play whickedsick sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 12) then
    engine_client:client_cmd("play " .. whickedsick)
    end

    end

    return end



-- variables for on_pait function
local local_player = entity_list:get_localplayer() --< creating local player variable  
local screen_size = render:screen_size( ); --< getting personal screen size
local animationAlpha = 0 --< animation alpha start
--



-- rendering text effects
function on_paint( )

        local font_size_value = font_size_item:get_float() * 1 --< changing value from float to int ( to be able to add this variable to the font size )
        local animation_speed_value = animation_speed_item:get_float()
        local verdanaCustom = render:create_font( "Verdana", font_size_value, 700, false ); --< creating new font

        -- smooth fade out
        local step = 255 / 0.6 * global_vars.frametime
        if hurt_time + 0.4 > global_vars.realtime then
        alpha = 255
        else
        alpha = alpha - step
        end

        -- animations
        local animationStep = 255 / animation_speed_value * global_vars.frametime
        if hurt_time + 0.1 > global_vars.realtime then
            animationAlpha = - 80
        else
        animationAlpha = animationAlpha - animationStep
        end

    -- effects checkbox check
    if effects_enable_item:get_bool() then

        -- alpha check
        if (alpha > 0) then

             -- if we did 2 kills, then draw DOUBLEKILL effect
            if(kills == 1) then
            render:text(verdanaCustom, screen_size.x / 2 + 1 - 150, screen_size.y / 2 + animationAlpha + 2, "FIRST BLOOD",  csgo.color(0, 0, 0, math.floor(alpha)))
            render:text(verdanaCustom, screen_size.x / 2 - 150, screen_size.y / 2 + animationAlpha, "FIRST BLOOD",  csgo.color(255, 50, 0, math.floor(alpha)))
            end

            -- if we did 2 kills, then draw DOUBLEKILL effect
            if(kills == 2) then
            render:text(verdanaCustom, screen_size.x / 2  + animationAlpha + 1, screen_size.y / 2 + animationAlpha + 2, "DOUBLEKILL",  csgo.color(0, 0, 0, math.floor(alpha)))
            render:text(verdanaCustom, screen_size.x / 2  + animationAlpha, screen_size.y / 2 + animationAlpha, "DOUBLEKILL",  csgo.color(0, 0, 255, math.floor(alpha)))
            end
 
     
            -- if we did 4 kills, then draw MULTIKILL effect
            if( kills == 4) then
            render:text(verdanaCustom, screen_size.x / 2  - animationAlpha + 1, screen_size.y / 2 + animationAlpha + 2, "MULTIKILL",  csgo.color(0, 0, 0, math.floor(alpha)))
            render:text(verdanaCustom, screen_size.x / 2  - animationAlpha, screen_size.y / 2 + animationAlpha, "MULTIKILL",  csgo.color(0, 255, 0, math.floor(alpha)))
            end

      

            -- if we did 6 kills, then draw GODLIKE effect
            if( kills == 6) then
            render:text(verdanaCustom, screen_size.x / 2  + animationAlpha + 1, screen_size.y / 2 - animationAlpha + 2, "GODLIKE",  csgo.color(0, 0, 0, math.floor(alpha)))
            render:text(verdanaCustom, screen_size.x / 2  + animationAlpha, screen_size.y / 2 - animationAlpha, "GODLIKE",  csgo.color(255, 0, 0, math.floor(alpha)))
            end

      
            -- if we did 8 kills, then draw MONSTERKILL effect
            if( kills == 8) then
            render:text(verdanaCustom, screen_size.x / 2 - animationAlpha + 1, screen_size.y / 2 - animationAlpha + 2, "MONSTERKILL",  csgo.color(0, 0, 0, math.floor(alpha)))
            render:text(verdanaCustom, screen_size.x / 2 - animationAlpha, screen_size.y / 2 - animationAlpha, "MONSTERKILL",  csgo.color(255, 0, 255, math.floor(alpha)))
            end

      

            -- if we did 10 kills, then draw UNSTOPPABLE effect
            if( kills == 10) then
            render:text(verdanaCustom, screen_size.x / 2  + animationAlpha + 1, screen_size.y / 2 + animationAlpha + 2, "UNSTOPPABLE",  csgo.color(0, 0, 0, math.floor(alpha)))
            render:text(verdanaCustom, screen_size.x / 2  + animationAlpha, screen_size.y / 2 + animationAlpha, "UNSTOPPABLE",  csgo.color(0, 255, 255, math.floor(alpha)))
            end

     

            -- if we did 12 kills, then draw WHICKEDSICK effect
            if( kills == 12) then
            render:text(verdanaCustom, screen_size.x / 2  - animationAlpha + 1, screen_size.y / 2 + animationAlpha + 2, "WHICKEDSICK",  csgo.color(0, 0, 0, math.floor(alpha)))
            render:text(verdanaCustom, screen_size.x / 2  - animationAlpha, screen_size.y / 2 + animationAlpha, "WHICKEDSICK",  csgo.color(255, 255, 0, math.floor(alpha)))
            end

        end

    end
       
end



-- kills are becoming 0, if round started
fatality.callbacks:add("events", function(e)
    if(e:get_name() == "round_start") then
        kills = 0
    end
end)
 


-- callbacks    
callbacks:add( "registered_shot", on_shot )
callbacks:add("paint", on_paint)

-- end of the code