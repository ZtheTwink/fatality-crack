local cvar = csgo.interface_handler:get_cvar( );
local config = fatality.config;
local menu = fatality.menu;

local skyboxes = {
    [0] = "cern",
    [1] = "extreme_glaciation_",
    [2] = "persistent_fog_",
    [3] = "polluted_atm_",
    [4] = "toxic_atm_",
    [5] = "sky_oblako_01",
    [6] = "Clear_night_sky",
    [7] = "pink",
    [8] = "sky105",
    [9] = "glorious_morning",
    [10] = "cruel_night_ovl_hq",
    [11] = "sky100",
    [12] = "marslike01",
    [13] = "blood1_"
}

local skybox_bool_item, skybox_value_item = config:add_item( "skybox_bool", 1 ), config:add_item( "skybox_values", 0 )
local skybox_bool_checkbox, skybox_value_combobox = menu:add_checkbox( "Custom Skyboxes", "visuals", "misc", "various", skybox_bool_item ), menu:add_combo( "Skyboxes", "visuals", "misc", "various", skybox_value_item )
for i = 0, #skyboxes, 1 do
    skybox_value_combobox:add_item( skyboxes[ i ], skybox_value_item );
end

local sv_skyname = cvar:find_var( "sv_skyname" );
local needs_reset = true
local old_val = -1;

function on_paint( )
    if needs_reset and skybox_bool_item:get_bool( ) then
        sv_skyname:set_string( skyboxes[ skybox_value_item:get_int( ) ] )
        needs_reset = false
    end

    if old_var == skybox_value_item:get_int( ) then
        return
    end

    old_var = skybox_value_item:get_int( )
    needs_reset = true
end

local function on_level_init( )
    needs_reset = true
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );
callbacks:add( "level_init", on_level_init );