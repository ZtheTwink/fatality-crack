local menu = fatality.menu
local config = fatality.config
local input = fatality.input

local ANTI_AIM_Standing_Yaw_add = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "add" )
local ANTI_AIM_Moving_Yaw_add = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "add" )
local ANTI_AIM_Air_Yaw_add = menu:get_reference( "RAGE", "ANTI-AIM", "Air", "add" )

local ANTI_AIM_Standing_Yaw_add1 = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "yaw add" )
local ANTI_AIM_Moving_Yaw_add1 = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "yaw add" )
local ANTI_AIM_Air_Yaw_add1 = menu:get_reference( "RAGE", "ANTI-AIM", "Air", "yaw add" )

local Left = menu:get_reference( "RAGE", "ANTI-AIM", "General", "Left" )
local Right = menu:get_reference( "RAGE", "ANTI-AIM", "General", "Right" )
--evade aa
local right_key = 0x41
local left_key = 0x44
--manual aa refined (change these values to use different keys other than the arrow ones)
local left_arrow_key = 0x25
local right_arrow_key = 0x27
local down_arrow_key = 0x28

local evade_item = config:add_item( "evade", 1.0 )
local evade_checkbox = menu:add_checkbox( "Evade AA", "RAGE", "ANTI-AIM", "General", evade_item )

local manual_item = config:add_item( "manual", 1.0 )
local manual_checkbox = menu:add_checkbox( "Manual AA w spin", "RAGE", "ANTI-AIM", "General", manual_item )

fatality.callbacks:add("paint", function()
    if not evade_item:get_bool( ) then
        return end
    if(input:is_key_pressed(right_key)) then
        Right:set_bool(true)
    end
end)

fatality.callbacks:add("paint", function()
    if not evade_item:get_bool( ) then
        return end
    if(input:is_key_pressed(left_key)) then
    Left:set_bool(true)
    end
end)

fatality.callbacks:add("paint", function()
    if not manual_item:get_bool( ) then
        return end
    if(input:is_key_pressed(right_arrow_key)) then
        ANTI_AIM_Standing_Yaw_add1:set_bool(true)
        ANTI_AIM_Moving_Yaw_add1:set_bool(true)
        ANTI_AIM_Air_Yaw_add1:set_bool(true)

        ANTI_AIM_Standing_Yaw_add:set_float(90)
        ANTI_AIM_Moving_Yaw_add:set_float(90)
        ANTI_AIM_Air_Yaw_add:set_float(90)
    end
end)

fatality.callbacks:add("paint", function()
    if not manual_item:get_bool( ) then
        return end
    if(input:is_key_pressed(left_arrow_key)) then
        ANTI_AIM_Standing_Yaw_add1:set_bool(true)
        ANTI_AIM_Moving_Yaw_add1:set_bool(true)
        ANTI_AIM_Air_Yaw_add1:set_bool(true)

        ANTI_AIM_Standing_Yaw_add:set_float(-90)
        ANTI_AIM_Moving_Yaw_add:set_float(-90)
        ANTI_AIM_Air_Yaw_add:set_float(-90)
    end
end)


fatality.callbacks:add("paint", function()
    if not manual_item:get_bool( ) then
        return end
    if(input:is_key_pressed(down_arrow_key)) then
        ANTI_AIM_Standing_Yaw_add1:set_bool(true)
        ANTI_AIM_Moving_Yaw_add1:set_bool(true)
        ANTI_AIM_Air_Yaw_add1:set_bool(true)

        ANTI_AIM_Standing_Yaw_add:set_float(0)
        ANTI_AIM_Moving_Yaw_add:set_float(0)
        ANTI_AIM_Air_Yaw_add:set_float(0)
    end
end)