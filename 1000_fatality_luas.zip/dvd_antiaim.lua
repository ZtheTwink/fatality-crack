-- https://fatality.win/threads/dvd-anti-aim.5214/

--main instances

local render = fatality.render

local menu = fatality.menu

local config = fatality.config

local callbacks = fatality.callbacks

local screen_size = render:screen_size()

local font = render:create_font('TI logoso TFB', 100, 0, false)

local global_vars = csgo.interface_handler:get_global_vars( )

--main instances

local x = math.random(0,screen_size.x)

local y = math.random(0,screen_size.y)

local xBool = true

local yBool = true

local speed = config:add_item( 'speen', 0.5 )

menu:add_slider( 'DVD SPEED', 'misc', '', 'movement', speed, 0.5, 10, 0.5 )

function paint()

    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )

    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )

    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 )

    if xBool then

        x = x + speed:get_float()

        if x > screen_size.x - screen_size.x/8.72727273 then

            xBool = false

        end

    else

        x = x - speed:get_float()

        if x < 0 then

            xBool = true

        end

    end

    if yBool then

        y = y + speed:get_float()

        if y > screen_size.y - screen_size.y/10.8 then

            yBool = false

        end

    else

        y = y - speed:get_float()

        if y < 0 then

            yBool = true

        end

    end

    render:text( font, x, y, 'j', csgo.color(r,g,b,255) )

end

callbacks:add( 'paint', paint )