hope this shit can helps you

--interfaces
local render = fatality.render;
local menu = fatality.menu
local input = fatality.input
local config = fatality.config
local screensize = render:screen_size();
--func
local Aimbot_Backtrack = menu:get_reference( "RAGE", "AIMBOT", "Aimbot", "Backtrack" )
local keybind_type_item = config:add_item("keybind_type_item", 0)
local key_combo = menu:add_combo("bracktrack keybind type", "RAGE", "AIMBOT", "Misc", keybind_type_item)
key_combo:add_item("Hold", keybind_type_item)
key_combo:add_item("Toggle", keybind_type_item)


local key = 0x48 --h key

--callbacks
fatality.callbacks:add("paint", function()
if keybind_type_item:get_int() == 0 then
if(input:is_key_down(key)) then
render:indicator( 10, screensize.y -100, "BT", true , -1)
Aimbot_Backtrack:set_bool(false)
else
Aimbot_Backtrack:set_bool(true)
end
end
if keybind_type_item:get_int() == 1 then
if(input:is_key_pressed(key)) then
Aimbot_Backtrack:set_bool(not ext_ref:get_bool())
end
end
end)