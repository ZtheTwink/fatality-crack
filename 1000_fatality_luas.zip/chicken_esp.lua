-- https://fatality.win/threads/chicken-esp.596/

local entity_list = csgo.interface_handler:get_entity_list( )

local render = fatality.render;

local small_12 = render:create_font( "Small Fonts", 12, 400, true )
function on_paint( )
    for i = 1, entity_list:get_max_entities( ), 1 do
        all_entity = entity_list:get_entity( i );
        if ( all_entity and all_entity:get_class_id( ) == 34 ) then
            origin = all_entity:get_var_vector( "CBaseEntity->m_vecOrigin" );
            origin:to_screen( );
            render:text( small_12, origin.x, origin.y, "Chicken", csgo.color( 255,255,255,255 ) );
        end
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );