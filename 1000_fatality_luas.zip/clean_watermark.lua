         -- Watermark By Toes --
--- Screensizing thanks to Rhealys code ---
-- https://fatality.win/threads/lua-clean-watermark-time-name-uid.5248/
local global_vars = csgo.interface_handler:get_global_vars( );
local entity_list = csgo.interface_handler:get_entity_list( );
local engine_client = csgo.interface_handler:get_engine_client( );

local config = fatality.config
local menu = fatality.menu
local render = fatality.render;

local watermark_item = config:add_item( "toes_watermark", 1.0 );
local random_ = config:add_item( "toes_button", 0.0 );
local space_button = menu:add_button( "                       < WATERMARK >                       ", "Visuals", "Misc", "Beams", random_ )
local watermark_checkbox = menu:add_checkbox( "Watermark", "Visuals", "Misc", "Beams", watermark_item )

local x_size, y_size = -250, 25;


local font = render:create_font( "Verdana", 12, 50, true );

function on_paint( )
    if ( watermark_item:get_bool( ) ) then
        local local_player = entity_list:get_localplayer( );
        if ( local_player == nil ) then
            return end

        local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
        local g = math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
        local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );

        local screen_size = render:screen_size( );
        local x = x_size >= 0 and x_size or screen_size.x + x_size;
        local y = y_size >= 0 and y_size or screen_size.y + y_size
        local x_cus = -0;

        render:rect_filled( x+8-x_cus, y+5, 197, 20, csgo.color(15,15,15,255) )
        render:rect_filled( x+2-x_cus, y+1, 208, 28, csgo.color(15,15,15,215) )
        render:rect( x+2-x_cus, y+0, 209, 30, csgo.color(95,95,95,255) )
        render:rect( x+7-x_cus, y+5, 198, 20, csgo.color(95,95,95,255) )
        render:rect_filled( x+8-x_cus, y+5, 196, 1, csgo.color(math.floor(r), math.floor(g), math.floor(b), 255));
        render:text( font, x+12-x_cus, y+9, "fata     .win", csgo.color( 255, 255, 255, 255 ) );
        render:text( font, x+31-x_cus, y+9, "lity", csgo.color( 125, 0, 0, 255 ) );
        render:text( font, x+67-x_cus, y+9, "|", csgo.color( 255, 255, 255, 255 ) );
        render:text( font, x+76-x_cus, y+9, "Toes  |", csgo.color( 255, 255, 255, 255 ) ); -- CHANGE NAME HERE
        render:text( font, x+115-x_cus, y+9, os.date("%H:%M:%S"), csgo.color( 255, 255, 255, 255 ) );
        render:text( font, x+170-x_cus, y+9, "| 391", csgo.color( 255, 255, 255, 255 ) ); -- CHANGE UID HERE

    
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );