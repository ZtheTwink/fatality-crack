-- https://fatality.win/threads/baim-based-on-velocity-advanced-baim.1269/
-- interfaces
local render = fatality.render
local input = fatality.input
local menu = fatality.menu
local config = fatality.config
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()
local entity_list = csgo.interface_handler:get_entity_list()

-- menu reference
local force_baim_ref = menu:get_reference("rage", "aimbot", "aimbot", "force baim")

-- adding some function to the menu
local force_baim_item = config:add_item( "force_baim_item", 0 )
local force_baim_checkbox = menu:add_checkbox( "Advanced force-baim", "rage", "aimbot", "aimbot", force_baim_item )

local min_velocity_item = config:add_item("min_velocity_item", 20)
local min_velocity_slider = menu:add_slider("Baim if speed over", "rage", "aimbot", "aimbot", min_velocity_item, 0 , 320, 1)

local max_velocity_item = config:add_item("max_velocity_item", 30)
local max_velocity_slider = menu:add_slider("Baim if speed under", "rage", "aimbot", "aimbot", max_velocity_item, 0 , 320, 1)

-- on paint function
fatality.callbacks:add("paint", function()

-- in-game check
if(not engine_client:is_in_game()) then
return
end

-- changing float to int
local min_velocity_value = min_velocity_item:get_float( ) * 1
local max_velocity_value = max_velocity_item:get_float( ) * 1

-- getting local player
local local_player = entity_list:get_localplayer( )

-- getting all players
for i = 1, entity_list:get_max_players() do

-- variable with a number of players
local player = entity_list:get_player( i )

-- definition of enemy
if player ~= nil and player:is_alive() and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then

-- getting velocity
local velocity = player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
local speed = math.ceil( math.sqrt( math.abs( velocity.x ) * math.abs( velocity.x ) + math.abs( velocity.y ) * math.abs( velocity.y ) ) )

-- if speed is more than it has to be
if force_baim_item:get_bool() then
if speed > min_velocity_value and speed < max_velocity_value then
force_baim_ref:set_bool(true)
else
force_baim_ref:set_bool(false)
end
end

end

end

end)

fatality.callbacks:add("events", function(e)
if(e:get_name() == "round_start") then
force_baim_ref:set_bool(false)
end
end)

-- end of the code