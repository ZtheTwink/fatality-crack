-- pasted by AzuaLL#8099

local menu = fatality.menu
local config = fatality.config
local value = fatality.value
local callbacks = fatality.callbacks;
local coffinsync_item = config:add_item( "example_item", 1.0 )
local coffinsync_checkbox = menu:add_checkbox( "Coffinsync", "RAGE", "ANTI-AIM", "General", coffinsync_item )
local clantagCombo = menu:add_checkbox("coffinsync clantag", 'rage', 'anti-aim', 'general', clantagItem)
local clantagItem = config:add_item('clantag item', 0)
-- references
    --stand
local stand_add = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
local stand_type = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )
local stand_fake = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
    --move
local move_add = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Add" )
local move_type = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake type" )
local move_fake = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake amount" )

--Font
local Cambria = fatality.render:create_font( "Cambria", 50, 255, 255 )
local change_x = fatality.config:add_item( "pos_x", 0 )
local change_y = fatality.config:add_item( "pos_y", 0 )
local cursor_pos = fatality.input:get_mouse_pos( )




function paint()
    if (coffinsync_item:get_bool()) then     
    side = not side
    stand_add:set_bool( true )
        if (side) then
		--move
	    move_add:set_float( 2 )
        move_fake:set_float( -65 )
		move_type:set_int( 2 )
        --standing
        stand_add:set_float( 2 )
		stand_fake:set_float( -65 )
        else
		--moving
		move_add:set_float( -5 )
        move_fake:set_float( -85 )
		--standing
        stand_add:set_float( -5 )
		stand_fake:set_float( -85 )
        stand_type:set_int( 2 )
        end
    end
end
fatality.callbacks:add( "paint", paint)
--slowwalk
local cvar = csgo.interface_handler:get_cvar( );
local config = fatality.config
local menu = fatality.menu
local input = fatality.input;
cl_sidespeed = cvar:find_var( "cl_sidespeed" );
cl_forwardspeed = cvar:find_var( "cl_forwardspeed" );
cl_backspeed = cvar:find_var( "cl_backspeed" );
function set_speed( new_speed )
    if ( cl_sidespeed:get_int( ) == 450 and new_speed == 450 ) then
        return;
    end
     cl_sidespeed:set_float( new_speed );
     cl_forwardspeed:set_float( new_speed );
     cl_backspeed:set_float( new_speed );
end
local slowwalk_item = config:add_item( "slowwalk_rage", 0.0 )
local slowwalk_slider = menu:add_slider( "Slow walk", "rage", "ANTI-AIM", "general", slowwalk_item, 1, 100, 1 )
function on_paint( )
local is_down = input:is_key_down( 16 );
if not ( is_down ) then
set_speed( 450 )
else
local final_val = 250 * slowwalk_item:get_float( ) / 100
set_speed( final_val )
end
end
local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );



