-- Vizualize hitboxes by eslipe v.1.1 (Current version of: 25.04.2019)

--[[ Updatelog:

(25.04.2019)
- Added button to enable/disable texture
- Fixed FPS issue
- Fixed problem with compatibility of light-event log

(25.04.2019)
- Release

]]       

-- interfaces
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local cvar = csgo.interface_handler:get_cvar( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )
local render = fatality.render
local menu = fatality.menu
local config = fatality.config

-- screensize
local screensize = render:screen_size()

-- reference
local showHitboxes_item = config:add_item( "sh_enable", 0 )
local showHitboxes_checkbox = menu:add_checkbox( "Vizualize hitboxes", "visuals", "esp", "world", showHitboxes_item )
local showTexture_item = config:add_item( "sh_enable_texture", 1 )
local showTexture_checkbox = menu:add_checkbox( "Enable texture", "visuals", "esp", "world", showTexture_item )
local moveX_item = config:add_item("sh_moveX", 0)
local moveX_slider = menu:add_slider("Position X", "visuals", "esp", "world", moveX_item, 0 , screensize.x, 1)
local moveY_item = config:add_item("sh_moveY", 0)
local moveY_slider = menu:add_slider("Position Y", "visuals", "esp", "world", moveY_item, 0, screensize.y, 1 )

-- fonts
local sPixel7 = render:create_font( "Smallest Pixel-7", 11, 100, false )

-- creating hitlogs variable to place the hitlogs there
local hitlogs = {}
 
-- creating function to take hitlogs from on shot function
function add_hitlog(hitgroup)
    table.insert(hitlogs, {hitgroup = hitgroup, expiration = 10, fadein = 0})
end

-- on paint function
function on_paint()

    -- in-game check
    if not engine_client:is_in_game() then
    return
    end

    -- local player
    local local_player = entity_list:get_localplayer()

    -- changes float to int
    local moveX_value = moveX_item:get_float() * 1
    local moveY_value = moveY_item:get_float() * 1
    
    -- custom position
    local customPos = csgo.vector2( moveX_value, moveY_value )

    -- enable check
    if showHitboxes_item:get_bool() then

        -- < [ HEAD ] > --
        ------------------
        render:rect_filled( customPos.x - 1, customPos.y - 1, 152, 23, csgo.color(150,150,150,150)) --< outline
        render:rect_filled( customPos.x, customPos.y, 150, 21, csgo.color(50,50,50,255)) --< background
        render:rect_fade(customPos.x, customPos.y, 150, 21, csgo.color(25, 25, 34, 255), csgo.color(44, 45, 54, 255), true) --< gradient
        render:text(sPixel7, customPos.x + 6, customPos.y + 6, "Hitgroups", csgo.color(0,0,0,230)) --< shadow for header text
        render:text(sPixel7, customPos.x + 5, customPos.y + 5, "Hitgroups", csgo.color(180,180,180,255)) --< header text
        ------------------
        -- < [ HEAD ] > --

---

        -- < [ BODY ] > --
        ------------------
        render:rect_filled( customPos.x - 1, customPos.y + 21, 152, 122, csgo.color(150,150,150,150)) --< outline
        render:rect_filled( customPos.x, customPos.y + 22, 150, 120, csgo.color(10,10,17,255)) --< background
            if showTexture_item:get_bool() then
            -- [texture]
            for addY = 0, 22, 1 do
                for addX = 0, 29, 1 do
                render:rect_filled( (customPos.x + 2) + addX * 5, (customPos.y + 25) + addY * 5, 1, 1, csgo.color(150,150,150,5))
                end
            end
            -- [/texture]
            end
        ------------------
        -- < [ BODY ] > --

 ---

        -- < [ HITBOXES ] > --
        ----------------------
        -- [head]
            render:rect( customPos.x + 65, customPos.y + 45, 15, 15, csgo.color(150,150,150,100))
        -- [/head]

        -- [chest]
            render:rect( customPos.x + 70, customPos.y + 59, 6, 8, csgo.color(150,150,150,100))
        -- [/chest]
            
        -- [stomach]
            render:rect( customPos.x + 65, customPos.y + 66, 15, 30, csgo.color(150,150,150,100))
        -- [/stomach]

        -- [arms]
            render:rect( customPos.x + 57, customPos.y + 66, 6, 20, csgo.color(150,150,150,100)) --< left
            render:rect( customPos.x + 82, customPos.y + 66, 6, 20, csgo.color(150,150,150,100)) --< right
        -- [/arms]

        -- [hands]
            render:rect( customPos.x + 57, customPos.y + 87, 6, 6, csgo.color(150,150,150,100)) --< left
            render:rect( customPos.x + 82, customPos.y + 87, 6, 6, csgo.color(150,150,150,100)) --< right
        -- [/hands]

        -- [legs]
            render:rect( customPos.x + 65, customPos.y + 98, 6, 20, csgo.color(150,150,150,100)) --< left
            render:rect( customPos.x + 74, customPos.y + 98, 6, 20, csgo.color(150,150,150,100)) --< right

            render:rect( customPos.x + 65, customPos.y + 120, 6, 6, csgo.color(150,150,150,100)) --< left
            render:rect( customPos.x + 74, customPos.y + 120, 6, 6, csgo.color(150,150,150,100)) --< right
        -- [/legs]
        ----------------------   
        -- < [ HITBOXES ] > --

---       

        -- < [ HIT ] > --
        -----------------
        for i = 1, #hitlogs do
        
            -- nil check
            if (hitlogs[i] ~= nil) then
    
                if hitlogs[i].hitgroup == 1 then
                    render:rect( customPos.x + 65, customPos.y + 45, 15, 15, csgo.color(255,0,0,255))
                end
                if hitlogs[i].hitgroup == 2 or hitlogs[i].hitgroup == 8 then
                    render:rect( customPos.x + 70, customPos.y + 59, 6, 8, csgo.color(255,0,0,255))
                end
                if hitlogs[i].hitgroup == 3 then
                    render:rect( customPos.x + 65, customPos.y + 66, 15, 30, csgo.color(255,0,0,255))
                end
                if hitlogs[i].hitgroup == 4 then
                    render:rect( customPos.x + 57, customPos.y + 87, 6, 6, csgo.color(255,0,0,255)) --< left
                    render:rect( customPos.x + 82, customPos.y + 87, 6, 6, csgo.color(255,0,0,255)) --< right
                end
                if hitlogs[i].hitgroup == 5 then
                    render:rect( customPos.x + 57, customPos.y + 66, 6, 20, csgo.color(255,0,0,255)) --< left
                    render:rect( customPos.x + 82, customPos.y + 66, 6, 20, csgo.color(255,0,0,255)) --< right
                end
                if hitlogs[i].hitgroup == 6 or hitlogs[i].hitgroup == 7 then
                    render:rect( customPos.x + 65, customPos.y + 98, 6, 20, csgo.color(255,0,0,255)) --< left
                    render:rect( customPos.x + 74, customPos.y + 98, 6, 20, csgo.color(255,0,0,255)) --< right

                    render:rect( customPos.x + 65, customPos.y + 120, 6, 6, csgo.color(255,0,0,255)) --< left
                    render:rect( customPos.x + 74, customPos.y + 120, 6, 6, csgo.color(255,0,0,255)) --< right
                end


                -- removes log if time is expired
                hitlogs[i].expiration = hitlogs[i].expiration - 0.01
                if (hitlogs[i].expiration <= 1.2) then
                    table.remove(hitlogs, l)
                end

            end
    
        end

    end

end
        -----------------
        -- < [ HIT ] > --

---       

-- on shot function
    function on_registered_shot( shot )
 
 
        -- creating a variable of the enemy
        local enemy = entity_list:get_player( shot.victim )
    
        -- nil check
        if enemy == nil then
            return
        end
    
        -- getting shot info
        local shot_info_t = shot.shot_info
    
        -- returns the function if something goes wrong
        if not shot_info_t.has_info then
            return
        end
    
        -- creating a variable of default hitgroup
        local hitgroup=0
    
        -- if we did a hit
        if shot.hurt then
    
            local getHealth = enemy:get_var_int("CBasePlayer->m_iHealth")
    
             -- if the cheat did a hit, then render this line
            add_hitlog(shot.hit_hitgroup)

        end
    
    end

local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint)
callbacks:add( "registered_shot", on_registered_shot)

-- end of the code