-- fatality interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local interfaces = csgo.interface_handler
local input = fatality.input;
-- csgo interfaces
local game =
{
    globals = interfaces:get_global_vars(),
    engine = interfaces:get_engine_client(),
    entity_list = interfaces:get_entity_list(),
    events = interfaces:get_events(),
    cvar = interfaces:get_cvar()
}
-- fonts
local fonts =
{
    main = render:create_font( "Tahoma", 14, 300, true )
}
local keys =
{
    peek_left = 0x4F, -- O
    peek_right = 0x50, -- P
    abort = 0xA0 -- LSHIFT
}
local data =
{
    last_tickcount = 0,
    is_peeking = false,
    is_retracting = false,
    direction = 0, -- 0 = left, 1 = right
    peek_start = csgo.vector3( 0, 0, 0 ),
    peek_end = csgo.vector3( 0, 0, 0 ),
    travelled_distance = 0,
    last_velocity = 0
}
local helper =
{
    move_left = function()
                    -- just make sure we are no longer trying to move right
                    game.engine:client_cmd( "-moveright" )
                    game.engine:client_cmd( "+moveleft" )
                end,
   
    move_right = function()
                    -- just make sure we are no longer trying to move left
                    game.engine:client_cmd( "-moveleft" )
                    game.engine:client_cmd( "+moveright" )
                end,
    reset = function()
                data.is_peeking = false
                data.is_retracting = false
                data.last_velocity = 0
                if data.direction == 0 then
                    game.engine:client_cmd( "-moveleft" )
                else
                    game.engine:client_cmd( "-moveright" )
                end
            end,
    vector_length = function( vec )
                        return math.sqrt( vec.x * vec.x + vec.y * vec.y + vec.z * vec.z )
                    end,
    vector_distance = function( first, second )
                        local x, y, z = first.x - second.x, first.y - second.y, first.z - second.z;
                        return math.sqrt( x * x + y * y + z * z )
                    end
}

local function on_paint( )
    -- render start point if necessary
    if data.is_peeking or data.is_retracting then
        local start_pos = csgo.vector3( data.peek_start.x, data.peek_start.y, data.peek_start.z + 12 )
        if start_pos:to_screen() then
            render:rect_filled( start_pos.x - 10, start_pos.y - 10, 20, 20, csgo.color( 200, 200, 200, 255 ) )
        end
    end
    -- only run handling code once per tick
    if last_tickcount == game.globals.tickcount then
        return
    end
   
    last_tickcount = game.globals.tickcount
   
    -- abort if necessary
    if data.is_peeking or data.is_retracting then
        if input:is_key_down( keys.abort ) then
            helper.reset()
        end
    end
   
    -- if we're peeking already there's nothing to handle here except drawing start point
    if data.is_peeking then
        -- check if cheat wants to autostop, cance out any movement then
        local cur_velocity = helper.vector_length( game.entity_list:get_localplayer():get_var_vector( "CBasePlayer->m_vecVelocity[0]" ) )
        if cur_velocity + 16 < data.last_velocity then       
            if data.direction == 0 then
                game.engine:client_cmd( "-moveleft" )
            else
                game.engine:client_cmd( "-moveright" )
            end
            data.last_velocity = 0
        end
       
        data.last_velocity = cur_velocity
        return
    end

    -- check if we're done retracting
    if data.is_retracting then
        local cur_pos = game.entity_list:get_localplayer():get_var_vector( "CCSPlayer->m_vecOrigin" )
        if helper.vector_distance( cur_pos, data.peek_end ) >= data.travelled_distance then
            helper.reset()
        end
    end
    -- should we start peeking left ?
    if input:is_key_down( keys.peek_left ) then
        data.is_peeking = true
        data.is_retracting = false
        data.direction = 0
        data.peek_start = game.entity_list:get_localplayer():get_var_vector( "CCSPlayer->m_vecOrigin" )
        helper.move_left()
    -- should we start peeking right ?
    elseif input:is_key_down( keys.peek_right ) then
        data.is_peeking = true
        data.is_retracting = false
        data.direction = 1
        data.peek_start = game.entity_list:get_localplayer():get_var_vector( "CCSPlayer->m_vecOrigin" )
        helper.move_right()
    end
end
local function on_shot( shot )
    -- if we were peeking, stop now
    if not data.is_peeking then
        return
    end
    data.is_peeking = false
    data.is_retracting = true
    data.peek_end = game.entity_list:get_localplayer():get_var_vector( "CCSPlayer->m_vecOrigin" )
    data.travelled_distance = helper.vector_distance( data.peek_end, data.peek_start )
    -- start moving back
    if data.direction == 0 then
        data.direction = 1
        helper.move_right()
    else
        data.direction = 0
        helper.move_left()
    end
end
-- Register callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )
callbacks:add( "registered_shot", on_shot )