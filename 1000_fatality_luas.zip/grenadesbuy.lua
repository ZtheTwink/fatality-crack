local f = fatality
local client = csgo.interface_handler:get_engine_client()

local nades = f.config:add_item('ch.autobuy.nades',0)

local function getRef(...)
	return f.menu:get_reference(...)
end

f.menu:add_checkbox('Grenades', 'misc', '', 'buy bot',nades)

f.callbacks:add("events", function(ev)
	local name = ev:get_name()

	if name == "round_prestart" then
		if nades:get_bool() == true then
			client:client_cmd("buy molotov; buy hegrenade; buy smokegrenade;buy flashbang")
		end
	end
end)