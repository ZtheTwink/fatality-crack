-- https://fatality.win/threads/custom-clantag-with-input-box.4311/

require "clantag_api"
local menu = fatality.menu;
local config = fatality.config;
local globals   = csgo.interface_handler:get_global_vars()
local last_tick = globals.realtime
local render = fatality.render;
local input = fatality.input;
local active = false
local txt = ""
local save_txt = ""
local save_rotate_txt = ""
local p

function active_func()
    active = not active
end

local ct_custom_speed_item  = config:add_item("clantag_custom_speed_lua", 0.6)
local ct_custom_animated_item = config:add_item( "clantag_custom_animated_lua", 0 );
menu:add_button( "Custom CT Input", "Visuals", "misc", "various", active_func )
menu:add_slider("Clantag Speed", "Visuals", "misc", "various", ct_custom_speed_item, 0, 10, 0.1)
local ct_custom_animated_combo = menu:add_combo("Animated Custom CT", "Visuals", "misc", "various", ct_custom_animated_item)
ct_custom_animated_combo:add_item( "Static", ct_custom_animated_item );
ct_custom_animated_combo:add_item( "Build", ct_custom_animated_item );
ct_custom_animated_combo:add_item( "Rotate", ct_custom_animated_item );

local small_13 = render:create_font( "Small Fonts", 15, 650, false );

function draw_container( x, y, w, h )
    local c = {10, 60, 40, 40, 40, 60, 20};
    for i = 0,6,1 do
        render:rect_filled( x+i, y+i, w-(i*2), h-(i*2), csgo.color( c[i+1], c[i+1], c[i+1], 255 ) );
    end
end

local offset_x, offset_y = -193, 500;

local screen_size = render:screen_size( );
local x = offset_x >= 0 and offset_x or screen_size.x + offset_x;
local y = offset_y >= 0 and offset_y or screen_size.y + offset_y
local offset_x_temp = 16.5;

function input_box()
    if active then
        draw_container(x-offset_x_temp+10, y, 184+offset_x_temp, 30)
        if input:is_key_down( 0x08 ) then    
            if globals.realtime > last_tick+0.10 then
            txt = string.sub(txt,0,string.len(txt)-1)
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x0D ) then    
            if globals.realtime > last_tick+0.10 then
            active = false;
            save_txt = txt
            save_rotate_txt = txt
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x20 ) then    
            if globals.realtime > last_tick+0.10 then
                txt = txt .. " "
                last_tick = globals.realtime
                end
        end
        if input:is_key_down( 0x30 ) and not input:is_key_down( 0x10 ) then    
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "0"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x31 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "1"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x32 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "2"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x33 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "3"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x34 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "4"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x35 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "5"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x36 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "6"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x37 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "7"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x38 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "8"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x39 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "9"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x30 ) and input:is_key_down( 0x10 ) then    
            if globals.realtime > last_tick+0.10 then
            txt = txt .. ")"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x31 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "!"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x32 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "@"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x33 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "#"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x34 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "$"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x35 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "%"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x36 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "^"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x37 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "&"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x38 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "*"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x39 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "("
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x41 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "a"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x42 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "b"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x43 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "c"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x44 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "d"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x45 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "e"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x46 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "f"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x47 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "g"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x48 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "h"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x49 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "i"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4A ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "j"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4B ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "k"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4C ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "l"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4D ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "m"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4E ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "n"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4F ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "o"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x50 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "p"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x51 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "q"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x52 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "r"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x53 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "s"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x54 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "t"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x55 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "u"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x56 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "v"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x57 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "w"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x58 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "x"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x59 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "y"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x5A ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "z"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x41 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "A"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x42 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "B"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x43 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "C"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x44 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "D"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x45 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "E"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x46 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "F"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x47 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "G"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x48 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "H"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x49 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "I"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4A ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "J"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4B ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "K"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4C ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "L"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4D ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "M"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4E ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "N"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x4F ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "O"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x50 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "P"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x51 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "Q"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x52 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "R"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x53 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "S"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x54 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "T"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x55 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "U"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x56 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "V"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x57 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "W"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x58 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "X"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x59 ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "Y"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x5A ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "Z"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x60 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "0"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x61 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "1"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x62 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "2"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x63 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "3"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x64 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "4"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x65 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "5"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x66 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "6"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x67 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "7"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x68 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "8"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x69 ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "9"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x6A ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "*"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x6B ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "+"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x6C ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "."
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x6D ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "-"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0x6F ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "/"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBA ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. ";"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBA ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. ":"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBB ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "+"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBB ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "="
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBD ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "-"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBD ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "_"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBE ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "."
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBF ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "/"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBF ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "?"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBF ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "`"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xBF ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "~"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xDB ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "["
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xDB ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "{"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xDC ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "\\"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xDC ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "|"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xDD ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "]"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xDD ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "}"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xDE ) and not input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "\'"
            last_tick = globals.realtime
            end
        end
        if input:is_key_down( 0xDE ) and input:is_key_down( 0x10 ) then
            if globals.realtime > last_tick+0.10 then
            txt = txt .. "\""
            last_tick = globals.realtime
            end
        end
        render:text( small_13, x+23-offset_x_temp, y+8, txt.."|", csgo.color( 255, 255, 255, 230 ) );
    end
end



function custom_rotate()
    if save_rotate_txt ~= nil then
        fist_char = string.sub(save_rotate_txt,0,1)
        save_rotate_txt = string.sub(save_rotate_txt,2,string.len(save_rotate_txt)) .. fist_char
        SET_CLANTAG_MADE_BY_DUCARII(save_rotate_txt)
    end
end

local phase = 0;
local up = true

function build_clantag(clan)
    if clan ~= nil then
        if up then
            if phase < string.len(clan) then
                clan = string.sub(clan,0,phase)
                SET_CLANTAG_MADE_BY_DUCARII(clan)
                phase = phase +1
            else
               up = false
            end
        else
            if phase > 0 then
                clan = string.sub(clan,0,phase)
                SET_CLANTAG_MADE_BY_DUCARII(clan)
                phase = phase -1
            else
               up = true
            end
        end
    end
end


local function on_paint()
    input_box()
    if ct_custom_animated_item:get_int() == 0 then
        SET_CLANTAG_MADE_BY_DUCARII(save_txt)

    elseif ct_custom_animated_item:get_int() == 1 then
        if globals.realtime > last_tick + ct_custom_speed_item:get_float() then
            build_clantag(save_txt)
            last_tick = globals.realtime
        end
        
    elseif ct_custom_animated_item:get_int() == 2 then
        if globals.realtime > last_tick + ct_custom_speed_item:get_float() then
            custom_rotate()
            last_tick = globals.realtime
        end
        
    end
end


local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )