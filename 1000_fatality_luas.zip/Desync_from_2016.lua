-- https://fatality.win/threads/desynq-since-2016-freestand-pitch-0.5356/

print 'Desynq since 2k16 load by Dyson.'
 
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local entity_list = csgo.interface_handler:get_entity_list()
local global_vars = csgo.interface_handler:get_global_vars()
local screen_size = render:screen_size()

local ref_stand = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Freestand")
local ref_move = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Freestand")
local ref_pitch0 = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Pitch")
local ref_pitch1 = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Pitch")

local new_freestandonland = config:add_item("rage_freestandonland", 0)

local tickcount = 0
local lastground = false
local local_player
basicallydontcare = menu:add_checkbox("Desynq since 2k16","RAGE", "ANTI-AIM", "Standing", new_freestandonland)
function on_paint()
  local_player = entity_list:get_localplayer()
  if(local_player ~= nil and local_player:is_alive()) then   
        local velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
        if (new_freestandonland:get_bool()) then
            local onground = velocity.z == 0
            if not onground then
                tickcount = global_vars.curtime + .9;
            end
            if onground then
                if global_vars.curtime > tickcount  then
                    ref_stand:set_int(0)
                    ref_move:set_int(0)
                    ref_pitch0:set_int(1)
                    ref_pitch1:set_int(1)
                else
                    ref_stand:set_int(1)
                    ref_move:set_int(1)
                    ref_pitch0:set_int(3)
                    ref_pitch1:set_int(3)
                end
            end
        end

    end       
end
local callbacks = fatality.callbacks

callbacks:add( "paint", on_paint )