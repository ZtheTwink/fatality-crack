-- Baim slowwwalk Lua by johnyy177
--UPDATE: [30.8.2019] - fixed lua for latest cheat update, fixed bugs and baim indicator is always on from now

local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )

local baim_slowwalk_item = config:add_item( "baim_slowwalk_lua", 1.0 )
local baim_slowwalk_slider_item = config:add_item( "baim_slowwalk_slider_lua", 1.0 )
local baim_slowwalk_checkbox = menu:add_checkbox( "Baim Slow-walk", "RAGE", "AIMBOT", "Aimbot", baim_slowwalk_item )
local baim_slowwalk_slider = menu:add_slider( "Slow-walk - max velocity", "RAGE", "AIMBOT", "Aimbot", baim_slowwalk_slider_item, 1.0, 150.0, 1.0 )

local force_baim = menu:get_reference( "RAGE", "AIMBOT", "Aimbot", "Force fallback" )
local screensize = render:screen_size()
function on_paint()
    if not engine_client:is_in_game( ) then
       return end
       
    local local_player = entity_list:get_localplayer( )

    if not local_player:is_alive( ) then
        return end
       
   if baim_slowwalk_item:get_bool( ) then
       for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_TeamNum") then
                velocity = player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
                velocity2d = math.ceil( math.sqrt( math.abs( velocity.x ) * math.abs( velocity.x ) + math.abs( velocity.y ) * math.abs( velocity.y ) ) )
                if velocity2d <= baim_slowwalk_slider_item:get_float( ) and velocity2d >= 10 then
                   force_baim:set_bool( true )
                else
                   force_baim:set_bool( false )
                end
            end
        end
    end
    if force_baim:get_bool( ) then
        render:indicator( 10, screensize.y/1.77, "BAIM", true, -1)
    else
        render:indicator( 10, screensize.y/1.77, "BAIM", false, -1)
    end
end

local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)