local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local render = fatality.render
local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()
local globals   = csgo.interface_handler:get_global_vars()
local engine    = csgo.interface_handler:get_engine_client()
local menu      = fatality.menu
local config    = fatality.config
local input     = fatality.input
local callbacks = fatality.callbacks
local last_tick_stand = globals.realtime
local last_tick_move = globals.realtime
local last_tick_air = globals.realtime
local in_use_stand = false
local in_use_move = false
local in_use_air = false
local aa_state_standing = menu:get_reference( "rage", "anti-aim", "standing", "yaw add" )
local aa_state_standing2 = menu:get_reference( "rage", "anti-aim", "standing", "add" )
local standing_faketype = menu:get_reference( "rage", "anti-aim", "standing", "fake type" )

local aa_state_moving = menu:get_reference( "rage", "anti-aim", "moving", "yaw add" )
local aa_state_moving2 = menu:get_reference( "rage", "anti-aim", "moving", "add" )
local moving_faketype = menu:get_reference( "rage", "anti-aim", "moving", "fake type" )

local aa_state_air = menu:get_reference( "rage", "anti-aim", "air", "yaw add" )
local aa_state_air2 = menu:get_reference( "rage", "anti-aim", "air", "add" )
local air_faketype = menu:get_reference( "rage", "anti-aim", "air", "fake type" )



local aa_jitter_item = config:add_item( "aa_jitter_item", 0 )
local aa_jitter_checkbox = menu:add_checkbox( "AA jitter ", "rage", "anti-aim", "general", aa_jitter_item )

local aa_desync_invterter_item = config:add_item( "aa_state_item", 0 )
local aa_desync_invterter_checkbox = menu:add_checkbox( "Desync inverter", "rage", "anti-aim", "general", aa_desync_invterter_item )

local jitter_droite_item = config:add_item ( "jitter_droite" , 0 )
local jitter_droite_slider = menu:add_slider( "Yaw add right", "rage", "anti-aim", "general", jitter_droite_item ,-180,180, 1)

local jitter_gauche_item = config:add_item ( "jitter_gauche" , 0 )
local jitter_gauche_slider = menu:add_slider( "Yaw add left", "rage", "anti-aim", "general", jitter_gauche_item ,-180,180, 1)

local jitter_delais_item = config:add_item( "jitter_delais", 0 );
local jitter_delais_slider = menu:add_slider( "Delay (.01 step)", "Rage", "Anti-Aim", "general", jitter_delais_item, 0, 1, 0.01 )

local fake_type_item = config:add_item("fake_type_item", 0)
local fake_combobox = menu:add_combo( "Fake type", "rage", "anti-aim", "general", fake_type_item):add_item( "fake around real", fake_type_item):add_item( "real around fake", fake_type_item)

local font = render:create_font("arial", 25, 1,  true)
local screen_size = render:screen_size()




local function switch()

if fake_type_item:get_int()== 0  then

    standing_faketype:set_int(1)
    moving_faketype:set_int(1)
    air_faketype:set_int(1)

end

if fake_type_item:get_int()== 1  then

    standing_faketype:set_int(2)
    moving_faketype:set_int(2)
    air_faketype:set_int(2)

end
    if aa_jitter_item:get_bool() then
        render:indicator( screen_size.x / 150, screen_size.y / 1.1 , "FATTER",true, -2 );  
        if aa_desync_invterter_item:get_bool() then
         
            if last_tick_stand + jitter_delais_item:get_float() < globals.realtime then
                if in_use_stand then
                    menu:get_reference( "Rage", "Anti-Aim", "Standing", "add" ):set_int( jitter_droite_item:get_int() );
                    aa_state_standing:set_bool(true)
                    standing_faketype:set_int(2)
                    in_use_stand = false;
                else
                    menu:get_reference( "Rage", "Anti-Aim", "Standing", "add" ):set_int( jitter_gauche_item:get_int() );
                    aa_state_standing:set_bool(true)
                    standing_faketype:set_int(1)
                    in_use_stand = true;
                end
                last_tick_stand = globals.realtime;
            end
        else
            if last_tick_stand + jitter_delais_item:get_float() < globals.realtime then
                if in_use_stand then
                    menu:get_reference( "Rage", "Anti-Aim", "Standing", "add" ):set_int( jitter_droite_item:get_int() );
                    aa_state_standing:set_bool(true)
                    in_use_stand = false;
                else
                    menu:get_reference( "Rage", "Anti-Aim", "Standing", "add" ):set_int( jitter_gauche_item:get_int() );
                    aa_state_standing:set_bool(true)
                    in_use_stand = true;
                end
                last_tick_stand = globals.realtime;
            end
        end
    end


    if aa_jitter_item:get_bool()  then
       if aa_desync_invterter_item:get_bool() then
        if last_tick_move + jitter_delais_item:get_float() < globals.realtime then
            if in_use_move then
                menu:get_reference( "Rage", "Anti-Aim", "Moving", "add" ):set_int( jitter_droite_item:get_int() );
                aa_state_moving:set_bool(true)
                moving_faketype:set_int(2)
                in_use_move = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Moving", "add" ):set_int( jitter_gauche_item:get_int() );
                aa_state_moving:set_bool(true)
                moving_faketype:set_int(1)
                in_use_move = true;
            end
            last_tick_move = globals.realtime;
        end
    else
         if last_tick_move + jitter_delais_item:get_float() < globals.realtime then
            if in_use_move then
                menu:get_reference( "Rage", "Anti-Aim", "Moving", "add" ):set_int( jitter_droite_item:get_int() );
                aa_state_moving:set_bool(true)
                in_use_move = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Moving", "add" ):set_int( jitter_gauche_item:get_int() );
                aa_state_moving:set_bool(true)
                in_use_move = true;
            end
            last_tick_move = globals.realtime;
        end
    end
end

    if aa_jitter_item:get_bool() then
        if aa_desync_invterter_item:get_bool() then

            if last_tick_air + jitter_delais_item:get_float() < globals.realtime then
                if in_use_air then
                    menu:get_reference( "Rage", "Anti-Aim", "Air", "add" ):set_int( jitter_droite_item:get_int() );
                aa_state_air:set_bool(true)
                air_faketype:set_int(2)
                in_use_air = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Air", "add" ):set_int( jitter_gauche_item:get_int() );
                aa_state_air:set_bool(true)
                 air_faketype:set_int(1)
                in_use_air = true;
            end
            last_tick_air = globals.realtime;
        end

    else
         if last_tick_air + jitter_delais_item:get_float() < globals.realtime then
            if in_use_air then
                menu:get_reference( "Rage", "Anti-Aim", "Air", "add" ):set_int( jitter_droite_item:get_int() );
                aa_state_air:set_bool(true)               
                in_use_air = false;
            else
                menu:get_reference( "Rage", "Anti-Aim", "Air", "add" ):set_int( jitter_gauche_item:get_int() );
                aa_state_air:set_bool(true)

                in_use_air = true;
            end
            last_tick_air = globals.realtime;
        end
    end
end
end




callbacks:add("paint", switch)