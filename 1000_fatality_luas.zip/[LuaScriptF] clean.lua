config: https://ufile.io/k5cmul6j
steam: https://steamcommunity.com/id/simplerealistic/
group: https://steamcommunity.com/groups/simplesgroup
youtube: https://www.youtube.com/dylanx