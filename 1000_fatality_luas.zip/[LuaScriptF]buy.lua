local callbacks = fatality.callbacks
local menu = fatality.menu
local config = fatality.config

local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()

local cfg =
{
    flame =
    {
        when_killed = config:add_item( "ch.flame.when_killed", 0 ),
        on_kill = config:add_item( "ch.flame.on_kill", 0 ),
		on_disconnect = config:add_item( "ch.flame.on_disconnect", 0 ),
		on_round_start = config:add_item( "ch.flame.on_round_start", 0 ),
		on_chicken_kill = config:add_item( "ch.flame.on_chicken_kill", 0 ),
		on_plant = config:add_item( "ch.flame.on_plant", 0 ),
	},
	autobuy =
    {
		selected = config:add_item( "ch.autobuy.selected", 0 ),
	}
}

    local menu_items =
{
		autobuy_combo = menu:add_combo('Cherry\'s autobuy', 'misc', '', 'buy bot', cfg.autobuy.selected ):add_item( '-', nil ):add_item( 'Auto', nil ):add_item( 'Scout', nil ):add_item( 'AWP', nil ),
		flame_multi_combo = menu:add_multi_combo('Flame', 'visuals', 'misc', 'various' ):add_item( 'When killed', cfg.flame.when_killed ):add_item( 'On kill', cfg.flame.on_kill  ):add_item( 'On disconnect', cfg.flame.on_disconnect  ):add_item( 'On round start', cfg.flame.on_round_start ):add_item( 'On chicken kill', cfg.flame.on_chicken_kill ):add_item( 'On plant', cfg.flame.on_plant ),
}

function string_starts(string, start)
  return string.sub(string, 1, string.len(start))==start
end

local function say(message)
	local message = string.gsub(message, ";", ";") --greek question mark, cuz fuck command injection
	engine_client:client_cmd("say " .. message)
end

local function on_round_prestart()
	if cfg.autobuy.selected:get_int() == 1 then
		engine_client:client_cmd('buy scar20')
		engine_client:client_cmd('buy elite')
		engine_client:client_cmd('buy hegrenade')
		engine_client:client_cmd('buy smokegrenade')
		engine_client:client_cmd('buy molotov')
		engine_client:client_cmd('buy defuser')
		engine_client:client_cmd('buy vesthelm')
		engine_client:client_cmd('buy taser')
	elseif cfg.autobuy.selected:get_int() == 2 then
		engine_client:client_cmd('buy ssg08')
		engine_client:client_cmd('buy deagle')
		engine_client:client_cmd('buy hegrenade')
		engine_client:client_cmd('buy smokegrenade')
		engine_client:client_cmd('buy molotov')
		engine_client:client_cmd('buy defuser')
		engine_client:client_cmd('buy vesthelm')
		engine_client:client_cmd('buy taser')
	elseif cfg.autobuy.selected:get_int() == 3 then
		engine_client:client_cmd('buy awp')
		engine_client:client_cmd('buy deagle')
		engine_client:client_cmd('buy hegrenade')
		engine_client:client_cmd('buy smokegrenade')
		engine_client:client_cmd('buy molotov')
		engine_client:client_cmd('buy defuser')
		engine_client:client_cmd('buy vesthelm')
		engine_client:client_cmd('buy taser')
	end
end

local function on_player_disconnect()
	if cfg.flame.on_disconnect:get_bool() then
		say("")
	end
end

local function on_round_start()
	if cfg.flame.on_round_start:get_bool() then
		say("")
	end
end

local function on_player_death(e)
	local victim_userid = e:get_int("userid")
	local attacker_userid = e:get_int("attacker")
	if victim_userid == nil or attacker_userid == nil then
		return
	end

	local local_ent = entity_list:get_localplayer()
	local victim_ent = entity_list:get_player_from_id(victim_userid)
	local attacker_ent = entity_list:get_player_from_id(attacker_userid)

	if local_ent == nil or victim_ent == nil or attacker_ent == nil then
		return
	end

	local local_team = local_ent:get_var_int( "CBaseEntity->m_iTeamNum" )
	local victim_team = victim_ent:get_var_int("CBaseEntity->m_iTeamNum")
	local attacker_team = attacker_ent:get_var_int("CBaseEntity->m_iTeamNum")
    
	local weapon = e:get_string("weapon")

	if cfg.flame.on_kill:get_bool() then
		if attacker_ent:get_index() == local_ent:get_index() and local_team ~= victim_team then
			if string_starts(weapon, "knife") or weapon == "bayonet" then
				say("god I wish I had suicidegang.life")
			elseif weapon == "taser" then
				say("god I wish I had suicidegang.life")
			elseif weapon == 'hegrenade' then 
				say("god I wish I had suicidegang.life")
			elseif weapon == 'incgrenade' or weapon == 'molotov' or weapon == 'inferno' then 
				say("god I wish I had suicidegang.life")
			elseif e:get_bool("headshot") then
				say("god I wish I had suicidegang.life")
			else
				say("god I wish I had suicidegang.life")
			end
		end
	end

	if cfg.flame.when_killed:get_bool() then
		if attacker_team ~= local_team and victim_ent:get_index() == local_ent:get_index() then
			if weapon == 'hegrenade' then
				say("god I wish I had suicidegang.life")
			elseif weapon == 'awp' then
				say("god I wish I had suicidegang.life")
			end
			if e:get_bool("headshot") then
				say("god I wish I had suicidegang.life")
			else
				say("god I wish I had suicidegang.life")
			end
		end
	end
end

local function on_other_death(e)
	local attacker_userid = e:get_int("attacker")
	if attacker_userid == nil then
		return
	end

	local local_ent = entity_list:get_localplayer()
	local attacker_ent = entity_list:get_player_from_id(attacker_userid)

	if local_ent == nil or attacker_ent == nil then
		return
	end

	local local_team = local_ent:get_var_int( "CBaseEntity->m_iTeamNum" )
	local attacker_team = attacker_ent:get_var_int("CBaseEntity->m_iTeamNum")

	if local_team ~= attacker_team then
		if cfg.flame.on_chicken_kill:get_bool() then
			say("")
		end
	end
end

local function on_bomb_plant(e)
	local userid = e:get_int("userid")
	if userid == nil then
		return
	end

	local local_ent = entity_list:get_localplayer()
	local userid_ent = entity_list:get_player_from_id(userid)

	if local_ent == nil or userid_ent == nil then
		return
	end

	local local_team = local_ent:get_var_int( "CBaseEntity->m_iTeamNum" )
	local userid_team = userid_ent:get_var_int("CBaseEntity->m_iTeamNum")

	if local_team ~= attacker_team then
		if cfg.flame.on_plant:get_bool() then
			say("")
		end
	end
end

local function on_event(e)

	local event_name = e:get_name()

	if event_name == "round_prestart" then
		on_round_prestart(e)
	elseif event_name == "player_disconnect" then
		on_player_disconnect()
	elseif event_name == "round_start" then
		on_round_start()
	elseif event_name == "bomb_planted" then
		on_bomb_plant(e)
	elseif event_name == "player_death" then
		on_player_death(e)
	elseif event_name == "other_death" then
		on_other_death(e)
	end
	
end

events:add_event( "round_prestart" )
events:add_event( "player_disconnect" )
events:add_event( "round_start" )
events:add_event( "bomb_planted" )
events:add_event( "player_death" )
events:add_event( "other_death" )

callbacks:add( "events", on_event )
