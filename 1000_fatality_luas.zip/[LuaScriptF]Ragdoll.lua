-- Fatality interfaces
local callbacks = fatality.callbacks;
local render = fatality.render
local input = fatality.input;
local math = fatality.math
local config = fatality.config
local menu = fatality.menu
-- end of Fatality interfaces

-- Handler Interfaces
local engine_client = csgo.interface_handler:get_engine_client( )
local events = csgo.interface_handler:get_events( )
local entity_list = csgo.interface_handler:get_entity_list( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )
local global_vars = csgo.interface_handler:get_global_vars( )
local cvar = csgo.interface_handler:get_cvar( )
-- end of Handler Interfaces

local gravity = cvar:find_var("cl_ragdoll_gravity")
gravity:unlock()

local ragdoll_item = config:add_item ( "ragdoll_item", 1.0 )
local gravity_item = config:add_item ( "gravity_item", 2.0 )

local Ragdoll_gravity = menu:add_checkbox( "Ragdoll gravity", "VISUALS", "MISC", "Various", ragdoll_item )
local Ragdoll_gravity_amount = menu:add_slider("Ragdoll gravity amount", "VISUALS", "MISC", "Various", gravity_item, -2000, 2000, 600 )

local function function_callback()
    if ragdoll_item:get_bool() then
        engine_client:client_cmd("cl_ragdoll_gravity " .. gravity_item:get_int())
    else
        engine_client:client_cmd("cl_ragdoll_gravity 600")
    end
end

callbacks:add( "events", function_callback )