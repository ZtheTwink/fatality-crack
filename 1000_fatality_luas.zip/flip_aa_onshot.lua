
-- https://fatality.win/threads/release-flip-aa-on-shot.4802/
--main instances
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks
local fatalMath = fatality.math
local events = csgo.interface_handler:get_events()
local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()
--main instances
local onShotItem = config:add_item( 'onshot', 0 )
local onHurtItem = config:add_item( 'on hurt', 0 )
local onShotCheck = menu:add_checkbox( 'Flip AA On Shot', 'rage', 'anti-aim', 'general', onShotItem )
local onHurtCheck = menu:add_checkbox( 'Flip AA On Damage Taken', 'rage', 'anti-aim', 'general', onHurtItem )
local function swap()
    local standRef = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount'):get_int()
    local moveRef = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount'):get_int()
    if standRef < 0 then
        menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount'):set_int(100)--change these to what you want them to flip from
    elseif standRef > 0 then
        menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount'):set_int(-100)--change these to what you want them to flip from
    end
    if moveRef < 0 then
        menu:get_reference('rage', 'anti-aim', 'moving', 'fake amount'):set_int(100)--change these to what you want them to flip from
    elseif moveRef > 0 then
        menu:get_reference('rage', 'anti-aim', 'moving', 'fake amount'):set_int(-100)--change these to what you want them to flip from
    end
end
local function isShot(e)
    if not engine_client:is_in_game() then
        return end
    local localPlayer = entity_list:get_localplayer()
    local hurtID = e:get_int('userid')
    
    if hurtID == nil then
        return end
    local hurtIDPlayer = entity_list:get_player_from_id(hurtID)
    local hurtName = hurtIDPlayer:get_name()
    local localPlayerName = localPlayer:get_name()
    if hurtName == localPlayerName then
        if onHurtItem:get_bool() then
            swap()
        end
    end
end
local function event(e)
    local event = e:get_name()  
    if event == 'player_hurt' then
        isShot(e)
    end
end
function onShot(shot)
    if not engine_client:is_in_game() then
        return end
    local localPlayer = entity_list:get_localplayer()
    local shotInfo = shot.shot_info
    if not shotInfo.has_info then
        return end  
    if shot.hurt then
        if onShotItem:get_bool() then
        swap()
        end
    end
end
events:add_event('weapon_fire')
callbacks:add('events', event )
callbacks:add( 'registered_shot', onShot )