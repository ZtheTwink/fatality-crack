-- https://fatality.win/threads/dt-silent-lethal-indicator.4740/
--main instances
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks
local fatalMath = fatality.math
--main instances

local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()

local silent = csgo.color(165,165,165,255)
local doubletap = csgo.color(165,165,165,255)
local fallback = csgo.color(165,165,165,255)

local blue = csgo.color(0,115,255,255)

local screensize = render:screen_size()

local x = config:add_item( 'x', 0 )
local y = config:add_item( 'y', 0 )

local xS = menu:add_slider( 'Silent/Dt/Lethal X', 'visuals', 'misc', 'various', x, 0, screensize.x - screensize.x/24, 1 )
local xS = menu:add_slider( 'Silent/Dt/Lethal Y', 'visuals', 'misc', 'various', y, 0, screensize.y - screensize.y/19.6, 1 )

local font = render:create_font( 'Verdana Bold', 13, 100, true )

local autoSilent = menu:get_reference( 'rage', 'weapons', 'auto', 'silent' )
local autoDoubletap = menu:get_reference( 'rage', 'weapons', 'auto', 'double tap' )
local autoFallback = menu:get_reference( 'rage', 'weapons', 'auto', 'fallback mode' )

local awpSilent = menu:get_reference( 'rage', 'weapons', 'awp', 'silent' )
local awpDoubletap = menu:get_reference( 'rage', 'weapons', 'awp', 'double tap' )
local awpFallback = menu:get_reference( 'rage', 'weapons', 'awp', 'fallback mode' )

local scoutSilent = menu:get_reference( 'rage', 'weapons', 'scout', 'silent' )
local scoutDoubletap = menu:get_reference( 'rage', 'weapons', 'scout', 'double tap' )
local scoutFallback = menu:get_reference( 'rage', 'weapons', 'scout', 'fallback mode' )

local heavyPistolSilent = menu:get_reference( 'rage', 'weapons', 'heavy pistols', 'silent' )
local heavyPistolDoubletap = menu:get_reference( 'rage', 'weapons', 'heavy pistols', 'double tap' )
local heavyPistolFallback = menu:get_reference( 'rage', 'weapons', 'heavy pistols', 'fallback mode' )

local pistolSilent = menu:get_reference( 'rage', 'weapons', 'pistols', 'silent' )
local pistolDoubletap = menu:get_reference( 'rage', 'weapons', 'pistols', 'double tap' )
local pistolFallback = menu:get_reference( 'rage', 'weapons', 'pistols', 'fallback mode' )

local otherSilent = menu:get_reference( 'rage', 'weapons', 'other', 'silent' )
local otherDoubletap = menu:get_reference( 'rage', 'weapons', 'other', 'double tap' )
local otherFallback = menu:get_reference( 'rage', 'weapons', 'other', 'fallback mode' )

local function paint()

local localPlayer = entity_list:get_localplayer()

if localPlayer == nil then
    return end

local weapon = csgo.interface_handler:get_entity_list():get_from_handle(localPlayer:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) )

if weapon == nil then
    return end

local currentWeapon = weapon:get_class_id()

    if currentWeapon == 244 or currentWeapon == 238 or currentWeapon == 257 or currentWeapon == 268  or currentWeapon == 245 or currentWeapon == 257 or currentWeapon == 240 then
        currentWeapon = 'pistol'
    elseif  currentWeapon == 46 then
        currentWeapon = 'heavy pistol'
    elseif currentWeapon == 266 then
        currentWeapon = 'scout'
    elseif currentWeapon == 260 or currentWeapon == 241 then
        currentWeapon = 'auto'
    elseif currentWeapon == 232 then
        currentWeapon = 'awp'
    elseif currentWeapon == 107 then
        currentWeapon = 'knife'
    else
        currentWeapon = 'other'
    end

if currentWeapon == 'auto' then
        if autoSilent:get_bool() then
            silent = csgo.color(0,115,255,255)
        else
            silent = csgo.color(165,165,165,255)
        end

        if autoDoubletap:get_int() == 1 or autoDoubletap:get_int() == 2 then
            doubletap = csgo.color(0,115,255,255)
        else
            doubletap = csgo.color(165,165,165,255)
        end
        if autoFallback:get_int() == 1 or autoFallback:get_int() == 2 then
            fallback = csgo.color(0,115,255,255)
        else
            fallback = csgo.color(165,165,165,255)
        end
    elseif currentWeapon == 'awp' then
        if awpSilent:get_bool() then
            silent = csgo.color(0,115,255,255)
        else
            silent = csgo.color(165,165,165,255)
        end
        doubletap = csgo.color(165,165,165,255)       
        if awpFallback:get_int() == 1 or awpFallback:get_int() == 2 then
            fallback = csgo.color(0,115,255,255)
        else
            fallback = csgo.color(165,165,165,255)
        end
    elseif currentWeapon == 'scout' then
        if scoutSilent:get_bool() then
            silent = csgo.color(0,115,255,255)
        else
            silent = csgo.color(165,165,165,255)
        end
        doubletap = csgo.color(165,165,165,255)     
        if scoutFallback:get_int() == 1 or scoutFallback:get_int() == 2 then
            fallback = csgo.color(0,115,255,255)
        else
            fallback = csgo.color(165,165,165,255)
        end
    elseif currentWeapon == 'pistol' then
        if pistolSilent:get_bool() then
            silent = csgo.color(0,115,255,255)
        else
            silent = csgo.color(165,165,165,255)
        end
        if pistolDoubletap:get_int() == 1 or pistolDoubletap:get_int() == 2 then
            doubletap = csgo.color(0,115,255,255)
        else
            doubletap = csgo.color(165,165,165,255)
        end
        if awpFallback:get_int() == 1 or awpFallback:get_int() == 2 then
            fallback = csgo.color(0,115,255,255)
        else
            fallback = csgo.color(165,165,165,255)
        end
        if pistolFallback:get_int() == 1 or pistolFallback:get_int() == 2 then
            fallback = csgo.color(0,115,255,255)
        else
            fallback = csgo.color(165,165,165,255)
        end
    elseif currentWeapon == 'heavy pistol' then
        if heavyPistolSilent:get_bool() then
            silent = csgo.color(0,115,255,255)
        else
            silent = csgo.color(165,165,165,255)
        end

        if heavyPistolDoubletap:get_int() == 1 or heavyPistolDoubletap:get_int() == 2 then
            doubletap = csgo.color(0,115,255,255)
        else
            doubletap = csgo.color(165,165,165,255)
        end
        if heavyPistolFallback:get_int() == 1 or heavyPistolFallback:get_int() == 2 then
            fallback = csgo.color(0,115,255,255)
        else
            fallback = csgo.color(165,165,165,255)
        end
    elseif currentWeapon == 'knife' then
        silent = csgo.color(165,165,165,255)
        doubletap = csgo.color(165,165,165,255)
        fallback = csgo.color(165,165,165,255)
    else
        if otherSilent:get_bool() then
            silent = csgo.color(0,115,255,255)
        else
            silent = csgo.color(165,165,165,255)
        end

        if otherDoubletap:get_int() == 1 or otherDoubletap:get_int() == 2 then
            doubletap = csgo.color(0,115,255,255)
        else
            doubletap = csgo.color(165,165,165,255)
        end
        if otherFallback:get_int() == 1 or otherFallback:get_int() == 2 then
            fallback = csgo.color(0,115,255,255)
        else
            fallback = csgo.color(165,165,165,255)
        end
    end

    
    render:text( font, x:get_int() + 18, y:get_int(), 'SILENT', silent)
    render:text( font, x:get_int() + 5 , y:get_int() + 19, 'DOUBLE TAP', doubletap )
    render:text( font, x:get_int(), y:get_int() + 38, 'LETHAL BAIM', fallback )
end

callbacks:add('paint', paint)