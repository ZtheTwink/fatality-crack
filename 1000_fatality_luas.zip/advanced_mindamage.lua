-- https://fatality.win/threads/advanced-min-damage.1311/

local menu = fatality.menu
local input = fatality.input
local config = fatality.config

-- func
local mindmg = menu:get_reference( "rage", "weapons", "auto", "min-damage")
local mindmgSwitch_item = config:add_item("tt_mindmgSwitch_item", 50)
local mindmgSwitch_slider = menu:add_slider("Min-damage value 1", "rage", "weapons", "auto", mindmgSwitch_item, 0, 100, 1)
local mindmgswitch2_item = config:add_item("tt_mindmgSwitch2_item", 50)
local mindmgSwitch2_slider = menu:add_slider("Min-damage value 2", "rage","weapons","auto", mindmgSwitch2_item, 0, 100, 1)
-- key binds
local key = 0x56 -- this is V change the virtual key code to change bind https://docs.microsoft.com/en-us/windows/desktop/inputdev/virtual-key-codes

-- needed variables
local enabled = false

-- callbacks 
fatality.callbacks:add("paint", function()

    local mindmgSwitch_value = mindmgSwitch_item:get_float() * 1
    local mindmgSwitch2_value = mindmgswitch2_item:get_float() * 1

    if(input:is_key_pressed(key)) then
        enabled = not enabled
    end

    if enabled == true then
        mindmg:set_int( mindmgSwitch_value )
    end

    if enabled == false then
        mindmg:set_int( mindmgSwitch2_value )
    end
end)