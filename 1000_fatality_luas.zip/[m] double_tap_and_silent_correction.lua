local engine_client 	= csgo.interface_handler:get_engine_client()
local entity_list		= csgo.interface_handler:get_entity_list()
local global_vars		= csgo.interface_handler:get_global_vars()
local menu 				= fatality.menu
local config 			= fatality.config

local double_tap_ref 	= menu:get_reference("RAGE", "AIMBOT", "Aimbot", "Double tap")
local silent_ref 		= menu:get_reference("RAGE", "AIMBOT", "Aimbot", "Silent")

local move_fakelag_ref	= menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake lag")

local autos 			= { 238, 257 }
local scouts 			= { 262 }
local awps 				= { 229 }
local heavypistols 		= { 44 }
local pistols 			= { 241, 254, 237, 235, 264, 242 }
local others 			= { 246, 250, 249, 266, 231, 255, 240, 236, 1, 245, 261, 228 }

function table_contains(t, v)
	for i = 1, #t do
		if t[i] == v then
			return true
		end
	end
	
	return false
end

-- Auto
local auto_silent_item = config:add_item("p9_auto_silent", 0)
local auto_doubletap_item = config:add_item("p9_auto_doubletap", 1)

local sdt_auto = menu:add_multi_combo("Silent and double tap", "RAGE", "Weapons", "Auto")
sdt_auto:add_item("Silent", auto_silent_item)
sdt_auto:add_item("Double tap", auto_doubletap_item)

-- Scout
local scout_silent_item = config:add_item("p9_scout_silent", 0)
local scout_doubletap_item = config:add_item("p9_scout_doubletap", 0)

local sdt_scout = menu:add_multi_combo("Silent and double tap", "RAGE", "Weapons", "Scout")
sdt_scout:add_item("Silent", scout_silent_item)
sdt_scout:add_item("Double tap", scout_doubletap_item)

-- AWP
local awp_silent_item = config:add_item("p9_awp_silent", 0)
local awp_doubletap_item = config:add_item("p9_awp_doubletap", 0)

local sdt_awp = menu:add_multi_combo("Silent and double tap", "RAGE", "Weapons", "AWP")
sdt_awp:add_item("Silent", awp_silent_item)
sdt_awp:add_item("Double tap", awp_doubletap_item)

-- Heavy pistols
local heavy_silent_item = config:add_item("p9_heavy_silent", 0)
local heavy_doubletap_item = config:add_item("p9_heavy_doubletap", 0)

local sdt_heavy = menu:add_multi_combo("Silent and double tap", "RAGE", "Weapons", "Heavy pistols")
sdt_heavy:add_item("Silent", heavy_silent_item)
sdt_heavy:add_item("Double tap", heavy_doubletap_item)

-- Pistols
local pistols_silent_item = config:add_item("p9_pistols_silent", 0)
local pistols_doubletap_item = config:add_item("p9_pistols_doubletap", 0)

local sdt_pistols = menu:add_multi_combo("Silent and double tap", "RAGE", "Weapons", "Pistols")
sdt_pistols:add_item("Silent", pistols_silent_item)
sdt_pistols:add_item("Double tap", pistols_doubletap_item)

-- Other
local other_silent_item = config:add_item("p9_other_silent", 0)
local other_doubletap_item = config:add_item("p9_other_doubletap", 0)

local sdt_other = menu:add_multi_combo("Silent and double tap", "RAGE", "Weapons", "Other")
sdt_other:add_item("Silent", other_silent_item)
sdt_other:add_item("Double tap", other_doubletap_item)

--[[
1. меняешь пушку
2. офф фейклаг
3. ждать
4. врубить силент и вернуть фейклаг
]]

local last_wpn = 0

local silent_enable = false
local doubletap_enable = false

local silent_timer = 0
local doubletap_timer = 0

function set_silent(val)
	silent_timer = global_vars.curtime
	silent_enable = val
end

function set_doubletap(val)
	doubletap_timer = global_vars.curtime
	doubletap_enable = val
end

function update_sdt()
	local delay = 1
	
	if(global_vars.curtime >= (silent_timer + delay)) then
		silent_ref:set_bool(silent_enable)
	end
	
	if(global_vars.curtime >= (doubletap_timer + delay)) then
		double_tap_ref:set_bool(doubletap_enable)
	end
end

fatality.callbacks:add("paint", function()
	if(engine_client:is_in_game()) then
		
		update_sdt()
		
		local local_player = entity_list:get_localplayer()
		local wpn = local_player:get_var_handle("CBaseCombatCharacter->m_hActiveWeapon")
		wpn = entity_list:get_from_handle(wpn)
		
		if(wpn ~= nil and last_wpn ~= wpn:get_class_id()) then
			last_wpn = wpn:get_class_id()
			
			-- Auto
			if(table_contains(autos, wpn:get_class_id())) then
				set_silent(auto_silent_item:get_bool())
				set_doubletap(auto_doubletap_item:get_bool())
				
				-- Scout
			elseif(table_contains(scouts, wpn:get_class_id())) then
				set_silent(scout_silent_item:get_bool())
				set_doubletap(scout_doubletap_item:get_bool())
				
				-- AWP
			elseif(table_contains(awps, wpn:get_class_id())) then
				silent_ref:set_bool(awp_silent_item:get_bool())
				set_doubletap(awp_doubletap_item:get_bool())
				
				-- Heavy pistols
			elseif(table_contains(heavypistols, wpn:get_class_id())) then
				set_silent(heavy_silent_item:get_bool())
				set_doubletap(heavy_doubletap_item:get_bool())
				
				-- Pistols
			elseif(table_contains(pistols, wpn:get_class_id())) then
				set_silent(pistols_silent_item:get_bool())
				set_doubletap(pistols_doubletap_item:get_bool())
				
				-- Other
			elseif(table_contains(others, wpn:get_class_id())) then
				set_silent(other_silent_item:get_bool())
				set_doubletap(other_doubletap_item:get_bool())
				
				-- Knives / Taser / Nades etc.....
			else
				silent_enable = false
				doubletap_enable = true
			end
		end
	end
end)