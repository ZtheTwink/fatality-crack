local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local debug = csgo.interface_handler:get_debug_overlay( )
local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()
local engine_client = csgo.interface_handler:get_engine_client()
local font = render:create_font( ' ', 25, 100, false )
-- https://fatality.win/threads/release-desync-angle-lines.4688/

local math1 = fatality.math
local toggleItem = config:add_item( 'toggle', 1 )
local toggleCheck = menu:add_checkbox( 'Desync Lines', 'visuals', 'misc', 'various', toggleItem )
local lbyRItem = config:add_item( 'lby red', 0 )
local lbyGItem = config:add_item( 'lby green', 115 )
local lbyBItem = config:add_item( 'lby blue', 255 )
local fakeRItem = config:add_item( 'fake red ', 255 )
local fakeGItem = config:add_item( 'fake green ', 0 )
local fakeBItem = config:add_item( 'fake blue ', 0 )
local lbyRSLider = menu:add_slider( 'LBY Line R', 'visuals', 'misc', 'various', lbyRItem, 0, 255, 1 )
local lbyGSLider = menu:add_slider( 'LBY Line G', 'visuals', 'misc', 'various', lbyGItem, 0, 255, 1 )
local lbyBSLider = menu:add_slider( 'LBY Line B', 'visuals', 'misc', 'various', lbyBItem, 0, 255, 1 )
local fakeRSLider = menu:add_slider( 'Fake Line R', 'visuals', 'misc', 'various', fakeRItem, 0, 255, 1 )
local fakeGSLider = menu:add_slider( 'Fake Line G', 'visuals', 'misc', 'various', fakeGItem, 0, 255, 1 )
local fakeBSLider = menu:add_slider( 'Fake Line B', 'visuals', 'misc', 'various', fakeBItem, 0, 255, 1 )



function paint()
    local lbyColor = csgo.color(lbyRItem:get_int(), lbyGItem:get_int(), lbyBItem:get_int(), 255)
    local fakeColor = csgo.color(fakeRItem:get_int(), fakeGItem:get_int(), fakeBItem:get_int(), 255)
    
    if not engine_client:is_in_game() then
        return end

    local localPlayer = entity_list:get_localplayer()
    local curPos = localPlayer:get_eye_pos()
    local lby = localPlayer:get_var_float('CCSPlayer->m_flLowerBodyYawTarget')
    local testE = localPlayer:get_var_float('CCSPlayer->m_angEyeAngles[1]')
    local yaw = math.rad(lby)
    local yawE = math.rad(testE)
    local distance = 25
   
    local lineEndX = curPos.x + distance * (math.sin(1000) * math.cos(yaw))
    local lineEndY = curPos.y + distance * (math.sin(1000) * math.sin(yaw))
    local lineEndX2 = curPos.x + distance * (math.sin(1000) * math.cos(yawE))
    local lineEndY2 = curPos.y + distance * (math.sin(1000) * math.sin(yawE))
    local endLine = csgo.vector3(lineEndX, lineEndY, curPos.z -50)
    local endLine2 = csgo.vector3(lineEndX2, lineEndY2, curPos.z -50)
    local posToScreen = csgo.vector3(lineEndX, lineEndY, curPos.z -50)
    local posToScreen2 = csgo.vector3(lineEndX2, lineEndY2, curPos.z -50)
    local customPos = csgo.vector3(curPos.x, curPos.y, curPos.z - 50)
    posToScreen:to_screen(true)
    posToScreen2:to_screen(true)
    if localPlayer:is_alive() and toggleItem:get_bool() then
        debug:add_line_overlay(customPos, endLine, fakeColor, false, 0.01)
        debug:add_line_overlay(customPos, endLine2, lbyColor, false, 0.01)
        render:text(font, posToScreen.x-10,posToScreen.y+10,'fake', csgo.color(255,255,255,255))
        render:text(font, posToScreen2.x-10,posToScreen2.y+10,'lby', csgo.color(255,255,255,255))
    
    end
end
local callbacks = fatality.callbacks
callbacks:add( 'paint', paint )
