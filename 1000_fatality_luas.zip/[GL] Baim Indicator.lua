local engine_client = csgo.interface_handler:get_engine_client( );

local render = fatality.render;
local config = fatality.config;

function on_paint( )
    if ( engine_client:is_in_game( ) and config:get_item( "aim.force_baim" ):get_bool( ) ) then
        local screen_size = render:screen_size( );
        render:indicator( screen_size.x / 190, screen_size.y / 2 - -80, "BODYAIM", true, -1 );
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );