-- https://fatality.win/threads/skybox.577/
local cvar = csgo.interface_handler:get_cvar( );
local config = fatality.config;
local menu = fatality.menu;
local skybox_bool_item = config:add_item( "skybox_bool", 1 );
local skybox_bool_checkbox = menu:add_checkbox( "Skybox", "visuals", "misc", "various", skybox_bool_item );

local skybox_value_item = config:add_item( "skybox_values", 0 );
local skybox_value_combobox = menu:add_combo( "Skybox items", "visuals", "misc", "various", skybox_value_item );
skybox_value_combobox:add_item( "cs_baggage_skybox_", skybox_value_item );
skybox_value_combobox:add_item( "cs_tibet", skybox_value_item );
skybox_value_combobox:add_item( "embassy", skybox_value_item );
skybox_value_combobox:add_item( "italy", skybox_value_item );
skybox_value_combobox:add_item( "jungle", skybox_value_item );
skybox_value_combobox:add_item( "office", skybox_value_item );
skybox_value_combobox:add_item( "sky_cs15_daylight01_hdr", skybox_value_item );
skybox_value_combobox:add_item( "sky_day02_05", skybox_value_item );
skybox_value_combobox:add_item( "nukeblank", skybox_value_item );
skybox_value_combobox:add_item( "sky_venice", skybox_value_item );
skybox_value_combobox:add_item( "sky_cs15_daylight03_hdr", skybox_value_item );
skybox_value_combobox:add_item( "sky_cs15_daylight04_hdr", skybox_value_item );
skybox_value_combobox:add_item( "sky_csgo_cloudy01", skybox_value_item );
skybox_value_combobox:add_item( "sky_csgo_night02", skybox_value_item );
skybox_value_combobox:add_item( "sky_csgo_night02b", skybox_value_item );
skybox_value_combobox:add_item( "vertigo", skybox_value_item );
skybox_value_combobox:add_item( "vertigoblue_hdr", skybox_value_item );
skybox_value_combobox:add_item( "sky_dust", skybox_value_item );
skybox_value_combobox:add_item( "vietnam", skybox_value_item );
local sv_skyname = cvar:find_var( "sv_skyname" );

function on_paint( )
    if ( skybox_bool_item:get_bool( ) ) then
        if ( skybox_value_item:get_int( ) == 0 ) then
            skybox_name = "cs_baggage_skybox_";
        end
        if ( skybox_value_item:get_int( ) == 1 ) then
            skybox_name = "cs_tibet";
        end
        if ( skybox_value_item:get_int( ) == 2 ) then
            skybox_name = "embassy";
        end
        if ( skybox_value_item:get_int( ) == 3 ) then
            skybox_name = "italy";
        end
        if ( skybox_value_item:get_int( ) == 4 ) then
            skybox_name = "jungle";
        end
        if ( skybox_value_item:get_int( ) == 5 ) then
            skybox_name = "office";
        end
            if ( skybox_value_item:get_int( ) == 6 ) then
            skybox_name = "sky_cs15_daylight01_hdr";
        end
        if ( skybox_value_item:get_int( ) == 7 ) then
            skybox_name = "sky_day02_05";
        end
        if ( skybox_value_item:get_int( ) == 8 ) then
            skybox_name = "nukeblank";
        end
        if ( skybox_value_item:get_int( ) == 9 ) then
            skybox_name = "sky_venice";
        end
        if ( skybox_value_item:get_int( ) == 10 ) then
            skybox_name = "sky_cs15_daylight03_hdr";
        end
        if ( skybox_value_item:get_int( ) == 11 ) then
            skybox_name = "sky_cs15_daylight004_hdr";
        end
        if ( skybox_value_item:get_int( ) == 12 ) then
            skybox_name = "sky_csgo_cloudy01";
        end
        if ( skybox_value_item:get_int( ) == 13 ) then
            skybox_name = "sky_csgo_night02";
        end
        if ( skybox_value_item:get_int( ) == 14 ) then
            skybox_name = "sky_csgo_night02b";
        end
        if ( skybox_value_item:get_int( ) == 15 ) then
            skybox_name = "vertigo_bluehdr";
        end
        if ( skybox_value_item:get_int( ) == 16 ) then
            skybox_name = "sky_dust";
        end
        if ( skybox_value_item:get_int( ) == 17 ) then
            skybox_name = "vietnam";
        end
    else
        skybox_name = "";
    end
    sv_skyname:set_string( skybox_name );
end
local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );