local global_vars         = csgo.interface_handler:get_global_vars( );
local entity_list         = csgo.interface_handler:get_entity_list( );
local engine_client        = csgo.interface_handler:get_engine_client( );
local entity_list         = csgo.interface_handler:get_entity_list( )
local input             = fatality.input;

local config             = fatality.config
local menu                 = fatality.menu
local render             = fatality.render;

local hotkey_item         = config:add_item( "hotkeys", 1.0 );
local hotkey_checkbox     = menu:add_checkbox( "Arkwindos", "visuals", "misc", "various", hotkey_item );


local offset_x, offset_y = -100, 30;

--box drawing function
function draw_container( x, y, w, h )
    local c = {10, 60, 40, 40, 40, 60, 20};
    for i = 0,6,1 do
        render:rect_filled( x+i, y+i, w-(i*2), h-(i*2), csgo.color( c[i+1], c[i+1], c[i+1], 255 ) );
    end
end

--references
local slide = menu:get_reference( "misc", "", "movement", "slide" );
local forcebaim = menu:get_reference( "rage", "aimbot", "aimbot", "force safepoint" );
local dt = config:get_weapon_setting("autosniper", "double_tap")
local fd = menu:get_reference( "misc", "", "movement", "fake duck");
local hss = config:get_weapon_setting("scout", "silent")
local hso = menu:get_reference( "rage", "aimbot", "aimbot", "Headshot only" );


--fonts
local small_12 = render:create_font( "Small Fonts", 12, 400, true );
local small_13 = render:create_font( "Small Fonts", 15, 650, false );

function on_paint( )

    local menusize = 24
	  if ( hso:get_bool() ) then
      
            menusize = menusize + 11
         end
		    if ( hss:get_bool() ) then
      
            menusize = menusize + 11
         end
	
	    if ( slide:get_bool() ) then
      
            menusize = menusize + 11
         end
  
        if ( dt:get_bool() ) then
      
            menusize = menusize + 11
        end
        if ( forcebaim:get_bool() ) then
  
        menusize = menusize + 11
        end
        if ( fd:get_bool() ) then
  
        menusize = menusize + 11
        end 

  
        if ( toggled ) then
        menusize = menusize + 11
        end
      
        --rainbow shit
        local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
        local g = math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
        local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );

        local distance = 438

        if ( hotkey_item:get_bool( ) ) then
            local local_player = entity_list:get_localplayer( );
            if ( local_player == nil ) then
            return end

            local screen_size = render:screen_size( );
            local x = offset_x >= 0 and offset_x or screen_size.x + offset_x;
            local y = offset_y >= 0 and offset_y or screen_size.y + offset_y
            local offset_x_temp = 16.5;
          
          
            local local_player = entity_list:get_localplayer()
          
            --checking if the player is alive
            if(local_player ~= nil and local_player:is_alive()) then
                  
              
          

            -- risuyu kak dalboeb boxi i liniyu
                if not ( dt:get_bool() or forcebaim:get_bool() or hss:get_bool() or fd:get_bool() or slide:get_bool() or hso:get_bool() ) then
                else
                    draw_container( 30, y + 440, 210, menusize ); 
                    render:rect_filled(36, y + 446, 198 , 1, csgo.color(r,g,b, 255));
                end
              
              
            --double tap
                if ( dt:get_bool() ) then
                    distance = distance + 12
                  
                    if not ( fd:get_bool() ) then
                  
                        render:text( small_12, 40, y + distance, "Double tap", csgo.color( 255, 255, 255, 230 ) );
                        render:text( small_12, 200, y + distance, "[ on ]", csgo.color( 149, 184, 6, 230 ) );
                    else
                  
                        render:text( small_12, 40, y + distance, "Double tap", csgo.color( 255, 255, 255, 230 ) );
                        render:text( small_12, 200, y + distance, "[ off ]", csgo.color( 255, 0, 72, 230 ) );
                    end
                end
            --force baim   
                if ( forcebaim:get_bool() ) then
                    distance = distance + 12
              
                    render:text( small_12, 40, y + distance, "Force baim", csgo.color( 255, 255, 255, 230 ) );
                    render:text( small_12, 200, y + distance, "[ on ]", csgo.color( 149, 184, 6, 230 ) );
                  
                end
            --fake duck 
                if ( fd:get_bool() ) then
                    distance = distance + 12
              
                    render:text( small_12, 40, y + distance, "Duck peek assist", csgo.color( 255, 255, 255, 230 ) );
                    render:text( small_12, 200, y + distance, "[ on ]", csgo.color( 149, 184, 6, 230 ) );
                end     
            --slide
                if ( slide:get_bool() ) then
              
                    distance = distance + 12
                  
                    render:text( small_12, 40, y + distance, "Slowmotion", csgo.color( 255, 255, 255, 230 ) );
                    render:text( small_12, 200, y + distance, "[ on ]", csgo.color( 149, 184, 6, 230 ) );
					end
					            --hs scout
                if ( hss:get_bool() ) then
                    distance = distance + 12
                  
                  
                        render:text( small_12, 40, y + distance, "Hideshots", csgo.color( 255, 255, 255, 230 ) );
                        render:text( small_12, 200, y + distance, "[ on ]", csgo.color( 149, 184, 6, 230 ) );
                    end
			    if ( hso:get_bool() ) then
                    distance = distance + 12
                  
                  
                        render:text( small_12, 40, y + distance, "Only HS", csgo.color( 255, 255, 255, 230 ) );
                        render:text( small_12, 200, y + distance, "[ on ]", csgo.color( 149, 184, 6, 230 ) );
                    end

                end
                end
            end
  

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint );