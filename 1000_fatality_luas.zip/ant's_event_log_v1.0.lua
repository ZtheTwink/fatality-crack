--[[
  Original animated event log by eslipe

  Changes made by anthony/antja03:
    - Removed useless code
    - Code reformatted for my personal preference
    - Removed the font picker since there were only 2 options anyway
    - Removed preset color modes
    - Made the color picker RGB sliders (Percentage, not 0-255)
    - Slightly changed the theme
    - Removed watermark option
    - Added support for many more events
]]

-- Start references
local cvar                 = csgo.interface_handler:get_cvar()
local entity_list          = csgo.interface_handler:get_entity_list()
local global_vars          = csgo.interface_handler:get_global_vars()
local events               = csgo.interface_handler:get_events()
local render               = fatality.render
local menu                 = fatality.menu
local config               = fatality.config
local callbacks            = fatality.callbacks
local math                 = require("math")
local table                = require("table")
-- End references

-- The prefix used for all config item identifiers
local conf_prefix          = "event_log_"

-- Start menu items
local conf_logs            = config:add_item(conf_prefix.."logs", 0)
local menu_logs            = menu:add_multi_combo("Logs", "Visuals", "ESP", "World", conf_logs, 0, 100, 1)
local conf_color_red       = config:add_item(conf_prefix.."color_red", 85)
local menu_color_red       = menu:add_slider("Red", "Visuals", "ESP", "World", conf_color_red, 0, 100, 1)
local conf_color_green     = config:add_item(conf_prefix.."color_green", 10)
local menu_color_green     = menu:add_slider("Green", "Visuals", "ESP", "World", conf_color_green, 0, 100, 1)
local conf_color_blue      = config:add_item(conf_prefix.."color_blue", 10)
local menu_color_blue      = menu:add_slider("Blue", "Visuals", "ESP", "World", conf_color_blue, 0, 100, 1)
local ref_hurt_log         = menu:get_reference("visuals", "misc", "various", "Hurt log")
local ref_additional       = menu:get_reference("visuals", "misc", "various", "Additional info")

local conf_logs_miss       = config:add_item(conf_prefix.."logs_miss", 1)
local conf_logs_hit        = config:add_item(conf_prefix.."logs_hit", 1)
local conf_logs_bomb       = config:add_item(conf_prefix.."logs_bomb", 1)
local conf_logs_hostage    = config:add_item(conf_prefix.."logs_hostage", 1)
menu_logs:add_item("Miss", conf_logs_miss)
menu_logs:add_item("Hit", conf_logs_hit)
menu_logs:add_item("Bomb", conf_logs_bomb)
menu_logs:add_item("Hostage", conf_logs_hostage)
-- End menu items

-- Start variables
local logs = {}
local fontRenderer = render:create_font("Verdana", 12, 400, false);
-- End variales

-- Registers a log with a custom expiration time and fade animation
function log(text, expiration)
    table.insert(logs, {text = text, expiration = expiration})
end

-- Returns the site a player is on
function get_site(player)
    local playerMin = player:get_var_vector("CBaseEntity->m_vecMins")
    local playerMax = player:get_var_vector("CBaseEntity->m_vecMaxs")
    local playerX = (playerMin.x + playerMax.x) / 2
    local playerY = (playerMin.y + playerMax.y) / 2
    local playerZ = (playerMin.z + playerMax.z) / 2
    local bombsiteA = player:get_var_vector("CCSPlayerResource->m_bombsiteCenterA")
    local bombsiteB = player:get_var_vector("CCSPlayerResource->m_bombsiteCenterB")
    local distanceA = math.sqrt((bombsiteA.x - playerX)^2 + (bombsiteA.y - playerY)^2 + (bombsiteA.z - playerZ)^2);
    local distanceB = math.sqrt((bombsiteB.x - playerX)^2 + (bombsiteB.y - playerY)^2 + (bombsiteB.z - playerZ)^2);
    if distanceA < distanceB then return 0 else return 1 end
end

-- Paint callback
function on_paint()
    if conf_logs_hit:get_int() == 1
            or conf_logs_miss:get_int() == 1
            or conf_logs_bomb:get_int() == 1
            or conf_logs_hostage:get_int() == 1 then
        ref_hurt_log:set_int(0)
        ref_additional:set_int(0)
    end

    local i = 1;
    for k, v in pairs(logs) do
        local color = csgo.color(
            math.floor(255 * (100 / conf_color_red:get_int())),
            math.floor(255 * (100 / conf_color_green:get_int())),
            math.floor(255 * (100 / conf_color_blue:get_int())),
            math.floor(255))

        local ratio = 1
        if (v.expiration <= 1) then
            ratio = (v.expiration) / 1
        end

        render:rect_filled(((1 - ratio) * 300), 12 * (i - 1) * 2 - 5, 395, 24, color)
        render:rect_filled(((1 - ratio) * 600), 12 * (i - 1) * 2 - 5, 380, 24, csgo.color(20,20,20,255))
        render:text(fontRenderer, 5 - ((1 - ratio) * 600), 12 * (i - 1) * 2 + 3,  v.text, csgo.color(255,255,255,255))

        v.expiration = v.expiration - 0.01
        if (v.expiration <= -1) then
            table.remove(logs, i)
        end
        i = i+1
    end
end

-- Shot callback
function on_shot(shot)
    local shot_info_t = shot.shot_info

    if not shot_info_t.has_info then
        return
    end

    local enemy = entity_list:get_player(shot.victim)

    if enemy == nil then
        return
    end

    if shot.hurt and conf_logs_hit:get_int() == 1 then
        local hitgroup = shot.hit_hitgroup
        if hitgroup == 1 then
            hitgroup = "Head"
        elseif hitgroup == 2 then
            hitgroup = "Chest"
        elseif hitgroup == 3 then
            hitgroup = "Stomach"
        elseif hitgroup == 4 then
            hitgroup = "Hand"
        elseif hitgroup == 5 then
            hitgroup = "Arm"
        elseif hitgroup == 6 then
            hitgroup = "Leg"
        elseif hitgroup == 7 then
            hitgroup = "Leg"
        elseif hitgroup == 8 then
            hitgroup = "Neck"
        else
            hitgroup = "Unknown"
        end

        log("Hit a shot. (Player:"..enemy:get_name().. " Hitbox:"..hitgroup.." Damage:"..shot.hit_damage..")", 5)
    elseif not shot.hurt and shot.hit and conf_logs_miss:get_int() == 1 then
        log("Missed shot due to resolver. (Player: "..enemy:get_name()..")", 5)
    elseif conf_logs_miss:get_int() == 1 then
        log("Missed shot due to spread. (Player: "..enemy:get_name()..")", 5)
    end
end

function on_event(game_event)
    if game_event:get_name() == "bomb_beginplant" then
        if conf_logs_bomb:get_int() == 0 then return end

        local player = entity_list:get_player_from_id(game_event:get_int("userid"))
        if get_site(player) == 0 then
            log(player:get_name().." is planting the bomb at site: A", 5)
        else
            log(player:get_name().." is planting the bomb at site: B", 5)
        end
    end

    if game_event:get_name() == "bomb_abortplant" then
        if conf_logs_bomb:get_int() == 0 then return end

        local player = entity_list:get_player_from_id(game_event:get_int("userid"))
        if get_site(player) == 0 then
            log(player:get_name().." is no longer planting the bomb at site: A", 5)
        else
            log(player:get_name().." is no longer planting the bomb at site: B", 5)
        end
    end

    if game_event:get_name() == "bomb_planted" then
        if conf_logs_bomb:get_int() == 0 then return end

        local player = entity_list:get_player_from_id(game_event:get_int("userid"))
        if get_site(player) == 0 then
            log(player:get_name().." planted the bomb at site: A", 5)
        else
            log(player:get_name().." planted the bomb at site: B", 5)
        end
    end

    if game_event:get_name() == "bomb_begindefuse" then
        if conf_logs_bomb:get_int() == 0 then return end

        local player = entity_list:get_player_from_id(game_event:get_int("userid"))
        if get_site(player) == 0 then
            log(player:get_name().." is defusing the bomb at site: A", 5)
        else
            log(player:get_name().." is defusing the bomb at site: B", 5)
        end
    end

    if game_event:get_name() == "bomb_abortdefuse" then
        if conf_logs_bomb:get_int() == 0 then return end

        local player = entity_list:get_player_from_id(game_event:get_int("userid"))
        if get_site(player) == 0 then
            log(player:get_name().." is no longer defusing the bomb at site: A", 5)
        else
            log(player:get_name().." is no longer defusing the bomb at site: B", 5)
        end
    end

    if game_event:get_name() == "enter_bombzone" then
        local player = entity_list:get_player_from_id(game_event:get_int("userid"))

        if game_event:get_bool("hasbomb") then
            if get_site(player) == 0 then
                log(player:get_name().." entered A site with the bomb", 5)
            else
                log(player:get_name().." entered B site with the bomb", 5)
            end
        end

        if game_event:get_bool("isplanted") then
            if get_site(player) == 0 then
                log(player:get_name().." entered A site where the bomb is planted", 5)
            else
                log(player:get_name().." entered B site where the bomb is planted", 5)
            end
        end
    end

    if game_event:get_name() == "hostage_follows" then
        local player = entity_list:get_player_from_id(game_event:get_int("userid"))
        log(player:get_name().." picked up the hostage", 5)
    end

    if game_event:get_name() == "hostage_stops_following" then
        local player = entity_list:get_player_from_id(game_event:get_int("userid"))
        log(player:get_name().." dropped the hostage", 5)
    end
end

callbacks:add("paint", on_paint)
callbacks:add("registered_shot", on_shot)
callbacks:add("events", on_event)
events:add_event("bomb_beginplant")
events:add_event("bomb_abortplant")
events:add_event("bomb_planted")
events:add_event("bomb_begindefuse")
events:add_event("bomb_abortdefuse")
events:add_event("enter_bombzone")
events:add_event("hostage_follows")
events:add_event("hostage_stops_following")