-- https://fatality.win/threads/advanced-penetration-crosshair-updated-06-03-2019.920/

-- Advanced penetration crosshair by eslipe v.1.1 (Current version of: 06.03.2019)

--[[ Updatelog:

(06.03.2019)
- Update

(06.02.2019)
- Release

]]


-- interfaces
local render = fatality.render
local input = fatality.input
local menu = fatality.menu
local config = fatality.config
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()
local entity_list = csgo.interface_handler:get_entity_list( )

local smartCrosshair_item = config:add_item( "sc_smartCrosshair_item", 0 )
local smartCrosshair_checkbox = menu:add_checkbox( "Enable extra crosshair settings", "visuals", "misc", "local", smartCrosshair_item )


local smartCrosshair2_item = config:add_item("sc_smartCrosshair2_item", 0)
local onlyOnWeapons_item = config:add_item("sc_onlyOnWeapons_item", 0)
local onlyInScope_item = config:add_item("sc_onlyInScope_item", 0)
local crosshair_combo = menu:add_multi_combo( "Customize crosshair", "visuals", "misc", "local")
crosshair_combo:add_item( "- Only on weapons", onlyOnWeapons_item, 0 )
crosshair_combo:add_item( "- Only if scoped", onlyInScope_item, 0 )

local addOutline_item = config:add_item( "sc_addOutline_item", 0 )
local addOutline_checkbox = menu:add_checkbox( "Add outline", "visuals", "misc", "local", addOutline_item )

local colour_item = config:add_item("sc_outlineColour_item", 255)
local colour_slider = menu:add_slider("Outline opacity", "visuals", "misc", "local", colour_item, 0 , 255, 1)

local outlineSize_item = config:add_item("sc_outlineSize_item", 1)
local outlineSize_slider = menu:add_slider("Outline size", "visuals", "misc", "local", outlineSize_item, 1 , 3, 1)



-- menu reference
local crosshair = menu:get_reference( "visuals", "misc", "local", "penetration crosshair" )


-- isScoped function
function isScoped()

    local lp = entity_list:get_localplayer();
    if (lp == nil or not lp:is_alive()) then
    return false
    end

    return lp:get_var_bool("CCSPlayer->m_bIsScoped");

end



-- on paint function
function on_paint()

    -- weapon list
    weapontable = {
        [1] = "AK47",
        [32] = "C4",
        [44] = "Desert Eagle",
        [45] = "Decoy Grenade",
        [75] = "Flashbang",
        [94] = "Frag Grenade",
        [97] = "Incendiary Grenade",
        [110] = "Molotov Grenade",
        [105] = "Knife",
        [152] = "Smoke Grenade",
        [228] = "AUG",
        [229] = "AWP",
        [231] = "Bizon",
        [235] = "Dualies",
        [237] = "Five Seven",
        [238] = "G3SG1",
        [240] = "Galil-AR",
        [241] = "Glock",
        [242] = "P2000",
        [243] = "M249",
        [245] = "M4A1",
        [249] = "MP7",
        [250] = "MP9",
        [247] = "Mag7",
        [252] = "Nova",
        [251] = "Negev",
        [254] = "P250",
        [255] = "P90",
        [257] = "SCAR20",
        [261] = "SG556",
        [262] = "SSG08",
        [263] = "Taser",
        [264] = "Tec9",
        [266] = "UMP45",
        [268] = "XM1014",
    }


    -- changing value from float to int
    local colour_value = colour_item:get_float() * 1
    local outlineSize_value = outlineSize_item:get_float() * 1


    -- colours
    local black_colour = csgo.color(0, 0, 0, colour_value)
 
    -- local player variable
    local local_player = entity_list:get_localplayer( );

    -- nil value check
    if local_player == nil then
    return
    end

    -- local player active weapon
    local weapon = csgo.interface_handler:get_entity_list():get_from_handle(local_player:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) )


    -- nil value check
    if weapon == nil then
    return
    end

    -- weapon index
    local weaponindex = weapon:get_class_id()

    -- renaming weapon index to weapon name
    local weaponname = weapontable[weaponindex]


    -- getting screen size
    local screen_size = render:screen_size()

    -- enable check
    if smartCrosshair_item:get_bool() then

        -- Only on weapons
        if onlyOnWeapons_item:get_bool() then

            if(weaponindex == 94 or weaponindex == 105 or weaponindex == 32 or weaponindex == 45 or weaponindex == 75 or weaponindex == 152 or weaponindex == 97 or weaponindex == 110 or weaponindex == 263) then
                crosshair:set_bool(false)
            else
                crosshair:set_bool(true)
            end

        end

         -- Only if scoped
         if onlyInScope_item:get_bool() then

            crosshair:set_bool(isScoped())

        end

        -- Outline
        if addOutline_item:get_bool() then

            if crosshair:get_bool() then

                if outlineSize_value == 1 then
                render:rect(screen_size.x / 2 - 2, screen_size.y / 2 - 2, 5, 5, black_colour );
                elseif outlineSize_value == 2 then
                render:rect(screen_size.x / 2 - 2, screen_size.y / 2 - 2, 5, 5, black_colour );
                render:rect(screen_size.x / 2 - 3, screen_size.y / 2 - 3, 7, 7, black_colour );
                elseif outlineSize_value == 3 then
                render:rect(screen_size.x / 2 - 2, screen_size.y / 2 - 2, 5, 5, black_colour );
                render:rect(screen_size.x / 2 - 3, screen_size.y / 2 - 3, 7, 7, black_colour );
                render:rect(screen_size.x / 2 - 4, screen_size.y / 2 - 4, 9, 9, black_colour );
                end

            end

        end

    end

end



-- callbacks
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)

-- end of the code