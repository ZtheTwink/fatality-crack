--
-- shoppy.gg/@edward22
--
local engine_client 	= csgo.interface_handler:get_engine_client()
local menu 				= fatality.menu
local render            = fatality.render
local input             = fatality.input

local stand_add_ref22 	= menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Add")
local stand_dir_ref 	= menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake amount")
local stand_add_ref57	= menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake type")
local backwards_ref22   = menu:get_reference("RAGE", "ANTI-AIM", "General", "Back")

local move_add_ref22 	= menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Add")
local move_dir_ref 	    = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake amount")
local move_add_ref57	= menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake type")

local side = false
local switch_key = 0x58     -- SWITCH KEY BY DEFAULT ITS "X"  // CHANGE IT HERE https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes
local switch_held = false

local font = render:create_font('Arial', 42, 800, true)
fatality.callbacks:add("paint", function()
    if(engine_client:is_in_game()) then
        -- Logic
        if input:is_key_down(switch_key) then
            if not switch_held then
                side = not side

                if side then
                    stand_add_ref22:set_float(3)		-- STANDING YAW // LEFT SIDE //
                    stand_dir_ref:set_int(100)		-- CUSTOM FAKE // MOVING LEFT // 
                    stand_add_ref57:set_int(2)		-- STANDING LEFT SIDE FAKE TYPE
					move_add_ref22:set_float(-4)		-- MOVING YAW LEFT SIDE // 
                    move_dir_ref:set_int(100)		-- CUSTOM FAKE // MOVING LEFT //
					move_add_ref57:set_int(2)		-- MOVING LEFT SIDE FAKE TYPE//
                else
                    stand_add_ref22:set_float(-3)		-- STANDING YAW RIGHT SIDE // 
                    stand_dir_ref:set_int(-100)		 -- CUSTOM FAKE // STAND RIGHT // 
                    stand_add_ref57:set_int(2)		-- STANDING RIGHT SIDE FAKE TYPE
					move_add_ref22:set_float(5)		-- MOVING YAW RIGHT SIDE //
                    move_dir_ref:set_int(-100)		-- CUSTOM FAKE // MOVING RIGHT // 
					move_add_ref57:set_int(2)		-- MOVING RIGHT SIDE FAKE TYPE //
				end
            end

            switch_held = true
        else
            switch_held = false
        end
		if backwards_ref22:get_bool() then
		    col_b = csgo.color(255, 151, 153, 255)
        end

        -- Drawing
        local screen_size = render:screen_size()
        local x, y = screen_size.x / 2, screen_size.y / 2
        local col_l = csgo.color(255, 151, 153, 255)
        local col_r = csgo.color(255, 151, 153, 255)
		local col_b = csgo.color(64, 64, 64, 185)

        -- logic
        if not side then
            col_l = csgo.color(64, 64, 64, 185) 
        else
            col_r = csgo.color(64, 64, 64, 185)
        end
		if backwards_ref22:get_bool() then
		    col_b = csgo.color(255, 151, 153, 255)
        end

        -- render
        render:text(font, x - 57, y - 18, '<', col_r)
        render:text(font, x + 41, y - 18, '>', col_l)
		render:text(font, x - 9, y + 24, 'v', col_b)
    end
end)