-- map: a b (wingman maps are not included since there's only one site)
-- mirage: 425 426
-- dust2: 278 279
-- inferno 334 423
-- overpass 79 507
-- cache 317 318
-- nuke 152 403
-- train 93 538
-- austria 288 570
-- cobblestone 216 107
-- biome 170 347
-- subzero 491 503
-- de_dust2_legenden 369 366
-- de_dust2_legends 370 367

-- report bugs/suggestions
-- https://fatality.win/threads/c4-timer.773/

local sites = {
    a = { 425, 278, 334, 79, 317, 152, 93, 288, 216, 170, 491, 369, 370 },
    b = { 426, 279, 423, 507, 318, 403, 538, 570, 107, 347, 503, 366, 367 }
}

function array_contains(arr, val)
    for i, v in ipairs(arr) do
        if(v == val) then
            return true
        end
    end
    return false
end

local render = fatality.render
local engine_client = csgo.interface_handler:get_engine_client()
local events = csgo.interface_handler:get_events()
local get_cvar = csgo.interface_handler:get_cvar()
local global_vars = csgo.interface_handler:get_global_vars()
local entity_list = csgo.interface_handler:get_entity_list()

local timer_font = render:create_font("verdana", 24, 400, false)

local background = csgo.color(33, 27, 70, 255)
local text_color = csgo.color(220, 220, 220, 255)

local green = csgo.color(20, 200, 20, 255)
local red = csgo.color(255, 50, 50, 255)
local orange = csgo.color(255, 255, 50, 255)
local blue = csgo.color(0, 150, 255, 255)

local dark_blue = csgo.color(50, 52, 255, 255)
local pink = csgo.color(255, 0, 72, 255)

local border = csgo.color(0, 0, 0, 100)

-- change x and y to replace timer on the screen
local timer_coords = { x = 600, y = 700, w = 170, h = 37 }

local bomb = {
    is_planting = false,
    is_planted = false,
    is_in_site = false,
    is_dropped = false,
    site = "-", -- 0 = a, 1 = b
    planted_time = 0, -- global_vars.curtime when bomb was planted
    explosion_time = 0, -- time until bomb explosion set on server
    is_defusing = 0, -- 0 = not defusing, 1 = defusing, 2 = defusing with kit
    defusing_started = 0 -- curtime when defusing was started
}

function reset_bomb()
    bomb = {
        is_planting = false,
        is_planted = false,
        is_in_site = false,
        is_dropped = false,
        site = "-",
        planted_time = 0,
        explosion_time = 0,
        is_defusing = 0,
        defusing_started = 0
    }
end

function round(num, numDecimalPlaces)
    local mult = 10^(numDecimalPlaces or 0)
    return math.floor(num * mult + 0.5) / mult
end

function ternary ( cond , T , F )
    if cond then return T else return F end
end

function on_paint()
    if(not engine_client:is_in_game()) then
        reset_bomb()
    end

    if(bomb.is_in_site or bomb.is_planted or bomb.is_planting or bomb.is_dropped) then
        render:rect(timer_coords.x - 1, timer_coords.y - 1, timer_coords.w + 2, timer_coords.h + 2, border)
        render:rect_filled(timer_coords.x, timer_coords.y, timer_coords.w, timer_coords.h, background)
        render:rect_fade(timer_coords.x, timer_coords.y, timer_coords.w, 2, dark_blue, pink, true)
    end

    if(bomb.is_dropped) then
        render:text(timer_font, timer_coords.x + 15, timer_coords.y + 7, "Dropped", blue)
    end

    if(bomb.is_in_site and not bomb.is_planted and not bomb.is_planting and not bomb.is_dropped) then
        render:text(timer_font, timer_coords.x + 15, timer_coords.y + 7, "Warning", pink)
    end

    if(bomb.is_planted) then

        -- if site was unknown while planting we determine it after it was planted
        if(bomb.site == "-") then
            local max_entities = entity_list:get_max_entities()
            for i = 0, max_entities do
                local entity = entity_list:get_entity(i)
                if(entity ~= nil) then
                    if(entity:get_class_id() == 126) then
                        local site = entity:get_var_int("CPlantedC4->m_nBombSite")
                        bomb.site = ternary(site == 0, "A", "B")
                    end
                end
            end
        end

        local timeleft = (global_vars.curtime - (bomb.planted_time + bomb.explosion_time))
        local defuse_timeleft = (bomb.defusing_started - (bomb.planted_time + bomb.explosion_time) + ternary(bomb.is_defusing == 1, 10, 5)) - timeleft
 
        if(timeleft <= 0) then
            local color = green
     
            if(math.abs(timeleft) <= 5) then
                color = red
            elseif(math.abs(timeleft) <= 10) then
                color = orange
            end
     
            if(bomb.is_defusing ~= 0 and defuse_timeleft > math.abs(timeleft)) then
                color = red
            elseif(bomb.is_defusing ~= 0 and defuse_timeleft < math.abs(timeleft)) then
                color = blue
            end
     
            render:text(timer_font, timer_coords.x + 15, timer_coords.y + 8, bomb.site, green)
            render:text(timer_font, timer_coords.x + 40, timer_coords.y + 8, "Time:", text_color)
            render:text(timer_font, timer_coords.x + 100, timer_coords.y + 8, round(math.abs(timeleft), 1) .. "s", color)
        end
 
    elseif(bomb.is_planting) then 
        render:text(timer_font, timer_coords.x + 15, timer_coords.y + 8, bomb.site, green)
        render:text(timer_font, timer_coords.x + 40, timer_coords.y + 8, "Planting..", text_color)
    end
end

function on_event(e)
    if(e:get_name() == "bomb_planted") then
        bomb.explosion_time = get_cvar:find_var("mp_c4timer"):get_int()
        bomb.planted_time = global_vars.curtime
        bomb.is_planted = true
        bomb.is_planting = false
    end

    if(e:get_name() == "bomb_beginplant") then
        bomb.is_planting = true
        if(array_contains(sites.a, e:get_int("site"))) then
            bomb.site = "A"
        elseif(array_contains(sites.b, e:get_int("site"))) then
            bomb.site = "B"
        else
            bomb.site = "-"
            print("Unknown bomb site:" .. e:get_int("site"))
        end
    end

    if(e:get_name() == "bomb_abortplant") then
        bomb.is_planting = false
    end

    if(e:get_name() == "bomb_exploded" or e:get_name() == "bomb_defused" or e:get_name() == "round_start") then
        reset_bomb()
    end

    if(e:get_name() == "bomb_begindefuse") then
        bomb.defusing_started = global_vars.curtime
        bomb.is_defusing = 1
        if(e:get_bool("haskit")) then
            bomb.is_defusing = 2
        end
    end

    if(e:get_name() == "bomb_abortdefuse") then
        bomb.is_defusing = 0
    end

    if(e:get_name() == "enter_bombzone") then
        if(e:get_bool("hasbomb")) then
            bomb.is_in_site = true
        end
    end

    if(e:get_name() == "exit_bombzone") then
        if(e:get_bool("hasbomb")) then
            bomb.is_in_site = false
        end
    end

    if(e:get_name() == "bomb_dropped") then
        bomb.is_dropped = true
    end

    if(e:get_name() == "bomb_pickup") then
        bomb.is_dropped = false
    end
end

events:add_event("bomb_beginplant")
events:add_event("bomb_planted")
events:add_event("bomb_abortplant")
events:add_event("bomb_exploded")
events:add_event("bomb_dropped")
events:add_event("bomb_pickup")
events:add_event("bomb_defused")
events:add_event("enter_bombzone")
events:add_event("exit_bombzone")
events:add_event("bomb_begindefuse")
events:add_event("bomb_abortdefuse")
events:add_event("round_start")

local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)
callbacks:add("events", on_event)