-- stupid Lua by kez#2466

-- my monkey code
local config = fatality.config;
local menu = fatality.menu;
local render = fatality.render;
local callbacks = fatality.callbacks;
local engine_client = csgo.interface_handler:get_engine_client();
--ref
local Vis_chm = menu:get_reference("VISUALS", "MODELS", "Local", "type")
local Vis_fake_chm = menu:get_reference("VISUALS", "MODELS", "Local", "Fake Type")

-- fake chamz
local CFG_fake = config:add_item("local_fake_Chamz",0)
local MENU_fake = menu:add_combo("override fake","VISUALS", "MODELS", "Local", CFG_fake)
MENU_fake:add_item("Off", CFG_fake)
MENU_fake:add_item("Glow", CFG_fake)
MENU_fake:add_item("Override", CFG_fake)
--real chamz

local CFG_real = config:add_item("local_real_Chamz",0)
local MENU_real = menu:add_combo("override real","VISUALS", "MODELS", "Local", CFG_real)
MENU_real:add_item("Off", CFG_real)
MENU_real:add_item("Glow", CFG_real)
MENU_real:add_item("Override", CFG_real)
function chams()
     if not engine_client:is_in_game( ) then
        return
     end

     if CFG_fake:get_int() == 1 then
          Vis_fake_chm:set_int(9)
     elseif CFG_fake:get_int() == 2 then
          Vis_fake_chm:set_int(12)
     end
     if CFG_real:get_int() == 1 then
          Vis_chm:set_int(9)
     end
     if CFG_real:get_int() == 2 then
          Vis_chm:set_int(12)
     end
end

local callbacks = fatality.callbacks
callbacks:add("paint", chams )