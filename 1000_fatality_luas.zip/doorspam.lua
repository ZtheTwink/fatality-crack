-- https://fatality.win/threads/doorspam-lua.3328/

local globals   = csgo.interface_handler:get_global_vars()
local engine    = csgo.interface_handler:get_engine_client()
local menu      = fatality.menu
local config    = fatality.config
local input     = fatality.input
local callbacks = fatality.callbacks
local last_tick = globals.tickcount
local doorspam  = config:add_item("Doorspam", 0)
local checkbox  = menu:add_checkbox("Doorspam", "MISC", "", "Movement", doorspam)

local in_use    = false
local keycode   = 86
local function spamdoor()
    local key_down = input:is_key_down(keycode)
    if key_down and doorspam:get_int() == 1 then
        in_use = true
        if globals.tickcount - last_tick > 0 then
            engine:client_cmd("+use")
        end
        if globals.tickcount - last_tick > 1 then
            engine:client_cmd("-use")
            last_tick = globals.tickcount
        end    
    else
        if not key_down and in_use then
            engine:client_cmd("-use")
            in_use = false
        end
    end
end
callbacks:add("paint", spamdoor)