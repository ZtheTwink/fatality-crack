-- Fatality interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu

-- Interfaces
local global_vars = csgo.interface_handler:get_global_vars( )
local engine = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )

local cfg =
{
watermark =
{
FatalMark = config:add_item( "local.watermark.FatalMark", 0 ),
logo = config:add_item( "local.watermark.logo", 0 ),
info = config:add_item( "local.watermark.info", 0 ),
time = config:add_item( "local.watermark.time", 0 ),
rainbow = config:add_item( "local.watermark.rainbow", 0 ),
}
}

local menu_items =
{
watermark_combo = menu:add_multi_combo( "watermarks", "misc", "", "movement" ):add_item( "Background", cfg.watermark.FatalMark ):add_item( " -- Logo", cfg.watermark.logo ):add_item( " -- Infomation", cfg.watermark.info ):add_item( " -- Time", cfg.watermark.time ):add_item( " -- Rainbow", cfg.watermark.rainbow )
}

-------------------- Fonts --------------------
local fonts =
{
watermark_FatalMark = render:create_font( "Verdana", 16, 400, true ),
watermark_small = render:create_font( "Smallest Pixel-7", 11, 400, true ),
logo = render:create_font( "Porter", 24, 300, false ),
}

--------------------- FPS ---------------------
local frame_rate = 0.0;

function get_fps( )
frame_rate = 0.9 * frame_rate + ( 1.0 - 0.9 ) * global_vars.frametime;
return math.floor( ( 1.0 / frame_rate ) + 0.5 );
end

--------------------- Ping --------------------

local function get_ping( )
if not engine:is_connected( ) then
return 0 end

return math.abs( engine:get_ping( ) )
end

------------------- Tickrate ------------------

local function get_tickrate( )
if not engine:is_connected( ) then
return 0 end

return math.floor( 1.0 / global_vars.interval_per_tick )
end

------------------ Draw Angle -----------------

function draw_container( x, y, w, h, header )
local c = {10, 60, 40, 40, 40, 60, 20};
for i = 0,6,1 do
render:rect_filled( x+i, y+i, w-(i*2), h-(i*2), csgo.color( c[i+1], c[i+1], c[i+1], 255 ) );

end
end

------------------ Screen Size -----------------

local screen_size = render:screen_size( )

local FatalMark =
{
watermark_pos = csgo.vector2( screen_size.x, 10 ),
watermark_size = csgo.vector2( 0, 16 ),
}
------------------ Background ------------------

local function watermark_FatalMark( )

FatalMark.watermark_size.x = render:text_size( fonts.watermark_FatalMark, text ).x + 10
FatalMark.watermark_pos.x = screen_size.x - 16 - FatalMark.watermark_size.x - 10

draw_container( FatalMark.watermark_pos.x + 22, FatalMark.watermark_pos.y - 3, 40, 40 )
draw_container( FatalMark.watermark_pos.x - 140, FatalMark.watermark_pos.y - 3, 160, 40 )
draw_container( FatalMark.watermark_pos.x - 231, FatalMark.watermark_pos.y - 3, 89, 40 )
end

--------------------- LOGO ---------------------

local function watermark_logo( )

FatalMark.watermark_size.x = render:text_size( fonts.watermark_FatalMark, text ).x + 10
FatalMark.watermark_pos.x = screen_size.x - 16 - FatalMark.watermark_size.x - 10

render:text( fonts.logo, FatalMark.watermark_pos.x + 36, FatalMark.watermark_pos.y + 4, "F", csgo.color(244, 66, 131, 255) )
end

------------------- Watermark -------------------

local function watermark_info( )

FatalMark.watermark_size.x = render:text_size( fonts.watermark_FatalMark, text ).x + 10
FatalMark.watermark_pos.x = screen_size.x - 16 - FatalMark.watermark_size.x - 10

local fps = get_fps( )
local ping = get_ping( )
local tick = get_tickrate( )

local local_player = entity_list:get_localplayer( )
if local_player == nil then
return end

local velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
local vel_2d = math.ceil( math.sqrt( math.abs( velocity.x ) * math.abs( velocity.x ) + math.abs( velocity.y ) * math.abs( velocity.y ) ) )

local r = math.sin((global_vars.realtime / 8) * 3) * 127 + 128;
local g = math.sin((global_vars.realtime / 8) * 5) * 127 + 128;
local b = math.sin((global_vars.realtime / 8) * 7) * 127 + 128;

-- Custom Position
local x;
if ( vel_2d == 0 ) then
x = FatalMark.watermark_pos.x - 44
elseif ( vel_2d <= 99 ) then
x = FatalMark.watermark_pos.x - 48
else
x = FatalMark.watermark_pos.x - 51
end

local xFPS;
if ( fps <= 9 ) then
xFPS = FatalMark.watermark_pos.x - 122
elseif ( fps <= 99 ) then
xFPS = FatalMark.watermark_pos.x - 126
else
xFPS = FatalMark.watermark_pos.x - 130
end

local xPING;
if ( ping <= 9 ) then
xPING = FatalMark.watermark_pos.x - 85
elseif ( ping <= 99 ) then
xPING = FatalMark.watermark_pos.x - 89
else
xPING = FatalMark.watermark_pos.x - 93
end

local xTICK;
if ( tick <= 64 ) then
xTICK = FatalMark.watermark_pos.x - 6
else
xTICK = FatalMark.watermark_pos.x - 11
end
--



-- Render Text 2 Screen
render:text(fonts.watermark_small, FatalMark.watermark_pos.x - 125, FatalMark.watermark_pos.y + 17, "fps", csgo.color(255, 255, 255, 255));
render:text(fonts.watermark_FatalMark, xFPS, FatalMark.watermark_pos.y + 3, fps, csgo.color(185, 255, 0, 255));
render:text(fonts.watermark_FatalMark, xPING, FatalMark.watermark_pos.y + 3, ping, csgo.color(185, 255, 0, 255));
render:text(fonts.watermark_small, FatalMark.watermark_pos.x - 90, FatalMark.watermark_pos.y + 17, "ping", csgo.color(255, 255, 255, 255));
render:text(fonts.watermark_FatalMark, x, FatalMark.watermark_pos.y + 3, vel_2d, csgo.color(185, 255, 0, 255));
render:text(fonts.watermark_small, FatalMark.watermark_pos.x - 52, FatalMark.watermark_pos.y + 17, "speed", csgo.color(255, 255, 255, 255));
render:text(fonts.watermark_FatalMark, xTICK, FatalMark.watermark_pos.y + 3, tick, csgo.color(185, 255, 0, 255));
render:text(fonts.watermark_small, FatalMark.watermark_pos.x - 6, FatalMark.watermark_pos.y + 17, "tick", csgo.color(255, 255, 255, 255));
end

--------------------- Time ---------------------

local function watermark_time( )

FatalMark.watermark_size.x = render:text_size( fonts.watermark_FatalMark, text ).x + 10
FatalMark.watermark_pos.x = screen_size.x - 16 - FatalMark.watermark_size.x - 10

render:text(fonts.watermark_FatalMark, FatalMark.watermark_pos.x - 216, FatalMark.watermark_pos.y + 3, os.date("%H:%M:%S"), csgo.color(0, 161, 255, 255));
render:text(fonts.watermark_small, FatalMark.watermark_pos.x - 211, FatalMark.watermark_pos.y + 17, "current time", csgo.color(255, 255, 255, 255));
end

--------------------- Soon ---------------------

local function watermark_rainbow( )

FatalMark.watermark_size.x = render:text_size( fonts.watermark_FatalMark, text ).x + 10
FatalMark.watermark_pos.x = screen_size.x - 16 - FatalMark.watermark_size.x - 10

end

-------------------- Paint ---------------------

function on_paint( )

if not engine:is_in_game( ) then
return end

if cfg.watermark.FatalMark:get_bool( ) then
watermark_FatalMark( ) end

if cfg.watermark.logo:get_bool( ) then
watermark_logo( ) end

if cfg.watermark.info:get_bool( ) then
watermark_info( ) end

if cfg.watermark.time:get_bool( ) then
watermark_time( ) end

if cfg.watermark.rainbow:get_bool( ) then
watermark_rainbow( ) end
end

------------------ Callbacks -------------------

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )