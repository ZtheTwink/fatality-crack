-- grab fatality_interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu

-- grab csgo_interfaces
local globals = csgo.interface_handler:get_global_vars( )
local entity_list = csgo.interface_handler:get_entity_list( )
local events = csgo.interface_handler:get_events( )
local cvar = csgo.interface_handler:get_cvar( )
local engine = csgo.interface_handler:get_engine_client()

--define font
local font_main = render:create_font( "Verdana", 12, 400, true );


--define color's (kinda like a namespace)
local colors =
{
    color_name = csgo.color(240, 240, 240, 255);
    color_health = csgo.color(0, 255, 0, 255);
}

local function on_paint( )

    --local player
    --has to be outside of max entity list
    local local_player = entity_list:get_localplayer( )

    --i is 1 in get_max_players
    for i = 1, entity_list:get_max_players( ), 1 do

         --player needs to be defined under becuase of get_max_players
         local player = entity_list:get_player( i )


         --checking if our qualifications meet to draw the info
         if player == nil or not player:is_alive( ) or player:get_var_int( "CBaseEntity->m_iTeamNum" ) ~= local_player:get_var_int( "CBaseEntity->m_iTeamNum" ) or player:get_index( ) == local_player:get_index( ) then
         --if these checks work then we continue
         goto continue end

             --distance credit to https://www.varsitytutors.com/hotmath/hotmath_help/topics/distance-formula-in-3d && DR4X
             local localorigin = local_player:get_var_vector("CBaseEntity->m_vecOrigin")

             local origin = player:get_var_vector("CBaseEntity->m_vecOrigin")

             local localpos = local_player:get_eye_pos()

             local distance = math.sqrt(math.pow(localorigin.x - origin.x, 2) + math.pow(localpos.y - origin.y, 2) +  math.pow(localpos.z - origin.z, 2)) * 0.0254

             --defines csgo health offset
             local health = player:get_var_int( "CBasePlayer->m_iHealth" )

             --if health is greater than or equal to 75
             if health >= 75 then
             --then set to green
             colors.color_health = csgo.color(0, 255, 0, 255)
             --if health is less then or equal to 25 (is above the middle run so it can override the other color)
             elseif health <= 25 then
             --then set to red
             colors.color_health = csgo.color(255, 20, 20, 255)
             --if health is less than to 75
             elseif health < 75 then
             --then set to orange
             colors.color_health = csgo.color(255, 150, 0, 255)
             end

             --pos definition
             local pos = player:get_eye_pos( )

             --define pos refrence to world
             pos = csgo.vector3( pos.x, pos.y, pos.z + 4 )

            -- making it so all text draws in game
            if pos:to_screen( ) then

               --defining string info
               local getname = player:get_name( )
               local getdistance = distance
               local seperator = " | "

               --clamping name size
               if string.len( getname ) > 7 then
                getname = string.sub( getname, 0, 7) .. "..."
               end

               --clamping distance becuase of the way we do distance
               if string.len( getdistance ) > 2 then
                getdistance = string.sub( getdistance, 0, 2) .. "FT"
               end

               --putting string info together
               local mainstring = getname .. seperator .. getdistance .. seperator
               local healthstring = health

                --makes textsize dynamic based off of the font size and length of string
                local text_size_main = render:text_size( font_main, mainstring )
                local text_size_health = render:text_size( font_main, healthstring )

                render:text( font_main, pos.x - 10 - text_size_main.x * 0.5, pos.y - text_size_main.y * 1.5, mainstring, colors.color_name)
                render:text( font_main, pos.x - 10 - text_size_main.x * 0.5 + text_size_main.x, pos.y - text_size_health.y * 1.5, healthstring, colors.color_health)

            end
             
            ::continue::
    end
end
-- Register callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )