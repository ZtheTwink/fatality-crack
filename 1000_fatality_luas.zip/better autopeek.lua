-- lua created by Hypnotic with <3
-- https://fatality.win/threads/release-actually-a-real-good-autopeek-lua-without-use-two-keys.5313
local menu = fatality.menu
local config = fatality.config
local render = fatality.render
local input = fatality.input
local interfaces = csgo.interface_handler

local cfg1 = config:add_item( "wtf", 0 )
local cfg2 = config:add_item( "wtf2", 0 )
local cfg3 = config:add_item( "wtf3", 7.0 )

local dummylol = config:add_item( "<3", 0 )
local autopeek_enable = menu:add_checkbox( "Autopeek", "MISC", "", "Movement", cfg1 )
local keybinds_list = menu:add_combo( "Bind key", "MISC", "", "Movement", cfg2 )
local expire_time = menu:add_slider( "Expire Time", "MISC", "", "Movement", cfg3, 0.0, 100.0, 1.0 )


keybinds_list:add_item( "[KEY] ALT", cfg2 )
keybinds_list:add_item( "[KEY] C", cfg2 )
keybinds_list:add_item( "[KEY] X", cfg2 )


local time = 0
local leftpeek
local rightpeek
local left = 0x25
local right = 0x27
local activatekey
local engine = interfaces:get_engine_client( )
local shotleft
local shotright
local activated = false

function main()


  if ( cfg1:get_bool() ) then

    if ( cfg2:get_int() == 0 ) then
      activatekey = 0xA4
    end

    if ( cfg2:get_int() == 1 ) then
      activatekey = 0x43
    end

    if ( cfg2:get_int() == 2 ) then
      activatekey = 0x58
    end

    render:indicator( 10, 700, "TIME: " .. time, true, time )
    if (input:is_key_pressed(left)) then
      leftpeek = true
      rightpeek = false
    end

    if ( input:is_key_pressed(right) ) then
      leftpeek = false
      rightpeek = true
    end

    if ( leftpeek ) then
      render:indicator( 10, 750, "SIDE: LEFT" , true, 0 )
    end

    if ( rightpeek ) then
      render:indicator( 10, 750, "SIDE: RIGHT" , true, 0 )
    end

    if ( input:is_key_down(activatekey) ) then
      render:indicator( 10, 780, "HOLD" , true, 0 )
    else
      render:indicator( 10, 780, "HOLD" , false, 0 )
    end

    if ( activated ) then
      time = time + 1
    end

    if ( time == cfg3:get_int() and leftpeek ) then
      engine:client_cmd( "-moveleft" )
      activated = false
      time = 0
      shotleft = false
      shotright = false

    end

    if ( time == 0 ) then
      render:indicator( 10, 725, "AUTOPEEKING", false, 0 )
    else
      render:indicator( 10, 725, "AUTOPEEKING" , true, 0 )
    end

    if ( time == cfg3:get_int() and rightpeek ) then
      engine:client_cmd( "-moveright" )
      activated = false
      time = 0
      shotleft = false
      shotright = false
    end


  end
end

function on_shot( )
  if ( input:is_key_down(activatekey) ) then
    if ( leftpeek ) then
      shotleft = false
      shotright = true
      activated = true
    end

  end

  if ( input:is_key_down(activatekey) ) then
    if ( rightpeek ) then
      shotleft = true
      shotright = false
      activated = true
    end

  end

  if ( shotleft ) then
    engine:client_cmd( "+moveright" )
  end

  if ( shotright ) then
    engine:client_cmd( "+moveleft" )
  end

end

fatality.callbacks:add( "paint", main )
fatality.callbacks:add( "registered_shot", on_shot )

