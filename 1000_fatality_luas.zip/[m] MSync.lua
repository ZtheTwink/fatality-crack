-- remake lua by zel
local engine_client     = csgo.interface_handler:get_engine_client()
local menu              = fatality.menu
local render            = fatality.render
local input             = fatality.input
local config = fatality.config
local entity_list = csgo.interface_handler:get_entity_list()
local global_vars = csgo.interface_handler:get_global_vars()
 
local stand_add_ref22   = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Add")
local stand_add_ref     = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake type", "Real around fake")
local stand_dir_ref     = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake amount")
local move_add_ref22    = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Add")
local move_add_ref      = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Add")
local move_dir_ref      = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake amount")
 
-- added side for air
local air_add_ref2    = menu:get_reference("RAGE", "ANTI-AIM", "Air", "Add")
local air_add_amount_2  = menu:get_reference("RAGE", "ANTI-AIM", "Air", "Add")
local air_dir_ref       = menu:get_reference("RAGE", "ANTI-AIM", "Air", "Fake amount")
 
local size_item = config:add_item( "size_item", 18 )
local size_slider = menu:add_slider( "Arrows size", "visuals", "misc", "local", size_item, 0, 23, 1 )
local pos_item = config:add_item( "pos_item", 0 )
local lise_slider = menu:add_slider( "Indicator", "rage", "aimbot", "misc" , pos_item, -1080, 0, 1 )
 
 
 
 
local colour_item = config:add_item("C_colour_item", 19 ) -- 14
local colour_slider = menu:add_slider("Arrows colour", "visuals", "misc", "local", colour_item, 0 , 20, 1)
 
local rainbow_item = config:add_item( "C_rainbow_item", 0 )
local rainbow_item_checkbox = menu:add_checkbox( "Enable rainbow arrows", "visuals", "misc", "local", rainbow_item )
 
local darkmode_item = config:add_item( "C_darkmode_item", 1.0 )
local darkmode_checkbox = menu:add_checkbox( "Enable dark mode for disabled arrows", "visuals", "misc", "local", darkmode_item )
 
local directindicator_item = config:add_item( "C_directindicator_item", 1.0 )
local global_vars = csgo.interface_handler:get_global_vars( )
local engine = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
 
 
 
local side = false
local side_2 = false
local side_3 = false
local switch_key = 0x58     -- SWITCH KEY BY DEFAULT ITS  MAYBE "X"  // CHANGE IT HERE https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-codes
local switch_held = false
local subpos = 0
 
 
-- draw arrows 1
function draw_side_arrow(x, y, size, color, side)
    if(side) then
        for i = 0, (size - 1) do
            render:rect(x + i, y + (i / 2) + 1, 1, size - i, color)
        end
       
    else
        for i = 0, (size - 1) do
            render:rect(x - i, y + (i / 2) + 1, 1, size - i, color)
        end
    end  
end
 
 
-- draw arrows 2
function draw_side_arrow_2(x, y, size_2, color, side_2)
    if(side_2) then
        for i = 0, (size_2 - 1) do
            render:rect(x + i, y + (i / 2) + 1, 1, size_2 - i, color)
        end
       
    else
        for i = 0, (size_2 - 1) do
            render:rect(x - i, y + (i / 2) + 1, 1, size_2 - i, color)
        end
    end  
end
 
local forcebaim_item = config:add_item( "forcebaimindicator", 0 )
local slidewalk_item = config:add_item( "slidewalkindicator", 0 )
local silent_item = config:add_item( "silentindicator", 0 )
local fake_item = config:add_item("fakeindicator", 0 )
local choke_item = config:add_item("chokeindicator", 0 )
 
 
local indicator_combobox = menu:add_multi_combo( "Indicators", "rage", "aimbot", "misc" ):add_item( "Manual desync", directindicator_item ):add_item( "Force baim", forcebaim_item ):add_item( "SLOW", slidewalk_item ):add_item( "AA ON SHOT", silent_item ):add_item( "Fake", fake_item ):add_item( "Ping", choke_item )
 
 
local indicator_font = render:create_font('Verdana', 25, 900, true) -- 32 700
 
local fl_indicator = render:create_font( "Smallest Pixel-7", 11, 100, false )
 
fatality.callbacks:add("paint", function()
 
   -- changing values from float to int
    local size_slider = size_item:get_float() * 1
    local colour_value = colour_item:get_float( ) * 1
 
    -- colours
    local white_colour = csgo.color(100, 100, 100, 100)
    local black_colour = csgo.color(0, 0, 0, 100)
   
      -- rainbow RGB
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
 
 
    -- colour changer (final version) (pasted)
    if colour_value == 0 then
        custom_colour = csgo.color(255, 255, 255, 255) --< white
        elseif colour_value == 1 then
        custom_colour = csgo.color(0, 0, 0, 255) --< black
        elseif colour_value == 2 then
        custom_colour = csgo.color(255, 0, 0, 255) --< deep-red
        elseif colour_value == 3 then
        custom_colour = csgo.color(244,67,54, 255) --< red
        elseif colour_value == 4 then
        custom_colour = csgo.color(255,87,34, 255) --< light-red
        elseif colour_value == 5 then
        custom_colour = csgo.color(255,152,0, 255) --< deep-orange
        elseif colour_value == 6 then
        custom_colour = csgo.color(255,193,7, 255) --< orange
        elseif colour_value == 7 then
        custom_colour = csgo.color(255,235,59, 255) --< yellow
        elseif colour_value == 8 then
        custom_colour = csgo.color(205,220,57, 255) --< lime
        elseif colour_value == 9 then
        custom_colour = csgo.color(139,195,74, 255) --< light-green
        elseif colour_value == 10 then
        custom_colour = csgo.color(76,175,80, 255) --< green
        elseif colour_value == 11 then
        custom_colour = csgo.color(0,150,136, 255) --< teal
        elseif colour_value == 12 then
        custom_colour = csgo.color(0,188,212, 255) --< cyan
        elseif colour_value == 13 then
        custom_colour = csgo.color(3,169,244, 255) --< ligh-blue
        elseif colour_value == 14 then
        custom_colour = csgo.color(33,150,243, 255) --< blue
        elseif colour_value == 15 then
        custom_colour = csgo.color(63,81,181, 255) --< indigo
        elseif colour_value == 16 then
        custom_colour = csgo.color(103,58,183, 255) --< deep-purple
        elseif colour_value == 17 then
        custom_colour = csgo.color(156,39,176, 255) --< purple
        elseif colour_value == 18 then
        custom_colour = csgo.color(126,87,194, 255) --< -light-purple
        elseif colour_value == 19 then
        custom_colour = csgo.color(233,30,99, 255) --< deep-pink
        elseif colour_value == 20 then
        custom_colour = csgo.color(236,64,122, 255) --< light-pink
        else
        custom_colour = csgo.color(255, 255, 255, 255) --< default
    end
   
    -- chroma mode for arrows
    if rainbow_item:get_bool() then
        custom_colour = csgo.color(r, g, b, 255)
    end
 
    -- dark mode for arrows
    if darkmode_item:get_bool() then
        white_colour = black_colour
    end
   
   
    local local_player = entity_list:get_localplayer()
   
    local screen_size = render:screen_size()
 
-- check is player in game
    if(engine_client:is_in_game()) then
   
    -- is local player alive,if not,then return
      if(local_player ~= nil and local_player:is_alive()) then
     
   
    local slide = menu:get_reference( "rage", "aimbot", "aimbot", "slide" )
    local forcebaim = menu:get_reference( "rage", "aimbot", "aimbot", "force fallback" )
    local silent = menu:get_reference( "rage", "aimbot", "aimbot", "Silent" )
    local fake = menu:get_reference( "rage", "anti-aim", "general", "anti-aim" )
    local flchoke = menu:get_reference( "rage", "anti-aim", "general", "anti-aim" )
       local velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
       
        local vel_2d = math.ceil( math.sqrt( math.abs( velocity.x ) * math.abs( velocity.x ) + math.abs( velocity.y ) * math.abs( velocity.y ) ) )
       
       
  local frame_rate = 0.0;
   
        function get_fps( )
        frame_rate = 0.9 * frame_rate + ( 1.0 - 0.9 ) * global_vars.frametime;
        return math.floor( ( 1.0 / frame_rate ) + 0.5 );
       
    end
      local fps = get_fps( )
    local clr_i = csgo.color(fps + 150, 255 - vel_2d, 0, 255)
    local clr_a = csgo.color(255, 255, 255, 255)
    local yaw = fps / 100 * 4
    local syaw = 255 - vel_2d
    local lyaw = yaw / 62
     local function get_ping( )
        if not engine:is_connected( ) then
    return 0 end
   
        return math.abs( engine:get_ping( ) )
    end
     local ping = get_ping( )
   
    if silent:get_bool() then
        sl = true
    else
        sl = false
    end
   
    if forcebaim:get_bool() then
        fb = true
    else
        fb = false
    end
 
    if slide:get_bool() then
        sw = true
    else
        sw = false
    end
   
    if fake:get_bool() then
        fk = true
    else
        fk = false
    end
   
    if flchoke:get_bool() then
        fl = true
    else
        fl = false
    end
     local addxx = pos_item:get_int()
   
    if silent_item:get_bool() then
 
        render:indicator( 9, screen_size.y - 140 + addxx , "SHOT", sl , -1)
        subpos = 125
 
    end
   
    if forcebaim_item:get_bool() then
 
        render:indicator( 9, screen_size.y - 170 + addxx, "BAIM", fb , -1)
        subpos = 100
 
    end
   
    if fake_item:get_bool() then       
 
render:text(indicator_font, 9, screen_size.y - 80 + addxx, "FAKE", clr_i, fk)
--render:text(indicator_font, 70, screen_size.y - 80, yaw, clr_i, fk)
render:text(indicator_font, 9, screen_size.y - 200 + addxx, "YAW", clr_a, fk)
render:text(indicator_font, 70, screen_size.y - 200 + addxx , yaw, clr_a, fk)
--render:text(indicator_font, 160, screen_size.y - 80, syaw, clr_i, fk)
       -- render:indicator( 9, screen_size.y - 80 , "FAKE", clr_i , fk)
        subpos = 0
 
    end
   
    if choke_item:get_bool( ) then
   
       render:text(indicator_font, 9, screen_size.y - 230 + addxx, "PING", clr_a, fk)
         render:text(indicator_font, 75, screen_size.y - 230 + addxx, ping, clr_a, fk)
       
    end
   
    if slidewalk_item:get_bool() then
 
        render:indicator( 10, screen_size.y - 110 + addxx , "SLOW", sw , -1) -- 440 -- 80
        subpos = 75
 
    end
   
        -- Logic
        if input:is_key_down(switch_key) then
            if not switch_held then
                side = not side
 
                if side then
                    stand_add_ref22:set_float(-52) -- STANDING YAW LEFT SIDE //
                    stand_dir_ref:set_int(100)      -- CUSTOM FAKE .. MOVING LEFT //
                    move_add_ref:set_float(-52)     -- MOVING YAW LEFT SIDE //
                    move_dir_ref:set_int(100)       -- CUSTOM FAKE // MOVING LEFT //
                    air_dir_ref:set_int(100)        -- AIR LEFT SIDE
                else
                    stand_add_ref22:set_float(52)  -- STANDING YAW RIGHT SIDE //
                    stand_dir_ref:set_int(-100)       -- CUSTOM FAKE // STAND RIGHT //
                    move_add_ref:set_float(52)       -- MOVING YAW RIGHT SIDE //
                    move_dir_ref:set_int(-100)        -- CUSTOM FAKE // MOVING RIGHT //
                    air_dir_ref:set_int(-100)           -- AIR RIGHT SIDE          
                end
            end
 
            switch_held = true
        else
            switch_held = false
        end
       
        if directindicator_item:get_bool() then
            dc = true
        else
            dc = false
        end
       
        local indicator_white = csgo.color(255, 255, 255, 255)
       
        -- B1G LOGIC OF MY RENDER
 
        if not side then
       
 
            draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y / 2 - 10, size_slider, custom_colour, side)  --right
            side_2 = true;
            draw_side_arrow_2(screen_size.x / 2 + 10 + 30 + 1, screen_size.y / 2 - 10, size_slider, white_colour, side_2) --left disabled
           
            if directindicator_item:get_bool() then
       --     render:indicator( 9, screen_size.y - 75  - subpos, "DC RIGHT", dc , -1)
             render:text(indicator_font, 9, screen_size.y - 260, "LEFT", indicator_white, dc)
            subpos = 25
           end         
           
        else
            draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y / 2 - 10, size_slider, custom_colour, side) --right
               
            side_2 = false;
            draw_side_arrow_2(screen_size.x / 2 - 10 - 30 + 1, screen_size.y / 2 - 10, size_slider, white_colour, side_2) --left disabled
           
            if directindicator_item:get_bool() then
        --  render:indicator( 9, screen_size.y - 75  - subpos, "DC LEFT", dc , -1)
               render:text(indicator_font, 9, screen_size.y - 260 , "RIGHT", indicator_white, dc)
            subpos = 25
            end
        end
    end
 end
end)