-- _markjelo luas + cfg

print("off AA on round end LUA for my cfg _markjelo#9266")

-- Fatality interfaces
local render = fatality.render
local config = fatality.config
local menu = fatality.menu

-- Interfaces
local globals = csgo.interface_handler:get_global_vars()
local engine = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()

local aa_rndend_item = config:add_item( "aa_roundend", 0 )
local aa_rndend_checkbox = menu:add_checkbox("Turn Antiaim off at round end", "rage", "anti-aim", "general", aa_rndend_item )

local antiaim = menu:get_reference( "rage", "anti-aim", "general", "anti-aim" )

function on_event( e )

    local event_name = e:get_name()

    local local_player = entity_list:get_localplayer()
    for i = 0, entity_list:get_max_players( ), 1 do
        local player = entity_list:get_player( i )
        if player == nil then
        goto continue end

        local enemy_team = player:get_var_int("CBaseEntity->m_iTeamNum")
        local my_team = local_player:get_var_int( "CBaseEntity->m_iTeamNum" )

        if enemy_team == my_team then -- only enemy
        goto continue end

        if (aa_rndend_item:get_bool()) then
            if event_name == "round_end" then
                if not player:is_alive() then
                    antiaim:set_bool(false)
                else
                    antiaim:set_bool(true)
                end
            end
            if event_name == "round_start" then
                antiaim:set_bool(true)
            end
        end
        ::continue::
    end
end

-- Listen to events
events:add_event( "round_end" )
events:add_event( "round_start" )

-- Register callbacks
local callbacks = fatality.callbacks
callbacks:add( "events", on_event )