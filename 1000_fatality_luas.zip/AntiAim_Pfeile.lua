-- Manual arrows (anti-aim arrows) by eslipe v.1.6 (19.05.2019)
 
--[[ Updatelog:
 
(19.05.2019)
- Added "Rectangle to the arrows" function
- Added new arrows "Left/Right only" (L/R = left/right, L/D/R = left/down/right)
- Added "Extra-large font" for font-based arrows
- Removed arrows at the bottom (if you want to use it, please follow the link below (old version))
- Fixed uncorrect position of the arrows
 
 
(03.05.2019)
- Improved UI
- Added new type of arrows (text-arrows)
- Added customizable thickness of the text-arrows
- Fixed uncorrect distance between arrows
- Fixed some bugs in the code
 
(06.03.2019)
- Improved UI ( made it easier to use )
- Added new types of design ( Bottom, Bottom with background )
- Added dark mode.
- Added final version of colour-picker
- Added chroma mode
- Removed old rgb colour-picker
 
(20.02.2019)
- Added new design for manual arrows.
- Removed "Height of arrows" function, because it's actually useless.
- Fixed some bugs in the code.
 
 
(14.02.2019)
- Added RGB colour changer
- Added customizable size of arrows
- Added customizable height of arrows ( Yaw )
 
]]
 
 
 
-- interfaces
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local entity_list = csgo.interface_handler:get_entity_list()
local global_vars = csgo.interface_handler:get_global_vars()
 
 
-- getting reference of menu features
local aa_back = menu:get_reference( "rage", "anti-aim", "general", "back" )
local aa_right = menu:get_reference( "rage", "anti-aim", "general", "right" )
local aa_left = menu:get_reference( "rage", "anti-aim", "general", "left" )
 
 
-- adding features to the menu
local manualAA_item = config:add_item( "manual_arrows", 0 )
local manualAA_checkbox = menu:add_checkbox( "Manual arrows", "visuals", "misc", "local", manualAA_item )
 
local customDesign_item  = config:add_item("Ma_customDesign_item", 0)
local customDesign_combo = menu:add_combo("Arrows design", "visuals", "misc", "local", customDesign_item)
customDesign_combo:add_item("Centre (Icon, L/D/R)", customDesign_item)
customDesign_combo:add_item("Centre (Icon, L/R)", customDesign_item)
customDesign_combo:add_item("Centre (Font, Light)", customDesign_item)
customDesign_combo:add_item("Centre (Font, Bold)", customDesign_item)
customDesign_combo:add_item("Centre (Font, Extra)", customDesign_item)
 
local add_rect_item = config:add_item( "Ma_add_rect_item", 0 )
local add_rect_checkbox = menu:add_checkbox( "Add rectangle to arrows (Icon only)", "visuals", "misc", "local", add_rect_item )
 
local colour_item = config:add_item("Ma_colour_item", 14)
local colour_slider = menu:add_slider("Arrows colour", "visuals", "misc", "local", colour_item, 0 , 20, 1)
 
local chroma_item = config:add_item( "Ma_chroma_item", 0 )
local chroma_checkbox = menu:add_checkbox( "Chroma mode for enabled arrows", "visuals", "misc", "local", chroma_item )
 
local darkmode_item = config:add_item( "Ma_darkmode_item", 0 )
local darkmode_checkbox = menu:add_checkbox( "Dark mode for disabled arrows", "visuals", "misc", "local", darkmode_item )
 
 
-- fonts
local light_font = render:create_font( "Verdana Bold", 25, 400, false );
local bold_font = render:create_font( "Verdana Bold", 25, 800, false );
local extra_font = render:create_font( "Verdana Bold", 50, 800, false );
 
 
-- needed variables
local side = false
local back = false
 
 
-- left and right arrows
function draw_side_arrow(x, y, size, color, side)
    if(side) then
        for i = 0, (size - 1) do
            render:rect(x + i, y + (i / 2) + 1, 1, size - i, color)
        end
       
    else
        for i = 0, (size - 1) do
            render:rect(x - i, y + (i / 2) + 1, 1, size - i, color)
        end
    end  
end
 
 
-- back arrow
function draw_back_arrow(x, y, size, color, side)
    if(back) then
        for i = 0, (size - 1) do
            render:rect(x - 0.5 - (i / 2), y - i / 50 + 30, 1, size - i, color)
        end
        for i = 0, (size - 1) do
            render:rect(x + (i / 2), y - i / 50 + 30, 1, size - i, color)
        end
       
    else
        for i = 0, (size - 1) do
            render:rect(x - i, y + (i / 2) + 1, 1, size - i, color)
        end
    end  
end
 
 
 
-- rendering arrows
function on_paint()
 
    -- changing values from float to int
    local colour_value = colour_item:get_float( ) * 1
 
    -- colours
    local white_colour = csgo.color(100, 100, 100, 100)
    local black_colour = csgo.color(0, 0, 0, 100)
 
    -- rainbow RGB
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
 
 
    -- colour changer (final version)
    if colour_value == 0 then
        custom_colour = csgo.color(255, 255, 255, 255) --< white
        elseif colour_value == 1 then
        custom_colour = csgo.color(0, 0, 0, 255) --< black
        elseif colour_value == 2 then
        custom_colour = csgo.color(255, 0, 0, 255) --< deep-red
        elseif colour_value == 3 then
        custom_colour = csgo.color(244,67,54, 255) --< red
        elseif colour_value == 4 then
        custom_colour = csgo.color(255,87,34, 255) --< light-red
        elseif colour_value == 5 then
        custom_colour = csgo.color(255,152,0, 255) --< deep-orange
        elseif colour_value == 6 then
        custom_colour = csgo.color(255,193,7, 255) --< orange
        elseif colour_value == 7 then
        custom_colour = csgo.color(255,235,59, 255) --< yellow
        elseif colour_value == 8 then
        custom_colour = csgo.color(205,220,57, 255) --< lime
        elseif colour_value == 9 then
        custom_colour = csgo.color(139,195,74, 255) --< light-green
        elseif colour_value == 10 then
        custom_colour = csgo.color(76,175,80, 255) --< green
        elseif colour_value == 11 then
        custom_colour = csgo.color(0,150,136, 255) --< teal
        elseif colour_value == 12 then
        custom_colour = csgo.color(0,188,212, 255) --< cyan
        elseif colour_value == 13 then
        custom_colour = csgo.color(3,169,244, 255) --< ligh-blue
        elseif colour_value == 14 then
        custom_colour = csgo.color(33,150,243, 255) --< blue
        elseif colour_value == 15 then
        custom_colour = csgo.color(63,81,181, 255) --< indigo
        elseif colour_value == 16 then
        custom_colour = csgo.color(103,58,183, 255) --< deep-purple
        elseif colour_value == 17 then
        custom_colour = csgo.color(156,39,176, 255) --< purple
        elseif colour_value == 18 then
        custom_colour = csgo.color(126,87,194, 255) --< -light-purple
        elseif colour_value == 19 then
        custom_colour = csgo.color(233,30,99, 255) --< deep-pink
        elseif colour_value == 20 then
        custom_colour = csgo.color(236,64,122, 255) --< light-pink
        else
        custom_colour = csgo.color(255, 255, 255, 255) --< default
    end
 
    if chroma_item:get_bool() then
        custom_colour = csgo.color(r, g, b, 255) --< chroma mode
    end
 
    if darkmode_item:get_bool() then
        white_colour = black_colour --< dark mode
    end
 
    -- getting localplayer variable
    local local_player = entity_list:get_localplayer()
 
    -- getting screen size
    local screen_size = render:screen_size()
 
      -- check box check
      if manualAA_item:get_bool() then
 
        -- local player check
        if(local_player ~= nil and local_player:is_alive()) then
       
                -- Centre (Icon, L/D/R)
                if customDesign_item:get_int() == 0 then
 
                        -- [ DISABLED ARROWS ] --
                        -- right
                        side = true;
                        draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y / 2 + 2 - 10, 16, white_colour, side)
                        if add_rect_item:get_bool() == true then
                        render:rect_filled( screen_size.x / 2 + 26, screen_size.y / 2 + 2 - 5, 15, 8, white_colour);
                        end
                       
                        -- left
                        side = false;
                        draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y / 2 + 2 - 10, 16, white_colour, side)
                        if add_rect_item:get_bool() == true then
                        render:rect_filled( screen_size.x / 2 - 38, screen_size.y / 2 + 2 - 5, 15, 8, white_colour);
                        end
           
                        -- back
                        back = true;
                        draw_back_arrow(screen_size.x / 2 + 1, screen_size.y / 2 + 10, 16, white_colour, back)
                        if add_rect_item:get_bool() == true then
                        render:rect_filled( screen_size.x / 2 - 3, screen_size.y / 2 + 24, 8, 15, white_colour);
                        end
                       
                        -- [ DISABLED ARROWS ] --
 
 
 
                        -- [ ENABLED ARROWS ] --
                        -- right activated
                        if aa_right:get_bool() then
                            side = true;
                            draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y / 2 + 2 - 10, 16, custom_colour, side)
                            if add_rect_item:get_bool() == true then
                            render:rect_filled( screen_size.x / 2 + 26, screen_size.y / 2 + 2 - 5, 15, 8, custom_colour);
                            end
 
                        -- left activated
                        elseif aa_left:get_bool() then
                            side = false;
                            draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y / 2 + 2 - 10, 16, custom_colour, side)
                            if add_rect_item:get_bool() == true then
                            render:rect_filled( screen_size.x / 2 - 38, screen_size.y / 2 + 2 - 5, 15, 8, custom_colour);
                            end
 
                        -- back activated
                        elseif aa_back:get_bool() then
                            back = true;
                            draw_back_arrow(screen_size.x / 2 + 1, screen_size.y / 2 + 10, 16, custom_colour, back)
                            if add_rect_item:get_bool() == true then
                            render:rect_filled( screen_size.x / 2 - 3, screen_size.y / 2 + 24, 8, 15, custom_colour);
                            end
                        -- [ ENABLED ARROWS ] --
                        end
 
                end    
               
                -- Centre (Icon, L/R)
                if customDesign_item:get_int() == 1 then
 
                    -- [ DISABLED ARROWS ] --
                        -- right
                        side = true;
                        draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y / 2 + 2 - 10, 16, white_colour, side)
                        if add_rect_item:get_bool() == true then
                        render:rect_filled( screen_size.x / 2 + 26, screen_size.y / 2 + 2 - 5, 15, 8, white_colour);
                        end
                       
                        -- left
                        side = false;
                        draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y / 2 + 2 - 10, 16, white_colour, side)
                        if add_rect_item:get_bool() == true then
                        render:rect_filled( screen_size.x / 2 - 38, screen_size.y / 2 + 2 - 5, 15, 8, white_colour);
                        end
       
                        -- [ DISABLED ARROWS ] --
 
 
 
                        -- [ ENABLED ARROWS ] --
                        -- right activated
                        if aa_right:get_bool() then
                            side = true;
                            draw_side_arrow(screen_size.x / 2 + 10 + 30 + 1, screen_size.y / 2 + 2 - 10, 16, custom_colour, side)
                            if add_rect_item:get_bool() == true then
                            render:rect_filled( screen_size.x / 2 + 26, screen_size.y / 2 + 2 - 5, 15, 8, custom_colour);
                            end
 
                        -- left activated
                        elseif aa_left:get_bool() then
                            side = false;
                            draw_side_arrow(screen_size.x / 2 - 10 - 30 + 1, screen_size.y / 2 + 2 - 10, 16, custom_colour, side)
                            if add_rect_item:get_bool() == true then
                            render:rect_filled( screen_size.x / 2 - 38, screen_size.y / 2 + 2 - 5, 15, 8, custom_colour);
                            end
 
                        -- [ ENABLED ARROWS ] --
                        end
 
                end
 
               -- Font (Light)
                if customDesign_item:get_int() == 2 then
 
                    -- [ DISABLED ARROWS ] --
                    -- right
                    side = true;
                    render:text(light_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 11,  ">", white_colour)
 
                    -- left
                    side = false;
                    render:text(light_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", white_colour)
 
                    -- back
                    back = true;
                    render:text(light_font, screen_size.x / 2 - 5, screen_size.y / 2 + 25,  "v", white_colour)
                    -- [ DISABLED ARROWS ] --
 
 
 
                    -- [ ENABLED ARROWS ] --
                    -- right activated
                    if aa_right:get_bool() then
                    side = true;
                    render:text(light_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 11,  ">", custom_colour)
 
                    -- left activated
                    elseif aa_left:get_bool() then
                    side = false;
                    render:text(light_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", custom_colour)
 
                    -- back activated
                    elseif aa_back:get_bool() then
                    back = true;
                    render:text(light_font, screen_size.x / 2 - 5, screen_size.y / 2 + 25,  "v", custom_colour)
                    -- [ ENABLED ARROWS ] --
                    end
            end
 
            -- Font (Bold)
            if customDesign_item:get_int() == 3 then
 
                    -- [ DISABLED ARROWS ] --
                    -- right
                    side = true;
                    render:text(bold_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 11,  ">", white_colour)
 
                    -- left
                    side = false;
                    render:text(bold_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", white_colour)
 
                    -- back
                    back = true;
                    render:text(bold_font, screen_size.x / 2 - 5, screen_size.y / 2 + 25,  "v", white_colour)
                    -- [ DISABLED ARROWS ] --
 
 
 
                    -- [ ENABLED ARROWS ] --
                    -- right activated
                    if aa_right:get_bool() then
                    side = true;
                    render:text(bold_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 11,  ">", custom_colour)
 
                    -- left activated
                    elseif aa_left:get_bool() then
                    side = false;
                    render:text(bold_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", custom_colour)
 
                    -- back activated
                    elseif aa_back:get_bool() then
                    back = true;
                    render:text(bold_font, screen_size.x / 2 - 5, screen_size.y / 2 + 25,  "v", custom_colour)
                    -- [ ENABLED ARROWS ] --
                    end
            end
           
                -- Font (Extra)
                if customDesign_item:get_int() == 4 then
 
                    -- [ DISABLED ARROWS ] --
                    -- right
                    side = true;
                    render:text(extra_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 23,  ">", white_colour)
 
                    -- left
                    side = false;
                    render:text(extra_font, screen_size.x / 2 - 10 - 50 + 1, screen_size.y / 2 - 23,  "<", white_colour)
 
                    -- back
                    back = true;
                    render:text(extra_font, screen_size.x / 2 - 11, screen_size.y / 2 + 25,  "v", white_colour)
                    -- [ DISABLED ARROWS ] --
 
 
 
                    -- [ ENABLED ARROWS ] --
                    -- right activated
                    if aa_right:get_bool() then
                    side = true;
                    render:text(extra_font, screen_size.x / 2 + 10 + 27 + 1, screen_size.y / 2 - 23,  ">", custom_colour)
 
                    -- left activated
                    elseif aa_left:get_bool() then
                    side = false;
                    render:text(extra_font, screen_size.x / 2 - 10 - 50 + 1, screen_size.y / 2 - 23,  "<", custom_colour)
 
                    -- back activated
                    elseif aa_back:get_bool() then
                    back = true;
                    render:text(extra_font, screen_size.x / 2 - 11, screen_size.y / 2 + 25,  "v", custom_colour)
                    -- [ ENABLED ARROWS ] --
 
                end
 
            end
 
            end  
 
        end
 
end
 
 
 
-- callbacks
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)
 
-- end of the code