--aimbot indicators made by ??? edited & updated by Edward22
--
-- Stay fatal.
--
local render = fatality.render
local input = fatality.input
local menu = fatality.menu
local config = fatality.config
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()

local screensize = render:screen_size()

local forcebaim_item = config:add_item( "forcebaimindicator", 0 )
local slidewalk_item = config:add_item( "slidewalkindicator", 0 )
local silent_item = config:add_item( "silentindicator", 0 )

local forcebaim_combobox = menu:add_multi_combo( "indicators", "rage", "aimbot", "misc" ):add_item( "force baim", forcebaim_item ):add_item( "slide walk", slidewalk_item ):add_item( "silent", silent_item )

function on_paint()

 

    if not engine_client:is_in_game() then
    return end

    local slide = menu:get_reference( "rage", "aimbot", "aimbot", "slide" )
    local forcebaim = menu:get_reference( "rage", "aimbot", "aimbot", "force fallback" )
	local silent = menu:get_reference( "rage", "aimbot", "aimbot", "Silent" )

    if slide:get_bool() then
        sw = true
    else
        sw = false
    end

    if forcebaim:get_bool() then
        fb = true
    else
        fb = false
    end
	
    if silent:get_bool() then
        si = true
    else
        si = false
    end

    if forcebaim_item:get_bool() then 

        render:indicator( 15, screensize.y - 100, "NERVOSPEEK", fb , -1)

    end

    if slidewalk_item:get_bool() then 

        render:indicator( 15, screensize.y - 80, "NASAWALK", sw , -1)

    end
	
    if silent_item:get_bool() then 

        render:indicator( 15, screensize.y - 120, "POTIVBMANE", si , -1)

    end

end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )