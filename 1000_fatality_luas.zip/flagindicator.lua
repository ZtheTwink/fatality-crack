--inputs
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local input = fatality.input

--screensize
local get_screensize = render:screen_size( )

--menu checkbox
local choke_item = config:add_item( "fakelag_choke_indicator", 0.0 )
local choke_pos_x_item = config:add_item( "fakelag_choke_indicator_x", 0.0 )
local choke_pos_y_item = config:add_item( "fakelag_choke_indicator_y", 0.0 )
local choke_checkbox = menu:add_checkbox( "Fakelag choke indicator", "VISUALS", "MISC", "Various", choke_item )

local customviewmodel_slider_y = menu:add_slider( "FL Indicator Position", "VISUALS", "MISC", "Various", choke_pos_y_item, 1.0, 1080, 1080.0 )

--menu reference
local fakelag_stand = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Limit" )
local fakelag_move = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Limit" )
local fakelag_jump = menu:get_reference( "RAGE", "ANTI-AIM", "Air", "Limit" )
local silent = menu:get_reference( "RAGE", "weapons", "auto", "Silent" )

--fonts - i was testing some
local fonts = render:create_font( "Smallest Pixel-7", 11, 100, false )

--value def
local value1 = 0
local value2 = 0
local value3 = 0

local static_value1 = 0
local static_value2 = 0
local static_value3 = 0

local bar_value1 = 0
local bar_value2 = 0
local bar_value3 = 0


--colorpicker code (public)
local colorpicker_item = config:add_item( "fakelag_choke_color", 0.0 )
local colorpicker_combo = menu:add_combo( "Colours", "VISUALS", "MISC", "Various", colorpicker_item )
colorpicker_combo:add_item( "White", colorpicker_item )
colorpicker_combo:add_item( "Dark Red", colorpicker_item )
colorpicker_combo:add_item( "Red", colorpicker_item )
colorpicker_combo:add_item( "Orange", colorpicker_item )
colorpicker_combo:add_item( "Yellow", colorpicker_item )
colorpicker_combo:add_item( "Yellow-Green", colorpicker_item )
colorpicker_combo:add_item( "Green", colorpicker_item )
colorpicker_combo:add_item( "Cyan", colorpicker_item )
colorpicker_combo:add_item( "Light Blue", colorpicker_item )
colorpicker_combo:add_item( "Blue", colorpicker_item )
colorpicker_combo:add_item( "Purple", colorpicker_item )
colorpicker_combo:add_item( "Pink", colorpicker_item )
colorpicker_combo:add_item( "Bright Pink", colorpicker_item )
colorpicker_combo:add_item( "Grey", colorpicker_item )
colorpicker_combo:add_item( "Black", colorpicker_item )
local colorpicker_slider_item = config:add_item( "fakelag_choke_color_opacity", 0.0 )
local colorpicker_slider = menu:add_slider( "Opacity", "VISUALS", "MISC", "Various", colorpicker_slider_item, 1.0, 100.0, 100.0 )

--on paint
function on_paint()
    --if you arent in game, return
    if not engine_client:is_in_game( ) then
       return end
       
    local local_player = entity_list:get_localplayer( )

    --if you arent alive, return
    if not local_player:is_alive( ) then
        return end
       
    local get_is_space = 0x20
    velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
    velocity2d = math.ceil( math.sqrt( math.abs( velocity.x ) * math.abs( velocity.x ) + math.abs( velocity.y ) * math.abs( velocity.y ) ) )          
       
    local slider_float = (colorpicker_slider_item:get_float( ) * 2.55)
    local opacity = math.floor(slider_float)
    local default_color = csgo.color(255, 255, 255, 255)

    if colorpicker_item:get_float( ) == 0 then --white
        default_color = csgo.color(255, 255, 255, opacity)
    elseif colorpicker_item:get_float( ) == 1 then --dark red (maroon)
        default_color = csgo.color(128, 0, 0, opacity)
    elseif colorpicker_item:get_float( ) == 2 then    --red
        default_color = csgo.color(255, 0, 0, opacity)
    elseif colorpicker_item:get_float( ) == 3 then    --orange
        default_color = csgo.color(255, 128, 0, opacity)
    elseif colorpicker_item:get_float( ) == 4 then    --yellow
        default_color = csgo.color(255, 255, 0, opacity)
    elseif colorpicker_item:get_float( ) == 5 then    --yellow-green
        default_color = csgo.color(191, 255, 0, opacity)  
    elseif colorpicker_item:get_float( ) == 6 then    --green
        default_color = csgo.color(0, 255, 0, opacity)
    elseif colorpicker_item:get_float( ) == 7 then    --cyan
        default_color = csgo.color(0, 255, 255, opacity)
    elseif colorpicker_item:get_float( ) == 8 then    --light blue
        default_color = csgo.color(0, 191, 255, opacity)
    elseif colorpicker_item:get_float( ) == 9 then    --blue
        default_color = csgo.color(0, 0, 255, opacity)
    elseif colorpicker_item:get_float( ) == 10 then --purple
        default_color = csgo.color(128, 0, 255, opacity)  
    elseif colorpicker_item:get_float( ) == 11 then --pink
        default_color = csgo.color(255, 0, 255, opacity)  
    elseif colorpicker_item:get_float( ) == 12 then --bright pink
        default_color = csgo.color(255, 204, 255, opacity)  
    elseif colorpicker_item:get_float( ) == 13 then --grey
        default_color = csgo.color(128, 128, 128, opacity)  
    elseif colorpicker_item:get_float( ) == 14 then --black
        default_color = csgo.color(0, 0, 0, opacity)  
    end
       
    --sorry for dirty coding right here :P  
    if silent:get_bool( ) then  
        value1 = value1 + 0.13
        if value1 > static_value1+1 then
            value1 = 1          
        end
        value2 = value2 + 0.13
        if value2 > static_value2+1 then
            value2 = 1
        end
        value3 = value3 + 0.13
        if value3 > static_value3+1 then
            value3 = 1
        end
       
        if fakelag_stand:get_int( )*1 > 5 then
            static_value1 = 5
        elseif fakelag_stand:get_int( )*1 < 5 then
            static_value1 = fakelag_stand:get_int( )*1
        end
       
        if fakelag_move:get_int( )*1 > 5 then
            static_value2 = 5
        elseif fakelag_move:get_int( )*1 < 5 then
            static_value2 = fakelag_move:get_int( )*1
        end
       
        if fakelag_jump:get_int( )*1 > 5 then
            static_value3 = 5
        elseif fakelag_jump:get_int( )*1 < 5 then
            static_value3 = fakelag_jump:get_int( )*1
        end
    else
        value1 = value1 + 0.13
        if value1 > fakelag_stand:get_int( )*1+1then
            value1 = 1
        end
        value2 = value2 + 0.13
        if value2 > fakelag_move:get_int( )*1+1 then
            value2 = 1
        end
        value3 = value3 + 0.13
        if value3 > fakelag_jump:get_int( )*1+1 then
            value3 = 1
        end
        static_value1 = fakelag_stand:get_int( )*1
        static_value2 = fakelag_move:get_int( )*1
        static_value3 = fakelag_jump:get_int( )*1
    end
   
    bar_value1 = value1*9
    bar_value2 = value2*9
    bar_value3 = value3*9
        local get_screen_size = render:screen_size( )
    if choke_item:get_bool( ) then
local indg = bar_value2 / 100
   
   
       
            render:indicator( 10, choke_pos_y_item:get_float( ) - 28  ,"FAKELAG", true, indg)
        --render:rect_fade( 6* 1 + 4.5, choke_pos_y_item:get_float( ) * 1 + 3, 130, 4, csgo.color( 0, 0, 0, 180 ), csgo.color( 0, 0, 0, 180 ), true )


        if velocity2d <= 0 then
       
           
        elseif velocity2d > 1 and not input:is_key_down( get_is_space ) then
elseif input:is_key_down( get_is_space ) then
                    end  
    end  
       
end --end

--callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )