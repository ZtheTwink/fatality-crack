--inputs
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local input = fatality.input

--menu checkbox
local wssavbf_item = config:add_item( "weapon_sway_view_bobbing_fix", 0.0 )
local wssavbf_checkbox = menu:add_checkbox( "Fix view bobbing and weapon sway", "VISUALS", "MISC", "Local", wssavbf_item )

--on paint
function on_paint()
    --if you arent in game, return
    if not engine_client:is_in_game( ) then
       return end
      
    local local_player = entity_list:get_localplayer( )

    --if you arent alive, return
    if not local_player:is_alive( ) then
        return end
      
    local wpnswayscale = cvar:find_var( "cl_wpn_sway_scale" )
    local usenewheadbob = cvar:find_var( "cl_use_new_headbob" )
    local minspec = cvar:find_var( "sv_competitive_minspec" )
    local bobcycle = cvar:find_var( "cl_bobcycle" )
    local bobup = cvar:find_var( "cl_bobup" )
    if wssavbf_item:get_bool( ) then
        wpnswayscale:unlock( )
        usenewheadbob:unlock( )
        minspec:unlock( )
        bobcycle:unlock( )
        bobup:unlock( )
        wpnswayscale:set_int( 0 )
        usenewheadbob:set_int( 0 )
        minspec:set_int( 0 )
        bobcycle:set_int( 0 )
        bobup:set_int( 0 )
        engine_client:client_cmd( "cl_bobup 0" ) --cuz bobup:set_int( 0 ) isnt working :/
    end
end --end

--callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )