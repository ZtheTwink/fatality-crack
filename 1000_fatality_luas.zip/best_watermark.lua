-- https://fatality.win/threads/lua-watermark-with-additional-user-interface-support-custom-menu.893/

-- watermark & infobar by eslipe v.1.4 (current version 11.03.2019)
 
--[[ Updatelog:
 
(11.03.2019)
- Added adanced version of the watermark
- Added "Gradient" option for coloured-bar
- Added dynamical gradient for "Gradient" option
 
 
(06.03.2019)
- Added menu support
- Added new type of colour picker ( final version )
- Added chroma mode ( synced with onetap spectator list )
 
]]
 
-- interfaces
local render = fatality.render
local global = csgo.interface_handler:get_global_vars( );
local engine = csgo.interface_handler:get_engine_client( );
local global_vars = csgo.interface_handler:get_global_vars( )
local engine_client = csgo.interface_handler:get_engine_client( )
 
-- fonts
local small_pixel_11 = render:create_font( "Smallest Pixel-7", 11, 100, false );
local verdanaBold_12 = render:create_font( "Comic Sans", 24, 700, false );
 
-- menu & config access
local menu = fatality.menu
local config = fatality.config
 
-- adding functions to the menu
local watermark_item = config:add_item( "wt_watermark_item", 0 )
local watermark_checkbox = menu:add_checkbox( "Watermark", "visuals", "misc", "various", watermark_item )
 
local watermarkType_item = config:add_item("wt_watermarkType", 0)
local watermarkType_combo = menu:add_combo( "Watermark type", "visuals", "misc", "various", watermarkType_item):add_item( "simple", watermarkType_item):add_item( "advanced", watermarkType_item)
 
local colour_item = config:add_item("wt_colour_item", 0)
local colour_slider = menu:add_slider("Watermark colour", "visuals", "misc", "various", colour_item, 0 , 20, 1)
 
local watermarkColourSwitch_item = config:add_item("wt_watermarkColourSwitch_item", 0)
local watermarkColourSwitch_combo = menu:add_combo( "Colour for bar", "visuals", "misc", "various", watermarkColourSwitch_item):add_item( "static", watermarkColourSwitch_item):add_item( "chroma", watermarkColourSwitch_item)
 
local rainbowBar_item = config:add_item("wt_rainbowBar_item", 0)
local rainbowBar_combo = menu:add_combo( "Gradient for bar", "visuals", "misc", "various", rainbowBar_item):add_item( "disabled", rainbowBar_item):add_item( "static", rainbowBar_item):add_item( "dynamic", rainbowBar_item)
 
 
-- getting tick-rate
local function get_tickrate( )
  if not engine:is_connected( ) then
  return 0 end
  return math.floor( 1.0 / global_vars.interval_per_tick )
end
 
 
 
-- counting fps value
local frame_rate = 0.0
function get_abs_fps( )
  frame_rate = 0.9 * frame_rate + ( 1.0 - 0.9 ) * global.frametime;
  return math.floor( ( 1.0 / frame_rate ) + 0.5 );
end
 
 
 
-- background colour static
local col_background = csgo.color( 25, 25, 25, 245 )
 
-- white colour static
local white_col = csgo.color(255, 255, 255, 255)
 
function draw_sized_outline( x, y, w, h, title )
 
    local c = {10, 60, 40, 40, 40, 60, 20};
 
    for i = 0,6,1 do
        render:rect( x+i, y+i, w-(i*2), h-(i*2), csgo.color( c[i+1], c[i+1], c[i+1], 200 ) );
    end
 
    -- transparency background
    render:rect_filled( x + 6, y + 6, w - 12, h - 12, csgo.color( 25, 25, 25, 245 ) );
 
    -- creating rainbow variables
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
 
 
 
        -- default colour
        local bar_col = csgo.color(138, 170, 234, 255)
 
        -- changing value from float to int
        local colour_value = colour_item:get_float() * 1
 
        -- colour changer (final version)
        if colour_value == 0 then
            bar_col = csgo.color(255, 255, 255, 255) --< white
            elseif colour_value == 1 then
            bar_col = csgo.color(0, 0, 0, 255) --< black
            elseif colour_value == 2 then
            bar_col = csgo.color(255, 0, 0, 255) --< deep-red
            elseif colour_value == 3 then
            bar_col = csgo.color(244,67,54, 255) --< red
            elseif colour_value == 4 then
            bar_col = csgo.color(255,87,34, 255) --< light-red
            elseif colour_value == 5 then
            bar_col = csgo.color(255,152,0, 255) --< deep-orange
            elseif colour_value == 6 then
            bar_col = csgo.color(255,193,7, 255) --< orange
            elseif colour_value == 7 then
            bar_col = csgo.color(255,235,59, 255) --< yellow
            elseif colour_value == 8 then
            bar_col = csgo.color(205,220,57, 255) --< lime
            elseif colour_value == 9 then
            bar_col = csgo.color(139,195,74, 255) --< light-green
            elseif colour_value == 10 then
            bar_col = csgo.color(76,175,80, 255) --< green
            elseif colour_value == 11 then
            bar_col = csgo.color(0,150,136, 255) --< teal
            elseif colour_value == 12 then
            bar_col = csgo.color(0,188,212, 255) --< cyan
            elseif colour_value == 13 then
            bar_col = csgo.color(3,169,244, 255) --< ligh-blue
            elseif colour_value == 14 then
            bar_col = csgo.color(33,150,243, 255) --< blue
            elseif colour_value == 15 then
            bar_col = csgo.color(63,81,181, 255) --< indigo
            elseif colour_value == 16 then
            bar_col = csgo.color(103,58,183, 255) --< deep-purple
            elseif colour_value == 17 then
            bar_col = csgo.color(156,39,176, 255) --< purple
            elseif colour_value == 18 then
            bar_col = csgo.color(126,87,194, 255) --< -light-purple
            elseif colour_value == 19 then
            bar_col = csgo.color(233,30,99, 255) --< deep-pink
            elseif colour_value == 20 then
            bar_col = csgo.color(236,64,122, 255) --< light-pink
            else
            bar_col = csgo.color(255, 255, 255, 255) --< default
        end
 
        -- coloured line on top
        if rainbowBar_item:get_int() == 0 then
 
            if watermarkColourSwitch_item:get_int() == 0 then
            render:rect_filled( x + 10, y + 10, w - 20, 5, bar_col );
            elseif watermarkColourSwitch_item:get_int() == 1 then
            render:rect_filled( x + 10, y + 10, w - 20, 5, csgo.color( r, g, b, 255 ) );
            end
 
        elseif rainbowBar_item:get_int() == 1 then
 
            render:rect_fade(x + 10, y + 10, w- 20, 5, csgo.color(50, 52, 255, 255), csgo.color(255, 0, 72, 255), true)
 
        elseif rainbowBar_item:get_int() == 2 then
 
            render:rect_fade(x + 10, y + 10, w- 20, 5, csgo.color(r, g, b, 255), csgo.color(b, g, r, 255), true)
 
        end
 
 
        render:rect( x + 10, y + 10, w - 20, 5, csgo.color( 0, 0, 0, 250 ) );  
 
   
    -- outline of coloured line on top
    render:rect_filled( x + 10, y + 15, w - 20, h - 25, csgo.color( 20, 20,20,245 ) );
    render:rect( x + 10, y + 15, w - 20, h - 25 , csgo.color( 40,40,40,245 ) );
 
end
 
function draw_outline( x, y, w, h, title )
 
    local c = {10, 60, 40, 40, 40, 60, 20};
 
    for i = 0,6,1 do
        render:rect( x+i, y+i, w-(i*2), h-(i*2), csgo.color( c[i+1], c[i+1], c[i+1], 200 ) );
    end
 
    -- transparency background
    render:rect_filled( x + 6, y + 6, w - 12, h - 12, csgo.color( 25, 25, 25, 245 ) );
 
    -- creating rainbow variables
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
 
 
        -- default colour
        local bar_col = csgo.color(138, 170, 234, 255)
 
        -- changing value from float to int
        local colour_value = colour_item:get_float() * 1
 
        -- colour changer (final version)
        if colour_value == 0 then
            bar_col = csgo.color(255, 255, 255, 255) --< white
            elseif colour_value == 1 then
            bar_col = csgo.color(0, 0, 0, 255) --< black
            elseif colour_value == 2 then
            bar_col = csgo.color(255, 0, 0, 255) --< deep-red
            elseif colour_value == 3 then
            bar_col = csgo.color(244,67,54, 255) --< red
            elseif colour_value == 4 then
            bar_col = csgo.color(255,87,34, 255) --< light-red
            elseif colour_value == 5 then
            bar_col = csgo.color(255,152,0, 255) --< deep-orange
            elseif colour_value == 6 then
            bar_col = csgo.color(255,193,7, 255) --< orange
            elseif colour_value == 7 then
            bar_col = csgo.color(255,235,59, 255) --< yellow
            elseif colour_value == 8 then
            bar_col = csgo.color(205,220,57, 255) --< lime
            elseif colour_value == 9 then
            bar_col = csgo.color(139,195,74, 255) --< light-green
            elseif colour_value == 10 then
            bar_col = csgo.color(76,175,80, 255) --< green
            elseif colour_value == 11 then
            bar_col = csgo.color(0,150,136, 255) --< teal
            elseif colour_value == 12 then
            bar_col = csgo.color(0,188,212, 255) --< cyan
            elseif colour_value == 13 then
            bar_col = csgo.color(3,169,244, 255) --< ligh-blue
            elseif colour_value == 14 then
            bar_col = csgo.color(33,150,243, 255) --< blue
            elseif colour_value == 15 then
            bar_col = csgo.color(63,81,181, 255) --< indigo
            elseif colour_value == 16 then
            bar_col = csgo.color(103,58,183, 255) --< deep-purple
            elseif colour_value == 17 then
            bar_col = csgo.color(156,39,176, 255) --< purple
            elseif colour_value == 18 then
            bar_col = csgo.color(126,87,194, 255) --< -light-purple
            elseif colour_value == 19 then
            bar_col = csgo.color(233,30,99, 255) --< deep-pink
            elseif colour_value == 20 then
            bar_col = csgo.color(236,64,122, 255) --< light-pink
            else
            bar_col = csgo.color(255, 255, 255, 255) --< default
        end
 
        -- coloured line on top
        if rainbowBar_item:get_int() == 0 then
 
            if watermarkColourSwitch_item:get_int() == 0 then
            render:rect_filled( x + 10, y + 10, 229, 5, bar_col );
            elseif watermarkColourSwitch_item:get_int() == 1 then
            render:rect_filled( x + 10, y + 10, 229, 5, csgo.color( r, g, b, 255 ) );
            end
 
        elseif rainbowBar_item:get_int() == 1 then
 
            render:rect_fade(x + 10, y + 10, 229, 5, csgo.color(50, 52, 255, 255), csgo.color(255, 0, 72, 255), true)
           
        elseif rainbowBar_item:get_int() == 2 then
 
            render:rect_fade(x + 10, y + 10, 229, 5, csgo.color(r, g, b, 255), csgo.color(b, g, r, 255), true)
 
        end
 
        render:rect( x + 10, y + 10, 229, 5, csgo.color( 0, 0, 0, 250 ) );
 
    -- outline of coloured line on top
    render:rect_filled( x + 10, y + 15, 229, h - 25, csgo.color( 20, 20,20,245 ) );
    render:rect( x + 10, y + 15, 229, h - 25 , csgo.color( 40,40,40,245 ) );
 
end
 
 
 
function on_paint( )
 
    -- in-game check
    if not engine_client:is_in_game( ) then
    return end
 
    -- getting screen size
    local screen_size = render:screen_size( );
 
    -- colours
    local bar_col = csgo.color(255, 255, 255, 255)
    local colour_value = colour_item:get_float() * 1
 
    -- creating rainbow variables
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
   
    -- colour changer (final version)
    if colour_value == 0 then
        bar_col = csgo.color(255, 255, 255, 255) --< white
        elseif colour_value == 1 then
        bar_col = csgo.color(0, 0, 0, 255) --< black
        elseif colour_value == 2 then
        bar_col = csgo.color(255, 0, 0, 255) --< deep-red
        elseif colour_value == 3 then
        bar_col = csgo.color(244,67,54, 255) --< red
        elseif colour_value == 4 then
        bar_col = csgo.color(255,87,34, 255) --< light-red
        elseif colour_value == 5 then
        bar_col = csgo.color(255,152,0, 255) --< deep-orange
        elseif colour_value == 6 then
        bar_col = csgo.color(255,193,7, 255) --< orange
        elseif colour_value == 7 then
        bar_col = csgo.color(255,235,59, 255) --< yellow
        elseif colour_value == 8 then
        bar_col = csgo.color(205,220,57, 255) --< lime
        elseif colour_value == 9 then
        bar_col = csgo.color(139,195,74, 255) --< light-green
        elseif colour_value == 10 then
        bar_col = csgo.color(76,175,80, 255) --< green
        elseif colour_value == 11 then
        bar_col = csgo.color(0,150,136, 255) --< teal
        elseif colour_value == 12 then
        bar_col = csgo.color(0,188,212, 255) --< cyan
        elseif colour_value == 13 then
        bar_col = csgo.color(3,169,244, 255) --< ligh-blue
        elseif colour_value == 14 then
        bar_col = csgo.color(33,150,243, 255) --< blue
        elseif colour_value == 15 then
        bar_col = csgo.color(63,81,181, 255) --< indigo
        elseif colour_value == 16 then
        bar_col = csgo.color(103,58,183, 255) --< deep-purple
        elseif colour_value == 17 then
        bar_col = csgo.color(156,39,176, 255) --< purple
        elseif colour_value == 18 then
        bar_col = csgo.color(126,87,194, 255) --< -light-purple
        elseif colour_value == 19 then
        bar_col = csgo.color(233,30,99, 255) --< deep-pink
        elseif colour_value == 20 then
        bar_col = csgo.color(236,64,122, 255) --< light-pink
        else
        bar_col = csgo.color(255, 255, 255, 255) --< default
    end
   
    -- checkbox check & type check [ simple ]
    if ( watermark_item:get_bool() and watermarkType_item:get_int() == 0 ) then
 
        -- background
        draw_outline( screen_size.x + 30 - 288, 5, 250, 50)
        --
 
            -- watermark
            render:text( small_pixel_11, screen_size.x + 30 - 275 + 5, 27, "fatality.win", white_col);
 
            -- fps
            render:text( small_pixel_11, screen_size.x + 30 - 275 + 75, 27, "FPS: ", white_col);
            if watermarkColourSwitch_item:get_int() == 0 then    
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 95, 27, tostring( get_abs_fps( ) ), bar_col);
            elseif watermarkColourSwitch_item:get_int() == 1 then
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 95, 27, tostring( get_abs_fps( ) ), csgo.color( r, g, b, 255 ));
            end
           
 
            -- ping
            render:text( small_pixel_11, screen_size.x + 30 - 275 + 120, 27, "PING: ", white_col);
            if watermarkColourSwitch_item:get_int() == 0 then    
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 145, 27, tostring( engine:get_ping( ) + 0 ).."ms", bar_col);
            elseif watermarkColourSwitch_item:get_int() == 1 then
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 145, 27, tostring( engine:get_ping( ) + 0 ).."ms", csgo.color( r, g, b, 255 ));
            end
 
            -- tickrate
            render:text( small_pixel_11, screen_size.x + 30 - 275 + 175, 27, "RATE: ", white_col);
            if watermarkColourSwitch_item:get_int() == 0 then    
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 200, 27, tostring (get_tickrate()), bar_col);
            elseif watermarkColourSwitch_item:get_int() == 1 then
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 200, 27, tostring (get_tickrate()), csgo.color( r, g, b, 255 ));
            end
 
    -- checkbox check & type check [ adanced ]        
    elseif ( watermark_item:get_bool() and watermarkType_item:get_int() == 1 ) then
 
        -- background
        draw_sized_outline( screen_size.x - 370, 5, 110, 50)
        draw_sized_outline( screen_size.x - 255, 5, 180, 50)
        draw_sized_outline( screen_size.x - 70, 5, 50, 50)
        --
 
            -- time
            render:text( small_pixel_11, screen_size.x + 30 - 425 + 50, 27, "TIME: ", white_col);
 
            if watermarkColourSwitch_item:get_int() == 0 then    
                render:text( small_pixel_11, screen_size.x + 30 - 425 + 75, 27, os.date("%H:%M:%S"), bar_col);
            elseif watermarkColourSwitch_item:get_int() == 1 then
                render:text( small_pixel_11, screen_size.x + 30 - 425 + 75, 27, os.date("%H:%M:%S"), csgo.color( r, g, b, 255 ));
            end
 
            -- fps
            render:text( small_pixel_11, screen_size.x + 30 - 275 + 75 - 63, 27, "FPS: ", white_col);
            if watermarkColourSwitch_item:get_int() == 0 then    
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 95 - 63, 27, tostring( get_abs_fps( ) ), bar_col);
            elseif watermarkColourSwitch_item:get_int() == 1 then
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 95 - 63, 27, tostring( get_abs_fps( ) ), csgo.color( r, g, b, 255 ));
            end
           
 
            -- ping
            render:text( small_pixel_11, screen_size.x + 30 - 275 + 120 - 63, 27, "PING: ", white_col);
            if watermarkColourSwitch_item:get_int() == 0 then    
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 145 - 63, 27, tostring( engine:get_ping( ) + 0 ).."ms", bar_col);
            elseif watermarkColourSwitch_item:get_int() == 1 then
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 145 - 63, 27, tostring( engine:get_ping( ) + 0 ).."ms", csgo.color( r, g, b, 255 ));
            end
 
            -- tickrate
            render:text( small_pixel_11, screen_size.x + 30 - 275 + 175 - 63, 27, "RATE: ", white_col);
            if watermarkColourSwitch_item:get_int() == 0 then    
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 200 - 63, 27, tostring (get_tickrate()), bar_col);
            elseif watermarkColourSwitch_item:get_int() == 1 then
                render:text( small_pixel_11, screen_size.x + 30 - 275 + 200 - 63, 27, tostring (get_tickrate()), csgo.color( r, g, b, 255 ));
            end
 
 
            if watermarkColourSwitch_item:get_int() == 0 then  
                render:text( verdanaBold_12, screen_size.x - 51, 21, "F", bar_col);
            elseif watermarkColourSwitch_item:get_int() == 1 then
                render:text( verdanaBold_12, screen_size.x - 51, 21, "F", csgo.color( r, g, b, 255 ));
            end
 
    end
 
end
 
 
-- callbacks    
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )
 
-- end of the code