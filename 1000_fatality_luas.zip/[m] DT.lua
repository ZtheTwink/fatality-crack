local entity_list = csgo.interface_handler:get_entity_list()
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local cvar = csgo.interface_handler:get_cvar( )
local global_vars = csgo.interface_handler:get_global_vars()
local screen_size = render:screen_size()

local dtdmg_item = config:add_item( "dtdmg_item", 1.0 )
local dtdmg_checkbox = menu:add_checkbox( "DT Damage", "rage", "aimbot", "aimbot", dtdmg_item )

local dtweapons_item = config:add_item( "dtweapons_item", 0.0 )
local auto_item = config:add_item( "autowep_item", 0.0 )
local pistol_item = config:add_item( "pistolwep_item", 0.0 )
local heavypistol_item = config:add_item( "heavypistolwep_item", 0.0 )
local other_item = config:add_item( "otherwep_item", 0.0 )
local dtweapons_combo = menu:add_multi_combo("weapons", "rage", "aimbot", "aimbot", dtweapons):add_item( "auto", auto_item):add_item( "pistols", pistol_item):add_item( "heavy pistols", heavypistol_item):add_item( "other", other_item)

local dmgamt_item = config:add_item( "dmgamt_item", 0.0 )
local dmgamt_slider = menu:add_slider("Damage override", "rage", "aimbot", "aimbot", dmgamt_item, 0, 100, 1)

local weapon_auto = menu:get_reference("rage", "weapons", "auto", "min-damage"):get_int()
local weapon_pistol = menu:get_reference("rage", "weapons", "pistols", "min-damage"):get_int()
local weapon_heavypistol = menu:get_reference("rage", "weapons", "heavy pistols", "min-damage"):get_int()
local weapon_other= menu:get_reference("rage", "weapons", "other", "min-damage"):get_int()

local doubletap_check = menu:get_reference("rage", "aimbot", "aimbot", "double tap")
local forcefallback_check = menu:get_reference("rage", "aimbot", "aimbot", "force fallback")

function on_paint( )
    if dtdmg_item:get_bool() and doubletap_check:get_bool() then
        if auto_item:get_bool() then
            menu:get_reference("rage", "weapons", "auto", "min-damage"):set_int(dmgamt_item:get_int())
        end

        if pistol_item:get_bool() then
            menu:get_reference("rage", "weapons", "pistols", "min-damage"):set_int(dmgamt_item:get_int())
        end

        if heavypistol_item:get_bool() then
            menu:get_reference("rage", "weapons", "heavy pistols", "min-damage"):set_int(dmgamt_item:get_int())
        end

        if other_item:get_bool() then
            menu:get_reference("rage", "weapons", "other", "min-damage"):set_int(dmgamt_item:get_int())
        end

        forcefallback_check:set_bool(true)
    else
      
        if auto_item:get_bool(false) then
            menu:get_reference("rage", "weapons", "auto", "min-damage"):set_int(weapon_auto)
        end

        if pistol_item:get_bool(false) then
            menu:get_reference("rage", "weapons", "pistols", "min-damage"):set_int(weapon_pistol)
        end

        if heavypistol_item:get_bool(false) then
            menu:get_reference("rage", "weapons", "heavy pistols", "min-damage"):set_int(weapon_heavypistol)
        end

        if other_item:get_bool(false) then
            menu:get_reference("rage", "weapons", "other", "min-damage"):set_int(weapon_other)
        end

        forcefallback_check:set_bool(false)
    end
end

local callbacks = fatality.callbacks;

callbacks:add( "paint", on_paint )