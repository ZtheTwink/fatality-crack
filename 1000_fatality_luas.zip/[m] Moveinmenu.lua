local input = fatality.input
local engine_client = csgo.interface_handler:get_engine_client()

local typing = false

function on_paint()
    if(input:is_key_pressed(0x59)) then -- Y
        typing = true
    elseif(input:is_key_pressed(0x0D) or input:is_key_pressed(0x1B)) then -- Enter
        typing = false
    end
    
    if(not typing) then   
        if(input:is_key_down(0x57)) then
            engine_client:client_cmd_unrestricted("+forward")
        else
            engine_client:client_cmd_unrestricted("-forward")
        end
        
        if(input:is_key_down(0x53)) then
            engine_client:client_cmd_unrestricted("+back")
        else
            engine_client:client_cmd_unrestricted("-back")
        end
        
        if(input:is_key_down(0x41)) then
            engine_client:client_cmd_unrestricted("+moveleft")
        else
            engine_client:client_cmd_unrestricted("-moveleft")
        end
        
        if(input:is_key_down(0x44)) then
            engine_client:client_cmd_unrestricted("+moveright")
        else
            engine_client:client_cmd_unrestricted("-moveright")
        end
        
        if(input:is_key_down(0x20)) then
            engine_client:client_cmd_unrestricted("+jump")
        else
            engine_client:client_cmd_unrestricted("-jump")
        end
        
        if(input:is_key_down(0xA2)) then
            engine_client:client_cmd_unrestricted("+duck")
        else
            engine_client:client_cmd_unrestricted("-duck")
        end
    end
end

local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)