require "clantag_api"

local timing_switch = 35
local cur_mode = 0
local timing = timing_switch

local clantag_timing = {
    [1] = function() return "f" end,
    [2] = function() return "fa"  end,
    [3] = function() return "fat" end,
    [4] = function() return "fata" end,
    [5] = function() return "fatal" end,
    [6] = function() return "fatality" end,
    [7] = function() return "fatality" end,
    [8] = function() return "fatality" end,
    [9] = function() return "fatality" end,
    [10] = function() return "fatalit" end,
    [11] = function() return "fatali" end,
    [12] = function() return "fatal" end,
    [13] = function() return "fata" end,
    [14] = function() return "fat" end,
    [15] = function() return "fa" end,
    [16] = function() return "f" end,
    [17] = function() return " " end,
}

local function on_paint()
timing = timing + 1

    if timing >= timing_switch then
        cur_mode = cur_mode + 1

        if cur_mode > #clantag_timing then
            cur_mode = 1
        end
      
        SET_CLANTAG_MADE_BY_DUCARII(clantag_timing[cur_mode]())
        timing = 0
    end

end


local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )