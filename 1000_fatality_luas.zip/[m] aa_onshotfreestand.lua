local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()
local menu = fatality.menu
local config = fatality.config
local global_vars = csgo.interface_handler:get_global_vars()

local change_aa_item = config:add_item("aa_onshot", 0)
local change_aa_slider = menu:add_checkbox( "Freestand on shot", "rage", "anti-aim", "general", change_aa_item );
local change_aa_duration_item = config:add_item("aa_onshot_duration", 0.0)
local change_aa_duration_slider = menu:add_slider( "Duration", "rage", "anti-aim", "general", change_aa_duration_item, 0, 100, 0.1 )

local fs_ref = menu:get_reference("RAGE", "anti-aim", "standing", "Freestand")
local fs_moving_ref = menu:get_reference("RAGE", "anti-aim", "moving", "Freestand")
local fs_air_ref = menu:get_reference("RAGE", "anti-aim", "air", "Freestand")

local time_shot = 0

fatality.callbacks:add("registered_shot", function(e)
	if change_aa_item:get_bool() then
		fs_ref:set_bool(true)
		fs_moving_ref:set_bool(true)
		fs_air_ref:set_bool(true)
		
		
		
		if(time_shot == 0) then
			time_shot = global_vars.tickcount + (0.5 + change_aa_duration_item:get_float()/ global_vars.interval_per_tick)
		end
		--shots_fired = true
		--fake_ref:set_int(1)
		--fake_moving_ref:set_int(1)
		--fake_air_ref:set_int(1)
		--fakelag_ref:set_int(14)
		--fakelag_moving_ref:set_int(14)
	end
end)

fatality.callbacks:add("events", function(e)
    if(e:get_name() == "round_start") then
		time_shot = 0
   end
 end)

function on_paint()
	if change_aa_item:get_bool() then
		--if fake_ref:get_int() >= 1 then
			local_player = entity_list:get_localplayer()
			if(local_player ~= nil and local_player:is_alive()) then
				--local shots_fired = local_player:get_var_int("CCSPlayer->m_iShotsFired")
				if global_vars.tickcount >= time_shot then -- shots_fired < 1 or  and global_vars.tickcount >= time_shot
					fs_ref:set_bool(false)
					fs_moving_ref:set_bool(false)
					fs_air_ref:set_bool(false)
					
					time_shot = 0
				end
			end
		--end
	end
end

-- callback
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )