local entity_list = csgo.interface_handler:get_entity_list()
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local cvar = csgo.interface_handler:get_cvar( )
local global_vars = csgo.interface_handler:get_global_vars()
local screen_size = render:screen_size()

local dtdmg_item = config:add_item( "dtdmg_item", 1.0 )
local dtdmg_checkbox = menu:add_checkbox( "DT Damage", "rage", "aimbot", "aimbot", dtdmg_item )

local dmgamt_item = config:add_item( "dmgamt_item", 0.0 )
local dmgamt_slider = menu:add_slider("Damage", "rage", "aimbot", "aimbot", dmgamt_item, 0, 100, 0.1)
local weapon_auto = menu:get_reference("rage", "weapons", "auto", "min-damage"):get_int()
local doubletap_check = menu:get_reference("rage", "aimbot", "aimbot", "double tap")

function on_paint( )
    if dtdmg_item:get_bool() and doubletap_check:get_bool() then
        menu:get_reference("rage", "weapons", "auto", "min-damage"):set_int(dmgamt_item:get_int())
    else
        menu:get_reference("rage", "weapons", "auto", "min-damage"):set_int(weapon_auto)
    end
end

local callbacks = fatality.callbacks;

callbacks:add( "paint", on_paint )
