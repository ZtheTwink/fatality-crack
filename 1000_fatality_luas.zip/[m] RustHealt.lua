--main instances
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks
local fatalMath = fatality.math
local input = fatality.input
local events = csgo.interface_handler:get_events()
local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()
local screen_size = render:screen_size()
--main instances
local font = render:create_font( 'IMPACT', 25, 100, false )
local icons = render:create_font( 'custom_csgo_icons', 30, 0, false )
local lighning = render:create_font( 'Lightning Bolt', 30, 0, false )
local grey, lightGrey, green, blue, white, yellow = csgo.color(80,80,80,255), csgo.color(150,150,150,255), csgo.color(137, 181, 58,255), csgo.color(68, 149, 206,255), csgo.color(255,255,255,2555), csgo.color(209, 206, 94,255)

local toggleItem = config:add_item( 'toggle', 0 )
local toggleCheck = menu:add_checkbox( 'Rust HealthBar', 'visuals', 'misc', 'various', toggleItem )

engine_client:client_cmd('cl_hud_healthammo_style 1')
engine_client:client_cmd('hud_scaling .8')
function on_paint()
    if not engine_client:is_in_game() then
        return end
    local localPlayer = entity_list:get_localplayer()

    local health = localPlayer:get_var_int('CBasePlayer->m_iHealth')
    local armour = localPlayer:get_var_int('CCSPlayer->m_ArmorValue')

    local velNetVar = localPlayer:get_var_vector( "CBasePlayer->m_vecVelocity[0]" ) --get velocity netvar
    local velocity = math.ceil(math.sqrt(math.abs(velNetVar.x)*math.abs(velNetVar.x)+math.abs(velNetVar.y)*math.abs(velNetVar.y))) --calculate velocity
    if velocity <=2 then 
        velocity = 0 --jittery velocity from 2-0 fix
    end
    if toggleItem:get_bool() then
    render:rect_filled( screen_size.x/384, screen_size.y/1.12617, screen_size.x/8.3478, screen_size.y/30.8571, grey )
    render:rect_filled( screen_size.x/384, screen_size.y/1.08108, screen_size.x/8.3478, screen_size.y/30.8571, grey )
    render:rect_filled( screen_size.x/384, screen_size.y/1.03946, screen_size.x/8.3478, screen_size.y/30.8571, grey )
    render:rect_filled( screen_size.x/192, screen_size.y/1.06719, screen_size.x/91.428, screen_size.y/216, lightGrey )
    render:rect_filled( screen_size.x/106.66, screen_size.y/1.07569,  screen_size.y/216, screen_size.x/91.428, lightGrey )
    ---health
    render:rect_filled( screen_size.x/54.85, screen_size.y/1.07784, health*2-screen_size.x/480, screen_size.y/38.57142, green )
    render:text( font, screen_size.x/48, screen_size.y/1.07784, health, white )
    ---armour
    render:text( icons, screen_size.x/213.33, screen_size.y/1.03846, 'q', lightGrey )
    render:rect_filled( screen_size.x/54.85, screen_size.y/1.03646, armour*2-screen_size.x/480, screen_size.y/38.57142, blue )
    render:text( font, screen_size.x/48, screen_size.y/1.03646, armour, white )
    --speed
    render:text( lighning, screen_size.x/147.69, screen_size.y/1.12266, '1', lightGrey )
    render:rect_filled( screen_size.x/54.85, screen_size.y/1.12266, velocity/(screen_size.x/1066.66), screen_size.y/38.57142, yellow )
    render:text( font, screen_size.x/48, screen_size.y/1.12266, velocity, white )
    end
end
callbacks:add('paint', on_paint)