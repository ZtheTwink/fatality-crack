-- https://fatality.win/threads/aspect-ratio-modifier-best-script-in-this-hack-improves-resolver-performance.529/

local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar()
local r_aspectratio = cvar:find_var("r_aspectratio")

local math_ceil, math_tan, math_log10, math_randomseed, math_cos, math_sinh, math_random, math_huge, math_pi, math_max, math_atan2, math_ldexp, math_floor, math_sqrt, math_deg, math_atan, math_fmod = math.ceil, math.tan, math.log10, math.randomseed, math.cos, math.sinh, math.random, math.huge, math.pi, math.max, math.atan2, math.ldexp, math.floor, math.sqrt, math.deg, math.atan, math.fmod 
local math_acos, math_pow, math_abs, math_min, math_sin, math_frexp, math_log, math_tanh, math_exp, math_modf, math_cosh, math_asin, math_rad = math.acos, math.pow, math.abs, math.min, math.sin, math.frexp, math.log, math.tanh, math.exp, math.modf, math.cosh, math.asin, math.rad 

local function set_aspect_ratio(multiplier)
	local screen_width = render:screen_size().x
	local screen_height = render:screen_size().y

	local value = (screen_width * multiplier) / screen_height

	if multiplier == 1 then
		value = 0
	end
	
	r_aspectratio:set_float(value)
end

local function gcd(m, n)
	while m ~= 0 do
		m, n = math_fmod(n, m), m;
	end

	return n
end

-- Menu entries.
local aspect_ratio_item = config:add_item( "aspect_ratio", 0.0 )
local aspect_ratio_slider = menu:add_slider( "Aspect ratio", "visuals", "misc", "various", aspect_ratio_item, 1, 200, 100 )

-- Doing it every frame because there is currently no item value update callback, and I'm lazy. I'll fix this later.
function on_paint( )
	local aspect_ratio = aspect_ratio_item:get_float() * 0.01
	aspect_ratio = 2 - aspect_ratio

	set_aspect_ratio(aspect_ratio)
end

-- Register all callback functions that should be called
local callbacks = fatality.callbacks
callbacks:add( "paint", "on_paint" )