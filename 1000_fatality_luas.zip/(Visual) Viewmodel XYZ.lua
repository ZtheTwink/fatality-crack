--inputs
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local input = fatality.input

--menu checkbox/sliders
local customviewmodel_item = config:add_item( "customviewmodel_changer", 0.0 )
local customviewmodel_slider_x_item = config:add_item( "customviewmodel_x_changer", 0.0 )
local customviewmodel_slider_y_item = config:add_item( "customviewmodel_y_changer", 0.0 )
local customviewmodel_slider_z_item = config:add_item( "customviewmodel_z_changer", 0.0 )
local customviewmodel_checkbox = menu:add_checkbox( "Custom viewmodel changer", "VISUALS", "MISC", "Local", customviewmodel_item )
local customviewmodel_slider_x = menu:add_slider( "Viewmodel X", "VISUALS", "MISC", "Local", customviewmodel_slider_x_item, -15 , 15, 3 )
local customviewmodel_slider_y = menu:add_slider( "Viewmodel Y", "VISUALS", "MISC", "Local", customviewmodel_slider_y_item, -15 , 15, 3 )
local customviewmodel_slider_z = menu:add_slider( "Viewmodel Z", "VISUALS", "MISC", "Local", customviewmodel_slider_z_item, -15 , 15, -3 )


--on paint
function on_paint()
    --if you arent in game, return
    if not engine_client:is_in_game( ) then
       return end
      
    local local_player = entity_list:get_localplayer( )

    --if you arent alive, return
    if not local_player:is_alive( ) then
        return end
      
    if customviewmodel_item:get_bool( ) then 
        local minspec = cvar:find_var( "sv_competitive_minspec" )
        minspec:unlock( )
        minspec:set_int( 0 )
      
        local x = cvar:find_var("viewmodel_offset_x")
        local y = cvar:find_var("viewmodel_offset_y")
        local z = cvar:find_var("viewmodel_offset_z")
      
        x:unlock( )
        y:unlock( )
        z:unlock( )
      
        local value = 0
        if customviewmodel_slider_x_item:get_int( ) > 0 then
            value = -customviewmodel_slider_x_item:get_int( )
        else
            value = -customviewmodel_slider_x_item:get_int( )
        end 
      
        engine_client:client_cmd( "viewmodel_offset_x "..value * -1 )
        engine_client:client_cmd( "viewmodel_offset_y "..customviewmodel_slider_y_item:get_int( ) * 1 )
        engine_client:client_cmd( "viewmodel_offset_z "..customviewmodel_slider_z_item:get_int( ) * 1 )
    end
end --end

--callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )