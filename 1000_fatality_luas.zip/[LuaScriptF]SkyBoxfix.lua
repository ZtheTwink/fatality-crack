local game_events = csgo.interface_handler:get_events( );
local cvar = csgo.interface_handler:get_cvar( );

local r_3dsky = cvar:find_var( "r_3dsky" );

-- done here as well so it gets set when you load the script.
r_3dsky:set_int( 0 );

function on_event( e )
    if e:get_name( ) == "game_newmap" then
        r_3dsky:set_int( 0 );
    end
end

game_events:add_event( "game_newmap" );

local callbacks = fatality.callbacks;
callbacks:add( "events", on_event );