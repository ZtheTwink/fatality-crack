-- _markjelo luas + cfg

print("nadebot LUA for my cfg _markjelo#9266")

local callbacks = fatality.callbacks
local menu = fatality.menu
local config = fatality.config
local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()
local cfg = 
{
    grenades = 
    {
        he_grenade = config:add_item("ch.grenades.he_grenade", 0),
        smoke_grenade = config:add_item("ch.grenades.smoke_grenade", 0),
        molotov_grenade = config:add_item("ch.grenades.molotov_grenades", 0),
        flash_grenade = config:add_item("ch.grenades.flash_grenade", 0),
    }
}
local autobuy_multi_combo = menu:add_multi_combo('Grenades', 'misc', '', 'buy bot'):add_item('HE', cfg.grenades.he_grenade):add_item('Smoke', cfg.grenades.smoke_grenade):add_item('Molotov', cfg.grenades.molotov_grenade):add_item('Flashbang', cfg.grenades.flash_grenade)
local function on_round_prestart()
    if cfg.grenades.he_grenade:get_bool() then
        engine_client:client_cmd('buy hegrenade')
    end
    if cfg.grenades.smoke_grenade:get_bool() then
        engine_client:client_cmd('buy smokegrenade')
    end
    if cfg.grenades.molotov_grenade:get_bool() then
        engine_client:client_cmd('buy molotov')
        engine_client:client_cmd('buy incgrenade')
    end
    if cfg.grenades.flash_grenade:get_bool() then
        engline_client:client_cmd('buy flashbang')
    end
end
local function on_event(e)
    local event_name = e:get_name()
    if event_name == "round_prestart" then
        on_round_prestart(e)
    end
end
events:add_event("round_prestart")
callbacks:add("events", on_event)
