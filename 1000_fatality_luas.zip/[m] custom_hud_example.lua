-- get fatality imports
local config = fatality.config;
local menu = fatality.menu;
local render = fatality.render;
local callbacks = fatality.callbacks;

-- create menu item
local custom_hud_item = config:add_item('visuals_custom_hud', 0);

-- create menu checkbox
local custom_hud_checkbox = menu:add_checkbox('Custom HUD', 'Visuals', 'Misc', 'Various', custom_hud_item);

-- get engine client interface
local engine_client = csgo.interface_handler:get_engine_client();

-- get entity list interface
local entity_list = csgo.interface_handler:get_entity_list();

-- get cvar interface
local cvar = csgo.interface_handler:get_cvar();

-- create font
local create_font = render:create_font('Tahoma', 20, 300, true);

-- round number function
local function round_number(number)
    return number % 1 >= 0.5 and math.ceil(number) or math.floor(number);
end

-- draw hud function
local function draw_hud()
    -- get screen size
    local screen_size = render:screen_size();

    -- get local player
    local local_player = entity_list:get_localplayer();

    -- check for nil value
    if local_player == nil then
        return;
    end

    -- get local player name
    local name = local_player:get_name();

    -- get local player position
    local position = local_player:get_eye_pos();

    -- get local player health value
    local health = local_player:get_var_int('CBasePlayer->m_iHealth');

    -- get local player armor value
    local armor = local_player:get_var_int('CCSPlayer->m_ArmorValue');

    -- get local player round kills
    local round_kills = local_player:get_var_int('CCSPlayer->m_iNumRoundKills');

    -- get active weapon handle
    local active_weapon_handle = local_player:get_var_handle('CBaseCombatCharacter->m_hActiveWeapon');

    -- get active weapon from handle
    local active_weapon = entity_list:get_from_handle(active_weapon_handle);

    -- check for nil value
    if active_weapon == nil then
        return;
    end

    -- get ammo clip from weapon handle
    local ammo_clip = active_weapon:get_var_int('CBaseCombatWeapon->m_iClip1');

    -- get ammo reserved from weapon handle
    local ammo_reserved = active_weapon:get_var_int('CBaseCombatWeapon->m_iPrimaryReserveAmmoCount');

    -- check for nil values
    if name == nil or position == nil or health == nil or armor == nil or round_kills == nil or ammo_clip == nil or ammo_reserved == nil then
        return;
    end

    -- render top left hud section
    render:rect_filled(0, 0, screen_size.x / 2 - 420, screen_size.y / 2 - 500, csgo.color(10, 10, 10, 240));

    -- local player name is over 12 characters
    if string.len(name) > 12 then
        -- substring remaining characters
        name = string.sub(name, 0, 12);
    end

    -- render top left hud information
    render:text(create_font, screen_size.x / 2 - 945, screen_size.y / 2 - 532, 'Player: '.. name ..' | Round Kills: '.. round_kills ..' | Position: X: '.. round_number(position.x) ..', Y: '.. round_number(position.y) ..', Z: '.. round_number(position.z) ..'', csgo.color(255, 255, 255, 255));

    -- render bottom left hud section
    render:rect_filled(0, screen_size.y / 2 + 500, screen_size.x / 2 - 420, screen_size.y / 2 - 500, csgo.color(10, 10, 10, 240));

    -- ammo clip is on an invalid weapon
    if ammo_clip == -1 then
        -- render bottom left hud information
        render:text(create_font, screen_size.x / 2 - 945, screen_size.y / 2 + 510, 'Health: '.. health ..' | Armor: '.. armor ..' | Ammo: Infinite', csgo.color(255, 255, 255, 255));
    else
        -- render bottom left hud information
        render:text(create_font, screen_size.x / 2 - 945, screen_size.y / 2 + 510, 'Health: '.. health ..' | Armor: '.. armor ..' | Ammo: '.. ammo_clip ..'/'.. ammo_reserved ..'', csgo.color(255, 255, 255, 255));
    end
end

-- on paint function
local function on_paint()
    -- local player connected and in game
    if engine_client:is_connected() and engine_client:is_in_game() then
        -- find hud cvar
        local hud = cvar:find_var('cl_draw_only_deathnotices');

        -- menu checkbox is enabled
        if custom_hud_item:get_bool() then
            -- disable hud
            hud:set_int(1);

            -- draw hud
            draw_hud();
        -- menu checkbox is disabled
        else
            -- enable hud
            hud:set_int(0);
        end
    end
end

-- add callback
callbacks:add('paint', on_paint);