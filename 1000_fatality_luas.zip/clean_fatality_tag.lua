-- https://fatality.win/threads/clean-fatality-clantag.4606/

require "clantag_api"

local timing_switch = 20
local cur_mode = 0
local timing = timing_switch

local clantag_timing = {
    [1]  = function() return " /        /" end,
    [2]  = function() return " /f       /" end,
    [3]  = function() return " /fa      /" end,
    [4]  = function() return " /fat     /" end,
    [5]  = function() return " /fata    /" end,
    [6]  = function() return " /fatal   /" end,
    [7]  = function() return " /fatali  /" end,
    [8]  = function() return " /fatalit /" end,
    [9]  = function() return " /fatality/" end,
    [10] = function() return " /fatality/" end,
    [11] = function() return " /fatality/" end,
    [12] = function() return " /fatality/" end,
    [13] = function() return " /fatality/" end,
    [14] = function() return " /fatality/" end,
    [15] = function() return " /fatalit /" end,
    [16] = function() return " /fatali  /" end,
    [17] = function() return " /fatal   /" end,
    [18] = function() return " /fata    /" end,
    [19] = function() return " /fat     /" end,
    [20] = function() return " /fa      /" end,
    [21] = function() return " /f       /" end,
    [22] = function() return " /        /" end,
    
}

local function on_paint()
timing = timing + 1

    if timing >= timing_switch then
        cur_mode = cur_mode + 1

        if cur_mode > #clantag_timing then
            cur_mode = 1
        end
      
        SET_CLANTAG_MADE_BY_DUCARII(clantag_timing[cur_mode]())
        timing = 0
    end

end


local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )