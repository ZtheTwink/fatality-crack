local menu = fatality.menu
local input = fatality.input
local config = fatality.config

local ext_ref = menu:get_reference("RAGE", "weapons", "auto", "Silent")
local keybind_type_item = config:add_item("keybind_type_item", 0)
local key_combo = menu:add_combo("Silent keybind type", "RAGE", "AIMBOT", "Misc", keybind_type_item)
key_combo:add_item("Hold", keybind_type_item)
key_combo:add_item("Toggle", keybind_type_item)

local key = 0x5A

fatality.callbacks:add("paint", function()
    if keybind_type_item:get_int() == 0 then
        if(input:is_key_down(key)) then
            ext_ref:set_bool(true)
        else
            ext_ref:set_bool(false)
        end
    end
    if keybind_type_item:get_int() == 1 then
    if(input:is_key_pressed(key)) then
        ext_ref:set_bool(not ext_ref:get_bool())
    end
end
end)