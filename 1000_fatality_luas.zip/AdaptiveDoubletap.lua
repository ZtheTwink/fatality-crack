--adaptive doubletap made by pxnch#7017
--

-- game vars
local entity_list = csgo.interface_handler:get_entity_list()
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local cvar = csgo.interface_handler:get_cvar()
local global_vars = csgo.interface_handler:get_global_vars()
local events = csgo.interface_handler:get_events()

-- references

local autosniper_doubletap = config:get_weapon_setting("autosniper", "double_tap")
local heavy_doubletap = config:get_weapon_setting("heavy_pistol", "double_tap")
local pistols_doubletap = config:get_weapon_setting("pistol", "double_tap")
local other_doubletap = config:get_weapon_setting("other", "double_tap")

-- lua menu

local config_item = config:add_item("lua_doubletap_doubletap_active", 0)
local config_combo = menu:add_combo("Adaptive Doubletap", "RAGE", "AIMBOT", "Aimbot", config_item)
config_combo:add_item("Disabled", config_item)
config_combo:add_item("Default", config_item)
config_combo:add_item("Switch to non-teleport", config_item)

-- lua vars

local reset_doubletap = false

-- functions
--    indicator api
function render_indicator( text, enabled )
    if(_G['draw_indicator_with_bool'] ~= nil) then
        draw_indicator_with_bool(text, enabled)
    end
end

function render_indicator_color( text, color )
    if(_G['draw_indicator_with_color'] ~= nil) then
        draw_indicator_with_color(text, color)
    end
end

function vec_length_2d(x, y)
    return math.abs(x) + math.abs(y)
end

function on_event(event)
    local user_id = event:get_int("userid")
    local local_player = entity_list:get_localplayer()
    if(local_player == nil) then
        return
    end

    if(config_item:get_int() == 0) then
        return
    end

    if(event:get_name() == "weapon_fire") then
        if (local_player:is_alive( )) then
            local entity = entity_list:get_player_from_id(user_id)
            if(entity:get_index() == local_player:get_index()) then
                if(autosniper_doubletap:get_int() == 2) or (heavy_doubletap:get_int() == 2) or(pistols_doubletap:get_int() == 2) or(other_doubletap:get_int() == 2) then
                    if(config_item:get_int() == 1) then
                        autosniper_doubletap:set_int(0)
                        heavy_doubletap:set_int(0)
                        pistols_doubletap:set_int(0)
                        other_doubletap:set_int(0)
                    end
                    if(config_item:get_int() == 2) then
                        autosniper_doubletap:set_int(1)
                        heavy_doubletap:set_int(1)
                        pistols_doubletap:set_int(1)
                        other_doubletap:set_int(1)
                    end

                    reset_doubletap = true
                end
            end
        end
    end
end

function on_paint() 
    local local_player = entity_list:get_localplayer() 
    local screen_size = render:screen_size( )

    if(local_player == nil) then
        return
    end

    if(local_player:is_alive( )) then
        if(reset_doubletap) then
            local velocity = local_player:get_var_vector("CBasePlayer->m_vecVelocity[0]")
            local velocity_length = vec_length_2d(velocity.x, velocity.y)
            if (velocity_length <= 1) then
                autosniper_doubletap:set_int(2)
                heavy_doubletap:set_int(2)
                pistols_doubletap:set_int(2)
                other_doubletap:set_int(2)
                reset_doubletap = false
            else
                render_indicator_color("doubletap", csgo.color(230, 230, 10, 255))
            end

            if(autosniper_doubletap:get_int() == 2) then
                reset_doubletap = false
            end
        end
    end
end

-- callbacks

events:add_event("weapon_fire")

local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)
callbacks:add("events", on_event)