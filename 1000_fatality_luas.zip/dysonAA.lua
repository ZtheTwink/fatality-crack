print '3'
print '2'
print '1'
print 'Dyson AA loaded good luck and fun!'
-- begin aa

local engine_client     = csgo.interface_handler:get_engine_client()
local menu              = fatality.menu
local render            = fatality.render
local input             = fatality.input
local config = fatality.config
local entity_list = csgo.interface_handler:get_entity_list()
local global_vars = csgo.interface_handler:get_global_vars()
local engine = csgo.interface_handler:get_engine_client()

local aa_back = menu:get_reference( "rage", "anti-aim", "general", "back" )
local aa_right = menu:get_reference( "rage", "anti-aim", "general", "right" )
local aa_left = menu:get_reference( "rage", "anti-aim", "general", "left" )

local manualAA_item = config:add_item( "manual_arrows", 0 )
local manualAA_checkbox = menu:add_checkbox( "Manual arrows", "visuals", "misc", "local", manualAA_item )

local customDesign_item	 = config:add_item("Ma_customDesign_item", 0)

local size11_item = config:add_item( "size_item", 18 )
local posi_item = config:add_item( "posi_item", 0 )
local indi_slider = menu:add_slider( "Indicator1", "rage", "anti-aim", "general" , posi_item, -1080, 0, 1 )
local colour_item = config:add_item("C_colour_item", 19 )

local size_item = config:add_item( "size_item", 18 )
local size_slider = menu:add_slider( "Size of arrows", "visuals", "misc", "local", size_item, 15, 23, 1 )

local colour_item = config:add_item("Ma_colour_item", 14)
local colour_slider = menu:add_slider("Arrows colour", "visuals", "misc", "local", colour_item, 0 , 20, 1)

local chroma_item = config:add_item( "Ma_chroma_item", 0 )
local chroma_checkbox = menu:add_checkbox( "Chroma mode for enabled arrows", "visuals", "misc", "local", chroma_item )

local darkmode_item = config:add_item( "Ma_darkmode_item", 0 )
local darkmode_checkbox = menu:add_checkbox( "Dark mode for disabled arrows", "visuals", "misc", "local", darkmode_item )

local baim_item = config:add_item( "baimindicator", 0 )
local slowwalk_item = config:add_item( "dtindicator", 0 )
local silent_item = config:add_item( "silentindicator", 0 )
local opposite_item = config:add_item( "oppositeindicator", 0 )
local indicator2_item = menu:add_checkbox( "Same side indi", "rage", "anti-aim", "general", opposite_item )
local indicator2_item = menu:add_checkbox( "Silent indi", "rage", "anti-aim", "general", silent_item )
local indicator_item = menu:add_checkbox( "Dt  indi", "rage", "anti-aim", "general", slowwalk_item )
local indicator1_item = menu:add_checkbox( "Baim indi", "rage", "anti-aim", "general", baim_item )

--fonts 
local font = render:create_font('Verdana', 18, 900, true);
local indicator_font = render:create_font('Verdana', 18, 900, true);
local light_font = render:create_font( "Verdana Bold", 25, 400, false );
local bold_font = render:create_font( "Verdana Bold", 32, 800, false );

local side = false
local back = false

--left and right
function draw_side_arrow(x, y, size, color, side)
    if(side) then
        for i = 0, (size - 1) do
            render:rect(x + i, y + (i / 2) + 1, 1, size - i, color)
        end
        
    else
        for i = 0, (size - 1) do
            render:rect(x - i, y + (i / 2) + 1, 1, size - i, color)
        end 
    end  
end
--back
function draw_back_arrow(x, y, size, color, side)
    if(back) then
        for i = 0, (size - 1) do
            render:rect(x - 0.5 - (i / 2), y - i / 50 + 30, 1, size - i, color)
        end
        for i = 0, (size - 1) do
            render:rect(x + (i / 2), y - i / 50 + 30, 1, size - i, color)
        end
        
    else
        for i = 0, (size - 1) do
            render:rect(x - i, y + (i / 2) + 1, 1, size - i, color)
        end 
    end  
end
-----
function on_paint()

    -- changing values from float to int
    local size_slider = size_item:get_float() * 1
    local colour_value = colour_item:get_float( ) * 1

    -- colours
    local white_colour = csgo.color(100, 100, 100, 175)
    local black_colour = csgo.color(0, 0, 0, 175)
	local blue_clr = csgo.color(152, 153, 161, 255)
	local white = csgo.color( 255, 255, 255, 255 )
	local green = csgo.color( 152, 153, 161, 255)
	

    -- rainbow RGB
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );


    -- colour changer (final version)
    if colour_value == 0 then
        custom_colour = csgo.color(255, 255, 255, 255) --< white
        elseif colour_value == 1 then
        custom_colour = csgo.color(0, 0, 0, 255) --< black
        elseif colour_value == 2 then
        custom_colour = csgo.color(255, 0, 0, 255) --< deep-red
        elseif colour_value == 3 then
        custom_colour = csgo.color(244,67,54, 255) --< red
        elseif colour_value == 4 then
        custom_colour = csgo.color(255,87,34, 255) --< light-red
        elseif colour_value == 5 then
        custom_colour = csgo.color(255,152,0, 255) --< deep-orange
        elseif colour_value == 6 then
        custom_colour = csgo.color(255,193,7, 255) --< orange
        elseif colour_value == 7 then
        custom_colour = csgo.color(255,235,59, 255) --< yellow
        elseif colour_value == 8 then
        custom_colour = csgo.color(205,220,57, 255) --< lime
        elseif colour_value == 9 then
        custom_colour = csgo.color(139,195,74, 255) --< light-green
        elseif colour_value == 10 then
        custom_colour = csgo.color(76,175,80, 255) --< green
        elseif colour_value == 11 then
        custom_colour = csgo.color(0,150,136, 255) --< teal
        elseif colour_value == 12 then
        custom_colour = csgo.color(0,188,212, 255) --< cyan
        elseif colour_value == 13 then
        custom_colour = csgo.color(3,169,244, 255) --< ligh-blue
        elseif colour_value == 14 then
        custom_colour = csgo.color(33,150,243, 255) --< blue
        elseif colour_value == 15 then
        custom_colour = csgo.color(63,81,181, 255) --< indigo
        elseif colour_value == 16 then
        custom_colour = csgo.color(103,58,183, 255) --< deep-purple
        elseif colour_value == 17 then
        custom_colour = csgo.color(156,39,176, 255) --< purple
        elseif colour_value == 18 then
        custom_colour = csgo.color(126,87,194, 255) --< -light-purple
        elseif colour_value == 19 then
        custom_colour = csgo.color(233,30,99, 255) --< deep-pink
        elseif colour_value == 20 then
        custom_colour = csgo.color(236,64,122, 255) --< light-pink
        else
        custom_colour = csgo.color(255, 255, 255, 255) --< default
    end

    if chroma_item:get_bool() then
        custom_colour = csgo.color(r, g, b, 255) --< chroma mode
    end

    if darkmode_item:get_bool() then
        white_colour = black_colour --< dark mode
    end

    -- getting localplayer variable
    local local_player = entity_list:get_localplayer()

    -- getting screen size
    local screen_size = render:screen_size()

      -- check box check
      if manualAA_item:get_bool() then

        -- local player check
        if(local_player ~= nil and local_player:is_alive()) then
		
		        if customDesign_item:get_int() == 2 then
                     
					 
                 
                       side = true;
                       render:text(bold_font, screen_size.x / 2 + 9 + 27 + 1, screen_size.y / 2 - 11,  ">", white_colour)

                
                       side = false;
                       render:text(bold_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", white_colour)

                
                       back = true;
                       render:text(bold_font, screen_size.x / 2 - 7, screen_size.y / 2 + 25,  "v", white_colour)
                


               
                       if aa_right:get_bool() then
                       side = true;
                       render:text(bold_font, screen_size.x / 2 + 9 + 27 + 1, screen_size.y / 2 - 11,  ">", custom_colour)

                
                       elseif aa_left:get_bool() then
                       side = false;
                       render:text(bold_font, screen_size.x / 2 - 10 - 41 + 1, screen_size.y / 2 - 11,  "<", custom_colour)

               
                       elseif aa_back:get_bool() then
                       back = true;
                       render:text(bold_font, screen_size.x / 2 - 7, screen_size.y / 2 + 25,  "v", custom_colour)
                       end
                 
                end
	        end
		end  

		
	if(engine_client:is_in_game()) then
   
    -- is local player alive,if not,then return
        if(local_player ~= nil and local_player:is_alive()) then
     
        end
    local baim = menu:get_reference( "rage", "aimbot", "aimbot", "force fallback" )
	local slowwalk = menu:get_reference( "rage", "weapons", "auto", "double tap" )
	local silent = menu:get_reference("rage", "weapons", "auto", "silent")
	local opposite = menu:get_reference("rage", "anti-aim", "general", "shot antiaim", "opposite")
	  local velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
       
        local vel_2d = math.ceil( math.sqrt( math.abs( velocity.x ) * math.abs( velocity.x ) + math.abs( velocity.y ) * math.abs( velocity.y ) ) )
    
	local frame_rate = 0.0;
   
        function get_fps( )
        frame_rate = 0.9 * frame_rate + ( 1.0 - 0.9 ) * global_vars.frametime;
        return math.floor( ( 1.0 / frame_rate ) + 0.5 );
       
    end
    local fps = get_fps( )
	local yaw = fps / 100 * 2
	
	local function get_ping( )
        if not engine:is_connected( ) then
    return 0 end
   
        return math.abs( engine:get_ping( ) )
    end
     local ping = get_ping( )
	
	if opposite:get_bool() then
	    o = true
	else
	    o = false 
	end
	
	if silent:get_bool() then 
	    s = true
	else
	    s = false
	end
	
	if slowwalk:get_bool() then
	    sl = true
	else
	    sl = false
	end
	
	if baim:get_bool() then
        fb = true
    else
        fb = false
    end
	
	local addxx = posi_item:get_int()
   
   
    if baim_item:get_bool() then
        render:indicator( 930, screen_size.y - 490 + addxx, "baim", fb , -1)
        subpos = 100
    end
	
	if slowwalk_item:get_bool() then
	    render:indicator( 865, screen_size.y - 470 + addxx, "doubletap extra", sl, -1)
		subpos = 100
	end
	
	if silent_item:get_bool() then 
	    render:indicator( 925, screen_size.y - 450 + addxx, "silent", s, -1)
	    subpos = 100
    
	end
	
	if opposite_item:get_bool() then
	
	    render:text(indicator_font, 914, screen_size.y  - 428 + addxx, "OPPOSITE", blue_clr, o)
		  render:text(font, 1020, screen_size.y - 525 + addxx, ping, green, o)
		  render:text(font, 980, screen_size.y - 525 + addxx, "ping:", white, o)
		  render:text(font, 890, screen_size.y - 525 + addxx , yaw, green, o)
		  render:text(font, 872, screen_size.y - 525 + addxx, "Y:", white, o)
		subpos = 100
	end
	
 end
end

local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)


local silent1 = csgo.color(255,0,0,255)
local doubletap = csgo.color(255,0,0,255)
local fallback = csgo.color(255,0,0,255)

local screensize = render:screen_size()

local x = config:add_item( 'x', 0 )
local y = config:add_item( 'y', 0 )

local blue = csgo.color(200,200,200,255)

local autoSilent = menu:get_reference( 'rage', 'weapons', 'auto', 'silent' )
local autoDoubletap = menu:get_reference( 'rage', 'weapons', 'auto', 'double tap' )
local autoFallback = menu:get_reference( 'rage', 'aimbot', 'aimbot', 'force fallback' )

local awpSilent = menu:get_reference( 'rage', 'weapons', 'awp', 'silent' )
local awpDoubletap = menu:get_reference( 'rage', 'weapons', 'awp', 'double tap' )
local awpFallback = menu:get_reference( 'rage', 'aimbot', 'aimbot', 'force fallback' )

local scoutSilent = menu:get_reference( 'rage', 'weapons', 'scout', 'silent' )
local scoutDoubletap = menu:get_reference( 'rage', 'weapons', 'scout', 'double tap' )
local scoutFallback = menu:get_reference( 'rage', 'aimbot', 'aimbot', 'force fallback' )

local heavyPistolSilent = menu:get_reference( 'rage', 'weapons', 'heavy pistols', 'silent' )
local heavyPistolDoubletap = menu:get_reference( 'rage', 'weapons', 'heavy pistols', 'double tap' )
local heavyPistolFallback = menu:get_reference( 'rage', 'aimbot', 'aimbot', 'force fallback' )

local pistolSilent = menu:get_reference( 'rage', 'weapons', 'pistols', 'silent' )
local pistolDoubletap = menu:get_reference( 'rage', 'weapons', 'pistols', 'double tap' )
local pistolFallback = menu:get_reference( 'rage', 'aimbot', 'aimbot', 'force fallback' )

local otherSilent = menu:get_reference( 'rage', 'weapons', 'other', 'silent' )
local otherDoubletap = menu:get_reference( 'rage', 'weapons', 'other', 'double tap' )
local otherFallback = menu:get_reference( 'rage', 'aimbot', 'aimbot', 'force fallback' )

local indicator_font = render:create_font('Verdana', 18, 900, true);

local function paint()

local localPlayer = entity_list:get_localplayer()

if localPlayer == nil then
    return end

local weapon = csgo.interface_handler:get_entity_list():get_from_handle(localPlayer:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) )

if weapon == nil then
    return end

local currentWeapon = weapon:get_class_id()

    if currentWeapon == 244 or currentWeapon == 238 or currentWeapon == 257 or currentWeapon == 268  or currentWeapon == 245 or currentWeapon == 257 or currentWeapon == 240 then
        currentWeapon = 'pistol'
    elseif  currentWeapon == 46 then
        currentWeapon = 'heavy pistol'
    elseif currentWeapon == 266 then
        currentWeapon = 'scout'
    elseif currentWeapon == 260 or currentWeapon == 241 then
        currentWeapon = 'auto'
    elseif currentWeapon == 232 then
        currentWeapon = 'awp'
    elseif currentWeapon == 107 then
        currentWeapon = 'knife'
    else
        currentWeapon = 'other'
    end

if currentWeapon == 'auto' then
        if autoSilent:get_bool() then
            silent1 = csgo.color(200,200,200,255)
        else
            silent1 = csgo.color(255,0,0,255)
        end

        if autoDoubletap:get_int() == 1 or autoDoubletap:get_int() == 2 then
            doubletap = csgo.color(200,200,200,255)
        else
            doubletap = csgo.color(255,0,0,255)
        end
        if autoFallback:get_int() == 1 or autoFallback:get_int() == 2 then
            fallback = csgo.color(200,200,200,255)
        else
            fallback = csgo.color(255,0,0,255)
        end
    elseif currentWeapon == 'awp' then
        if awpSilent:get_bool() then
            silent1 = csgo.color(200,200,200,255)
        else
            silent1 = csgo.color(255,0,0,255)
        end
        doubletap = csgo.color(0,0,0,255)       
        if awpFallback:get_int() == 1 or awpFallback:get_int() == 2 then
            fallback = csgo.color(200,200,200,255)
        else
            fallback = csgo.color(255,0,0,255)
        end
    elseif currentWeapon == 'scout' then
        if scoutSilent:get_bool() then
            silent1 = csgo.color(200,200,200,255)
        else
            silent1 = csgo.color(255,0,0,255)
        end
        doubletap = csgo.color(0,0,0,255)     
        if scoutFallback:get_int() == 1 or scoutFallback:get_int() == 2 then
            fallback = csgo.color(200,200,200,255)
        else
            fallback = csgo.color(255,0,0,255)
        end
    elseif currentWeapon == 'pistol' then
        if pistolSilent:get_bool() then
            silent1 = csgo.color(200,200,200,255)
        else
            silent1 = csgo.color(255,0,0,255)
        end
        if pistolDoubletap:get_int() == 1 or pistolDoubletap:get_int() == 2 then
            doubletap = csgo.color(200,200,200,255)
        else
            doubletap = csgo.color(255,0,0,255)
        end
        if awpFallback:get_int() == 1 or awpFallback:get_int() == 2 then
            fallback = csgo.color(200,200,200,255)
        else
            fallback = csgo.color(255,0,0,255)
        end
        if pistolFallback:get_int() == 1 or pistolFallback:get_int() == 2 then
            fallback = csgo.color(200,200,200,255)
        else
            fallback = csgo.color(255,0,0,255)
        end
    elseif currentWeapon == 'heavy pistol' then
        if heavyPistolSilent:get_bool() then
            silent = csgo.color(0,0,0,255)
        else
            silent = csgo.color(0,0,0,255)
        end

        if heavyPistolDoubletap:get_int() == 1 or heavyPistolDoubletap:get_int() == 2 then
            doubletap = csgo.color(0,0,0,255)
        else
            doubletap = csgo.color(0,0,0,255)
        end
        if heavyPistolFallback:get_int() == 1 or heavyPistolFallback:get_int() == 2 then
            fallback = csgo.color(200,200,200,255)
        else
            fallback = csgo.color(255,0,0,255)
        end
    elseif currentWeapon == 'knife' then
        silent1 = csgo.color(0,0,0,255)
        doubletap = csgo.color(0,0,0,255)
        fallback = csgo.color(0,0,0,255)
    else
        if otherSilent:get_bool() then
            silent1 = csgo.color(0,0,0,255)
        else
            silent1 = csgo.color(0,0,0,255)
        end

        if otherDoubletap:get_int() == 1 or otherDoubletap:get_int() == 2 then
            doubletap = csgo.color(0,0,0,255)
        else
            doubletap = csgo.color(0,0,0,255)
        end
        if otherFallback:get_int() == 1 or otherFallback:get_int() == 2 then
            fallback = csgo.color(0,0,0,255)
        else
            fallback = csgo.color(0,0,0,255)
        end
    end

    
    render:text( indicator_font, x:get_int() - 431, y:get_int(), 'SILENT', silent1)
    render:text( indicator_font, x:get_int() - 452 , y:get_int() + 19, 'DOUBLE TAP', doubletap )
    render:text( indicator_font, x:get_int() - 425, y:get_int() + 38, 'BAIM', fallback )
end

callbacks:add('paint', paint)


-----special AA by Dyson$-----

 local freestand_fake_standing = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Freestand fake" )
 local freestand_fake_moving = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Freestand fake" )
 local freestand_fake_in_air = menu:get_reference( "RAGE", "ANTI-AIM", "Air", "Freestand fake" )
 local stand = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Freestand fake" )
 local add1 = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Add" )
 local add2 = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
 local add3 = menu:get_reference( "RAGE", "ANTI-AIM", "Air", "Add" )
 local fakeamount1 = menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
 local fakeamount2 = menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake amount" )
 local fakeamount3 = menu:get_reference( "RAGE", "ANTI-AIM", "Air", "Fake amount" )
 
 
 local side = false
function paint()
    side = not side
	stand:get_bool( true )
	
	if (side) then
	freestand_fake_standing:set_float(0)
	freestand_fake_moving:set_float(0)
	freestand_fake_in_air:set_float(0)
	add1:set_float(5)
	add2:set_float(5)
	add3:set_float(5)
	fakeamount1:set_float(-67)
	fakeamount2:set_float(-67)
	fakeamount3:set_float(-67)
	
	
	else
	freestand_fake_standing:set_float(1)
	freestand_fake_moving:set_float(1)
	freestand_fake_in_air:set_float(1)
	add1:set_float(-5)
	add2:set_float(-5)
	add3:set_float(-5)
	fakeamount1:set_float(-80)
	fakeamount2:set_float(-80)
	fakeamount3:set_float(-80)
	
	end
end
fatality.callbacks:add( "paint", paint)


-----baim by Dyson$-----