-- Grab render interface to render :^)
local render = fatality.render
-- Grab config interface to config :^)
local config = fatality.config
-- Grab menu interface to menu :^)
local menu = fatality.menu

-- Get accessable interfaces
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )
local global_vars = csgo.interface_handler:get_global_vars( )



-- Create config & menu items
local spectator_list_item = config:add_item( "spectator_list", 1.0 )
local spectator_list_checkbox = menu:add_checkbox( "Spectator List", "visuals", "misc", "various", spectator_list_item )
local screen_size = render:screen_size();
local x_value_item = config:add_item("xvalue", 0)
local x_slider = menu:add_slider("x_slider", "visuals", "misc", "various", x_value_item, 0 , screen_size.x, 1)
local y_value_item = config:add_item("yvalue", 0)
local y_slider = menu:add_slider("y_slider", "visuals", "misc", "various", y_value_item, 0, screen_size.y, 1 )

-- Create font to use it for later text rendering
local small_12 = render:create_font( "Small Fonts", 12, 400, true )

function draw_window( x, y, w, h, title )
    local dark_blue = csgo.color( 33, 27, 70, 255 )
    local border = csgo.color( 60, 53, 93, 255 )
    local back = csgo.color( 25, 19, 59, 220 );

    local title_size = render:text_size( small_12, title )

    -- Draw inner
    render:rect_filled( x, y, w, h, back )

    -- Draw title bar
    render:rect_filled( x, y - title_size.y, w, title_size.y, dark_blue )
    render:rect( x, y - 1, w, 1, border )
    render:text( small_12, x + 4, y - title_size.y + 1, title, csgo.color( 230, 230, 230, 255 ) )

    -- Draw border
    render:rect( x, y - title_size.y, w, h + title_size.y, border )
end

-- Will be called every time a frame is rendered
function on_paint( )
    -- Don't run the script if the checkbox isn't selected
    if not spectator_list_item:get_bool( ) then
        return end

    if not engine_client:is_in_game( ) then
        return end

    local getslidervalue_x = x_value_item:get_float()
    local getslidervalue_y = y_value_item:get_float()
    -- Set position where the list will be drawn
    local spec_list_pos = csgo.vector2( getslidervalue_x, getslidervalue_y )

    local spec_names = { }
    local total_spectators = 0

    local local_player = entity_list:get_localplayer( )

    for i = 1, entity_list:get_max_players( ), 1 do
        player = entity_list:get_player( i )
        if player == nil or player:is_alive( ) or player:is_dormant( ) then
            goto continue end
     
        spec_handle = player:get_var_handle( "CBasePlayer->m_hObserverTarget" )
 
        spec_player = entity_list:get_from_handle( spec_handle )
        if spec_player == nil then
            goto continue end
     
        -- If the player is spectating us - add him/her to the list
        if spec_player:get_index( ) == local_player:get_index( ) then
            spec_names[ total_spectators ] = player:get_name( )
            total_spectators = total_spectators + 1;
        end
 
        ::continue::
    end

    draw_window( spec_list_pos.x, spec_list_pos.y, 150, total_spectators * 16 + 8, "Spectators" )

    -- Go through all registered spectators and draw the names
    for i = 0, total_spectators, 1 do
        if spec_names[ i ] == nil then break end
 
        render:text( small_12, spec_list_pos.x + 8, spec_list_pos.y + 4 + i * 16, spec_names[ i ], csgo.color(220,220,220,255) )
    end
end

-- Register all callback functions that should be called
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )