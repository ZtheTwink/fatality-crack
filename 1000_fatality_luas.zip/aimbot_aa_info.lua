-- https://fatality.win/threads/visual-aimbot-anti-aim-info.4718/

--main instances
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local callbacks = fatality.callbacks
local fatalMath = fatality.math
local global_vars = csgo.interface_handler:get_global_vars()
--main instances

local engine_client = csgo.interface_handler:get_engine_client()
local entity_list = csgo.interface_handler:get_entity_list()

local red = csgo.color(255,0,0,255)
local white = csgo.color(255,255,255,255)
local background = csgo.color( 35, 35, 35, 220)

local screensize = render:screen_size()

local aimbotToggle = config:add_item( 'Aimbot info', 0 )
local aimbotCheck = menu:add_checkbox( 'Aimbot Information', 'visuals', 'misc', 'various', aimbotToggle )
local xI = config:add_item( 'x', screensize.x - screensize.x/19.2 )
local yI = config:add_item( 'y', screensize.y - screensize.y/6.17 )
local rItem = config:add_item( 'red', 0 )
local gItem = config:add_item( 'green', 0 )
local bItem = config:add_item( 'blue', 0 )
local colorcomboItem = config:add_item( 'colorpicker', 0 )

local aaToggle = config:add_item( 'AA info', 0 )
local aaCheck = menu:add_checkbox( 'Anti Aimbot Information', 'visuals', 'misc', 'various', aaToggle )
local colorpickerCombo = menu:add_combo( 'Color Picker', 'visuals', 'misc', 'various', colorcomboItem)
colorpickerCombo:add_item('Rainbow', colorcomboItem)
colorpickerCombo:add_item('Red', colorcomboItem)
colorpickerCombo:add_item('Green', colorcomboItem)
colorpickerCombo:add_item('Hard Blue', colorcomboItem)
colorpickerCombo:add_item('Soft Blue', colorcomboItem)
colorpickerCombo:add_item('Custom', colorcomboItem)


local xS = menu:add_slider( 'Info X', 'visuals', 'misc', 'various', xI, 0, screensize.x - 175, 1 )
local xY = menu:add_slider( 'Info Y', 'visuals', 'misc', 'various', yI, 0, screensize.y - 190, 1 )
local rSlider = menu:add_slider( 'Red', 'visuals', 'misc', 'various', rItem, 0, 255, 1)
local gSlider = menu:add_slider( 'Green', 'visuals', 'misc', 'various', gItem, 0, 255, 1)
local bSlider = menu:add_slider( 'Blue', 'visuals', 'misc', 'various', bItem, 0, 255, 1)
local fontSizeFix = (screensize.x + screensize.y)/157.894

local font = render:create_font( 'VT323', math.floor(fontSizeFix), 100, true )

local function paint()

    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 )

    if colorcomboItem:get_int() == 0 then
        red = csgo.color(r,g,b,255)
    elseif colorcomboItem:get_int() == 1 then
        red = csgo.color(255,0,0,255)
    elseif colorcomboItem:get_int() == 2 then
        red = csgo.color(0,255,0,255)
    elseif colorcomboItem:get_int() == 3 then
        red = csgo.color(0,0,255,255)
    elseif colorcomboItem:get_int() == 4 then
        red = csgo.color(0,115,255,255)
    elseif colorcomboItem:get_int() == 5 then
        red = csgo.color(rItem:get_int(),gItem:get_int(),bItem:get_int(),255)
    end

    local auto = { --auto refrence table
    hitchance = menu:get_reference('rage', 'weapons', 'auto', 'hitchance'):get_int(),
    damage = menu:get_reference('rage', 'weapons', 'auto', 'min-damage'):get_int(),
    head = menu:get_reference('rage', 'weapons', 'auto', 'head scale'):get_int(),
    body = menu:get_reference('rage', 'weapons', 'auto', 'body scale'):get_int(),
    fallback = menu:get_reference('rage', 'weapons', 'auto', 'fallback mode'):get_int(),
    }
    local scout = { --scout refrence table
    hitchance = menu:get_reference('rage', 'weapons', 'scout', 'hitchance'):get_int(),
    damage = menu:get_reference('rage', 'weapons', 'scout', 'min-damage'):get_int(),
    head = menu:get_reference('rage', 'weapons', 'scout', 'head scale'):get_int(),
    body = menu:get_reference('rage', 'weapons', 'scout', 'body scale'):get_int(),
    fallback = menu:get_reference('rage', 'weapons', 'scout', 'fallback mode'):get_int(),
    }
    local pistol = { --pistol refrence table
    hitchance = menu:get_reference('rage', 'weapons', 'pistols', 'hitchance'):get_int(),
    damage = menu:get_reference('rage', 'weapons', 'pistols', 'min-damage'):get_int(),
    head = menu:get_reference('rage', 'weapons', 'pistols', 'head scale'):get_int(),
    body = menu:get_reference('rage', 'weapons', 'pistols', 'body scale'):get_int(),
    fallback = menu:get_reference('rage', 'weapons', 'pistols', 'fallback mode'):get_int(),
    }
    local heavyPistol = { --pistol refrence table
    hitchance = menu:get_reference('rage', 'weapons', 'heavy pistols', 'hitchance'):get_int(),
    damage = menu:get_reference('rage', 'weapons', 'heavy pistols', 'min-damage'):get_int(),
    head = menu:get_reference('rage', 'weapons', 'heavy pistols', 'head scale'):get_int(),
    body = menu:get_reference('rage', 'weapons', 'heavy pistols', 'body scale'):get_int(),
    fallback = menu:get_reference('rage', 'weapons', 'heavy pistols', 'fallback mode'):get_int(),
    }
    local awp = { --pistol refrence table
    hitchance = menu:get_reference('rage', 'weapons', 'awp', 'hitchance'):get_int(),
    damage = menu:get_reference('rage', 'weapons', 'awp', 'min-damage'):get_int(),
    head = menu:get_reference('rage', 'weapons', 'awp', 'head scale'):get_int(),
    body = menu:get_reference('rage', 'weapons', 'awp', 'body scale'):get_int(),
    fallback = menu:get_reference('rage', 'weapons', 'awp', 'fallback mode'):get_int(),
    }
    local other = { --pistol refrence table
    hitchance = menu:get_reference('rage', 'weapons', 'other', 'hitchance'):get_int(),
    damage = menu:get_reference('rage', 'weapons', 'other', 'min-damage'):get_int(),
    head = menu:get_reference('rage', 'weapons', 'other', 'head scale'):get_int(),
    body = menu:get_reference('rage', 'weapons', 'other', 'body scale'):get_int(),
    fallback = menu:get_reference('rage', 'weapons', 'other', 'fallback mode'):get_int(),
    }
    local standing = { --Standing anti aim refrences
    pitch = menu:get_reference('rage', 'anti-aim', 'standing', 'pitch'):get_int(),
    yawAddToggle = menu:get_reference('rage', 'anti-aim', 'standing', 'yaw add'):get_bool(),
    yawAdd = menu:get_reference('rage', 'anti-aim', 'standing', 'add'):get_int(),
    atTarget = menu:get_reference('rage', 'anti-aim', 'standing', 'at fov target'):get_bool(),
    fakeAmount  = menu:get_reference('rage', 'anti-aim', 'standing', 'fake amount'):get_int(),
    fakeType = menu:get_reference('rage', 'anti-aim', 'standing', 'fake type'):get_bool(),
    }
    local moving = { --moving anti aim refrences
    pitch = menu:get_reference('rage', 'anti-aim', 'moving', 'pitch'):get_int(),
    yawAddToggle = menu:get_reference('rage', 'anti-aim', 'moving', 'yaw add'):get_bool(),
    yawAdd = menu:get_reference('rage', 'anti-aim', 'moving', 'add'):get_int(),
    atTarget = menu:get_reference('rage', 'anti-aim', 'moving', 'at fov target'):get_bool(),
    fakeAmount  = menu:get_reference('rage', 'anti-aim', 'moving', 'fake amount'):get_int(),
    fakeType = menu:get_reference('rage', 'anti-aim', 'moving', 'fake type'):get_bool(),
    }
    local air = { --moving anti aim refrences
    pitch = menu:get_reference('rage', 'anti-aim', 'air', 'pitch'):get_int(),
    yawAddToggle = menu:get_reference('rage', 'anti-aim', 'air', 'yaw add'):get_bool(),
    yawAdd = menu:get_reference('rage', 'anti-aim', 'air', 'add'):get_int(),
    atTarget = menu:get_reference('rage', 'anti-aim', 'air', 'at fov target'):get_bool(),
    fakeAmount  = menu:get_reference('rage', 'anti-aim', 'air', 'fake amount'):get_int(),
    fakeType = menu:get_reference('rage', 'anti-aim', 'air', 'fake type'):get_bool(),
    }

    if standing.atTarget then --Translating standing atTarget int to string
        standing.atTarget = 'On'
    else 
        standing.atTarget = 'Off'
    end
    if moving.atTarget then --Translating moving atTarget int to string
        moving.atTarget = 'On'
    else 
        moving.atTarget = 'Off'
    end
    if air.atTarget then --Translating air atTarget int to string
        air.atTarget = 'On'
    else 
        air.atTarget = 'Off'
    end

    if standing.pitch == 0 then -- translate standing pitch int to string
        standing.pitch = 'Off'
    elseif standing.pitch == 1 then
        standing.pitch = 'Down'
    elseif standing.pitch == 2 then
        standing.pitch = 'Up'
    elseif standing.pitch == 3 then
        standing.pitch = 'Zero'
    end
    if moving.pitch == 0 then -- translate moving pitch int to string
        moving.pitch = 'Off'
    elseif moving.pitch == 1 then
        moving.pitch = 'Down'
    elseif moving.pitch == 2 then
        moving.pitch = 'Up'
    elseif moving.pitch == 3 then
        moving.pitch = 'Zero'
    end
    if air.pitch == 0 then -- translate moving pitch int to string
        air.pitch = 'Off'
    elseif air.pitch == 1 then
        air.pitch = 'Down'
    elseif air.pitch == 2 then
        air.pitch = 'Up'
    elseif air.pitch == 3 then
        air.pitch = 'Zero'
    end

    -- translate auto fallback int to string
    if auto.fallback == 0 then
        auto.fallback = 'Off'
    elseif auto.fallback == 1 then 
        auto.fallback = 'Adaptive'
    elseif auto.fallback == 2 then 
        auto.fallback = 'Prefer'
    end
    -- translate scout fallback int to string
    if scout.fallback == 0 then
        scout.fallback = 'Off'
    elseif scout.fallback == 1 then 
        scout.fallback = 'Adaptive'
    elseif scout.fallback == 2 then 
        scout.fallback = 'Prefer'
    end
    -- translate pistol fallback int to string
    if pistol.fallback == 0 then
        pistol.fallback = 'Off'
    elseif pistol.fallback == 1 then 
        pistol.fallback = 'Adaptive'
    elseif pistol.fallback == 2 then 
        pistol.fallback = 'Prefer'
    end
    -- translate heavy pistol fallback int to string
    if heavyPistol.fallback == 0 then
        heavyPistol.fallback = 'Off'
    elseif heavyPistol.fallback == 1 then 
        heavyPistol.fallback = 'Adaptive'
    elseif heavyPistol.fallback == 2 then 
        heavyPistol.fallback = 'Prefer'
    end
    -- translate awp fallback int to string
    if awp.fallback == 0 then
        awp.fallback = 'Off'
    elseif awp.fallback == 1 then 
        awp.fallback = 'Adaptive'
    elseif awp.fallback == 2 then 
        awp.fallback = 'Prefer'
    end
    -- translate other fallback int to string
    if other.fallback == 0 then
        other.fallback = 'Off'
    elseif other.fallback == 1 then 
        other.fallback = 'Adaptive'
    elseif other.fallback == 2 then 
        other.fallback = 'Prefer'
    end

    if not engine_client:is_in_game() then -- If you are in game 
        return end

    local localPlayer = entity_list:get_localplayer()

    local velNetVar = localPlayer:get_var_vector( "CBasePlayer->m_vecVelocity[0]" ) --get velocity netvar
    local velocity = math.ceil(math.sqrt(math.abs(velNetVar.x)*math.abs(velNetVar.x)+math.abs(velNetVar.y)*math.abs(velNetVar.y))) --calculate velocity

    local x = xI:get_int() -- x coord
    local y = yI:get_int() -- x coord
    --if not in game fix
    if localPlayer == nil then
        return end
    --get weapon handle
    local weapon = csgo.interface_handler:get_entity_list():get_from_handle(localPlayer:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) )
    --if nil then dont run
    if weapon == nil then
        return end
    local currentWeapon = weapon:get_class_id() -- get weapon id
    --weapon id to class
    if currentWeapon == 244 or currentWeapon == 238 or currentWeapon == 257 or currentWeapon == 268  or currentWeapon == 245 or currentWeapon == 257 or currentWeapon == 240 then
        currentWeapon = 'pistol'
    elseif  currentWeapon == 46 then
        currentWeapon = 'heavy pistol'
    elseif currentWeapon == 266 then
        currentWeapon = 'scout'
    elseif currentWeapon == 260 or currentWeapon == 241 then
        currentWeapon = 'auto'
    elseif currentWeapon == 232 then
        currentWeapon = 'awp'
    elseif currentWeapon == 107 then
        currentWeapon = 'knife'
    else 
        currentWeapon = 'other'
    end

    if aimbotToggle:get_bool() then --If aimbot info is toggled
        --aimbot info background start
        render:rect_filled( x, y, screensize.x/10.97, screensize.y/12, background )
        render:rect_filled( x + screensize.x/384, y + screensize.y/54, screensize.x/11.63, 3, red )
        render:text( font, x+screensize.x/137.14, y, 'AIMBOT INFORMATION', white )
        render:text( font, x+1, y+screensize.y/46.95, 'Hit Chance:', white )
        render:text( font, x+1, y+screensize.y/28.42, 'Min Damage:', white )
        render:text( font, x+1, y+screensize.y/20, 'Multi Point:', white )
        render:text( font, x+1, y+screensize.y/15.55, 'Fallback:', white )
        --aimbot info background end

        --knife
        if currentWeapon == 'knife' then
            render:text( font, x+screensize.x/21.33, y+screensize.y/46.95, '???', white )
            render:text( font, x+screensize.x/21.33, y+screensize.y/28.42, '???', white )
            render:text( font, x+screensize.x/19.79, y+screensize.y/20, '???/???', white )
            render:text( font, x+screensize.x/25.6,  y+screensize.y/15.55, '???', white )
        --auto
        elseif currentWeapon == 'auto' then
            render:text( font, x+screensize.x/21.33, y+screensize.y/46.95, auto.hitchance, white )
            render:text( font, x+screensize.x/21.33, y+screensize.y/28.42, auto.damage, white )
            render:text( font, x+screensize.x/19.59, y+screensize.y/20, auto.head, white)
        if auto.head < 10 then
            render:text( font, x+screensize.x/18.28, y+screensize.y/20, '/' ..auto.body, white)
        elseif auto.head > 10 and auto.head < 100 then
            render:text( font, x+screensize.x/16.99, y+screensize.y/20, '/' ..auto.body, white)
        else
            render:text( font, x+screensize.x/15.86, y+screensize.y/20, '/' ..auto.body, white)
        end
            render:text( font, x+screensize.x/25.6,  y+screensize.y/15.55, auto.fallback, white )
        --scout  
        elseif currentWeapon == 'scout' then
            render:text( font, x+screensize.x/21.33, y+screensize.y/46.95, scout.hitchance, white )
            render:text( font, x+screensize.x/21.33, y+screensize.y/28.42, scout.damage, white )
            render:text( font, x+screensize.x/19.59, y+screensize.y/20, scout.head, white)
        if scout.head < 10 then
            render:text( font, x+screensize.x/18.28, y+screensize.y/20, '/' ..scout.body, white)
        elseif scout.head > 10 and scout.head < 100 then
            render:text( font, x+screensize.x/16.99, y+screensize.y/20, '/' ..scout.body, white)
        else
            render:text( font, x+screensize.x/15.86, y+screensize.y/20, '/' ..scout.body, white)
        end
            render:text( font, x+screensize.x/25.6,  y+screensize.y/15.55, scout.fallback, white )
        --pistols
        elseif currentWeapon == 'pistol' then
            render:text( font, x+screensize.x/21.33, y+screensize.y/46.95, pistol.hitchance, white )
            render:text( font, x+screensize.x/21.33, y+screensize.y/28.42, pistol.damage, white )
            render:text( font, x+screensize.x/19.59, y+screensize.y/20, pistol.head, white)
        if pistol.head < 10 then
            render:text( font, x+screensize.x/18.28, y+screensize.y/20, '/' ..pistol.body, white)
        elseif pistol.head > 10 and pistol.head < 100 then
            render:text( font, x+screensize.x/16.99, y+screensize.y/20, '/' ..pistol.body, white)
        else
            render:text( font, x+screensize.x/15.86, y+screensize.y/20, '/' ..pistol.body, white)
        end
            render:text( font, x+screensize.x/25.6,  y+screensize.y/15.55, pistol.fallback, white )
        -- heavy pistol
        elseif currentWeapon == 'heavy pistol' then
            render:text( font, x+screensize.x/21.33, y+screensize.y/46.95, heavyPistol.hitchance, white )
            render:text( font, x+screensize.x/21.33, y+screensize.y/28.42, heavyPistol.damage, white )
            render:text( font, x+screensize.x/19.59, y+screensize.y/20, heavyPistol.head, white)
        if heavyPistol.head < 10 then
            render:text( font, x+screensize.x/18.28, y+screensize.y/20, '/' ..heavyPistol.body, white)
        elseif heavyPistol.head > 10 and heavyPistol.head < 100 then
            render:text( font, x+screensize.x/16.99, y+screensize.y/20, '/' ..heavyPistol.body, white)
        else
            render:text( font, x+screensize.x/15.86, y+screensize.y/20, '/' ..heavyPistol.body, white)
        end
            render:text( font, x+screensize.x/25.6,  y+screensize.y/15.55, heavyPistol.fallback, white )
            --awp
        elseif currentWeapon == 'awp' then
            render:text( font, x+screensize.x/21.33, y+screensize.y/46.95, awp.hitchance, white )
            render:text( font, x+screensize.x/21.33, y+screensize.y/28.42, awp.damage, white )
            render:text( font, x+screensize.x/19.59, y+screensize.y/20, awp.head, white)
        if awp.head < 10 then
            render:text( font, x+screensize.x/18.28, y+screensize.y/20, '/' ..awp.body, white)
        elseif awp.head > 10 and awp.head < 100 then
            render:text( font, x+screensize.x/16.99, y+screensize.y/20, '/' ..awp.body, white)
        else
            render:text( font, x+screensize.x/15.86, y+screensize.y/20, '/' ..awp.body, white)
        end
            render:text( font, x+screensize.x/25.6,  y+screensize.y/15.55, awp.fallback, white )
            --other
        elseif currentWeapon == 'other' then
            render:text( font, x+screensize.x/21.33, y+screensize.y/46.95, other.hitchance, white )
            render:text( font, x+screensize.x/21.33, y+screensize.y/28.42, other.damage, white )
            render:text( font, x+screensize.x/19.59, y+screensize.y/20, other.head, white)
        if other.head < 10 then
            render:text( font, x+screensize.x/18.28, y+screensize.y/20, '/' ..other.body, white)
        elseif other.head > 10 and other.head < 100 then
            render:text( font, x+screensize.x/16.99, y+screensize.y/20, '/' ..other.body, white)
        else
            render:text( font, x+screensize.x/15.86, y+screensize.y/20, '/' ..other.body, white)
        end
            render:text( font, x+screensize.x/25.6,  y+screensize.y/15.55, other.fallback, white )
        end
    end
    if aaToggle:get_bool() then -- if aa info is toggled 
        render:rect_filled( x, y+screensize.y/10.8 ,screensize.x/10.97, screensize.y/12, background )
        render:rect_filled( x + screensize.x/384, y+screensize.y/9, screensize.x/11.63, screensize.y/360, red)
        render:text( font, x+screensize.x/274.28, y+screensize.y/10.8, 'ANTI-AIM INFORMATION', white)
        render:text( font, x+1, y+screensize.y/8.78, 'Pitch:', white)
        render:text( font, x+1, y+screensize.y/7.82, 'Yaw Add:', white)
        render:text( font, x+1, y+screensize.y/7.05, 'At Target:', white)
        render:text( font, x+1, y+screensize.y/6.42, 'Fake Amount:', white)
    if velocity < 5 and velNetVar.z == 0 then
        render:text( font, x+screensize.x/38.4, y+screensize.y/8.78, standing.pitch, white )
        render:text( font, x+screensize.x/23.1, y+screensize.y/7.05, standing.atTarget, white )
        if standing.fakeType then
        render:text( font, x+screensize.x/19.79, y+screensize.y/6.42, standing.fakeAmount, white )
        else
        render:text( font, x+screensize.x/19.79, y+screensize.y/6.42, 'Off', white )
        end
        if standing.yawAddToggle then
            render:text( font, x+screensize.x/29.53, y+screensize.y/7.82, standing.yawAdd, white )
        else
            render:text( font, x+screensize.x/29.53, y+screensize.y/7.82, 'Off', white )
        end
    elseif velocity > 5 and velNetVar.z == 0 then
        render:text( font, x+screensize.x/38.4, y+screensize.y/8.78, moving.pitch, white )
        render:text( font, x+screensize.x/23.13, y+screensize.y/7.05, moving.atTarget, white )
        if moving.fakeType then
        render:text( font, x+screensize.x/19.79, y+screensize.y/6.42, moving.fakeAmount, white )
        else
        render:text( font, x+screensize.x/19.79, y+screensize.y/6.42, 'Off', white )
        end
        if moving.yawAddToggle then
            render:text( font, x+screensize.x/29.53, y+screensize.y/7.82, moving.yawAdd, white )
        else
            render:text( font, x+screensize.x/29.53, y+screensize.y/7.82, 'Off', white )
        end
    elseif velNetVar.z < 0 or velNetVar.z > 0 then
        render:text( font, x+screensize.x/38.4, y+screensize.y/8.78, air.pitch, white )
        render:text( font, x+screensize.x/23.13, y+screensize.y/7.05, air.atTarget, white )
        if air.fakeType then
        render:text( font, x+screensize.x/19.79, y+screensize.y/6.42, air.fakeAmount, white )
        else
        render:text( font, x+screensize.x/19.79, y+screensize.y/6.42, 'Off', white )
        end
        if air.yawAddToggle then
            render:text( font, x+screensize.x/29.53, y+screensize.y/7.82, air.yawAdd, white )
        else
            render:text( font, x+screensize.x/29.53, y+screensize.y/7.82, 'Off', white )
        end
    end
    end
end

callbacks:add('paint', paint)