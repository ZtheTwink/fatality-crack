local render = fatality.render

local menu = fatality.menu
local callbacks = fatality.callbacks


local entity_list = csgo.interface_handler:get_entity_list()


local hai = menu:get_reference("visuals","misc","local","Penetration crosshair")

local entity_list = csgo.interface_handler:get_entity_list( );


function get_scoped( )
    local local_player = entity_list:get_localplayer( );
    if ( local_player == nil or not local_player:is_alive( ) ) then
        return false end

    return local_player:get_var_bool("CCSPlayer->m_bIsScoped");
end

function on_paint( )
  
hai:set_bool( get_scoped())
 
end


callbacks:add( "paint", on_paint );