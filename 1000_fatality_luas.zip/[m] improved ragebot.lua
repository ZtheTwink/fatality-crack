-- june's lua megapack
-- this config was free at: discord.gg/XhMvwqr

--interfaces
local menu = fatality.menu
local input = fatality.input
local config = fatality.config
local render = fatality.render
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local scrnsize = render:screen_size( )
-------------------------------------------------------------------------------
-- enable cfg
--auto
local smart_min_dmg_activate_auto = config:add_item( "smart_min_dmg_activate_auto", 1 )
local smart_min_dmg_amount_auto = config:add_item( "smart_min_dmg_amount_auto", 1 )
--awp
local smart_min_dmg_activate_awp = config:add_item( "smart_min_dmg_activate_awp", 1 )
local smart_min_dmg_amount_awp = config:add_item( "smart_min_dmg_amount_awp", 1 )
--pistols
local smart_min_dmg_activate_pistols = config:add_item( "smart_min_dmg_activate_pistols", 1 )
local smart_min_dmg_amount_pistols = config:add_item( "smart_min_dmg_amount_pistols", 1 )
--scout
local smart_min_dmg_activate_scout = config:add_item( "smart_min_dmg_activate_scout", 1 )
local smart_min_dmg_amount_scout = config:add_item( "smart_min_dmg_amount_scout", 1 )
--heavy pistols
local smart_min_dmg_activate_heavy_pistols = config:add_item( "smart_min_dmg_activate_heavy_pistols", 1 )
local smart_min_dmg_amount_heavy_pistols = config:add_item( "smart_min_dmg_amount_heavy_pistols", 1 )
--other
local smart_min_dmg_activate_other = config:add_item( "smart_min_dmg_activate_other", 1 )
local smart_min_dmg_amount_other = config:add_item( "smart_min_dmg_amount_other", 1 )
-------------------------------------------------------------------------------
-- enable
--auto
local smart_min_dmg_activate_auto = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "auto", smart_min_dmg_activate_auto)
local smart_min_dmg_amount_auto = menu:add_slider( "Smart amount", "rage", "weapons", "auto", smart_min_dmg_amount_auto, -100, 100, 1)
--awp
local smart_min_dmg_activate_awp = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "awp", smart_min_dmg_activate_awp)
local smart_min_dmg_amount_awp = menu:add_slider( "Smart amount", "rage", "weapons", "awp", smart_min_dmg_amount_awp, -100, 100, 1)
--pistols
local smart_min_dmg_activate_pistols = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "pistols", smart_min_dmg_activate_pistols)
local smart_min_dmg_amount_pistols = menu:add_slider( "Smart amount", "rage", "weapons", "pistols", smart_min_dmg_amount_pistols, -100, 100, 1)
--scout
local smart_min_dmg_activate_scout = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "scout", smart_min_dmg_activate_scout)
local smart_min_dmg_amount_scout = menu:add_slider( "Smart amount", "rage", "weapons", "scout", smart_min_dmg_amount_scout, -100, 100, 1)
--heavy pistols
local smart_min_dmg_activate_heavy_pistols = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "heavy pistols", smart_min_dmg_activate_heavy_pistols)
local smart_min_dmg_amount_heavy_pistols = menu:add_slider( "Smart amount", "rage", "weapons", "heavy pistols", smart_min_dmg_amount_heavy_pistols, -100, 100, 1)
--other
local smart_min_dmg_activate_other = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "other", smart_min_dmg_activate_other)
local smart_min_dmg_amount_other = menu:add_slider( "Smart amount", "rage", "weapons", "other", smart_min_dmg_amount_other, -100, 100, 1)
-------------------------------------------------------------------------------
-- ref
--auto
local auto_min_dmg = menu:get_reference( "rage", "weapons", "auto", "Min-damage" )
local smart_min_dmg_activate_auto = menu:get_reference( "rage", "weapons", "auto", "Smart min dmg")
local smart_min_dmg_amount_auto = menu:get_reference( "rage", "weapons", "auto", "Smart amount")
--awp
local awp_min_dmg = menu:get_reference( "rage", "weapons", "awp", "Min-damage" )
local smart_min_dmg_activate_awp = menu:get_reference( "rage", "weapons", "awp", "Smart min dmg")
local smart_min_dmg_amount_awp = menu:get_reference( "rage", "weapons", "awp", "Smart amount")
--pistols
local pistols_min_dmg = menu:get_reference( "rage", "weapons", "pistols", "Min-damage" )
local smart_min_dmg_activate_pistols = menu:get_reference( "rage", "weapons", "pistols", "Smart min dmg")
local smart_min_dmg_amount_pistols = menu:get_reference( "rage", "weapons", "pistols", "Smart amount")
--scout
local scout_min_dmg = menu:get_reference( "rage", "weapons", "scout", "Min-damage" )
local smart_min_dmg_activate_scout = menu:get_reference( "rage", "weapons", "scout", "Smart min dmg")
local smart_min_dmg_amount_scout = menu:get_reference( "rage", "weapons", "scout", "Smart amount")
--heavy pistols
local heavy_pistols_min_dmg = menu:get_reference( "rage", "weapons", "heavy pistols", "Min-damage" )
local smart_min_dmg_activate_heavy_pistols = menu:get_reference( "rage", "weapons", "heavy pistols", "Smart min dmg")
local smart_min_dmg_amount_heavy_pistols = menu:get_reference( "rage", "weapons", "heavy pistols", "Smart amount")
--other
local other_min_dmg = menu:get_reference( "rage", "weapons", "other", "Min-damage" )
local smart_min_dmg_activate_other = menu:get_reference( "rage", "weapons", "other", "Smart min dmg")
local smart_min_dmg_amount_other = menu:get_reference( "rage", "weapons", "other", "Smart amount")
-------------------------------------------------------------------------------

-- function
function on_paint( )
	if not engine_client:is_in_game( ) then
		return end
        
    local local_player = entity_list:get_localplayer( )

    if not local_player:is_alive( ) then
		return end
	--awp
	if smart_min_dmg_activate_awp:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_awp:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				awp_min_dmg:set_int( enemy_health + smart_min_dmg_amount_awp:get_int( ))
            end
        end
	end
	--auto
	if smart_min_dmg_activate_auto:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_auto:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				auto_min_dmg:set_int( enemy_health + smart_min_dmg_amount_auto:get_int( ))
            end
        end
	end
	--pistols
	if smart_min_dmg_activate_pistols:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_pistols:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				pistols_min_dmg:set_int( enemy_health + smart_min_dmg_amount_pistols:get_int( ))
            end
        end
	end
	--scout
	if smart_min_dmg_activate_scout:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_scout:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				scout_min_dmg:set_int( enemy_health + smart_min_dmg_amount_scout:get_int( ))
            end
        end
	end
	--heavy pistols
	if smart_min_dmg_activate_heavy_pistols:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_heavy_pistols:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				heavy_pistols_min_dmg:set_int( enemy_health + smart_min_dmg_amount_heavy_pistols:get_int( ))
            end
        end
	end
	--other
	if smart_min_dmg_activate_other:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_other:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				other_min_dmg:set_int( enemy_health + smart_min_dmg_amount_other:get_int( ))
            end
        end
	end
end

-- callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )

--end
local render = fatality.render
local config = fatality.config
local menu = fatality.menu
local input = fatality.input

local toggle = false

local items = {
    
    autoS = config:add_item('autoS',0),
    awpS = config:add_item('awpS',0),
    pistolsS = config:add_item('pistolS',0),
    scoutS = config:add_item('scoutS',0),
    heavyPistolS = config:add_item('heavyPistolS',0),
    otherS = config:add_item('otherS',0),

    autoC = config:add_item('autoC',0),
    awpC = config:add_item('awpC',0),
    pistolsC = config:add_item('pistolC',0),
    scoutC = config:add_item('scoutC',0),
    heavyPistolC = config:add_item('heavyPistolC',0),
    otherC = config:add_item('otherC',0),

    autoR = config:add_item('autoR', menu:get_reference('rage', 'weapons', 'auto', 'min-damage'):get_int()),
    awpR = config:add_item('awpR', menu:get_reference('rage', 'weapons', 'awp', 'min-damage'):get_int()),
    pistolsR = config:add_item('pistolsR',menu:get_reference('rage', 'weapons', 'pistols', 'min-damage'):get_int()),
    scoutR = config:add_item('scoutR', menu:get_reference('rage', 'weapons', 'scout', 'min-damage'):get_int()),
    heavyPistolsR = config:add_item('heavyPistolsR',menu:get_reference('rage', 'weapons', 'heavy pistols', 'min-damage'):get_int()),
    otherR = config:add_item('otherR', menu:get_reference('rage', 'weapons', 'other', 'min-damage'):get_int()),

}

local toggles = {

    autoC = menu:add_checkbox('Damage on key','rage', 'weapons','auto',items.autoC),
    awpC = menu:add_checkbox('Damage on key','rage', 'weapons','awp',items.awpC),
    pistolsC = menu:add_checkbox('Damage on key','rage', 'weapons','pistols',items.pistolsC),
    scoutC = menu:add_checkbox('Damage on key','rage', 'weapons','scout',items.scoutC),
    heavyPistolC = menu:add_checkbox('Damage on key','rage', 'weapons','heavy pistols', items.heavyPistolC),
    otherC = menu:add_checkbox('Damage on key','rage', 'weapons','other',items.otherC),

    autoS = menu:add_slider('Damage on key','rage', 'weapons','auto',items.autoS, 0, 100, 1),
    awpS = menu:add_slider('Damage on key','rage', 'weapons','awp',items.awpS, 0, 100, 1),
    pistolsS = menu:add_slider('Damage on key','rage', 'weapons','pistols',items.pistolsS, 0, 100, 1),
    scoutS = menu:add_slider('Damage on key','rage', 'weapons','scout',items.scoutS, 0, 100, 1),
    heavyPistolS = menu:add_slider('Damage on key','rage', 'weapons','heavy pistols',items.heavyPistolS, 0, 100, 1),
    otherS = menu:add_slider('Damage on key','rage', 'weapons','other',items.otherS, 0, 100, 1),

    autoR = menu:add_slider('Damage off key','rage', 'weapons','auto', items.autoR,0,100,1),
    awpR = menu:add_slider('Damage off key','rage', 'weapons','awp', items.awpR,0,100,1),
    pistolsR = menu:add_slider('Damage off key','rage', 'weapons','pistols', items.pistolsR,0,100,1),
    scoutR = menu:add_slider('Damage off key','rage', 'weapons','scout', items.scoutR,0,100,1),
    heavyPistolsR = menu:add_slider('Damage off key','rage', 'weapons','heavy pistols', items.heavyPistolsR,0,100,1),
    otherR = menu:add_slider('Damage off key','rage', 'weapons','other', items.otherR,0,100,1),

}


local key = 0x12--change it here https://docs.microsoft.com/en-us/windows/win32/inputdev/virtual-key-co

function bean()

    local damageRef = {
        autoO = items.autoR:get_int(),
        awpO = items.awpR:get_int(),
        pistolsO = items.pistolsR:get_int(),
        scoutO = items.scoutR:get_int(),
        heavyPistolO = items.heavyPistolsR:get_int(),
        otherO = items.otherR:get_int(),
    
        auto = menu:get_reference('rage', 'weapons', 'auto', 'min-damage'),
        awp = menu:get_reference('rage', 'weapons', 'awp', 'min-damage'),
        pistols = menu:get_reference('rage', 'weapons', 'pistols', 'min-damage'),
        scout = menu:get_reference('rage', 'weapons', 'scout', 'min-damage'),
        heavyPistol = menu:get_reference('rage', 'weapons', 'heavy pistols', 'min-damage'),
        other = menu:get_reference('rage', 'weapons', 'other', 'min-damage'),
    }
--
    if items.autoC:get_bool() and input:is_key_down(key) then
            damageRef.auto:set_int(items.autoS:get_int())
    elseif items.autoC:get_bool() then
        damageRef.auto:set_int(damageRef.autoO)
    end
--
    if items.awpC:get_bool() and input:is_key_down(key) then
            damageRef.awp:set_int(items.awpS:get_int())
    elseif items.awpC:get_bool() then
        damageRef.awp:set_int(damageRef.awpO)
    end
--
    if items.pistolsC:get_bool() and input:is_key_down(key) then
            damageRef.pistols:set_int(items.pistolsS:get_int())
    elseif items.pistolsC:get_bool() then
        damageRef.pistols:set_int(damageRef.pistolsO)
    end
--
    if items.scoutC:get_bool() and input:is_key_down(key) then
            damageRef.scout:set_int(items.scoutC:get_int())
    elseif items.scoutC:get_bool() then
        damageRef.scout:set_int(damageRef.scoutO)
    end
--
    if items.heavyPistolC:get_bool() and input:is_key_down(key) then
        damageRef.heavyPistol:set_int(items.heavyPistolS:get_int())
    elseif items.heavyPistolC:get_bool() then
    damageRef.heavyPistol:set_int(damageRef.heavyPistolO)
--
    if items.otherC:get_bool() and input:is_key_down(key) then
        damageRef.other:set_int(items.otherS:get_int())
    elseif items.otherC:get_bool() then
    damageRef.other:set_int(damageRef.otherO)
    end
end
    

end
local callbacks = fatality.callbacks
callbacks:add('paint', bean)
--end