local entity_list = csgo.interface_handler:get_entity_list()
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local cvar = csgo.interface_handler:get_cvar()
local global_vars = csgo.interface_handler:get_global_vars()
local events = csgo.interface_handler:get_events()
local debug_overlay = csgo.interface_handler:get_debug_overlay()
local callbacks = fatality.callbacks
local fmath = fatality.math

local oldtickcount = global_vars.tickcount
local ragebotfov_cfg = config:add_item("ragebotfov", 0)
local ragebotfov_slider = menu:add_slider("FOV", "rage", "aimbot", "aimbot", ragebotfov_cfg, 0, 30, 1)
local aimbot_checkbox = menu:get_reference("rage", "aimbot", "aimbot", "aimbot")
local autofire_checkbox = menu:get_reference("rage", "aimbot", "aimbot", "autofire")

function on_paint()
    local localplayer = entity_list:get_localplayer()
    if(localplayer == nil or localplayer:is_alive() == false) then
        return
    end
    if(oldtickcount ~= global_vars.tickcount) then
        aimbot_checkbox:set_bool(false)
        autofire_checkbox:set_bool(false)
        for i = 1, entity_list:get_max_players() do
            local player = entity_list:get_player(i)
            if(player and player:is_alive() and player:is_dormant() == false) then
                local localteam = player:get_var_int("CBaseEntity->m_iTeamNum")
                local playerteam = localplayer:get_var_int("CBaseEntity->m_iTeamNum")
                if(playerteam ~= localteam) then
                    local angle = fmath:calc_angle(localplayer:get_eye_pos(), player:get_eye_pos())
                    local localangle = localplayer:get_var_angle("CCSPlayer->m_angEyeAngles")
                    local anglediff = csgo.angle(angle.x - localangle.x, angle.y - localangle.y, 0)
                    local angletotarget = math.sqrt(anglediff.x ^ 2 + anglediff.y ^ 2)
                    if(angletotarget > 180) then
                        angletotarget = angletotarget - 360
                    end
                    if(angletotarget < -180) then
                        angletotarget = angletotarget + 360
                    end
                    angletotarget = math.abs(angletotarget)
                
                    if(angletotarget < ragebotfov_cfg:get_int()) then
                        aimbot_checkbox:set_bool(true)
                        autofire_checkbox:set_bool(true)
                    end
                end
            end
        end
    
        oldtickcount = global_vars.tickcount
    end
end

callbacks:add("paint", on_paint)