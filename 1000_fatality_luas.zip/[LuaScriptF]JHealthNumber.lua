--callbacks
local callbacks = fatality.callbacks
local events = csgo.interface_handler:get_events()
--interfaces
local menu = fatality.menu
local input = fatality.input
local config = fatality.config
local render = fatality.render
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )
local scrnsize = render:screen_size( )

----
local actv_health = config:add_item( "actv_health", 1 )
local slider_r = config:add_item( "slider_r", 1 )
local slider_g = config:add_item( "slider_g", 1 )
local slider_b = config:add_item( "slider_b", 1 )
local slider_a = config:add_item( "slider_a", 1 )
local xinc = config:add_item( "xinc", 1 )
local yinc = config:add_item( "yinc", 1 )

local actv_health = menu:add_checkbox( "health", "visuals", "misc", "beams", actv_health)
local slider_r = menu:add_slider( "r", "visuals", "misc", "beams", slider_r, 0, 255, 1)
local slider_g = menu:add_slider( "g", "visuals", "misc", "beams", slider_g, 0, 255, 1)
local slider_b = menu:add_slider( "b", "visuals", "misc", "beams", slider_b, 0, 255, 1)
local slider_a = menu:add_slider( "a", "visuals", "misc", "beams", slider_a, 0, 255, 1)
local xinc = menu:add_slider( "x", "visuals", "misc", "beams", xinc, -100, 100, 1)
local yinc = menu:add_slider( "y", "visuals", "misc", "beams", yinc, -100, 100, 1)
local actv_health = menu:get_reference( "visuals", "misc", "beams", "health" )
local slider_r = menu:get_reference( "visuals", "misc", "beams", "r" )
local slider_g = menu:get_reference( "visuals", "misc", "beams", "g" )
local slider_b = menu:get_reference( "visuals", "misc", "beams", "b" )
local slider_a = menu:get_reference( "visuals", "misc", "beams", "a" )
local xinc = menu:get_reference( "visuals", "misc", "beams", "x" )
local yinc = menu:get_reference( "visuals", "misc", "beams", "y" )
----

--init
local courier_new = render:create_font( "Small Fonts", 12, 1, true ) --create font

function on_paint( ) --paint event (called every frame)
    local r = slider_r:get_int( )
    local g = slider_g:get_int( )
    local b = slider_b:get_int( )
    local a = slider_a:get_int( )
    local xinc = xinc:get_int( )
    local yinc = yinc:get_int( )
    local local_player = entity_list:get_localplayer( ) --get local player
	for i = 1, entity_list:get_max_players( ) do
		local player = entity_list:get_player( i )
		if actv_health:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") and player:get_index( ) ~= local_player:get_index ( ) then
		local pos = player:get_eye_pos( )
		local local_pos = local_player:get_eye_pos( )
		local_pos = csgo.vector3( local_pos.x, local_pos.y, local_pos.z - 10)
		pos = csgo.vector3( pos.x, pos.y, pos.z )
			local health_enemy = player:get_var_int( "CBasePlayer->m_iHealth" )
			local text_size = render:text_size( courier_new, name )	
			if pos:to_screen( ) then
				render:text( courier_new, pos.x + xinc, pos.y + yinc, health_enemy, csgo.color(r,g,b,a) )
			end
		end
	end
end
callbacks:add( "paint", on_paint ) --callbacks