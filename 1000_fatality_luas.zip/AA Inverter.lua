--          Cheat Stuff
local config = fatality.config
local menu = fatality.menu
local input = fatality.input
local callbacks = fatality.callbacks

--           References
-- Standing
local standing_yawamount = menu:get_reference("rage", "anti-aim", "standing", "add")
local standing_fakeamount = menu:get_reference("rage", "anti-aim", "standing", "fake amount")
-- Moving
local moving_yawamount = menu:get_reference("rage", "anti-aim", "moving", "add")
local moving_fakeamount = menu:get_reference("rage", "anti-aim", "moving", "fake amount")
-- Air
local air_yawamount = menu:get_reference("rage", "anti-aim", "air", "add")
local air_fakeamount = menu:get_reference("rage", "anti-aim", "air", "fake amount")
--          Config Tree
local master_switch = config:add_item("master_switch", 0)
local inverter_item = config:add_item("invert_key picker item", 0)
--          Menu Items
local watermark = menu:add_button("Visa's Inverter", "rage", "anti-aim", "general")
local master_switch_checkbox = menu:add_checkbox("Enable Script", "rage", "anti-aim", "general", master_switch)
local KeyPicker = menu:add_combo("Inverter Key", "rage", "anti-aim", "general", inverter_item)
KeyPicker:add_item("-", inverter_item)
KeyPicker:add_item("Mouse1", inverter_item)
KeyPicker:add_item("Mouse2", inverter_item)
KeyPicker:add_item("Mouse3", inverter_item)
KeyPicker:add_item("Mouse5", inverter_item)
KeyPicker:add_item("Mouse6", inverter_item)
KeyPicker:add_item("Alt", inverter_item)
KeyPicker:add_item("Q", inverter_item)
KeyPicker:add_item("W", inverter_item)
KeyPicker:add_item("E", inverter_item)
KeyPicker:add_item("R", inverter_item)
KeyPicker:add_item("T", inverter_item)
KeyPicker:add_item("Y", inverter_item)
KeyPicker:add_item("U", inverter_item)
KeyPicker:add_item("I", inverter_item)
KeyPicker:add_item("O", inverter_item)
KeyPicker:add_item("P", inverter_item)
KeyPicker:add_item("A", inverter_item)
KeyPicker:add_item("S", inverter_item)
KeyPicker:add_item("D", inverter_item)
KeyPicker:add_item("F", inverter_item)
KeyPicker:add_item("G", inverter_item)
KeyPicker:add_item("H", inverter_item)
KeyPicker:add_item("J", inverter_item)
KeyPicker:add_item("K", inverter_item)
KeyPicker:add_item("L", inverter_item)
KeyPicker:add_item("Z", inverter_item)
KeyPicker:add_item("X", inverter_item)
KeyPicker:add_item("C", inverter_item)
KeyPicker:add_item("V", inverter_item)
KeyPicker:add_item("B", inverter_item)
KeyPicker:add_item("N", inverter_item)
KeyPicker:add_item("M", inverter_item)

--          Functions
local invert_key
function get_inverter_key()
    if inverter_item:get_int() == 1 then
        invert_key = 0x01
    elseif inverter_item:get_int() == 2 then
        invert_key = 0x02
    elseif inverter_item:get_int() == 3 then
        invert_key = 0x04
    elseif inverter_item:get_int() == 4 then
        invert_key = 0x05
    elseif inverter_item:get_int() == 5 then
        invert_key = 0x06
    elseif inverter_item:get_int() == 6 then
        invert_key = 0x12
    elseif inverter_item:get_int() == 7 then
        invert_key = 0x51
    elseif inverter_item:get_int() == 8 then
        invert_key = 0x57
    elseif inverter_item:get_int() == 9 then
        invert_key = 0x45
    elseif inverter_item:get_int() == 10 then
        invert_key = 0x52
    elseif inverter_item:get_int() == 11 then
        invert_key = 0x54
    elseif inverter_item:get_int() == 12 then
        invert_key = 0x59
    elseif inverter_item:get_int() == 13 then
        invert_key = 0x55
    elseif inverter_item:get_int() == 14 then
        invert_key = 0x49
    elseif inverter_item:get_int() == 15 then
        invert_key = 0x4F
    elseif inverter_item:get_int() == 16 then
        invert_key = 0x50
    elseif inverter_item:get_int() == 17 then
        invert_key = 0x41
    elseif inverter_item:get_int() == 18 then
        invert_key = 0x53
    elseif inverter_item:get_int() == 19 then
        invert_key = 0x44
    elseif inverter_item:get_int() == 20 then
        invert_key = 0x46
    elseif inverter_item:get_int() == 21 then
        invert_key = 0x47
    elseif inverter_item:get_int() == 22 then
        invert_key = 0x48
    elseif inverter_item:get_int() == 23 then
        invert_key = 0x4A
    elseif inverter_item:get_int() == 24 then
        invert_key = 0x4B
    elseif inverter_item:get_int() == 25 then
        invert_key = 0x4C
    elseif inverter_item:get_int() == 26 then
        invert_key = 0x5A
    elseif inverter_item:get_int() == 27 then
        invert_key = 0x58
    elseif inverter_item:get_int() == 28 then
        invert_key = 0x43
    elseif inverter_item:get_int() == 29 then
        invert_key = 0x56
    elseif inverter_item:get_int() == 30 then
        invert_key = 0x42
    elseif inverter_item:get_int() == 31 then
        invert_key = 0x4E
    elseif inverter_item:get_int() == 32 then
        invert_key = 0x4D
    else
        invert_key = 0x73
    end
end

-- Inverter
function inverter()
    -- Calculation for what to set values as
    local calc_standing_yaw = standing_yawamount:get_int() - standing_yawamount:get_int() * 2
    local calc_standing_fakeamount = standing_fakeamount:get_int() - standing_fakeamount:get_int() * 2
    local calc_moving_fakeamount = moving_fakeamount:get_int() - moving_fakeamount:get_int() * 2
    local calc_moving_yaw = moving_yawamount:get_int() - moving_yawamount:get_int() * 2
    local calc_air_yaw = air_yawamount:get_int() - air_yawamount:get_int() * 2
    local calc_air_fakeamount = air_fakeamount:get_int() - air_fakeamount:get_int() * 2

    if (master_switch:get_bool(true)) then
        if (input:is_key_pressed(invert_key)) then
            standing_yawamount:set_int(calc_standing_yaw)
            standing_fakeamount:set_int(calc_standing_fakeamount)
            --
            moving_fakeamount:set_int(calc_moving_fakeamount)
            moving_yawamount:set_int(calc_moving_yaw)
            --
            air_yawamount:set_int(calc_air_yaw)
            air_fakeamount:set_int(calc_air_fakeamount)
        end
    end
end
--          Paint Callbacks
function paint_callbacks()
    get_inverter_key()
    inverter()
end
callbacks:add("paint", paint_callbacks)