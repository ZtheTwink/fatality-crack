-- grab render interface to render
local render = fatality.render
-- grab config interface to config
local config = fatality.config
-- grab menu interface to menu
local menu = fatality.menu

-- get all needed accessable interfaces
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )

-- create config & menu items
local draw_hitbox_on_hit = config:add_item( "draw_hitbox_on_hit", 0.0 )
local draw_hitbox_on_hit_duration = config:add_item( "draw_hitbox_on_hit_duration", 2.0 )
local draw_shots = config:add_item( "draw_shots", 0.0 )
local menu_checkbox = menu:add_checkbox( "Draw hit hitbox", "visuals", "misc", "various", draw_hitbox_on_hit )
local menu_slider = menu:add_slider( "Duration", "visuals", "misc", "various", draw_hitbox_on_hit_duration, 1.0, 10.0, 0.2 )
local menu_checkbox = menu:add_checkbox( "Draw indented/server impact line", "visuals", "misc", "various", draw_shots )

-- will be called every time a registered event gets fired
function on_shot( shot )

    -- check if checkbox enabled
    if not draw_hitbox_on_hit:get_bool() then
        return end

    -- get the victim of the shot
    player = entity_list:get_player( shot.victim )
    if player == nil then
        return end

    -- create color variable as it is used multiple times
    local col_pink = csgo.color( 200, 0, 90, 255 )
      
    if draw_shots:get_bool() then

        -- draw line to the intended hit position
        debug_overlay:add_line_overlay( shot.shotpos, shot.target_hitpos, col_pink, true, 4 )

        -- draw line to the server hit position
        -- hint: constructors (for colors for example) can also be inlined just like in this example
        debug_overlay:add_line_overlay( shot.shotpos, shot.hitpos, csgo.color( 200, 200, 200, 255 ), true, 4 )

    end
  
    -- draw hitgroups
    -- hint: you can also pass -1 for the hitgroup to draw the whole matrix
    if shot.hurt then
        -- draw hit hitgroup when shot hurt the player
        render:draw_hitgroup( player, shot.record.matrix, shot.hit_hitgroup, draw_hitbox_on_hit_duration:get_float(), col_pink )
    else
        -- else draw the targeted hitgroup as no hurt hitgroup has been registered
        render:draw_hitgroup( player, shot.record.matrix, shot.target_hitgroup, draw_hitbox_on_hit_duration:get_float(), col_pink )
    end
      
end

-- register impacted shot callback
local callbacks = fatality.callbacks
callbacks:add( "registered_shot", on_shot )