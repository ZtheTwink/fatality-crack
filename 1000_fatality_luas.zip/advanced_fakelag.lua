-- Smart fake-lags by eslipe v.1.2 (current version of: 11.03.2019)
 
--[[ Updatelog:
 
(11.03.2019)
- Added "Disable if fakeduck" option
- Added "Disable on pistols" option
- Added "Disable on SMG" option
- Improved UI ( Made it easier to use )
- Fixed "Disable on grenades" function ( now works correctly)
 
]]
 
-- interfaces
local render = fatality.render
local input = fatality.input
local menu = fatality.menu
local config = fatality.config
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()
local entity_list = csgo.interface_handler:get_entity_list( )
 
local fl_stand_item = config:add_item( "fl_stand_item", 0 )
local fl_stand_checkbox = menu:add_checkbox( "Extra fake-lags", "rage", "anti-aim", "standing", fl_stand_item )
 
local fl_move_item = config:add_item( "fl_move_item", 0 )
local fl_move_checkbox = menu:add_checkbox( "Extra fake-lags", "rage", "anti-aim", "moving", fl_move_item )
 
local fl_air_item = config:add_item( "fl_air_item", 0 )
local fl_air_checkbox = menu:add_checkbox( "Extra fake-lags", "rage", "anti-aim", "air", fl_air_item )
 
 
 
local preset =
{
        standing = {
 
                disable_on_knife = config:add_item( "standing.disalbe_on_knife", 0 ),
                disable_on_taser = config:add_item( "standing.disalbe_on_taser", 0 ),
                disable_on_revolver = config:add_item( "standing.disalbe_on_resolver", 0 ),
                disable_on_pistols = config:add_item( "standing.disable_on_pistols", 0 ),
                disable_on_smg = config:add_item( "standing.disable_on_smg", 0 ),
                disable_on_grenades = config:add_item( "standing.disalbe_on_grenades", 0 ),
                disable_if_fakeducking = config:add_item( "standing.disable_if_fakeducking", 0 ),
 
        },
 
        moving = {
 
                disable_on_knife = config:add_item( "moving.disalbe_on_knife", 0 ),
                disable_on_taser = config:add_item( "moving.disalbe_on_taser", 0 ),
                disable_on_revolver = config:add_item( "moving.disalbe_on_resolver", 0 ),
                disable_on_pistols = config:add_item( "moving.disable_on_pistols", 0 ),
                disable_on_smg = config:add_item( "moving.disable_on_smg", 0 ),
                disable_on_grenades = config:add_item( "moving.disalbe_on_grenades", 0 ),
                disable_if_fakeducking = config:add_item( "moving.disable_if_fakeducking", 0 ),
       
        },
 
        air = {
 
                disable_on_knife = config:add_item( "air.disalbe_on_knife", 0 ),
                disable_on_taser = config:add_item( "air.disalbe_on_taser", 0 ),
                disable_on_revolver = config:add_item( "air.disalbe_on_resolver", 0 ),
                disable_on_pistols = config:add_item( "air.disable_on_pistols", 0 ),
                disable_on_smg = config:add_item( "air.disable_on_smg", 0 ),
                disable_on_grenades = config:add_item( "air.disalbe_on_grenades", 0 ),
                disable_if_fakeducking = config:add_item( "air.disable_if_fakeducking", 0 ),
       
        },
}
 
    local item =
{
        extraComboST = menu:add_multi_combo( "Fake-lag settings", "rage", "anti-aim", "standing" ):add_item( "Disable on knife", preset.standing.disable_on_knife ):add_item( "Disable on taser", preset.standing.disable_on_taser ):add_item( "Disable on revolver", preset.standing.disable_on_revolver ):add_item( "Disable on pistols", preset.standing.disable_on_pistols ):add_item( "Disable on SMG", preset.standing.disable_on_smg ):add_item( "Disable on grenades", preset.standing.disable_on_grenades ):add_item( "Disable if fakeduck", preset.standing.disable_if_fakeducking ),
 
        extraComboMV = menu:add_multi_combo( "Fake-lag settings", "rage", "anti-aim", "moving" ):add_item( "Disable on knife", preset.moving.disable_on_knife ):add_item( "Disable on taser", preset.moving.disable_on_taser ):add_item( "Disable on revolver", preset.moving.disable_on_revolver ):add_item( "Disable on pistols", preset.moving.disable_on_pistols ):add_item( "Disable on SMG", preset.moving.disable_on_smg ):add_item( "Disable on grenades", preset.moving.disable_on_grenades ):add_item( "Disable if fakeduck", preset.moving.disable_if_fakeducking ),
 
        extraComboAR = menu:add_multi_combo( "Fake-lag settings", "rage", "anti-aim", "air" ):add_item( "Disable on knife", preset.air.disable_on_knife ):add_item( "Disable on taser", preset.air.disable_on_taser ):add_item( "Disable on revolver", preset.air.disable_on_revolver ):add_item( "Disable on pistols", preset.air.disable_on_pistols ):add_item( "Disable on SMG", preset.air.disable_on_smg ):add_item( "Disable on grenades", preset.air.disable_on_grenades ):add_item( "Disable if fakeduck", preset.air.disable_if_fakeducking )
}
 
 
 
-- menu reference
local fl_standing = menu:get_reference( "rage", "anti-aim", "standing", "fake lag" )
local fl_moving = menu:get_reference( "rage", "anti-aim", "moving", "fake lag" )
local fl_air = menu:get_reference( "rage", "anti-aim", "air", "fake lag" )
local fakeduck = menu:get_reference( "rage", "aimbot", "aimbot", "fake duck" )
 
-- fonts
local small_pixel_11 = render:create_font( "Smallest Pixel-7", 11, 100, false );
 
-- getting screen size
local screen_size = render:screen_size( );
   
-- white colour static
local white_col = csgo.color(255, 255, 255, 255)
 
-- on_paint function
function on_paint()
 
-- weapon list
 weapontable = {
        [1] = "AK47",
        [32] = "C4",
        [44] = "Desert Eagle",
        [45] = "Decoy Grenade",
        [75] = "Flashbang",
        [94] = "Frag Grenade",
        [97] = "Incendiary Grenade",
        [110] = "Molotov Grenade",
        [105] = "Knife",
        [152] = "Smoke Grenade",
        [228] = "AUG",
        [229] = "AWP",
        [231] = "Bizon",
        [235] = "Dualies",
        [237] = "Five Seven",
        [238] = "G3SG1",
        [240] = "Galil-AR",
        [241] = "Glock",
        [242] = "P2000",
        [243] = "M249",
        [245] = "M4A1",
        [249] = "MP7",
        [250] = "MP9",
        [247] = "Mag7",
        [252] = "Nova",
        [251] = "Negev",
        [254] = "P250",
        [255] = "P90",
        [257] = "SCAR20",
        [261] = "SG556",
        [262] = "SSG08",
        [263] = "Taser",
        [264] = "Tec9",
        [266] = "UMP45",
        [268] = "XM1014",
 }
 
-- local player variable
local local_player = entity_list:get_localplayer( );
 
-- nil value check
if local_player == nil then
    return
end
 
-- local player active weapon
 local weapon = csgo.interface_handler:get_entity_list():get_from_handle(local_player:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) )
 
-- nil value check
if weapon == nil then
    return
end
 
 -- weapon index
 local weaponindex = weapon:get_class_id()
 
 -- renaming weapon index to weapon name
 local weaponname = weapontable[weaponindex]
 
        -- [ STANDING ]
        if fl_stand_item:get_bool() then
                if ( preset.standing.disable_on_knife:get_bool() and weaponindex == 105 ) or --< on knife [ standing ]
                   ( preset.standing.disable_on_taser:get_bool() and weaponindex == 263 ) or --< on taser [ standing ]
                   ( preset.standing.disable_on_grenades:get_bool() and weaponindex == 110 or preset.standing.disable_on_grenades:get_bool() and weaponindex == 97 or preset.standing.disable_on_grenades:get_bool() and weaponindex == 94 or preset.standing.disable_on_grenades:get_bool() and weaponindex == 75 or preset.standing.disable_on_grenades:get_bool() and weaponindex == 45 or preset.standing.disable_on_grenades:get_bool() and weaponindex == 152 ) or --< on grenades [ standing ]
                   ( preset.standing.disable_on_revolver:get_bool() and weaponindex == 44 ) or --< on revolver [ standing ]
                   ( preset.standing.disable_on_pistols:get_bool() and weaponindex == 235 or preset.standing.disable_on_pistols:get_bool() and weaponindex == 237 or preset.standing.disable_on_pistols:get_bool() and weaponindex == 241 or preset.standing.disable_on_pistols:get_bool() and weaponindex == 242 or preset.standing.disable_on_pistols:get_bool() and weaponindex == 254 or preset.standing.disable_on_pistols:get_bool() and weaponindex == 264 ) or --< on pistols [ standing ]
                   ( preset.standing.disable_on_smg:get_bool() and weaponindex == 231 or preset.standing.disable_on_smg:get_bool() and weaponindex == 249 or preset.standing.disable_on_smg:get_bool() and weaponindex == 250 or preset.standing.disable_on_smg:get_bool() and weaponindex == 266 or preset.standing.disable_on_smg:get_bool() and weaponindex == 255 ) or --< on SMG [ standing ]
                   ( preset.standing.disable_if_fakeducking:get_bool() and fakeduck:get_bool() == true ) then --< if fakeducking [ standing ]
                   fl_standing:set_bool(false)
                else
                   fl_standing:set_bool(true)
                end
        end
   
 
        -- [ MOVING ]
        if fl_move_item:get_bool() then
                if ( preset.moving.disable_on_knife:get_bool() and weaponindex == 105 ) or --< on knife [ moving ]
                   ( preset.moving.disable_on_taser:get_bool() and weaponindex == 263 ) or --< on taser [ moving ]
                   ( preset.moving.disable_on_grenades:get_bool() and weaponindex == 110 or preset.moving.disable_on_grenades:get_bool() and weaponindex == 97 or preset.moving.disable_on_grenades:get_bool() and weaponindex == 94 or preset.moving.disable_on_grenades:get_bool() and weaponindex == 75 or preset.moving.disable_on_grenades:get_bool() and weaponindex == 45 or preset.moving.disable_on_grenades:get_bool() and weaponindex == 152 ) or --< on grenades [ moving ]
                   ( preset.moving.disable_on_revolver:get_bool() and weaponindex == 44 ) or --< on revolver [ moving ]
                   ( preset.moving.disable_on_pistols:get_bool() and weaponindex == 235 or preset.moving.disable_on_pistols:get_bool() and weaponindex == 237 or preset.moving.disable_on_pistols:get_bool() and weaponindex == 241 or preset.moving.disable_on_pistols:get_bool() and weaponindex == 242 or preset.moving.disable_on_pistols:get_bool() and weaponindex == 254 or preset.moving.disable_on_pistols:get_bool() and weaponindex == 264 ) or --< on pistols [ moving ]
                   ( preset.moving.disable_on_smg:get_bool() and weaponindex == 231 or preset.moving.disable_on_smg:get_bool() and weaponindex == 249 or preset.moving.disable_on_smg:get_bool() and weaponindex == 250 or preset.moving.disable_on_smg:get_bool() and weaponindex == 266 or preset.moving.disable_on_smg:get_bool() and weaponindex == 255 ) or --< on SMG [ moving ]
                   ( preset.moving.disable_if_fakeducking:get_bool() and fakeduck:get_bool() == true ) then --< if fakeducking [ moving ]
                   fl_moving:set_bool(false)
                else
                   fl_moving:set_bool(true)
                end
        end
     
               
        -- [ AIR ]
        if fl_air_item:get_bool() then
                if ( preset.air.disable_on_knife:get_bool() and weaponindex == 105 ) or --< on knife [ air ]
                   ( preset.air.disable_on_taser:get_bool() and weaponindex == 263 ) or --< on taser [ air ]
                   ( preset.air.disable_on_grenades:get_bool() and weaponindex == 110 or weaponindex == 97 or preset.air.disable_on_grenades:get_bool() and weaponindex == 94 or preset.air.disable_on_grenades:get_bool() and weaponindex == 75 or preset.air.disable_on_grenades:get_bool() and weaponindex == 45 or preset.air.disable_on_grenades:get_bool() and weaponindex == 152 ) or --< on grenades [ air ]
                   ( preset.air.disable_on_revolver:get_bool() and weaponindex == 44 ) or --< on revolver [ air ]
                   ( preset.air.disable_on_pistols:get_bool() and weaponindex == 235 or preset.air.disable_on_pistols:get_bool() and weaponindex == 237 or preset.air.disable_on_pistols:get_bool() and weaponindex == 241 or preset.air.disable_on_pistols:get_bool() and weaponindex == 242 or preset.air.disable_on_pistols:get_bool() and weaponindex == 254 or preset.air.disable_on_pistols:get_bool() and weaponindex == 264 ) or --< on pistols [ air ]
                   ( preset.air.disable_on_smg:get_bool() and weaponindex == 231 or preset.air.disable_on_smg:get_bool() and weaponindex == 249 or preset.air.disable_on_smg:get_bool() and weaponindex == 250 or preset.air.disable_on_smg:get_bool() and weaponindex == 266 or preset.air.disable_on_smg:get_bool() and weaponindex == 255 ) or --< on SMG [ air ]
                   ( preset.air.disable_if_fakeducking:get_bool() and fakeduck:get_bool() == true ) then --< if fakeducking [ air ]
                   fl_air:set_bool(false)
                else
                   fl_air:set_bool(true)
                end
        end
       
end
 
 
 
-- callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )
 
-- end of the code