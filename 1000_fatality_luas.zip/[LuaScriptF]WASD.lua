local render = fatality.render;
local input = fatality.input;

local keys_pressed = {
w, a,
s, d,
space = false;
}

function manage_input( )
--is_key_down
if ( input:is_key_down( 87 ) ) then
keys_pressed.w = true;
else keys_pressed.w = false;
end
if ( input:is_key_down( 65 ) ) then
keys_pressed.a = true;
else keys_pressed.a = false;
end
if ( input:is_key_down( 83 ) ) then
keys_pressed.s = true;
else keys_pressed.s = false;
end
if ( input:is_key_down( 68 ) ) then
keys_pressed.d = true;
else keys_pressed.d = false;
end
if ( input:is_key_down( 32 ) ) then
keys_pressed.space = true;
else keys_pressed.space = false;
end 
end

local font = render:create_font( "Tahoma bold", 40, 400, false )
function on_paint( )
manage_input( );
local screen_size = render:screen_size( );
--W Render
if ( keys_pressed.w ) then w_alpha = 130; else w_alpha = 50; end
render:rect_filled( screen_size.x / 20.5, screen_size.y / 2 + -20, 50, 50, csgo.color( 61,42,96,w_alpha ) );
render:text( font, screen_size.x / 19, screen_size.y / 2 + -20, "W", csgo.color( 255,255,255,255 ) );
--A Render
if ( keys_pressed.a ) then a_alpha = 130; else a_alpha = 50; end
render:rect_filled( screen_size.x / 55 + 3, screen_size.y / 2 + 35, 50, 50, csgo.color( 61,42,96,a_alpha ) );
render:text( font, screen_size.x / 38, screen_size.y / 2 + 35, "A", csgo.color( 255,255,255,255 ) );
--S Render
if ( keys_pressed.s ) then s_alpha = 130; else s_alpha = 50; end
render:rect_filled( screen_size.x / 20.5, screen_size.y / 2 + 35, 50, 50, csgo.color( 61,42,96,s_alpha ) );
render:text( font, screen_size.x / 17.8, screen_size.y / 2 + 35, "S", csgo.color( 255,255,255,255 ) );
--D Render
if ( keys_pressed.d ) then d_alpha = 130; else d_alpha = 50; end
render:rect_filled( screen_size.x / 12.9, screen_size.y / 2 + 35, 50, 50, csgo.color( 61,42,96,d_alpha ) );
render:text( font, screen_size.x / 12, screen_size.y / 2 + 35, "D", csgo.color( 255,255,255,255 ) );
--Space Render
if ( keys_pressed.space ) then space_alpha = 130; else space_alpha = 50; end
render:rect_filled( screen_size.x / 52, screen_size.y / 2 + 90, 160.5, 45, csgo.color( 61,42,96,space_alpha ) );
render:text( font, screen_size.x / 30, screen_size.y / 2 + 90, "SPACE", csgo.color( 255,255,255,255 ) );

end
--render:text( font, screen_size.x / 12.3, screen_size.y / 2 + 145, "D", csgo.color( 255,255,255,255 ) );

local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint );