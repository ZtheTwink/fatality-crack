local config = fatality.config;
local menu = fatality.menu;
local render = fatality.render;
local callbacks = fatality.callbacks;

local custom_hud_checkbox_item = config:add_item('visuals_custom_hud', 0);
local custom_hud_checkbox = menu:add_checkbox('Custom Hud', 'Visuals', 'Misc', 'Various', custom_hud_checkbox_item);

local engine_client = csgo.interface_handler:get_engine_client();
local entity_list = csgo.interface_handler:get_entity_list();
local events = csgo.interface_handler:get_events();
local cvar = csgo.interface_handler:get_cvar();

local screen_size = render:screen_size();
local create_large_font = render:create_font('Calibri Light', 50, 300, true);
local create_icon_font = render:create_font('custom_csgo_icons', 50, 300, true);

events:add_event('player_say');
events:add_event('player_changename');
events:add_event('round_end');
events:add_event('round_mvp');

local function find_weapon_from_index(index)
    if index == 1 then
        return 'Desert Eagle';
    elseif index == 2 then
        return 'Dual Berettas';
    elseif index == 3 then
        return 'Five-Seven';
    elseif index == 4 then
        return 'Glock-18';
    elseif index == 7 then
        return 'AK-47';
    elseif index == 8 then
        return 'AUG';
    elseif index == 9 then
        return 'AWP';
    elseif index == 10 then
        return 'FAMAS';
    elseif index == 11 then
        return 'G3SG1';
    elseif index == 13 then
        return 'Galil AR';
    elseif index == 14 then
        return 'M249';
    elseif index == 16 then
        return 'M4A4';
    elseif index == 17 then
        return 'MAC-10';
    elseif index == 19 then
        return 'P90';
    elseif index == 23 then
        return 'MP5-SD';
    elseif index == 24 then
        return 'UMP-45';
    elseif index == 25 then
        return 'XM1014';
    elseif index == 26 then
        return 'PP-Bizon';
    elseif index == 27 then
        return 'MAG-7';
    elseif index == 28 then
        return 'Negev';
    elseif index == 29 then
        return 'Sawed-Off';
    elseif index == 30 then
        return 'Tec-9';
    elseif index == 31 then
        return 'Zeus x27';
    elseif index == 32 then
        return 'P2000';
    elseif index == 33 then
        return 'MP7';
    elseif index == 34 then
        return 'MP9';
    elseif index == 35 then
        return 'Nova';
    elseif index == 36 then
        return 'P250';
    elseif index == 37 then
        return 'Ballistic Shield';
    elseif index == 38 then
        return 'SCAR-20';
    elseif index == 39 then
        return 'SG 553';
    elseif index == 40 then
        return 'SSG 08';
    elseif index == 41 then
        return 'Knife';
    elseif index == 42 then
        return 'Knife';
    elseif index == 43 then
        return 'Flashbang';
    elseif index == 44 then
        return 'High Explosive Grenade';
    elseif index == 45 then
        return 'Smoke Grenade';
    elseif index == 46 then
        return 'Molotov';
    elseif index == 47 then
        return 'Decoy Grenade';
    elseif index == 48 then
        return 'Incendiary Grenade';
    elseif index == 49 then
        return 'C4 Explosive';
    elseif index == 57 then
        return 'Medi-Shot';
    elseif index == 59 then
        return 'Knife';
    elseif index == 60 then
        return 'M4A1-S';
    elseif index == 61 then
        return 'USP-S';
    elseif index == 63 then
        return 'CZ75-Auto';
    elseif index == 64 then
        return 'R8 Revolver';
    elseif index == 74 then
        return 'Knife';
    elseif index == 81 then
        return 'Fire Bomb';
    elseif index == 82 then
        return 'Diversion Device';
    elseif index == 83 then
        return 'Frag Grenade';
    elseif index == 84 then
        return 'Snowball';
    elseif index == 500 then
        return 'Bayonet';
    elseif index == 505 then
        return 'Flip Knife';
    elseif index == 506 then
        return 'Gut Knife';
    elseif index == 507 then
        return 'Karambit';
    elseif index == 508 then
        return 'M9 Bayonet';
    elseif index == 509 then
        return 'Huntsman Knife';
    elseif index == 512 then
        return 'Falchion Knife';
    elseif index == 514 then
        return 'Bowie Knife';
    elseif index == 515 then
        return 'Butterfly Knife';
    elseif index == 516 then
        return 'Shadow Daggers';
    elseif index == 519 then
        return 'Ursus Knife';
    elseif index == 520 then
        return 'Navaja Knife';
    elseif index == 522 then
        return 'Stiletto Knife';
    elseif index == 523 then
        return 'Talon Knife';
    else
        return 'Unknown Weapon';
    end
end

local function draw_left_section(local_player)
    local health = local_player:get_var_int('CBasePlayer->m_iHealth');
    local armor_value = local_player:get_var_int('CCSPlayer->m_ArmorValue');
    local account = local_player:get_var_int('CCSPlayer->m_iAccount');

    if health == nil or armor_value == nil or account == nil then
        return;
    end

    local base_width = 15;
    local base_height = screen_size.y / 2;
    local health_height = base_height + 370;
    local armor_height = base_height + 425;
    local account_height = base_height + 480;

    render:text(create_icon_font, base_width, health_height, 'p', csgo.color(255, 255, 255, 255));
    render:text(create_icon_font, base_width, armor_height, 'q', csgo.color(255, 255, 255, 255));
    render:text(create_icon_font, base_width, account_height, 'x', csgo.color(255, 255, 255, 255));
    render:text(create_large_font, base_width * 4, health_height, health, csgo.color(255, 255, 255, 255));
    render:text(create_large_font, base_width * 4, armor_height, armor_value, csgo.color(255, 255, 255, 255));
    render:text(create_large_font, base_width * 4, account_height, '$' .. account, csgo.color(255, 255, 255, 255));
end

local function draw_right_section(local_player)
    local active_weapon_handle = local_player:get_var_handle('CBaseCombatCharacter->m_hActiveWeapon');
    
    if active_weapon_handle == nil then
        return;
    end
    
    local active_weapon = entity_list:get_from_handle(active_weapon_handle);

    if active_weapon == nil then
        return;
    end

    local ammo_in_clip = active_weapon:get_var_int('CBaseCombatWeapon->m_iClip1');
    local ammo_reserved = active_weapon:get_var_int('CBaseCombatWeapon->m_iPrimaryReserveAmmoCount');
    local item_definition_index = active_weapon:get_var_int('CBaseAttributableItem->m_iItemDefinitionIndex') & 65535;

    if ammo_in_clip == nil or ammo_reserved == nil or item_definition_index == nil then
        return;
    end

    if ammo_in_clip == -1 then
        ammo_size = 'Infinite Ammo';
    else
        ammo_size = ammo_in_clip .. '/' .. ammo_reserved;
    end

    if ammo_size == nil then
        return;
    end

    local weapon_ammo = render:text_size(create_large_font, ammo_size);
    local weapon_name = render:text_size(create_large_font, find_weapon_from_index(item_definition_index));

    local base_width = 20;
    local base_height = screen_size.y / 2;
    local weapon_ammo_height = base_height + 425;
    local weapon_name_height = base_height + 480;

    render:text(create_large_font, screen_size.x - weapon_ammo.x - base_width, weapon_ammo_height, ammo_size, csgo.color(255, 255, 255, 255));
    render:text(create_large_font, screen_size.x - weapon_name.x - base_width, weapon_name_height, find_weapon_from_index(item_definition_index), csgo.color(255, 255, 255, 255));
end

local function draw_hud()
    local local_player = entity_list:get_localplayer(); 

    if local_player == nil then
        return;
    end

    draw_left_section(local_player);
    draw_right_section(local_player);
end

local function on_paint()
    if not engine_client:is_connected() and not engine_client:is_in_game() then
        return;
    end

    local cl_draw_only_deathnotices = cvar:find_var('cl_draw_only_deathnotices');

    if custom_hud_checkbox_item:get_bool() then
        cl_draw_only_deathnotices:set_int(1);

        draw_hud();
    else
        cl_draw_only_deathnotices:set_int(0);
    end
end

local function on_events(event)
    if not custom_hud_checkbox_item:get_bool() then
        return;
    end

    if not engine_client:is_connected() and not engine_client:is_in_game() then
        return;
    end

    if event:get_name() == 'player_say' then
        local event_user_id = event:get_int('userid');
        local event_text = event:get_string('text');

        if event_user_id == nil or event_text == nil then
            return;
        end

        if string.len(event_text) > 64 then
            event_text = string.sub(event_text, 0, 64);
        end

        local user_id = entity_list:get_player_from_id(event_user_id);

        if user_id == nil then
            return;
        end

        local name = user_id:get_name();

        if name == nil then
            return;
        end

        if string.len(name) > 32 then
            name = string.sub(name, 0, 32);
        end

        cvar:print_dev_console(name .. ': ' .. event_text .. '\n')
    end

    if event:get_name() == 'player_changename' then
        local event_old_name = event:get_string('oldname');
        local event_new_name = event:get_string('newname');

        if event_old_name == nil or event_new_name == nil then
            return;
        end

        if string.len(event_old_name) > 32 then
            event_old_name = string.sub(event_old_name, 0, 32);
        end

        if string.len(event_new_name) > 32 then
            event_new_name = string.sub(event_new_name, 0, 32);
        end

        cvar:print_dev_console(event_old_name .. ' has changed their name to ' .. event_new_name .. '\n')
    end

    if event:get_name() == 'round_end' then
        cvar:print_dev_console('The round has ended\n');
    end

    if event:get_name() == 'round_mvp' then
        local event_user_id = event:get_int('userid');

        if event_user_id == nil then
            return;
        end

        local user_id = entity_list:get_player_from_id(event_user_id);

        if user_id == nil then
            return;
        end

        local name = user_id:get_name();

        if name == nil then
            return;
        end

        if string.len(name) > 32 then
            name = string.sub(name, 0, 32);
        end

        cvar:print_dev_console(name .. ' was the round mvp\n');
    end
end

callbacks:add('paint', on_paint);
callbacks:add('events', on_events);