

-------------------------------------------------------------------hc-on-dt-by-jewls-----------------------------------------------
local config = fatality.config
local menu = fatality.menu
local dtHcToggle = config:add_item("dt toggle", 1)
local dtHcToggleCheck = menu:add_checkbox("Dt Hitchance", "RAGE", "AIMBOT", "Aimbot",dtHcToggle)

local staticHcAuto = config:add_item("static hc auto", 0)
local staticHcPistol = config:add_item("static hc pistol", 0)
local staticHcHeavyPistol = config:add_item("static hc heavy pistol", 0)
local staticHcOther = config:add_item("static hc other", 0)
--hitchance will go to this when dt is off
local staticHcAutoSlider = menu:add_slider("Static HC", "RAGE", "WEAPONS", "Auto", staticHcAuto, 0,100,1)
local staticHcPistolSlider = menu:add_slider("Static HC", "RAGE", "WEAPONS", "Pistols", staticHcPistol, 0,100,1)
local staticHcHeavyPistolSlider = menu:add_slider("Static HC", "RAGE", "WEAPONS", "Heavy pistols", staticHcHeavyPistol, 0,100,1)
local staticHcOtherSlider = menu:add_slider("Static HC", "RAGE", "WEAPONS", "Other", staticHcOther, 0,100,1)
--yes i know there is a more efficent way to write this but i like the way this looks change it if you want

--slider items
local autoItem = config:add_item( "auto", 0)
local pistolItem = config:add_item( "pistol",0)
local heavyPistolItem = config:add_item( "heavy",0)
local otherItem = config:add_item( "other",0)
--sliders
local autoSlider = menu:add_slider("Auto DT HC", "RAGE", "WEAPONS","Auto", autoItem, 0, 100, 1)
local pistolSlider = menu:add_slider("Pistol DT HC", "RAGE", "WEAPONS","Pistols", pistolItem, 0, 100, 1)
local heavyPistolSlider = menu:add_slider("HeavyP DT HC", "RAGE", "WEAPONS","Heavy pistols", heavyPistolItem, 0, 100, 1)
local otherSlider = menu:add_slider("Other DT HC", "RAGE", "WEAPONS","Other", otherItem, 0, 100, 1)
local currentHc = {
    autoHcRef = menu:get_reference("RAGE", "WEAPONS","Auto", "Hitchance");
    pistolHcRef = menu:get_reference("RAGE", "WEAPONS","Pistols", "Hitchance");
    heavyPistolHcRef = menu:get_reference("RAGE", "WEAPONS","Heavy pistols", "Hitchance");
    otherHcRef = menu:get_reference("RAGE", "WEAPONS","Other", "Hitchance");
}
local DtRef = {
    autoDtRef = menu:get_reference("RAGE", "WEAPONS","Auto", "Double tap");
    pistolDtRef = menu:get_reference("RAGE", "WEAPONS","Pistols", "Double tap");
    heavyPistolDtRef = menu:get_reference("RAGE", "WEAPONS","Heavy pistols", "Double tap");
    otherDtRef = menu:get_reference("RAGE", "WEAPONS","Other", "Double tap");
}
function on_paint()
    if dtHcToggle:get_bool() then
        -----------------------auto-----------------------
        if DtRef.autoDtRef:get_int() == 1 then
            currentHc.autoHcRef:set_int(autoItem:get_int())
        elseif DtRef.autoDtRef:get_int() == 2 then
            currentHc.autoHcRef:set_int(autoItem:get_int())
                     --Hitchance-Disable-Check--
        elseif DtRef.autoDtRef:get_int() == 0 then
             currentHc.autoHcRef:set_int(staticHcAuto:get_int())
        end
        ----------------------pistols----------------------
        if DtRef.pistolDtRef:get_int() == 1 then
            currentHc.pistolHcRef:set_int(pistolItem:get_int())
        elseif DtRef.pistolDtRef:get_int() == 2 then 
            currentHc.pistolHcRef:set_int(pistolItem:get_int())
        elseif DtRef.pistolDtRef:get_int() == 0 then
            currentHc.pistolHcRef:set_int(staticHcPistol:get_int())
        end
        --------------------Heavy-pistols--------------------
        if DtRef.heavyPistolDtRef:get_int() == 1 then
            currentHc.heavyPistolHcRef:set_int(heavyPistolItem:get_int())
        elseif DtRef.heavyPistolDtRef:get_int() == 2 then
            currentHc.heavyPistolHcRef:set_int(heavyPistolItem:get_int())
        elseif DtRef.heavyPistolDtRef:get_int() == 0 then
            currentHc.heavyPistolHcRef:set_int(staticHcHeavyPistol:get_int())
        end
        -------------------------other------------------------
        if DtRef.otherDtRef:get_int() == 1 then
            currentHc.otherHcRef:set_int(otherItem:get_int())
        elseif DtRef.otherDtRef:get_int() == 2 then
            currentHc.otherHcRef:set_int(otherItem:get_int())
        elseif DtRef.otherDtRefDtRef:get_int() == 0 then
            currentHc.otherHcRef:set_int(staticHcOther:get_int())
        end
    end
end
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)

