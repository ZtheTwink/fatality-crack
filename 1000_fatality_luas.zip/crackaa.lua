-- https://fatality.win/threads/crack-aa-insane-p100.4670/
--          _____                    _____                    _____                    _____                    _____                   _______                   _____          
--         /\    \                  /\    \                  /\    \                  /\    \                  /\    \                 /::\    \                 /\    \         
--        /::\    \                /::\____\                /::\____\                /::\____\                /::\    \               /::::\    \               /::\    \        
--        \:::\    \              /:::/    /               /:::/    /               /:::/    /               /::::\    \             /::::::\    \             /::::\    \       
--         \:::\    \            /:::/    /               /:::/    /               /:::/    /               /::::::\    \           /::::::::\    \           /::::::\    \      
--          \:::\    \          /:::/    /               /:::/    /               /:::/    /               /:::/\:::\    \         /:::/~~\:::\    \         /:::/\:::\    \     
--           \:::\    \        /:::/    /               /:::/    /               /:::/    /               /:::/__\:::\    \       /:::/    \:::\    \       /:::/  \:::\    \    
--           /::::\    \      /:::/    /               /:::/    /               /:::/    /               /::::\   \:::\    \     /:::/    / \:::\    \     /:::/    \:::\    \   
--  _____   /::::::\    \    /:::/    /      _____    /:::/    /      _____    /:::/    /               /::::::\   \:::\    \   /:::/____/   \:::\____\   /:::/    / \:::\    \  
-- /\    \ /:::/\:::\    \  /:::/____/      /\    \  /:::/____/      /\    \  /:::/    /               /:::/\:::\   \:::\____\ |:::|    |     |:::|    | /:::/    /   \:::\ ___\ 
--/::\    /:::/  \:::\____\|:::|    /      /::\____\|:::|    /      /::\____\/:::/____/               /:::/  \:::\   \:::|    ||:::|____|     |:::|    |/:::/____/     \:::|    |
--\:::\  /:::/    \::/    /|:::|____\     /:::/    /|:::|____\     /:::/    /\:::\    \               \::/    \:::\  /:::|____| \:::\    \   /:::/    / \:::\    \     /:::|____|
-- \:::\/:::/    / \/____/  \:::\    \   /:::/    /  \:::\    \   /:::/    /  \:::\    \               \/_____/\:::\/:::/    /   \:::\    \ /:::/    /   \:::\    \   /:::/    / 
--  \::::::/    /            \:::\    \ /:::/    /    \:::\    \ /:::/    /    \:::\    \                       \::::::/    /     \:::\    /:::/    /     \:::\    \ /:::/    /  
--   \::::/    /              \:::\    /:::/    /      \:::\    /:::/    /      \:::\    \                       \::::/    /       \:::\__/:::/    /       \:::\    /:::/    /   
--    \::/    /                \:::\__/:::/    /        \:::\__/:::/    /        \:::\    \                       \::/____/         \::::::::/    /         \:::\  /:::/    /    
--     \/____/                  \::::::::/    /          \::::::::/    /          \:::\    \                       ~~                \::::::/    /           \:::\/:::/    /     
--                               \::::::/    /            \::::::/    /            \:::\    \                                         \::::/    /             \::::::/    /      
--                                \::::/    /              \::::/    /              \:::\____\                                         \::/____/               \::::/    /       
--                                 \::/____/                \::/____/                \::/    /                                          ~~                      \::/____/        
--                                  ~~                       ~~                       \/____/                                                                    ~~         
                                  




require "clantag_api"

local globals          = csgo.interface_handler:get_global_vars()
local engine_client    = csgo.interface_handler:get_engine_client()
local menu             = fatality.menu
local config           = fatality.config
local callbacks        = fatality.callbacks
local math             = fatality.math
local render           = fatality.render
local screensize       = render:screen_size()

local clantagref = menu:get_reference("visuals", 'misc', 'various', 'clan tag')

local buttonPres = menu:add_button('Juul Pod', 'rage', 'anti-aim', 'general')

local timing = {
    lastTickStandDesync = globals.realtime,
    lastTickMoveDesync = globals.realtime,
    lastTickAirDesync = globals.realtime,
    
    lastTickStandYaw = globals.realtime,
    lastTickMoveYaw = globals.realtime,
    lastTickAirYaw = globals.realtime,
    
    standDesync = false,
    moveDesync = false,
    airDesync = false,
    standYaw = false,
    moveYaw = false,
    airYaw = false,
}
local yawAddRef = {
    stand = menu:get_reference('rage', 'anti-aim', 'standing', 'yaw add'),
    move = menu:get_reference('rage', 'anti-aim', 'moving', 'yaw add'),
    air = menu:get_reference('rage', 'anti-aim', 'air', 'yaw add'),
}
local items = { --checkbox items
    --------------------------------------------------------DESYNC--------------------------------------------------------
    desyncStandItem = config:add_item('desync stand', 1),--standing
    desyncMoveItem = config:add_item('desync move', 1),--moving
    desyncAirItem = config:add_item('desync air', 0),--air
    --------------------------------------------------------
    desyncStandFirstItem = config:add_item('first standing desync angle', 20), --standing
    desyncStandSecondItem = config:add_item('second standing desync angle', -99),--standing
    desyncMoveFirstItem = config:add_item('first moving desync angle', 14),--moving
    desyncMoveSecondItem = config:add_item('second moving desync angle', -71),--moving
    desyncAirFirstItem = config:add_item('first air desync angle', 0),--air
    desyncAirSecondItem = config:add_item('second air desync angle', 0),--air
    ----------------------------------------------------------
    desyncStandingDelayItem = config:add_item('standing desync delay', 0.1),
    desyncMovingDelayItem = config:add_item('moving desync delay', 0.4),
    desyncAirDelayItem = config:add_item('air desync delay', 0),

    ---------------------------------------------------------YAW---------------------------------------------------------
    yawStandItem = config:add_item('yaw stand', 1),--stand
    yawMoveItem = config:add_item('yaw Move', 0),--move
    yawAirItem = config:add_item('yaw Air', 0),--stand    
    --------------------------------------------------------
    yawStandFirstItem = config:add_item('first standing yaw angle', 20), --standing
    yawStandSecondItem = config:add_item('second standing yaw angle', -100),--standing
    yawMoveFirstItem = config:add_item('first moving yaw angle', 0),--moving
    yawMoveSecondItem = config:add_item('second moving yaw angle', 0),--moving
    yawAirFirstItem = config:add_item('first air yaw angle', 0),--air
    yawAirSecondItem = config:add_item('second air yaw angle', 0),--air
    --------------------------------------------------------
    yawStandingDelayItem = config:add_item('standing yaw delay', 0.1),
    yawMovingDelayItem = config:add_item('moving yaw delay', 0),
    yawAirDelayItem = config:add_item('air yaw delay', 0),

    ----------------------------aa-mode-------------------------
    aaModeItem = config:add_item('aa modes',2),

    standSwayItem = config:add_item('standing sway item', 0),
    moveSwayItem = config:add_item('moving sway item', 0),
    airSwayItem = config:add_item('in air sway item', 0),

    standSwaySpeedItem = config:add_item('standing sway speed', 0),
    moveSwaySpeedItem = config:add_item('moving sway speed', 0),
    airSwaySpeedItem = config:add_item('in air sway speed', 0),

    valueInfoItem = config:add_item('crosshair values', 0),

    colorItem = config:add_item('colorpicker', 0),
}
local references = {
    standDesync = menu:get_reference( 'rage', 'anti-aim', 'standing', 'fake amount'),
    moveDesync = menu:get_reference( 'rage', 'anti-aim', 'moving', 'fake amount'),
    airDesync = menu:get_reference( 'rage', 'anti-aim', 'air', 'fake amount'),


    standFakeType = menu:get_reference( 'rage', 'anti-aim', 'standing', 'fake type'),
    moveFakeType = menu:get_reference( 'rage', 'anti-aim', 'moving', 'fake type'),
    airFakeType = menu:get_reference( 'rage', 'anti-aim', 'air', 'fake type'),

    standYaw = menu:get_reference( 'rage', 'anti-aim', 'standing', 'add'),
    moveYaw = menu:get_reference( 'rage', 'anti-aim', 'moving', 'add'),
    airYaw = menu:get_reference( 'rage', 'anti-aim', 'air', 'add'),

}
local desyncCheckbox = { --its done like this for menu positioning

    --------------------------------------------------------DESYNC--------------------------------------------------------

    desyncStandCheck = menu:add_checkbox('Desync Jitter Stand', 'rage', 'anti-aim', 'standing', items.desyncStandItem),--standing
    desyncMovedCheck = menu:add_checkbox('Desync Jitter Move', 'rage', 'anti-aim', 'moving', items.desyncMoveItem),--moving
    desyncAirCheck = menu:add_checkbox('Desync Jitter Air', 'rage', 'anti-aim', 'air', items.desyncAirItem),--air

    

}
local desyncSliders = { --its done like this for menu positioning
    --standing desync
    desyncStandSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'standing',items.desyncStandFirstItem, -100, 100, 1),
    desyncStandSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'standing',items.desyncStandSecondItem, -100, 100, 1),
    --moving desync
    desyncMoveSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'moving',items.desyncMoveFirstItem, -100, 100, 1),
    desyncMoveSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'moving',items.desyncMoveSecondItem, -100, 100, 1),
    --air desync
    desyncAirSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'air',items.desyncAirFirstItem, -100, 100, 1),
    desyncAirSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'air',items.desyncAirSecondItem, -100, 100, 1),
    --desync delay
    desyncStandingDelaySlider = menu:add_slider('Desync Jitter Delay','rage', 'anti-aim', 'standing',items.desyncStandingDelayItem,0, 60, 0.1),
    desyncMovingDelaySlider = menu:add_slider('Desync Jitter Delay','rage', 'anti-aim', 'moving',items.desyncMovingDelayItem,0, 60, 0.1),
    desyncAirDelaySlider = menu:add_slider('Desync Jitter Delay','rage', 'anti-aim', 'air',items.desyncAirDelayItem,0, 60, 0.1),

}
local yawCheckbox = { --its done like this for menu positioning
    ---------------------------------------------------------YAW---------------------------------------------------------
    yawStandCheck = menu:add_checkbox('Yaw Jitter Stand', 'rage', 'anti-aim', 'standing', items.yawStandItem),--standing
    yawMovedCheck = menu:add_checkbox('Yaw Jitter Move', 'rage', 'anti-aim', 'moving', items.yawMoveItem),--moving
    yawAirCheck = menu:add_checkbox('Yaw Jitter Air', 'rage', 'anti-aim', 'air', items.yawAirItem),--air
}
local yawSliders = { --its done like this for menu positioning

    --standing yaw
    yawStandSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'standing',items.yawStandFirstItem, -100, 99, 1),
    yawStandSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'standing',items.yawStandSecondItem, -99, 100, 1),
    --moving yaw
    yawMoveSlider1 = menu:add_slider('First Angle', 'rage', 'anti-aim', 'moving',items.yawMoveFirstItem, -100, 100, 1),
    yawMoveSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'moving',items.yawMoveSecondItem, -100, 100, 1),
    --air yaw
    yawAirSlider1 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'air',items.yawAirFirstItem, -99, 100, 1),
    yawAirSlider2 = menu:add_slider('Second Angle', 'rage', 'anti-aim', 'air',items.yawAirSecondItem, -100, 100, 1),
    --yaw delay
    yawStandingDelaySlider = menu:add_slider('Yaw Jitter Delay','rage', 'anti-aim', 'standing',items.yawStandingDelayItem,0, 60, 0.1),
    yawMovingDelaySlider = menu:add_slider('Yaw Jitter Delay','rage', 'anti-aim', 'moving',items.yawMovingDelayItem,0, 60, 0.1),
    yawAirDelaySlider = menu:add_slider('Yaw Jitter Delay','rage', 'anti-aim', 'air',items.yawAirDelayItem,0, 60, 0.1),
}
local toggles = {
    standSwayCheck = menu:add_checkbox('Desync Sway', 'rage', 'anti-aim', 'standing',items.standSwayItem),
    moveSwayCheck = menu:add_checkbox('Desync Sway', 'rage', 'anti-aim', 'moving',items.moveSwayItem),
    airSwayCheck = menu:add_checkbox('Desync Sway', 'rage', 'anti-aim', 'air',items.airSwayItem),
    --aa mode combo
    aaModeCombo = menu:add_combo('AA MODE', 'rage', 'anti-aim','general',items.aaModeItem),
    --
    standSwaySlider = menu:add_slider('Sway Speed', 'rage', 'anti-aim', 'standing', items.standSwaySpeedItem, 1, 10, 1),
    moveSwaySlider = menu:add_slider('Sway Speed', 'rage', 'anti-aim', 'moving', items.moveSwaySpeedItem, 1, 10, 1),
    airSwaySlider = menu:add_slider('Sway Speed', 'rage', 'anti-aim', 'air', items.airSwaySpeedItem, 1, 10, 1),

    --value show
    valueInfoCombo = menu:add_combo('Value info', 'rage', 'anti-aim', 'general', items.valueInfoItem),
    --colors for values
    colorCombo = menu:add_combo('Color Picker', 'rage', 'anti-aim', 'general', items.colorItem),

    font = render:create_font( 'Verdana bold', 14, 400, false),

}
--aa modes
toggles.aaModeCombo:add_item('Off',items.aaModeItem)
toggles.aaModeCombo:add_item('D.I.Y',items.aaModeItem)
toggles.aaModeCombo:add_item('Main',items.aaModeItem)
toggles.aaModeCombo:add_item('Jitter',items.aaModeItem)
toggles.aaModeCombo:add_item('Sway',items.aaModeItem)
--value info modes
toggles.valueInfoCombo:add_item('Off', items.valueInfoItem)
toggles.valueInfoCombo:add_item('All', items.valueInfoItem)
toggles.valueInfoCombo:add_item('Fake', items.valueInfoItem)
toggles.valueInfoCombo:add_item('Yaw', items.valueInfoItem)
--colors
toggles.colorCombo:add_item('White', items.colorItem)
toggles.colorCombo:add_item('Blue', items.colorItem)
toggles.colorCombo:add_item('Sky Blue', items.colorItem)
toggles.colorCombo:add_item('Red', items.colorItem)
toggles.colorCombo:add_item('Green', items.colorItem)
toggles.colorCombo:add_item('Black', items.colorItem)
toggles.colorCombo:add_item('Pink', items.colorItem)
toggles.colorCombo:add_item('Hot Pink', items.colorItem)
toggles.colorCombo:add_item('Beige', items.colorItem)



local uffStanding = true-- for the sway
local yaStanding = false
local uffMoving = true-- for the sway
local yaMoving = false
local uffAir = true-- for the sway
local yaAir = false

references.standDesync:set_float(0) -- gotta do this cuz if its at 100 itll fuck it-- also for sway
references.moveDesync:set_float(0)
references.standDesync:set_float(0)


local color = csgo.color(255, 255, 255, 255)

function jitter ()

    if items.aaModeItem:get_int() == 0 then
        items.standSwayItem:set_int(0)
        items.moveSwayItem:set_int(0)
        items.airSwayItem:set_int(0)
        items.desyncStandItem:set_int(0)
        items.yawStandItem:set_int(0)
        items.desyncMoveItem:set_int(0)
        items.yawMoveItem:set_int(0)
        items.desyncAirItem:set_int(0)
        items.yawAirItem:set_int(0)
    elseif items.aaModeItem:get_int() == 1 then
        --custom
    elseif items.aaModeItem:get_int() == 2 then

        items.standSwayItem:set_int(0)
        items.moveSwayItem:set_int(0)
        items.airSwayItem:set_int(0)

        references.standFakeType:set_int(2)
        references.moveFakeType:set_int(2)
        references.airFakeType:set_int(2)

--------------------------------------------------------STAND--------------------------------------------------------
         --desync and yaw toggles
         yawAddRef.stand:set_int(1)
         items.desyncStandItem:set_int(1)
         items.yawStandItem:set_int(1)
        --desync 
        items.desyncStandFirstItem:set_int(20)
        items.desyncStandSecondItem:set_int(-100)
        items.desyncStandingDelayItem:set_float(0.1)
        --yaw
        items.yawStandFirstItem:set_int(24)
        items.yawStandSecondItem:set_int(0)
        items.yawStandingDelayItem:set_float(0.1)
--------------------------------------------------------MOVING--------------------------------------------------------
         --desync and yaw toggles
         yawAddRef.move:set_int(0)
         items.desyncMoveItem:set_int(1)
         items.yawMoveItem:set_int(0)
        --desync 
        items.desyncMoveFirstItem:set_int(14)
        items.desyncMoveSecondItem:set_int(-71)
        items.desyncMovingDelayItem:set_float(0.4)
        --yaw
        items.yawMoveFirstItem:set_int(0)
        items.yawMoveSecondItem:set_int(0)
        items.yawMovingDelayItem:set_float(30)
--------------------------------------------------------IN-AIR--------------------------------------------------------
         --desync and yaw toggles
         yawAddRef.air:set_int(1)
         items.desyncAirItem:set_int(1)
         items.yawAirItem:set_int(1)
        --desync 
        items.desyncAirFirstItem:set_int(0)
        items.desyncAirSecondItem:set_int(-100)
        items.desyncAirDelayItem:set_float(0.1)
        --yaw
        items.yawAirFirstItem:set_int(20)
        items.yawAirSecondItem:set_int(-20)
        items.yawAirDelayItem:set_float(0.1)
    elseif items.aaModeItem:get_int() == 3 then
        
        references.standFakeType:set_int(2)
        references.moveFakeType:set_int(2)
        references.airFakeType:set_int(2)
        --sway
        items.standSwayItem:set_int(0)
        items.moveSwayItem:set_int(0)
        items.airSwayItem:set_int(0)
        --desync and yaw toggles
        yawAddRef.stand:set_int(1)
        items.desyncStandItem:set_int(1)
        items.yawStandItem:set_int(1)
       --desync 
       items.desyncStandFirstItem:set_int(20)
       items.desyncStandSecondItem:set_int(-100)
       items.desyncStandingDelayItem:set_float(0.1)
       --yaw
       items.yawStandFirstItem:set_int(24)
       items.yawStandSecondItem:set_int(0)
       items.yawStandingDelayItem:set_float(0.1)
--------------------------------------------------------MOVING--------------------------------------------------------
        --desync and yaw toggles
        yawAddRef.move:set_int(1)
        items.desyncMoveItem:set_int(1)
        items.yawMoveItem:set_int(1)
       --desync 
       items.desyncMoveFirstItem:set_int(-30)
       items.desyncMoveSecondItem:set_int(-100)
       items.desyncMovingDelayItem:set_float(0.1)
       --yaw
       items.yawMoveFirstItem:set_int(-25)
       items.yawMoveSecondItem:set_int(0)
       items.yawMovingDelayItem:set_float(0.1)
--------------------------------------------------------IN-AIR--------------------------------------------------------
        --desync and yaw togglesx
        yawAddRef.air:set_int(1)
        items.desyncAirItem:set_int(1)
        items.yawAirItem:set_int(1)
       --desync 
       items.desyncAirFirstItem:set_int(0)
       items.desyncAirSecondItem:set_int(-100)
       items.desyncAirDelayItem:set_float(0.1)
       --yaw
       items.yawAirFirstItem:set_int(20)
       items.yawAirSecondItem:set_int(-20)
       items.yawAirDelayItem:set_float(0.1)
    
    elseif items.aaModeItem:get_int() == 4 then
----------------------------------------------------------

        items.yawStandItem:set_int(0)
        items.yawMoveItem:set_int(0)
        items.yawAirItem:set_int(0)
        items.desyncStandItem:set_int(0)
        items.desyncMoveItem:set_int(0)
        items.desyncAirItem:set_int(0)
        --standing sway
        items.standSwayItem:set_int(0)
        items.moveSwayItem:set_int(0)
        items.airSwayItem:set_int(0)
    if uffStanding then
            references.standDesync:set_float(references.standDesync:get_float() + 1)
            if references.standDesync:get_int() == 100 then
                uffStanding = false
                yaStanding = true
            end
    end
    if yaStanding then 
            references.standDesync:set_float(references.standDesync:get_float() - 1)
            if references.standDesync:get_int() == -100 then
                uffStanding = true
                yaStanding = false
            end
    end
    ----------moving sway
    if uffMoving then
        references.moveDesync:set_float(references.moveDesync:get_float() + 1)
        if references.moveDesync:get_int() == 100 then
            uffMoving = false
            yaMoving = true
        end
    end
    if yaMoving then 
        references.moveDesync:set_float(references.moveDesync:get_float() - 1)
        if references.moveDesync:get_int() == -100 then
            uffMoving = true
            yaMoving = false
        end
    end
    --------------in air sway
    if uffAir then
        references.airDesync:set_float(references.airDesync:get_float() + 1)
        if references.airDesync:get_int() == 100 then
            uffAir = false
            yaAir = true
        end
    end
    if yaAir then 
        references.airDesync:set_float(references.airDesync:get_float() - 1)
        if references.airDesync:get_int() == -100 then
            uffAir = true
            yaAir = false
        end
    end
end
---------------------------------------------------------DESYNC---------------------------------------------------------
    if items.desyncStandItem:get_bool() then --STANDING DESYNC
        if timing.lastTickStandDesync + items.desyncStandingDelayItem:get_float() < globals.realtime then
            if timing.standDesync then
                menu:get_reference( 'rage', 'anti-aim', 'standing', 'fake amount'):set_int( items.desyncStandFirstItem:get_int() );
                timing.standDesync = false
            else 
                menu:get_reference( 'rage', 'anti-aim', 'standing', 'fake amount'):set_int( items.desyncStandSecondItem:get_int() );
                timing.standDesync = true
            end
            timing.lastTickStandDesync = globals.realtime
        end
    end
    -------------------------------------------------------
    if items.desyncMoveItem:get_bool() then --MOVING DESYNC
       if timing.lastTickMoveDesync + items.desyncMovingDelayItem:get_float() < globals.realtime then
        if timing.moveDesync then
            menu:get_reference( 'rage', 'anti-aim', 'moving', 'fake amount'):set_int( items.desyncMoveFirstItem:get_int() );
            timing.moveDesync = false
        else
            menu:get_reference( 'rage', 'anti-aim', 'moving', 'fake amount'):set_int( items.desyncMoveSecondItem:get_int() );
            timing.moveDesync = true
        end
        timing.lastTickMoveDesync = globals.realtime
       end 
    end
    -------------------------------------------------------
    if items.desyncAirItem:get_bool() then --AIR DESYNC
       if timing.lastTickAirDesync + items.desyncAirDelayItem:get_float() < globals.realtime then
        if timing.airDesync then
            menu:get_reference('rage', 'anti-aim', 'air', 'fake amount'):set_int(items.desyncAirFirstItem:get_int())
            timing.airDesync = false
        else
            menu:get_reference('rage', 'anti-aim', 'air', 'fake amount'):set_int(items.desyncAirSecondItem:get_int())
            timing.airDesync = true
       end
       timing.lastTickAirDesync = globals.realtime
       end 
    end

    ---------------------------------------------------------YAW---------------------------------------------------------
    if items.yawStandItem:get_bool() then --Standing Yaw
        if timing.lastTickStandYaw + items.yawStandingDelayItem:get_float() < globals.realtime then
         if timing.standYaw then
             menu:get_reference('rage', 'anti-aim', 'standing', 'add'):set_int(items.yawStandFirstItem:get_int())
             timing.standYaw = false
         else
             menu:get_reference('rage', 'anti-aim', 'standing', 'add'):set_int(items.yawStandSecondItem:get_int())
             timing.standYaw = true
         end
        timing.lastTickStandYaw = globals.realtime
        end 
    end
    -------------------------------------------------------
    if items.yawMoveItem:get_bool() then --Moveing Yaw
        if timing.lastTickMoveYaw + items.yawMovingDelayItem:get_float() < globals.realtime then
         if timing.MoveYaw then
             menu:get_reference('rage', 'anti-aim', 'moving', 'add'):set_int(items.yawMoveFirstItem:get_int())
             timing.MoveYaw = false
         else
             menu:get_reference('rage', 'anti-aim', 'moving', 'add'):set_int(items.yawMoveSecondItem:get_int())
             timing.MoveYaw = true
         end
        timing.lastTickMoveYaw = globals.realtime
        end 
    end
    -------------------------------------------------------
    if items.yawAirItem:get_bool() then --Air Yaw
        if timing.lastTickAirYaw + items.yawAirDelayItem:get_float() < globals.realtime then
         if timing.AirYaw then
             menu:get_reference('rage', 'anti-aim', 'air', 'add'):set_int(items.yawAirFirstItem:get_int())
             timing.AirYaw = false
         else
             menu:get_reference('rage', 'anti-aim', 'air', 'add'):set_int(items.yawAirSecondItem:get_int())
             timing.AirYaw = true
         end
        timing.lastTickAirYaw = globals.realtime
        end 
    end
    if items.standSwayItem:get_bool() then --standing sway checkbox
        if uffStanding then
            references.standDesync:set_float(references.standDesync:get_float() + items.standSwaySpeedItem:get_int())
            if references.standDesync:get_int() > 100 or references.standDesync:get_int() > 110 then --bug fix <--
                uffStanding = false
                yaStanding = true
            end
        end
        if yaStanding then 
            references.standDesync:set_float(references.standDesync:get_float() - items.standSwaySpeedItem:get_int())
            if references.standDesync:get_int() < -100 or references.standDesync:get_int() < -110 then
                uffStanding = true
                yaStanding = false
            end
        end
    end
    if items.moveSwayItem:get_bool() then --moving sway checkbox
        if uffMoving then
            references.moveDesync:set_float(references.moveDesync:get_float() + items.moveSwaySpeedItem:get_int())
            if references.moveDesync:get_int() > 100 or references.moveDesync:get_int() > 110 then
                uffMoving = false
                yaMoving = true
            end
        end
        if yaMoving then 
            references.moveDesync:set_float(references.moveDesync:get_float() - items.moveSwaySpeedItem:get_int())
            if references.moveDesync:get_int() < -100 or references.moveDesync:get_int() < -110 then
                uffMoving = true
                yaMoving = false
            end
        end
    end
    if items.airSwayItem:get_bool() then --air sway checkbox
        if uffAir then
            references.airDesync:set_float(references.airDesync:get_float() + items.airSwaySpeedItem:get_int())
            if references.airDesync:get_int() > 100 or references.airDesync:get_int() > 110 then
                uffAir = false
                yaAir = true
            end
        end
        if yaAir then 
            references.airDesync:set_float(references.airDesync:get_float() - items.airSwaySpeedItem:get_int())
            if references.airDesync:get_int() < -100 or references.airDesync:get_int() < -110 then
                uffAir = true
                yaAir = false
            end
        end
    end

    if items.colorItem:get_int() == 0 then
        color = csgo.color(255, 255, 255, 255)
    elseif items.colorItem:get_int() == 1 then
        color = csgo.color(0, 0, 255, 255)
    elseif items.colorItem:get_int() == 2 then
        color = csgo.color(66, 135, 245, 255)
    elseif items.colorItem:get_int() == 3 then
        color = csgo.color(255, 0, 0, 255)
    elseif items.colorItem:get_int() == 4 then
        color = csgo.color(0, 255, 0, 255)
    elseif items.colorItem:get_int() == 5 then
        color = csgo.color(0, 0, 0, 255)
    elseif items.colorItem:get_int() == 6 then
        color = csgo.color(247, 138, 255, 255)
    elseif items.colorItem:get_int() == 7 then
        color = csgo.color(255, 0, 242, 255)
    elseif items.colorItem:get_int() == 8 then
        color = csgo.color(255, 234, 181, 255)

    end

    if not engine_client:is_in_game() then
    elseif engine_client:is_in_game() then
        if items.valueInfoItem:get_int() == 0 then   
        elseif items.valueInfoItem:get_int() == 1 then

            ----standing
            render:text(toggles.font, screensize.x + 10 - screensize.x/2, screensize.y - screensize.y/2,'Still Desync', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y - screensize.y/2, references.standDesync:get_int(), color)
            render:text(toggles.font, screensize.x + 10 - screensize.x/2, screensize.y + 15 - screensize.y/2,'Still Yaw', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y + 15 - screensize.y/2, references.standYaw:get_int(), color)
            ---moving
            render:text(toggles.font, screensize.x + 10 - screensize.x/2, screensize.y + 30 - screensize.y/2,'Move Desync', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y + 30 - screensize.y/2, references.moveDesync:get_int(), color)
            render:text(toggles.font, screensize.x + 10 - screensize.x/2, screensize.y + 45 - screensize.y/2,'Move Yaw', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y + 45 - screensize.y/2, references.moveYaw:get_int(), color)
            --air
            render:text(toggles.font, screensize.x + 10 - screensize.x/2, screensize.y + 60 - screensize.y/2,'Air Desync', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y + 60 - screensize.y/2, references.airDesync:get_int(), color)
            render:text(toggles.font, screensize.x + 10 - screensize.x/2, screensize.y + 75 - screensize.y/2,'Air Yaw', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y + 75 - screensize.y/2, references.airYaw:get_int(), color)
        elseif items.valueInfoItem:get_int() == 2 then
            --standing
            render:text(toggles.font, screensize.x + 10 - screensize.x/2, screensize.y - screensize.y/2,'Still Desync', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y - screensize.y/2, references.standDesync:get_int(), color)
            --moveing
            render:text(toggles.font, screensize.x + 10 - screensize.x/2, screensize.y + 15 - screensize.y/2,'Move Desync', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y + 15 - screensize.y/2, references.moveDesync:get_int(), color)
            --air
            render:text(toggles.font, screensize.x + 10 - screensize.x/2, screensize.y + 30 - screensize.y/2,'Air Desync', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y + 30 - screensize.y/2, references.airDesync:get_int(), color)
        elseif items.valueInfoItem:get_int() == 3 then
            --standing
            render:text(toggles.font, screensize.x + 15 - screensize.x/2, screensize.y  - screensize.y/2,'Still Yaw', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y  - screensize.y/2, references.standYaw:get_int(), color)
            --moving
            render:text(toggles.font, screensize.x + 15 - screensize.x/2, screensize.y + 15 - screensize.y/2,'Move Yaw', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y + 15 - screensize.y/2, references.moveYaw:get_int(), color)
            --yaw
            render:text(toggles.font, screensize.x + 15 - screensize.x/2, screensize.y + 30 - screensize.y/2,'Air Yaw', color)
            render:text(toggles.font, screensize.x + 100 - screensize.x/2, screensize.y + 30 - screensize.y/2, references.airYaw:get_int(), color)
        end
    end

end

local clantagItem = config:add_item('clantag item', 0)
local clantagCombo = menu:add_checkbox("Crack AA Clantag", 'rage', 'anti-aim', 'general', clantagItem)

local timing_switch = 0
local cur_mode = 0
local timing = timing_switch

local function clantag()

    local clantag_timing = { [1] = function() return end,}

    if clantagItem:get_bool() then
    clantagref:set_int(0)
    timing_switch = 60
    clantag_timing = {
    [1] = function() return " " end,
    [2] = function() return "c " end,
    [3] = function() return "cr " end,
    [4] = function() return "cra " end,
    [5] = function() return "crac " end,
    [6] = function() return "crack " end,
    [7] = function() return "crackA " end,
    [8] = function() return "crackAA " end,
    [9] = function() return "crackAA " end,
    [10] = function() return "rackAA " end,
    [11] = function() return "ackAA " end,
    [12] = function() return "ckAA " end,
    [13] = function() return "kAA " end,
    [14] = function() return "AA " end,
    [15] = function() return "A " end,
    }

end

timing = timing + 1

    if timing >= timing_switch then
        cur_mode = cur_mode + 1

        if cur_mode > #clantag_timing then
            cur_mode = 1
        end
        
        SET_CLANTAG_MADE_BY_DUCARII(clantag_timing[cur_mode]())
        timing = 0
    end

end

callbacks:add('paint', jitter)
callbacks:add('paint', clantag)