-- https://fatality.win/threads/f12-sound-on-kill.3916/
-- https://cdn.discordapp.com/attachments/640205777260380212/650762223815491644/voice_input.wav
-- ^ PUT THIS NEXT TO csgo.exe (C:\Program Files (x86)\Steam\steamapps\common\Counter-Strike Global Offensive) or the lua will not work! will appreciate feedback in comments! :). Happy 2020!

local menu = fatality.menu
local input = fatality.input
local config = fatality.config
local render = fatality.render
local callbacks = fatality.callbacks

local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local debug_overlay = csgo.interface_handler:get_debug_overlay( )
local global_vars = csgo.interface_handler:get_global_vars( )
local game_events = csgo.interface_handler:get_events( )
local events = csgo.interface_handler:get_events()
local cvar = csgo.interface_handler:get_cvar( )

local loopback = cvar:find_var("voice_loopback")
local fileinput = cvar:find_var("voice_inputfromfile")

local sound_exists = function(name)
    return (function(filename) return package.searchpath("", filename) == filename end)("./" .. name)
end
local currentTime = 0
local timer, enabled, snd_time = 0, true, 0.6 -- set sound file lenght default f12 sound = 0.6 .
local handler = nil

handler = function()
    currentTime = global_vars.realtime
    if currentTime >= timer then
        timer = global_vars.realtime + snd_time

        if enabled then
            print("script loaded")
            loopback:unlock()
            fileinput:unlock()
            loopback:set_int(0)
            fileinput:set_int(0)

            engine_client:client_cmd_unrestricted("-voicerecord")
            enabled = false
        end
    end
end

callbacks:add("paint", handler)
local actvie = config:add_item("f12sound", 1.0)
local active = menu:add_checkbox("F12 sound", "Visuals", "Misc", "Various", actvie)

local function on_player_death(e)
    if actvie == nil then
        return
    end
    local victim_userid = e:get_int("userid")
    local attacker_userid = e:get_int("attacker")
    if victim_userid == nil or attacker_userid == nil then
        return
    end

    if not sound_exists("voice_input.wav") then
        print("you need voice_input.wav next to your csgo.exe to use this lua.")
        return
    end

    local local_ent = entity_list:get_localplayer()
    local victim_ent = entity_list:get_player_from_id(victim_userid)
    local attacker_ent = entity_list:get_player_from_id(attacker_userid)

    if local_ent == nil or victim_ent == nil or attacker_ent == nil then
        return
    end
    if (attacker_ent:get_index() == local_ent:get_index()) then
        loopback:unlock()
        fileinput:unlock()
        loopback:set_int(1)
        fileinput:set_int(1)

        engine_client:client_cmd_unrestricted("+voicerecord")
        timer, enabled = global_vars.realtime + snd_time, true
    end
end
local function on_event(e)
    local event_name = e:get_name()

    if event_name == "player_death" then
        on_player_death(e)
    end
end
events:add_event("player_death")
callbacks:add("events", on_event)
handler()