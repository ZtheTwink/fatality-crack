

local render = fatality.render
local menu = fatality.menu
local callbacks = fatality.callbacks
local headshot = menu:get_reference("Rage", "Aimbot", "Aimbot", "Headshot only")
local fallback = menu:get_reference("Rage", "Aimbot", "Aimbot", "Force fallback")

function on_paint()
    if headshot:get_bool() then
        render:indicator(10, 619, "HS", hs, -1)
    end
    if fallback:get_bool() then
        render:indicator(10, 595,  "FB", fb, -1)
    end
end
callbacks:add("paint", on_paint)

 