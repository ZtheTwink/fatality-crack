-- https://fatality.win/threads/kool-watermark-thanks-to-eddy-for-his-moral-support.568/

-- interfaces
local engine_client = csgo.interface_handler:get_engine_client( )
local ent_list = csgo.interface_handler:get_entity_list( )
local Gvar = csgo.interface_handler:get_global_vars( )
local cvar = csgo.interface_handler:get_cvar( )
local render = fatality.render
local menu = fatality.menu
local config = fatality.config

local local_player = ent_list:get_localplayer( )

--menu/cfg
local something_item = config:add_item( "watermark_cool", 0 )
local something_checkbox = menu:add_checkbox( "watermark bar", "visuals", "misc", "various", something_item )

-- fps calc

local frame_rate = 0.0;

function get_abs_fps( )
    frame_rate = 0.9 * frame_rate + ( 1.0 - 0.9 ) * Gvar.frametime;
    return math.floor( ( 1.0 / frame_rate ) + 0.5 );
end

-- Get Velocity
function get_velocity( )
    local local_player = ent_list:get_localplayer( )
    if local_player == nil then
        return end

    local velocity = local_player:get_var_vector( "CBasePlayer->m_vecVelocity[0]" )
    local speed = math.ceil( math.sqrt( math.abs( velocity.x ) * math.abs( velocity.x ) + math.abs( velocity.y ) * math.abs( velocity.y ) ) )
    return math.floor( speed );
end

function get_ping( )
    ping = engine_client:get_ping()
    return math.floor( ping );
end

-- font
local verdana = render:create_font("Courier New", 14, 400, true);

--positioning garbage
local screen_size = render:screen_size();
local x = screen_size.x / 2
local y = screen_size.y * 0.972
local h = 30
local w = 250

function on_paint( )
    -- Paint code
  
    if not engine_client:is_in_game( ) then
    return end
  
    if something_item:get_bool() then
      
        render:text(verdana, x - 160 , y + 7, "ping: " , csgo.color(255, 255, 255, 255) );
        render:text(verdana, x - 122 , y + 7, tostring(get_ping()) , csgo.color(255, 255, 255, 255) );                       -- ping
        render:text(verdana, x + 105 , y + 7, "speed: " , csgo.color(255, 255, 255, 255) );
        render:text(verdana, x + 150 , y + 7, tostring(get_velocity()) , csgo.color(255, 255, 255, 255) );                       -- speed
        render:text(verdana, x - 30, y + 7 , "fps: " , csgo.color(255, 255, 255, 255) );
        render:text(verdana, x , y + 7 , tostring(get_abs_fps()) , csgo.color(158, 253, 6, 255))                                  -- fps
        render:rect_fade( x - 250, y , w , h , csgo.color(0,0,0,20), csgo.color(0,0,0,200), true )
        render:rect_fade( x, y , w , h , csgo.color(0,0,0,200), csgo.color(0,0,0,20), true )
    end
end

local callbacks = fatality.callbacks;
callbacks:add( "paint", on_paint )