--LUA MADE BY ONE AND ONLY anti#2528
--You are not allowed to use any code from this lua without my permission.
 
 
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local entity_list = csgo.interface_handler:get_entity_list()
local global_vars = csgo.interface_handler:get_global_vars()
local engine_client  = csgo.interface_handler:get_engine_client()
local debug_overlay  = csgo.interface_handler:get_debug_overlay()
 
local screen_size = render:screen_size()
local speedfont = render:create_font( "Verdana", 17, 550, true );
function round(num, numDecimalPlaces)
    local mult = 10^(numDecimalPlaces or 0)
    return math.floor(num * mult + 0.5) / mult
end
 
local eb_item = config:add_item("vis_wb", 1)
local eb_checkbox = menu:add_checkbox("(Re)Draw 1w crosses", "Misc", "Movement", "Movement", eb_item)
local colorpickerRl_item = config:add_item( "colorpicker1_red", 0 )
local colorpickerGl_item = config:add_item( "colorpicker1_green", 0 )
local colorpickerBl_item = config:add_item( "colorpicker1_blue", 0 )
local colorpickerRl_slider = menu:add_slider( "Red", "Misc", "Movement", "Movement", colorpickerRl_item, 1, 255, 1 )
local colorpickerGl_slider = menu:add_slider( "Green", "Misc", "Movement", "Movement", colorpickerGl_item, 1, 255, 1 )
local colorpickerBl_slider = menu:add_slider( "Blue", "Misc", "Movement", "Movement", colorpickerBl_item, 1, 255, 1 )
 
 
function on_paint()
 
if(not engine_client:is_in_game()) then return end
local r = math.floor( math.sin( global_vars.realtime * 4 + 1) * 127 + 128 );
    local r_col = math.floor(colorpickerRl_item:get_float( ))
    local g_col = math.floor(colorpickerGl_item:get_float( ))
    local b_col = math.floor(colorpickerBl_item:get_float( ))
local bco = csgo.color(r_col, g_col, b_col, 255)
if(eb_item:get_bool())then
    eb_item:set_bool(false)
 
 
debug_overlay:add_line_overlay(csgo.vector3(-151,462,-68), csgo.vector3(-192,532,-68), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-151,532,-68), csgo.vector3(-192,462,-68), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-619,520,-82), csgo.vector3(-712,616,-79), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-619,616,-78), csgo.vector3(-712,520,-77), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-982,-1305,-156), csgo.vector3(-1008,-1318,-158), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-982,-1318,-158), csgo.vector3(-1008,-1305,-155), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-735,-814,-261), csgo.vector3(-676,-731,-265), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-676,-814,-261), csgo.vector3(-739,-731,-265), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-970,332,-367), csgo.vector3(-1034,269,-366), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-1034,332,-367), csgo.vector3(-970,269,-366), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-466,491,-143), csgo.vector3(-495,428,-159), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-495,491,-159), csgo.vector3(-466,427,-143), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-820,-1142,-120), csgo.vector3(-772,-1198,-120), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-830,-1190,-120), csgo.vector3(-771,-1148,-120), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(199,767,-135), csgo.vector3(254,872,-135), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(254,766,-135), csgo.vector3(199,872,-135), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(363,766,-135), csgo.vector3(313,872,-135), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(307,766,-135), csgo.vector3(363,872,-135), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-174,-530,-229), csgo.vector3(-238,-575,-241), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-238,-530,-242), csgo.vector3(-174,-575,-229), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(820,-1611,-108), csgo.vector3(758,-1570,-108), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(758,-1611,-108), csgo.vector3(820,-1570,-108), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-1721,-1200,-254), csgo.vector3(-1686,-1222,-254), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-1686,-1200,-254), csgo.vector3(-1721,-1222,-254), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-2241,734,-39), csgo.vector3(-2288,667,-39), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-2288,734,-39), csgo.vector3(-2241,667,-39), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-495,-1518,-39), csgo.vector3(-455,-1565,-39), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-455,-1518,-39), csgo.vector3(-495,-1565,-39), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(1198,220,-231), csgo.vector3(1095,199,-219), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(1095,220,-226), csgo.vector3(1198,199,-223), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-300,-2065,-100), csgo.vector3(-304,-2119,-100), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-315,-2076,-100), csgo.vector3(-270,-2113,-100), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-4,-1755,-167), csgo.vector3(-37,-1732,-167), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-37,-1758,-167), csgo.vector3(-4,-1736,-167), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-464,755,-71), csgo.vector3(-405,719,-83), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-464,719,-71), csgo.vector3(-405,755,-83), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(1369,286,-209), csgo.vector3(1200,201,-177), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(1369,201,-180), csgo.vector3(1200,286,-207), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(1245,-723,-229), csgo.vector3(1233,-701,-227), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(1245,-701,-227), csgo.vector3(1233,-723,-230), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-1145,305,-159), csgo.vector3(-1101,288,-159), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-1101,310,-159), csgo.vector3(-1145,288,-159), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-405,-351,-163), csgo.vector3(-220,-322,-163), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-220,-358,-163), csgo.vector3(-405,-333,-163), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-1435,-848,-167), csgo.vector3(-1468,-796,-167), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-1468,-848,-167), csgo.vector3(-1435,-796,-167), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-1463,-1696,-258), csgo.vector3(-1474,-1663,-258), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-1463,-1663,-256), csgo.vector3(-1474,-1696,-258), bco, false, 90000)
 
debug_overlay:add_line_overlay(csgo.vector3(-530,-1418,-103), csgo.vector3(-550,-1385,-114), bco, false, 90000)
debug_overlay:add_line_overlay(csgo.vector3(-535,-1385,-118), csgo.vector3(-550,-1418,-100), bco, false, 90000)
end
local local_player = entity_list:get_localplayer()
if(local_player:is_alive()) then
local position = local_player:get_var_vector( "CBaseEntity->m_vecOrigin" ) -- so we get local pos
local positionx = round(position.x, 0)
local positiony = round(position.y, 0)
local positionz = round(position.z, 0)
local hard = csgo.color(230,20,20,255)
local medium = csgo.color(255,128,0,255)
local easy = csgo.color(57,230,0,255)
local spacebar = 0x20
--render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 100, "x " .. positionx .. " y ".. positiony .. " z "..positionz, csgo.color(255,255,255,255))
is_inside = false
if input:is_key_down(spacebar) then return end
if(positiony > 519 and positiony < 617 and positionx > -713 and positionx < -618)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Short B", medium)
end
if(positiony > 461 and positiony < 533 and positionx > -191 and positionx < -150)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Underground", medium)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -815 and positiony < -730 and positionx > -740 and positionx < -675)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Under stairs", easy)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > 255 and positiony < 330 and positionx > -1035 and positionx < -965 and positionz == -368)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - B apartment", medium)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > 426 and positiony < 481 and positionx > -495 and positionx < -466)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - T apartment", easy)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -576 and positiony < -539 and positionx > -234 and positionx < -176)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Top Middle", medium)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -2070 and positiony < -2016 and positionx > -234 and positionx < -180)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - CT", easy)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -1319 and positiony < -1308 and positionx > -1009 and positionx < -991)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Other side (MANUAL)", hard)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "CROUCH", csgo.color(200,50,50,r))
end
if(positiony > -1410 and positiony < -1394 and positionx > -553 and positionx < -534)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Palace", medium) -- box one
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -1199 and positiony < -1151 and positionx > -809 and positionx < -760)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Palace", medium) --stairs one
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -2120 and positiony < -2075 and positionx > -316 and positionx < -274 and positionz == -101)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Ramp", easy)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if((positiony > 765 and positiony < 873 and positionx > 306 and positionx < 364) or (positiony > 765 and positiony < 873 and positionx > 198 and positionx < 255))then
    render:text(speedfont, screen_size.x / 2 - 55, screen_size.y / 2 - 120, "1w - Top Middle", easy)
end
if(positiony > -359 and positiony < -325 and positionx > -406 and positionx < -219)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Top Middle", hard)
end
if(positiony > -1612 and positiony < -1569 and positionx > 753 and positionx < 816)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Ramp", easy)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "CROUCH", csgo.color(200,50,50,r))
end
if(positiony > 665 and positiony < 735 and positionx > -2289 and positionx < -2240)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Kitchen", medium)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -1562 and positiony < -1525 and positionx > -496 and positionx < -460)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Ramp", medium)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -1748 and positiony < -1735 and positionx > -38 and positionx < -3)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Palace", medium) --from ramp
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > 203 and positiony < 222 and positionx > 1103 and positionx < 1186)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - T Spawn", easy)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > 314 and positiony < 376 and positionx > 1190 and positionx < 1358)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - T Spawn/T Roof", easy)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
 end
if(positiony > 200 and positiony < 287 and positionx > 1190 and positionx < 1360)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - T to Ramp", medium)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -719 and positiony < -704 and positionx > 1232 and positionx < 1241)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Palace", hard)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -849 and positiony < -795 and positionx > -1469 and positionx < -1437)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Jungle", easy)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > -1697 and positiony < -1662 and positionx > -1475 and positionx < -1472)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - A to CT", hard)
end
if(positiony > -1223 and positiony < -1207 and positionx > -1712 and positionx < -1685)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - Kitchen", easy)
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 135, "FAKEDUCK", csgo.color(200,50,50,r))
end
if(positiony > 718 and positiony < 756 and positionx > -465 and positionx < -395)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - B apartment", easy)
end
if(positiony > 287 and positiony < 298 and positionx > -1146 and positionx < -1099)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - B underpass", hard)
end
if(positiony > 333 and positiony < 362 and positionx > 330 and positionx < 441)then
    render:text(speedfont, screen_size.x / 2 - 50, screen_size.y / 2 - 120, "1w - T Spawn cross", medium)
end
end
end
 
local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)