-- game vars
local entity_list = csgo.interface_handler:get_entity_list()
local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local input = fatality.input
local cvar = csgo.interface_handler:get_cvar()
local global_vars = csgo.interface_handler:get_global_vars()
local events = csgo.interface_handler:get_events()

-- references

local stand_add = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Yaw add")
local stand_add_val = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Add")
local stand_fake_amount = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake amount")
local stand_fake_type = menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake type")

local moving_add = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Yaw add")
local moving_add_val = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Add")
local moving_fake_amount = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake amount")
local moving_fake_type = menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake type")



-- lua menu

local swaponshot_item = config:add_item("lua_cheatservices_swaponshot", 0)
local swaponshot_checkbox = menu:add_checkbox("Enable Anti-Bruteforce", "RAGE", "ANTI-AIM", "General", swaponshot_item)

local swaponshot_mode_item = config:add_item("lua_cheatservices_swaponshot_mode", 0)
local swaponshot_mode_combo = menu:add_combo("Anti-Bruteforce Mode", "RAGE", "ANTI-AIM", "General", swaponshot_mode_item)
swaponshot_mode_combo:add_item("Invert Fake amount", flick_item)
swaponshot_mode_combo:add_item("Switch Fake type", flick_item)

-- lua vars

local closest_enemy = nil
local local_alive = false

-- functions

function vec_distance(f_x, f_y, f_z, t_x, t_y, t_z)

    local delta_x, delta_y, delta_z = f_x - t_x, f_y - t_y, f_z - t_z

    return math.sqrt(delta_x * delta_x + delta_y * delta_y + delta_z * delta_z)

end

function update_closest_enemy()
    local local_player = entity_list:get_localplayer()
    local local_team = local_player:get_var_int("CBaseEntity->m_iTeamNum")
    local local_origin = local_player:get_var_vector("CBaseEntity->m_vecOrigin")
    local best_entity = nil
    local best_distance = 9999999

    for i = entity_list:get_max_players(), 1, -1 do
        local entity = entity_list:get_player(i)
        if not (entity == nil) then
            if (entity:is_player()) then
                if not (entity:is_dormant()) then
                    if(entity:is_alive()) then
                        if not (entity:get_var_int("CBaseEntity->m_iTeamNum") == local_team) then
                            local origin = entity:get_var_vector("CBaseEntity->m_vecOrigin")
                            local temp_distance = vec_distance(local_origin.x, local_origin.y, local_origin.z, origin.x, origin.y, origin.z)
                            if(temp_distance < best_distance) then
                                best_entity = entity
                                best_distance = temp_distance
                            end
                        end
                    end
                end
            end
        end
    end
   
    closest_enemy = best_entity
end

function on_event(event)
    local user_id = event:get_int("userid")
    local local_player = entity_list:get_localplayer()
    if(local_player == nil) then
        return
    end

    if(event:get_name() == "weapon_fire") then
        if (local_player:is_alive( )) then
            if not (closest_enemy == nil) then
                local entity = entity_list:get_player_from_id(user_id)
                if(entity:get_index() == closest_enemy:get_index()) then
                    if(swaponshot_item:get_bool()) then
                        if(swaponshot_mode_item:get_int( ) == 0) then
                            stand_fake_amount:set_float(-stand_fake_amount:get_float())
                            moving_fake_amount:set_float(-moving_fake_amount:get_float())
                        end
                        if(swaponshot_mode_item:get_int( ) == 1) then
                            local new_mode = math.random(2, 3)
                            stand_fake_type:set_float(new_mode)
                            moving_fake_type:set_float(new_mode)
                        end
                    end
                end
            end
        end
    end
end

function on_paint()
    local local_player = entity_list:get_localplayer()
    local screen_size = render:screen_size( )

    if(local_player == nil) then
        return
    end

    if(local_player:is_alive( )) then
        update_closest_enemy()
    else
        closest_enemy = nil
    end

    if not (closest_enemy == nil) then
        render:indicator( 10, screen_size.y - screen_size.y / 4 - 30, "BruteForce Target: "..closest_enemy:get_name( ), true, -1 )
    end
end

-- callbacks

events:add_event("weapon_fire")

local callbacks = fatality.callbacks
callbacks:add("paint", on_paint)
callbacks:add("events", on_event)