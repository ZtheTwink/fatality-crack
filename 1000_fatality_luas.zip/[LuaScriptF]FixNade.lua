local render = fatality.render
local input = fatality.input
local menu = fatality.menu
local config = fatality.config
local engine_client = csgo.interface_handler:get_engine_client()
local global_vars = csgo.interface_handler:get_global_vars()
local entity_list = csgo.interface_handler:get_entity_list( )



local disable_nades_item = config:add_item( "fl_enable_standing_item", 0 )
local disable_nades_checkbox = menu:add_checkbox( "-Disable on nades", "rage", "anti-aim", "general", disable_nades_item )



local disable_nades = menu:get_reference( "rage", "anti-aim", "general", "anti-aim" )
local disable_nades1 = menu:get_reference( "rage", "anti-aim", "standing", "yaw add" )
local disable_nades2 = menu:get_reference( "rage", "anti-aim", "moving", "yaw add" )
local disable_nades3 = menu:get_reference( "rage", "anti-aim", "air", "yaw add" )
local disable_nades4 = menu:get_reference( "rage", "anti-aim", "standing", "add" )
local disable_nades5 = menu:get_reference( "rage", "anti-aim", "moving", "add" )
local disable_nades6 = menu:get_reference( "rage", "anti-aim", "air", "add" )
local disable_nades7 = menu:get_reference( "rage", "anti-aim", "standing", "fake direction" )
local disable_nades8 = menu:get_reference( "rage", "anti-aim", "moving", "fake direction" )
local disable_nades9 = menu:get_reference( "rage", "anti-aim", "air", "fake direction" )


function on_paint()
 weapontable = {
        [1] = "AK47",
        [32] = "C4",
        [44] = "Desert Eagle",
        [45] = "Decoy Grenade",
        [75] = "Flashbang",
        [94] = "Frag Grenade",
        [97] = "Incendiary Grenade",
        [110] = "Molotov Grenade",
        [105] = "Knife",
        [152] = "Smoke Grenade",
        [228] = "AUG",
        [229] = "AWP",
        [231] = "Bizon",
        [235] = "Dualies",
        [237] = "Five Seven",
        [238] = "G3SG1",
        [240] = "Galil-AR",
        [241] = "Glock",
        [242] = "P2000",
        [243] = "M249",
        [245] = "M4A1",
        [249] = "MP7",
        [250] = "MP9",
        [247] = "Mag7",
        [252] = "Nova",
        [251] = "Negev",
        [254] = "P250",
        [255] = "P90",
        [257] = "SCAR20",
        [261] = "SG556",
        [262] = "SSG08",
        [263] = "Taser",
        [264] = "Tec9",
        [266] = "UMP45",
        [268] = "XM1014",
 }

local local_player = entity_list:get_localplayer( );

if local_player == nil then
    return
end

 local weapon = csgo.interface_handler:get_entity_list():get_from_handle(local_player:get_var_handle( "CBaseCombatCharacter->m_hActiveWeapon" ) )


if weapon == nil then
    return
end

 local weaponindex = weapon:get_class_id()

 local weaponname = weapontable[weaponindex]

 
 

        if disable_nades_item:get_bool() then

                if ( disable_nades_item:get_bool() and weaponindex == 110 or weaponindex == 97 or weaponindex == 94 or weaponindex == 75 or weaponindex == 45 or weaponindex == 152 ) then
                   disable_nades:set_bool(false)
                   disable_nades1:set_bool(true)
                   disable_nades2:set_bool(true)
                   disable_nades3:set_bool(true)
                   disable_nades4:set_float(0)
                   disable_nades5:set_float(0)
                   disable_nades6:set_float(0)
                   disable_nades7:set_bool(false)
                   disable_nades8:set_bool(false)
                   disable_nades9:set_bool(false)                   
                else
                   disable_nades:set_bool(true)
                   disable_nades7:set_int(1)
                   disable_nades8:set_int(2)
                   disable_nades9:set_int(1)
                end

        end

end




local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )