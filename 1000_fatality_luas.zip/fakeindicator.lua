local a=fatality.render;
local b=fatality.config;
local c=fatality.menu;
local d=csgo.interface_handler:get_cvar()
local e=csgo.interface_handler:get_engine_client()
local f=csgo.interface_handler:get_entity_list()
local g=csgo.interface_handler:get_global_vars()
local h=fatality.input;
local i=b:add_item("fake_ghetto_indicator",0.0)
local j=c:add_combo("Fake indicator","VISUALS","MISC","Local",i)j:add_item("Off",i)j:add_item("Fake indicator",i)j:add_item("Fake indicator + bar",i)
local k=a:screen_size()
local l=a:create_font("Verdana",27,700,true)
local m=61;
local n=38;
local o=53;
local p=30;
local q=50;
local r=211;
local s=0;
local t=0;
local u=0;
local v=c:get_reference("RAGE","ANTI-AIM","General","Anti-aim")
function on_paint()if not e:is_in_game()then 
return end;
local w=f:get_localplayer()
if not w:is_alive()then return 
end;
local x=csgo.color(211,0,0,255)
local y=csgo.color(131,181,0,255)
local z=csgo.color(math.floor(r),math.floor(s),math.floor(t),255)
local A=w:get_var_vector("CBasePlayer->m_vecVelocity[0]")
local B=math.ceil(math.sqrt(math.abs(A.x)*math.abs(A.x)+math.abs(A.y)*math.abs(A.y)))
local C=w:get_var_bool("CBasePlayer->m_bDucking")
local D=w:get_var_bool("CBasePlayer->m_bDucked")
local E=w:get_var_bool("CBasePlayer->m_hGroundEntity")
if v:get_bool()then if C or D then if B>15 or E then if r<211 then r=r+280*g.frametime;
if r>211 then r=211 end end;
if s<110 then s=s+280*g.frametime;
if s>110 then s=110 end elseif s>110 then s=s-280*g.frametime;
if s<110 then s=110 end end;
if u<p then u=u+q*g.frametime;
if u>p then u=p end elseif u>p then u=u-q*g.frametime;
if u<p then u=p end end else if r>131 then r=r-280*g.frametime;
if r<131 then r=131 end end;
if s<181 then s=s+280*g.frametime;
if s>181 then s=181 end end;
if u<m then u=u+q*g.frametime;
if u>m then u=m end elseif u>m then u=u-q*g.frametime;
if u<m then u=m end end end else if B>15 and B<90 then if r>161 then r=r-280*g.frametime;
if r<161 then r=161 end elseif r<161 then r=r+280*g.frametime;
if r>161 then r=161 end end;if s<160 then s=s+280*g.frametime;
if s>160 then s=160 end elseif s>160 then s=s-280*g.frametime;
if s<160 then s=160 end end;if u<o then u=u+q*g.frametime;
if u>o then u=o end elseif u>o then u=u-q*g.frametime;
if u<o then u=o end end elseif B>90 or E then if not E then if r<211 then r=r+280*g.frametime;
if r>211 then r=211 end end;if s<190 then s=s+280*g.frametime;
if s>190 then s=190 end elseif s>190 then s=s-280*g.frametime;
if s<190 then s=190 end end;if u<n then u=u+q*g.frametime;
if u>n then u=n end elseif u>n then u=u-q*g.frametime;
if u<n then u=n end end else if r<211 then r=r+280*g.frametime;
if r>211 then r=211 end end;if s<140 then s=s+280*g.frametime;
if s>140 then s=140 end elseif s>140 then s=s-280*g.frametime;
if s<140 then s=140 end end;if u<n-5 then u=u+q*g.frametime;
if u>n-5 then u=n-5 end elseif u>n-5 then u=u-q*g.frametime;
if u<n-5 then u=n-5 end end end else if r>131 then r=r-280*g.frametime;
if r<131 then r=131 end end;if s<181 then s=s+280*g.frametime;
if s>181 then s=181 end end;if u<m then u=u+q*g.frametime;
if u>m then u=m end elseif u>m then u=u-q*g.frametime;
if u<m then u=m end end end end;
if i:get_int()==1 then a:text(l,10,k.y/1.115,"FAKE",z)
elseif i:get_int()==2 then a:text(l,10,k.y/1.115,"FAKE",z)a:rect_filled(12,k.y/1.087,61,4,csgo.color(45,45,45,120))a:rect_filled(12+1,k.y/1.087+1,0+u-2,2,z)
end 
end 
end;
local F=fatality.callbacks;F:add("paint",on_paint)
