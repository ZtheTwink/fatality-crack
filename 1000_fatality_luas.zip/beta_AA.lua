-- config

local invert_key = 0x5

-- dependencies

local csgo_globals = csgo.interface_handler:get_global_vars()
function tick() return csgo_globals.tickcount end

local function get_item(index, value)
    -- fatality crashes whenever this executes, shit cheat
    --[[local f_value = fatality.config:get_item(index)
    if type(f_value) == "nil" then return fatality.config:add_item(index, value) end
    return f_value--]]

    return fatality.config:add_item(index, value)
end

local function create_combo(name, tab_name, sub_tab_name, child_name, config_item, items)
    if not (type(items) == "table") or #items == 0 then return end

    local f_value = fatality.menu:add_combo(name, tab_name, sub_tab_name, child_name, config_item)
    for i, v in pairs(items) do
        f_value.add_item(i, v)
    end

    return f_value
end

local rage_antiaim_fakeamounts = {
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake amount"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake amount"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Air", "Fake amount")
}

local rage_antiaim_faketypes = {
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Standing", "Fake type"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Moving", "Fake type"),
    fatality.menu:get_reference("RAGE", "ANTI-AIM", "Air", "Fake type")
}

local enums = {
    antiaim = {
        sway = 1,
        match = 2
    },

    lby_type = {
        none = 0,
        match = 1,
        invert = 2,
        auto = 3
    },

    direction = {
        left = 1,
        right = 2
    },

    doubletap = {
        off = 0,
        on = 1
    }
}

local config_items = {
    enabled = get_item("ragesu_enabled", 0),
    lby_type = get_item("ragesu_antiaim_option", enums.lby_type.invert),
    antiaim = get_item("ragesu_antiaim_option", enums.antiaim.match),
    direction = get_item("ragesu_current_direction", enums.direction.left),
    direction_min = get_item("ragesu_current_direction_minimum", 0),
    direction_max = get_item("ragesu_current_direction_maximum", 100),
    speed = get_item("ragesu_speed", 1),
    doubletap = get_item("ragesu_doubletap", enums.doubletap.off),

    current_fakeamount = get_item("ragesu_current_fakeamount", 100)
}

local menu_items = {
    enabled = fatality.menu:add_checkbox("RageSu - Enable", "RAGE", "ANTI-AIM", "General", config_items.enabled),
   
    -- crashes fatality & gets you loader banned, dont recommend
    --[[lby_type = create_combo("LBY Type", "RAGE", "ANTI-AIM", "General", config_items.lby_type, {
        None = get_item("ragesu_enums_lby_type_none", enums.lby_type.none),
        Match = get_item("ragesu_enums_lby_type_match", enums.lby_type.match),
        Invert = get_item("ragesu_enums_lby_type_invert", enums.lby_type.invert),
        Auto = get_item("ragesu_enums_lby_type_auto", enums.lby_type.auto)
    }),
    antiaim = create_combo("Mode", "RAGE", "ANTI-AIM", "General", config_items.antiaim, {
        Sway = get_item("ragesu_enums_antiaim_sway", enums.antiaim.sway),
        Match = get_item("ragesu_enums_antiaim_match", enums.antiaim.match)
    }),--]]

    direction_min = fatality.menu:add_slider("Direction Minimum", "RAGE", "ANTI-AIM", "General", config_items.direction_min, 0, 100, config_items.direction_min:get_float()),
    direction_max = fatality.menu:add_slider("Direction Maximum", "RAGE", "ANTI-AIM", "General", config_items.direction_max, 0, 100, config_items.direction_max:get_float()),
    speed = fatality.menu:add_slider("Speed", "RAGE", "ANTI-AIM", "General", config_items.speed, 0, 5, config_items.speed:get_float())
}

-- main

local function clamp(value, minimum, maximum)
    if value > maximum then
        value = maximum
    elseif value < minimum then
        value = minimum
    end

    return value
end

local function abs(value)
    return (0 > value and -(value)) or value
end

local function set_fakeamounts(value)
    for _, fatality_value in pairs(rage_antiaim_fakeamounts) do
        fatality_value:set_int(value)
    end

    config_items.current_fakeamount:set_int(value)
end

local function set_faketype(value)
    for _, fatality_value in pairs(rage_antiaim_faketypes) do
        fatality_value:set_int(value)
    end
end

local last_tick = tick()

function on_paint_callback()
    if not config_items.enabled:get_bool() then return end

    if fatality.input:is_key_down(invert_key) then
        config_items.direction:set_int((config_items.direction:get_int() == enums.direction.left and enums.direction.right) or enums.direction.left)
    end

    local min_dir, max_dir, current_dir = config_items.direction_min:get_int(), config_items.direction_max:get_int(), config_items.direction:get_int()
    local speed = config_items.speed:get_int()

    if config_items.antiaim:get_int() == enums.antiaim.sway then
        if tick() - last_tick > 0.01 then
            local current_amount = config_items.current_fakeamount:get_int()
            current_amount = current_amount + ((current_dir == enums.direction.left and -speed) or speed)

            -- switch sides
            if abs(current_amount) > max_dir then
                current_dir = (current_dir == enums.direction.left and enums.direction.right) or enums.direction.left               
                config_items.direction:set_int(current_dir)
            end

            -- clamp
            if current_amount == abs(min_dir) then
                current_amount = -abs(min_dir)
            elseif current_amount == -abs(min_dir) then
                current_amount = abs(min_dir)
            end

            set_fakeamounts(current_amount)

            last_tick = tick()
        end
    elseif config_items.antiaim == enums.antiaim.match then
        if tick() - last_tick > 0.01 then
            local current_amount = config_items.current_fakeamount:get_int()
            current_amount = current_amount + ((current_dir == enums.direction.left and -speed) or speed)

            -- switch sides
            if abs(current_amount) > max_dir or abs(current_amount) == abs(min_dir) then
                current_dir = (current_dir == enums.direction.left and enums.direction.right) or enums.direction.left               
                config_items.direction:set_int(current_dir)
            end

            set_fakeamounts(current_amount)

            last_tick = tick()
        end
    end

    set_faketype(config_items.lby_type)
end

fatality.callbacks:add("paint", on_paint_callback)