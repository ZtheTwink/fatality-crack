

local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()
local menu = fatality.menu
local config = fatality.config

local force_baim_ref = menu:get_reference("RAGE", "AIMBOT", "Aimbot", "Force baim")

local baim_after_item = config:add_item("baim_after", 2)
local baim_after_slider = menu:add_slider("Baim after n", "RAGE", "AIMBOT", "Aimbot", baim_after_item, 1, 10, 1)

local misses = 0

events:add_event("round_start")

fatality.callbacks:add("registered_shot", function(e)
    -- resolver miss / server issue (head)
    if(e.hit and not e.hurt and e.target_hitgroup == 1) then
        misses = misses + 1
    end
   
    local player = entity_list:get_player(e.victim)
   
    -- if we killed someone, disable force baim
    if(e.hurt and player:get_var_int("CBasePlayer->m_iHealth") <= 0) then
        misses = 0
        force_baim_ref:set_bool(false)
    end
end)

fatality.callbacks:add("paint", function()
    if(misses >= baim_after_item:get_int()) then
        force_baim_ref:set_bool(true)
    end
end)

fatality.callbacks:add("events", function(e)
    if(e:get_name() == "round_start") then
        misses = 0
        force_baim_ref:set_bool(false)
    end
end)

