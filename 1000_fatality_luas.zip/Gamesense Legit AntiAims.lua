-- https://fatality.win/threads/gs-like-legit-aa-casual-detected-ofc-pasted.4429/

--Shoutout to Hypnotic (Pasted by Clownd)
local yawadd_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Yaw Add" )
local yawadd_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Yaw Add" )

local yawadd_stand_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Add" )
local yawadd_move_amount = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Add" )

local fakeamount_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake amount" )
local fakeamount_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake amount" )
local indicators = fatality.config:add_item( "indicators_desync", 0 )
local menu = fatality.menu:add_checkbox( "ClowndDesync [enable]", "RAGE", "ANTI-AIM", "General", indicators )
local faketype_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Fake type" )
local faketype_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Fake type" )

local freestandfake_stand = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Standing", "Freestand fake" )
local freestandfake_move = fatality.menu:get_reference( "RAGE", "ANTI-AIM", "Moving", "Freestand fake" )
local indswap = fatality.config:add_item( "swaplol", 0 )

local VK_KEY_Z = 0x5A
local VK_KEY_X = 0x58

local aa_type_legit = fatality.config:add_item( "aa_type_legit", 2 )

local aa_type_legit_add = fatality.menu:add_combo( "legit Desync Type", "RAGE", "ANTI-AIM", "General", aa_type_legit )

aa_type_legit_add:add_item("Off", aa_type_legit)
aa_type_legit_add:add_item("Legit [C&Z = INVERT]", aa_type_legit)

local arial = fatality.render:create_font( "Small Fonts", 9, 0, 0 )

local change_x = fatality.config:add_item( "pos_x", 0 )
local change_y = fatality.config:add_item( "pos_y", 0 )

local cursor_pos = fatality.input:get_mouse_pos( )



function render_indicators(pos_x, pos_y, width, height)
    if fatality.input:is_key_down(0x2E) and fatality.input:is_key_down(0x01) then

        change_x:set_int( fatality.input:get_mouse_pos( ).x )
        change_y:set_int( fatality.input:get_mouse_pos( ).y )
        fatality.render:rect_fade(  pos_x + change_x:get_int() - 5 - 1, pos_y + change_y:get_int() - 5 - 1, width + 10 + 2, height + 10 + 2, csgo.color(255, 0, 0, 255), csgo.color(255, 0, 255, 255))

      end
fatality.render:rect_filled( pos_x + change_x:get_int() - 5, pos_y + change_y:get_int() - 5, width + 10, height + 10, csgo.color(0,0,0, 255))
fatality.render:rect_filled( pos_x + change_x:get_int() - 4, pos_y + change_y:get_int() - 4, width + 8, height + 8, csgo.color(65, 65, 65, 155))
fatality.render:rect_filled( pos_x + change_x:get_int() - 3, pos_y + change_y:get_int() - 3, width + 6, height + 6, csgo.color(25, 25, 25, 155))
fatality.render:rect_filled( pos_x + change_x:get_int(), pos_y + change_y:get_int(), width, height, csgo.color(20, 20, 20, 255))
fatality.render:rect( pos_x + change_x:get_int(), pos_y + change_y:get_int(), width, height, csgo.color(65, 65, 65, 155))
fatality.render:rect_fade(  pos_x + change_x:get_int() + 3, pos_y + change_y:get_int() + 3, width - 6, height - 149, csgo.color(255, 255, 0, 255), csgo.color(255, 0, 255, 255), true )

fatality.render:text( arial, pos_x + change_x:get_int() + 6 + width - 135, pos_y + change_y:get_int() + 15 - 3, "CLOWNDLEGIT_DESYNC", csgo.color(255, 255, 255, 255) )
fatality.render:rect(  pos_x + change_x:get_int() + 6, pos_y + change_y:get_int() + 6 + 25 - 4, width - 12, height - 149, csgo.color(255, 255, 255, 10) )
fatality.render:rect(  pos_x + change_x:get_int() + 6, pos_y + change_y:get_int() + 6 + 25 - 3, width - 12, height - 149, csgo.color(0,0,0, 255) )
-- groupboxes <fucking skeet skeet nigga>

fatality.render:rect_filled( pos_x + change_x:get_int() + 7, pos_y + change_y:get_int() + 35, width - 45 + 30, height - 42, csgo.color(25, 25, 25, 255) )
fatality.render:rect( pos_x + change_x:get_int() + 7, pos_y + change_y:get_int() + 35, width - 45 + 30, height - 42, csgo.color(0,0,0, 255) )
fatality.render:rect( pos_x + change_x:get_int() + 7 + 1, pos_y + change_y:get_int() + 35 + 1, width - 45 + 30 - 2, height - 42 - 2, csgo.color(60, 60, 60, 255) )

-- <text>

fatality.render:text( arial, pos_x + change_x:get_int() + 6 + 25, pos_y + change_y:get_int() + 55 - 3, "FAKE AMOUNT TYPE:  " .. faketype_stand:get_int( ), csgo.color(207, 202, 70, 255) )
fatality.render:text( arial, pos_x + change_x:get_int() + 6 + 25, pos_y + change_y:get_int() + 55 - 3 + 15, "FREESTAND FAKE:  " .. faketype_stand:get_int( ), csgo.color(207, 202, 70, 255) )
if (indswap:get_bool()) then
    fatality.render:text( arial, pos_x + change_x:get_int() + 6 + 25, pos_y + change_y:get_int() + 55 - 3 + 15 + 15, "REAL DIRECTION: LEFT ", csgo.color(255, 255, 255, 255) )
else
fatality.render:text( arial, pos_x + change_x:get_int() + 6 + 25, pos_y + change_y:get_int() + 55 - 3 + 15 + 15, "REAL DIRECTION: RIGHT ", csgo.color(255, 255, 255, 255) )






    end

    if (aa_type_legit:get_int() == 1) then
        fatality.render:text( arial, pos_x + change_x:get_int() + 6 + 25, pos_y + change_y:get_int() + 55 - 3 + 15 + 15 + 15 + 15, "USING: LEGIT DESYNC  |  KEYBINDS:  Z & X", csgo.color(255, 255, 255, 255) )
    end
end


local side = false
function paint()





if (indicators:get_bool( )) then

    render_indicators(0, 0, 200, 150) -- < render the big boy >
    side = not side
    if (aa_type_legit:get_int() == 2) then
        yawadd_stand:set_bool( true )
        yawadd_move:set_bool( true )
        if (side) then
        yawadd_stand_amount:set_float( 60 )
        yawadd_move_amount:set_float( 0 )

        fakeamount_stand:set_float( 50 )
        fakeamount_move:set_float( 0 )

        faketype_stand:set_int( 2 )
        faketype_move:set_int( 2 )
        freestandfake_move:set_bool( true )
        freestandfake_stand:set_bool( true )

        else
            yawadd_stand_amount:set_float( -100 )
            yawadd_move_amount:set_float( -100 )

            fakeamount_stand:set_float( 65 )
        fakeamount_move:set_float( 0 )

        faketype_stand:set_int( 1 )
        faketype_move:set_int( 1 )


        freestandfake_move:set_bool( false )
        freestandfake_stand:set_bool( false )
        end

        end

    if (aa_type_legit:get_int() == 1 ) then
        yawadd_stand:set_bool( false )
        yawadd_move:set_bool( false )
        freestandfake_move:set_bool( false )
        freestandfake_stand:set_bool( false )
        faketype_stand:set_int( 2 )
        faketype_move:set_int( 2 )
    if (fatality.input:is_key_pressed( VK_KEY_Z )) then
    fakeamount_stand:set_float( 100 )
    indswap:set_bool( true )

    elseif (fatality.input:is_key_pressed( VK_KEY_X )) then

        fakeamount_stand:set_float( -100 )
        indswap:set_bool( false )
    end
    end

end



end


fatality.callbacks:add( "paint", paint)