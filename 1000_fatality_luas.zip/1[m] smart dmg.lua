-- _markjelo luas + cfg

print("mindmg LUA for my cfg _markjelo#9266")

--interfaces
local menu = fatality.menu
local input = fatality.input
local config = fatality.config
local render = fatality.render
local cvar = csgo.interface_handler:get_cvar( )
local engine_client = csgo.interface_handler:get_engine_client( )
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
local scrnsize = render:screen_size( )
-------------------------------------------------------------------------------
-- enable cfg
--auto
local smart_min_dmg_activate_auto = config:add_item( "smart_min_dmg_activate_auto", 1 )
local smart_min_dmg_amount_auto = config:add_item( "smart_min_dmg_amount_auto", 1 )
--awp
local smart_min_dmg_activate_awp = config:add_item( "smart_min_dmg_activate_awp", 1 )
local smart_min_dmg_amount_awp = config:add_item( "smart_min_dmg_amount_awp", 1 )
--pistols
local smart_min_dmg_activate_pistols = config:add_item( "smart_min_dmg_activate_pistols", 1 )
local smart_min_dmg_amount_pistols = config:add_item( "smart_min_dmg_amount_pistols", 1 )
--scout
local smart_min_dmg_activate_scout = config:add_item( "smart_min_dmg_activate_scout", 1 )
local smart_min_dmg_amount_scout = config:add_item( "smart_min_dmg_amount_scout", 1 )
--heavy pistols
local smart_min_dmg_activate_heavy_pistols = config:add_item( "smart_min_dmg_activate_heavy_pistols", 1 )
local smart_min_dmg_amount_heavy_pistols = config:add_item( "smart_min_dmg_amount_heavy_pistols", 1 )
--other
local smart_min_dmg_activate_other = config:add_item( "smart_min_dmg_activate_other", 1 )
local smart_min_dmg_amount_other = config:add_item( "smart_min_dmg_amount_other", 1 )
-------------------------------------------------------------------------------
-- enable
--auto
local smart_min_dmg_activate_auto = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "auto", smart_min_dmg_activate_auto)
local smart_min_dmg_amount_auto = menu:add_slider( "Smart amount", "rage", "weapons", "auto", smart_min_dmg_amount_auto, -100, 100, 1)
--awp
local smart_min_dmg_activate_awp = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "awp", smart_min_dmg_activate_awp)
local smart_min_dmg_amount_awp = menu:add_slider( "Smart amount", "rage", "weapons", "awp", smart_min_dmg_amount_awp, -100, 100, 1)
--pistols
local smart_min_dmg_activate_pistols = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "pistols", smart_min_dmg_activate_pistols)
local smart_min_dmg_amount_pistols = menu:add_slider( "Smart amount", "rage", "weapons", "pistols", smart_min_dmg_amount_pistols, -100, 100, 1)
--scout
local smart_min_dmg_activate_scout = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "scout", smart_min_dmg_activate_scout)
local smart_min_dmg_amount_scout = menu:add_slider( "Smart amount", "rage", "weapons", "scout", smart_min_dmg_amount_scout, -100, 100, 1)
--heavy pistols
local smart_min_dmg_activate_heavy_pistols = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "heavy pistols", smart_min_dmg_activate_heavy_pistols)
local smart_min_dmg_amount_heavy_pistols = menu:add_slider( "Smart amount", "rage", "weapons", "heavy pistols", smart_min_dmg_amount_heavy_pistols, -100, 100, 1)
--other
local smart_min_dmg_activate_other = menu:add_checkbox( "Smart min dmg", "rage", "weapons", "other", smart_min_dmg_activate_other)
local smart_min_dmg_amount_other = menu:add_slider( "Smart amount", "rage", "weapons", "other", smart_min_dmg_amount_other, -100, 100, 1)
-------------------------------------------------------------------------------
-- ref
--auto
local auto_min_dmg = menu:get_reference( "rage", "weapons", "auto", "Min-damage" )
local smart_min_dmg_activate_auto = menu:get_reference( "rage", "weapons", "auto", "Smart min dmg")
local smart_min_dmg_amount_auto = menu:get_reference( "rage", "weapons", "auto", "Smart amount")
--awp
local awp_min_dmg = menu:get_reference( "rage", "weapons", "awp", "Min-damage" )
local smart_min_dmg_activate_awp = menu:get_reference( "rage", "weapons", "awp", "Smart min dmg")
local smart_min_dmg_amount_awp = menu:get_reference( "rage", "weapons", "awp", "Smart amount")
--pistols
local pistols_min_dmg = menu:get_reference( "rage", "weapons", "pistols", "Min-damage" )
local smart_min_dmg_activate_pistols = menu:get_reference( "rage", "weapons", "pistols", "Smart min dmg")
local smart_min_dmg_amount_pistols = menu:get_reference( "rage", "weapons", "pistols", "Smart amount")
--scout
local scout_min_dmg = menu:get_reference( "rage", "weapons", "scout", "Min-damage" )
local smart_min_dmg_activate_scout = menu:get_reference( "rage", "weapons", "scout", "Smart min dmg")
local smart_min_dmg_amount_scout = menu:get_reference( "rage", "weapons", "scout", "Smart amount")
--heavy pistols
local heavy_pistols_min_dmg = menu:get_reference( "rage", "weapons", "heavy pistols", "Min-damage" )
local smart_min_dmg_activate_heavy_pistols = menu:get_reference( "rage", "weapons", "heavy pistols", "Smart min dmg")
local smart_min_dmg_amount_heavy_pistols = menu:get_reference( "rage", "weapons", "heavy pistols", "Smart amount")
--other
local other_min_dmg = menu:get_reference( "rage", "weapons", "other", "Min-damage" )
local smart_min_dmg_activate_other = menu:get_reference( "rage", "weapons", "other", "Smart min dmg")
local smart_min_dmg_amount_other = menu:get_reference( "rage", "weapons", "other", "Smart amount")
-------------------------------------------------------------------------------

-- function
function on_paint( )
	if not engine_client:is_in_game( ) then
		return end
        
    local local_player = entity_list:get_localplayer( )

    if not local_player:is_alive( ) then
		return end
	--awp
	if smart_min_dmg_activate_awp:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_awp:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				awp_min_dmg:set_int( enemy_health + smart_min_dmg_amount_awp:get_int( ))
            end
        end
	end
	--auto
	if smart_min_dmg_activate_auto:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_auto:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				auto_min_dmg:set_int( enemy_health + smart_min_dmg_amount_auto:get_int( ))
            end
        end
	end
	--pistols
	if smart_min_dmg_activate_pistols:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_pistols:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				pistols_min_dmg:set_int( enemy_health + smart_min_dmg_amount_pistols:get_int( ))
            end
        end
	end
	--scout
	if smart_min_dmg_activate_scout:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_scout:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				scout_min_dmg:set_int( enemy_health + smart_min_dmg_amount_scout:get_int( ))
            end
        end
	end
	--heavy pistols
	if smart_min_dmg_activate_heavy_pistols:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_heavy_pistols:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				heavy_pistols_min_dmg:set_int( enemy_health + smart_min_dmg_amount_heavy_pistols:get_int( ))
            end
        end
	end
	--other
	if smart_min_dmg_activate_other:get_bool( ) then
        for i = 1, entity_list:get_max_players( ) do
            local player = entity_list:get_player( i )
            if smart_min_dmg_activate_other:get_bool( ) and player ~= nil and player:is_alive() and not player:is_dormant( ) and player:get_var_int("CBaseEntity->m_iTeamNum") ~= local_player:get_var_int("CBaseEntity->m_iTeamNum") then
                local enemy_health = player:get_var_int( "CBasePlayer->m_iHealth" )
				other_min_dmg:set_int( enemy_health + smart_min_dmg_amount_other:get_int( ))
            end
        end
	end
end

-- callbacks
local callbacks = fatality.callbacks
callbacks:add( "paint", on_paint )