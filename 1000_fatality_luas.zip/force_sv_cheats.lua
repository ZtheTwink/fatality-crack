-- https://fatality.win/threads/simple-force-sv_cheats.3156/

local interface_cvar = csgo.interface_handler:get_cvar( )
local var = interface_cvar:find_var( "sv_cheats" )

if var:get_int( ) == 0 then
    var:unlock( )
    var:set_int( 1 )
end