-- Combokill sounds & effects by eslipe v.1.4 (current verison of: 30.07.2019)

--[[ Updatelog:

(30.07.2019)
- Added customizable fonts.
- Added ability to change text-effect for each kill.
- Added checkbox to switch capitalization of letters.
- Fixed incorrect placement of features.
- All objects, that need an installation are marked by a "*" symbol. "example*"
- Increased the minimum value of "Text size" and "Animation speed" functions.

(18.02.2019)
- Added animation speed slider.
- Added "First blood" sound effect (Automatically activates on the first kill)
- Added "First blood" text effect (Automatically activates on the first kill)
- Removed "!" symbol at the end of combo-kill text.
- Added shadow for combo-kill text.
- Fixed overflow error.



(14.02.2019)
- Added menu support.
- Added customizable text size.
- Now you can enable/disable effects and/or sounds/

]]

-- getting needed variables
local render = fatality.render --< to render text effects
local callbacks = fatality.callbacks --< to be albe to make callbacks
local menu = fatality.menu
local config = fatality.config

-- getting all interfaces
local engine_client = csgo.interface_handler:get_engine_client() --< engine client
local entity_list = csgo.interface_handler:get_entity_list() --< entity list
local global_vars = csgo.interface_handler:get_global_vars() --< global vars
local events = csgo.interface_handler:get_events() --< game events

-- adding to the menu checkboxes/sliders
local effects_enable_item = config:add_item( "ke_effects_enable_item", 1 )
local effects_enable_checkbox = menu:add_checkbox( "Combo-kill effects", "visuals", "misc", "various", effects_enable_item )
----
local sound_enable_item = config:add_item( "ke_sound_enable_item", 1 )
local sound_enable_checkbox = menu:add_checkbox( "Combo-kill sounds*", "visuals", "misc", "various", sound_enable_item )
----
local caps_enable_item = config:add_item( "ke_caps_enable_item", 1 )
local caps_enable_checkbox = menu:add_checkbox( "Capitalized letters", "visuals", "misc", "various", caps_enable_item )
----
local font_size_item = config:add_item( "ke_font_size_item", 49 )
local font_size_slider = menu:add_slider( "Text size", "visuals", "misc", "various", font_size_item, 35, 50, 1 )
----
local custom_font_item = config:add_item("ke_custom_font_item", 0)
local custom_font_combo = menu:add_combo("Font", "visuals", "misc", "various", custom_font_item)
custom_font_combo:add_item("Verdana", custom_font_item)
custom_font_combo:add_item("Comic Sans", custom_font_item)
custom_font_combo:add_item("Impact", custom_font_item)
custom_font_combo:add_item("Courier New", custom_font_item)
custom_font_combo:add_item("Visitor TTK2 *", custom_font_item)
custom_font_combo:add_item("Smallest Pixel 7*", custom_font_item)
custom_font_combo:add_item("Orbitron*", custom_font_item)
----
local animation_speed_item = config:add_item( "ke_animation_speed_item", 0.5 )
local animation_speed_slider = menu:add_slider( "Animation speed", "visuals", "misc", "various", animation_speed_item, 0.4, 0.9, 0.1 )
----
local double_kill_item = config:add_item("ke_2_kills_item", 0)
local double_kill_combo = menu:add_combo("2-Kills text", "visuals", "misc", "various", double_kill_item)
double_kill_combo:add_item("Doublekill", double_kill_item)
double_kill_combo:add_item("2k", custom_fonvt_item)
double_kill_combo:add_item("2 Kills", double_kill_item)
----
local multi_kill_item = config:add_item("ke_4_kills_item", 0)
local multi_kill_combo = menu:add_combo("4-Kills text", "visuals", "misc", "various", multi_kill_item)
multi_kill_combo:add_item("Multikill", multi_kill_item)
multi_kill_combo:add_item("4k", multi_kill_item)
multi_kill_combo:add_item("4 Kills", multi_kill_item)
----
local godlike_item = config:add_item("ke_6_kills_item", 0)
local godlike_combo = menu:add_combo("6-Kills text", "visuals", "misc", "various", godlike_item)
godlike_combo:add_item("Godlike", godlike_item)
godlike_combo:add_item("6k", godlike_item)
godlike_combo:add_item("6 Kills", godlike_item)
----
local monster_kill_item = config:add_item("ke_8_kills_item", 0)
local monster_kill_combo = menu:add_combo("8-Kills text", "visuals", "misc", "various", monster_kill_item)
monster_kill_combo:add_item("Monsterkill", monster_kill_item)
monster_kill_combo:add_item("8k", monster_kill_item)
monster_kill_combo:add_item("8 Kills", monster_kill_item)
----
local unstoppable_item = config:add_item("ke_10_kills_item", 0)
local unstoppable_combo = menu:add_combo("10-Kills text", "visuals", "misc", "various", unstoppable_item)
unstoppable_combo:add_item("Unstoppable", unstoppable_item)
unstoppable_combo:add_item("10k", unstoppable_item)
unstoppable_combo:add_item("10 Kills", unstoppable_item)
----
local whickedsick_item = config:add_item("ke_12_kills_item", 0)
local whickedsick_combo = menu:add_combo("12-Kills text", "visuals", "misc", "various", whickedsick_item)
whickedsick_combo:add_item("Whickedsick", whickedsick_item)
whickedsick_combo:add_item("12k", whickedsick_item)
whickedsick_combo:add_item("12 Kills", whickedsick_item)
----


-- variable to count kills
local kills = 0;

-- varaiable to realize script that you made a hit
local hurt_time = 0

-- start of alpha
local alpha = 0;

-- storage
local double_kill_text;
local multi_kill_text;
local godlike_text;
local monsterkill_text;
local unstoppable_text;
local whickedsick_text;

-- getting the round start event
events:add_event("round_start")

-- on-shot function
function on_shot( shot )

    -- sounds for kills
    local local_player = entity_list:get_localplayer()   --< creating local player variable
    local firstblood = "firstblood.wav" --< used for fisrt kill
    local doublekill = "double_kill.wav" --< used for 2 kills
    local multikill = "multikill.wav" --< used for 4 kills
    local godlike = "godlike.wav" --< used for 6 kills
    local monsterkill = "monsterkill_f.wav" --< used for 8 kills
    local unstoppable = "unstoppable.wav" --< used for 10 kills
    local whickedsick = "whickedsick.wav" --< used for 12 kills

    -- get the victim of the shot
    player = entity_list:get_player( shot.victim )
    if player == nil then
    return end

   -- counting value of kills
    if (shot.hurt and player:get_var_int("CBasePlayer->m_iHealth") <= 0) then
    hurt_time = global_vars.realtime
    kills = kills + 1;
    end

    -- sound checkbox check
    if sound_enable_item:get_bool() then 

    -- if we did 2 kills, then play doublekill sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 2) then
    engine_client:client_cmd("play " .. doublekill)
    end

    -- if we did 4 kills, then play multikill sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 4) then
    engine_client:client_cmd("play " .. multikill)
    end

    -- if we did 6 kills, then play godlike sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 6) then
    engine_client:client_cmd("play " .. godlike)
    end

    -- if we did 8 kills, then play monsterkill sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 8) then
    engine_client:client_cmd("play " .. monsterkill)
    end

    -- if we did 10 kills, then play unstoppable sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 10) then
    engine_client:client_cmd("play " .. unstoppable)
    end

    -- if we did 12 kills, then play whickedsick sound
    if (player:get_var_int("CBasePlayer->m_iHealth") <= 0 and kills == 12) then
    engine_client:client_cmd("play " .. whickedsick)
    end

    end

    return end



-- variables for on_pait function
local local_player = entity_list:get_localplayer() --< creating local player variable  
local screen_size = render:screen_size( ); --< getting personal screen size
local animationAlpha = 0 --< animation alpha start
--



-- rendering text effects
function on_paint( )

        local font_size_value = font_size_item:get_float() * 1 --< changing value from float to int ( to be able to add this variable to the font size )
        local animation_speed_value = animation_speed_item:get_float()
        local font;

        -- smooth fade out
        local step = 255 / 0.6 * global_vars.frametime
        if hurt_time + 0.4 > global_vars.realtime then
        alpha = 255
        else
        alpha = alpha - step
        end

        -- animations
        local animationStep = 255 / animation_speed_value * global_vars.frametime
        if hurt_time + 0.1 > global_vars.realtime then
            animationAlpha = - 80
        else
        animationAlpha = animationAlpha - animationStep
        end

    -- effects checkbox check
    if effects_enable_item:get_bool() then

        -- alpha check
        if (alpha > 0) then

            -- switching fonts
            if custom_font_item:get_int() == 0 then
                font = render:create_font( "Verdana", font_size_value, 700, false )
            elseif custom_font_item:get_int() == 1 then
                font = render:create_font( "Comic Sans MS", font_size_value, 700, false )
            elseif custom_font_item:get_int() == 2 then
                font = render:create_font( "Impact", font_size_value, 700, false )
            elseif custom_font_item:get_int() == 3 then
                font = render:create_font( "Courier New", font_size_value, 700, false )
            elseif custom_font_item:get_int() == 4 then
                font = render:create_font( "Visitor TT2 BRK", font_size_value, 700, false )
            elseif custom_font_item:get_int() == 5 then
                font = render:create_font( "Smallest Pixel-7", font_size_value, 700, false )
            elseif custom_font_item:get_int() == 6 then
                font = render:create_font( "Orbitron", font_size_value, 700, false )
            end

            -- switching custom text
            if double_kill_item:get_int() == 0 then
                double_kill_text = "doublekill"
            elseif double_kill_item:get_int() == 1 then
                double_kill_text = "2k"
            elseif double_kill_item:get_int() == 2 then
                double_kill_text = "2 kills"
            end
            ----
            if multi_kill_item:get_int() == 0 then
                multi_kill_text = "multikill"
            elseif multi_kill_item:get_int() == 1 then
                multi_kill_text = "4k"
            elseif multi_kill_item:get_int() == 2 then
                multi_kill_text = "4 kills"
            end
            ----
            if godlike_item:get_int() == 0 then
                godlike_text = "godlike"
            elseif godlike_item:get_int() == 1 then
                godlike_text = "6k"
            elseif godlike_item:get_int() == 2 then
                godlike_text = "6 kills"
            end
            ----
            if monster_kill_item:get_int() == 0 then
                monsterkill_text = "monsterkill"
            elseif monster_kill_item:get_int() == 1 then
                monsterkill_text = "8k"
            elseif monster_kill_item:get_int() == 2 then
                monsterkill_text = "8 kills"
            end
            ----
            if unstoppable_item:get_int() == 0 then
                unstoppable_text = "unstoppable"
            elseif unstoppable_item:get_int() == 1 then
                unstoppable_text = "10k"
            elseif unstoppable_item:get_int() == 2 then
                unstoppable_text = "10 kills"
            end
            ----
            if whickedsick_item:get_int() == 0 then
                whickedsick_text = "whickedsick"
            elseif whickedsick_item:get_int() == 1 then
                whickedsick_text = "10k"
            elseif whickedsick_item:get_int() == 2 then
                whickedsick_text = "12 kills"
            end
            ----


            -- if we did 2 kills, then draw DOUBLEKILL effect
            if(kills == 2) then

                if caps_enable_item:get_bool() == false then
                    render:text(font, screen_size.x / 2  + animationAlpha, screen_size.y / 2 + animationAlpha, double_kill_text:lower(),  csgo.color(0, 0, 255, math.floor(alpha)))
                elseif caps_enable_item:get_bool() == true then
                    render:text(font, screen_size.x / 2  + animationAlpha, screen_size.y / 2 + animationAlpha, double_kill_text:upper(),  csgo.color(0, 0, 255, math.floor(alpha)))
                end

            end
            -- if we did 4 kills, then draw MULTIKILL effect
            if( kills == 4) then

                if caps_enable_item:get_bool() == false then
                    render:text(font, screen_size.x / 2  - animationAlpha, screen_size.y / 2 + animationAlpha, multi_kill_text:lower(),  csgo.color(0, 255, 0, math.floor(alpha)))
                elseif caps_enable_item:get_bool() == true then
                    render:text(font, screen_size.x / 2  - animationAlpha, screen_size.y / 2 + animationAlpha, multi_kill_text:upper(),  csgo.color(0, 255, 0, math.floor(alpha)))
                end

            end
            -- if we did 6 kills, then draw GODLIKE effect
            if( kills == 6) then

                if caps_enable_item:get_bool() == false then
                    render:text(font, screen_size.x / 2  + animationAlpha, screen_size.y / 2 - animationAlpha, godlike_text:lower(),  csgo.color(255, 0, 0, math.floor(alpha)))
                elseif caps_enable_item:get_bool() == true then
                    render:text(font, screen_size.x / 2  + animationAlpha, screen_size.y / 2 - animationAlpha, godlike_text:upper(),  csgo.color(255, 0, 0, math.floor(alpha)))
                end
            
            end
            -- if we did 8 kills, then draw MONSTERKILL effect
            if( kills == 8) then

                if caps_enable_item:get_bool() == false then
                    render:text(font, screen_size.x / 2 - animationAlpha, screen_size.y / 2 - animationAlpha, monsterkill_text:lower(),  csgo.color(255, 0, 255, math.floor(alpha)))
                elseif caps_enable_item:get_bool() == true then
                    render:text(font, screen_size.x / 2 - animationAlpha, screen_size.y / 2 - animationAlpha, monsterkill_text:upper(),  csgo.color(255, 0, 255, math.floor(alpha)))
                end

            end
            -- if we did 10 kills, then draw UNSTOPPABLE effect
            if( kills == 10) then

                if caps_enable_item:get_bool() == false then
                    render:text(font, screen_size.x / 2  + animationAlpha, screen_size.y / 2 + animationAlpha, unstoppable_text:lower(),  csgo.color(0, 255, 255, math.floor(alpha)))
                elseif caps_enable_item:get_bool() == true then
                    render:text(font, screen_size.x / 2  + animationAlpha, screen_size.y / 2 + animationAlpha, unstoppable_text:upper(),  csgo.color(0, 255, 255, math.floor(alpha)))
                end
            
            end
            -- if we did 12 kills, then draw WHICKEDSICK effect
            if( kills == 12) then
        
                if caps_enable_item:get_bool() == false then
                    render:text(font, screen_size.x / 2  - animationAlpha, screen_size.y / 2 + animationAlpha, whickedsick_text:lower(),  csgo.color(255, 255, 0, math.floor(alpha)))
                elseif caps_enable_item:get_bool() == true then
                    render:text(font, screen_size.x / 2  - animationAlpha, screen_size.y / 2 + animationAlpha, whickedsick_text:upper(),  csgo.color(255, 255, 0, math.floor(alpha)))
                end

            end

        end

    end
       
end



-- kills are becoming 0, if round started
fatality.callbacks:add("events", function(e)
    if(e:get_name() == "round_start") then
        kills = 0
    end
end)
 


-- callbacks    
callbacks:add( "registered_shot", on_shot )
callbacks:add("paint", on_paint)

-- end of the code