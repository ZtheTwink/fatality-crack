-- https://fatality.win/threads/this-is-the-lua-you-have-been-needing.4659/

local render = fatality.render
local menu = fatality.menu
local config = fatality.config
local entity_list = csgo.interface_handler:get_entity_list()
local events = csgo.interface_handler:get_events()
local engine_client = csgo.interface_handler:get_engine_client()
local togglesItem = config:add_item( 'toggle', 0 )
local eventInfoMultiCombo = menu:add_multi_combo('Event Info', 'misc', '', 'movement', togglesItem)

local bombPlantingItem = config:add_item( 'bomb Planting', 0)
eventInfoMultiCombo:add_item('Bomb Planting', bombPlantingItem)

local bombStopPlantingItem = config:add_item( 'bomb stop Planting', 0)
eventInfoMultiCombo:add_item('Bomb Stop Planting', bombStopPlantingItem)

local bombPlantedItem = config:add_item( 'bomb Planted', 0)
eventInfoMultiCombo:add_item('Bomb Planted', bombPlantedItem)

local bombDefusingItem = config:add_item( 'bomb defusing', 0)
eventInfoMultiCombo:add_item('Bomb Defusing', bombDefusingItem)

local bombDefuseStopItem = config:add_item( 'bomb stop defusing', 0)
eventInfoMultiCombo:add_item('Stopped Defusing', bombDefuseStopItem)

local bombDefusedItem = config:add_item( 'bomb Defused', 0)
eventInfoMultiCombo:add_item('Bomb Defused', bombDefusedItem)

local bombExplodedItem = config:add_item( 'bomb Exploded', 0)
eventInfoMultiCombo:add_item('Bomb Exploded', bombExplodedItem)

local bombDroppedItem = config:add_item( 'bomb Dropped', 0)
eventInfoMultiCombo:add_item('Bomb Dropped', bombDroppedItem)

local bombPickedUpItem = config:add_item( 'Bomb Picked up', 0)
eventInfoMultiCombo:add_item('Bomb Picked up', bombPickedUpItem)

local grenadeThrownItem = config:add_item( 'nade thrown', 0)
eventInfoMultiCombo:add_item('Grenade Thrown', grenadeThrownItem)

local silencerOffItem = config:add_item( 'silencer off', 0)
eventInfoMultiCombo:add_item('Silencer Off', silencerOffItem)

local silencerOnItem = config:add_item( 'silencer on', 0)
eventInfoMultiCombo:add_item('Silencer On', silencerOnItem)

local playerFallDamageItem = config:add_item( 'falldamage', 0)
eventInfoMultiCombo:add_item('Fall Damage', playerFallDamageItem)

local playerHurtItem = config:add_item( 'Player Hurt', 0)
eventInfoMultiCombo:add_item('Player Hurt', playerHurtItem)

--yoiked from cherrys kilsay
local function say(message, name)
    local message = string.gsub(message, ";", ";")
    local name = string.gsub(name, ";", ";")
	engine_client:client_cmd("say " .. message..name)
end
local function say2(text1, text2, text3)
    local text1 = string.gsub(text1, ";", ";")
    local text2 = string.gsub(text2, ";", ";")
    local text3 = string.gsub(text3, ";", ";")
	engine_client:client_cmd("say " .. text1..text2..text3)
end
local function say3(text1, text2, text3, text4, text5, text6, text7)
    local text1 = string.gsub(text1, ";", ";")
    local text2 = string.gsub(text2, ";", ";")
    local text3 = string.gsub(text3, ";", ";")
    local text4 = string.gsub(text4, ";", ";")  
    local text5 = string.gsub(text5, ";", ";")
    local text6 = string.gsub(text6, ";", ";")
    local text7 = string.gsub(text7, ";", ";")

	engine_client:client_cmd("say " .. text1..text2..text3..text4..text5..text6..text7)
end

local function bombPlanting(e)

    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if bombPlantingItem:get_bool() then
    say ('The bomb is being planted by ', userName) 
    end
end
local function stopPlant(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if bombStopPlantingItem:get_bool() then
    say (userName, ' has stopped planting.') 
    end
end
local function bombPlanted(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if bombPlantedItem:get_bool() then
    say (userName, ' has planted the bomb.')
    end
end
local function bombDefusing(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if bombDefusingItem:get_bool() then
    say(userName, ' is defusing the bomb.')
    end
end
local function stopDefuse(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if bombDefuseStopItem:get_bool() then
    say(userName, ' has stopped defusing.')
    end
end
local function bombDefused(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if bombDefusedItem:get_bool() then
    say(userName, ' has defused the bomb.')
    end
end
local function bombExploded(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if bombExplodedItem:get_bool() then
    say(userName, ' has made the bomb go boom.')
    end
end
local function bombDropped(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if bombDroppedItem:get_bool() then
    say(userName, ' has dropped the bomb.')
    end
end
local function bombPickedUp(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if bombPickedUpItem:get_bool() then
    say(userName, ' has picked up the bomb.')
    end 
end
local function grenadeThrown(e)
    local userID = e:get_int('userid')
    local nade = e:get_string('weapon')
    if userID == nil then
        return
    end
    if nade == nil then
        return
    end
    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if grenadeThrownItem:get_bool() then 
    say2(userName, ' has thrown a ' , nade)
    end
end
local function silencerOff(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if silencerOffItem:get_bool() then
    say(userName, ' has taken off their silencer.')
    end
end
local function silencerOn(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if silencerOnItem:get_bool() then
    say(userName, ' has put their silencer on.')
    end
end
local function playerFallDamage(e)
    local userID = e:get_int('userid')

    if userID == nil then
        return
    end

    local userIDPlayer = entity_list:get_player_from_id(userID)
    local userName = userIDPlayer:get_name()

    if userIDPlayer == nil then
        return
    end
    if playerFallDamageItem:get_bool() then
    say(userName, ' has taken fall damage. Ouch.')
    end
end

local function playerHurt(e)
    local hurtPlayerID = e:get_int('userid')
    local attackerID = e:get_int('attacker')
    local hurtPlayerHp = e:get_int('health')
    local hurtPlayerArmor = e:get_int('armor') 
    local damageTaken = e:get_int('dmg_health') 
    local hitboxID = e:get_int('hitgroup') 
    local hitbox



    if hurtPlayerID == nil then
        return
    end

    if attackerID == nil then
        return end

    if hitboxID == 0 then
        hitbox = 'generic.'
    elseif hitboxID == 1 then
        hitbox = 'head.'
    elseif hitboxID == 2 then
        hitbox = 'chest.'
    elseif hitboxID == 3 then
        hitbox = 'stomach.'
    elseif hitboxID == 4 then
        hitbox = 'left arm.'
    elseif hitboxID == 5 then
        hitbox = 'right arm.'
    elseif hitboxID == 6 then
        hitbox = 'left leg.'
    elseif hitboxID == 7 then
            hitbox = 'right leg.'
    end

    local attacker = entity_list:get_player_from_id(attackerID)
    local attackerName = attacker:get_name()

    local hurtPlayer = entity_list:get_player_from_id(hurtPlayerID)
    local hurtPlayerName = hurtPlayer:get_name()

    if hurtPlayerID == nil then
        return
    end

    if attackerID == nil then
        return end

        if hitbox == nil then
            return end
    if playerHurtItem:get_bool() then
    say3(hurtPlayerName, ' has taken ', damageTaken, ' damage from ', attackerName, ' in the ', hitbox)
    end
end
local function event(e)
    local event = e:get_name()
    if event == 'bomb_beginplant' then
        bombPlanting(e) 
    elseif event == 'bomb_abortplant'then
        stopPlant(e) 
    elseif event == 'bomb_planted' then
        bombPlanted(e)
    elseif event == 'bomb_begindefuse' then
        bombDefusing(e)
    elseif event == 'bomb_abortdefuse' then
        stopDefuse(e)
    elseif event == 'bomb_defused' then
        bombDefused(e)
    elseif event == 'bomb_exploded' then
        bombExploded(e)
    elseif event == 'bomb_dropped' then
        bombDropped(e)
    elseif event == 'bomb_pickup' then
        bombPickedUp(e)
    elseif event == 'grenade_thrown' then
        grenadeThrown(e)
    elseif event == 'buytime_ended' then
        engine_client:client_cmd('say "Buytime is over.')
    elseif event == 'silencer_off' then
        silencerOff(e)
    elseif event == 'silencer_on' then
        silencerOn(e) 
    elseif event == 'player_falldamage' then
    playerFallDamage(e)
    elseif event == 'player_hurt' then
    playerHurt(e)
    end
end


events:add_event('bomb_beginplant')
events:add_event('bomb_abortplant')
events:add_event('bomb_planted') 
events:add_event('bomb_defused')
events:add_event('bomb_begindefuse')
events:add_event('bomb_abortdefuse')
events:add_event('bomb_defused') 
events:add_event('bomb_exploded') 
events:add_event('bomb_dropped') 
events:add_event('bomb_pickup')
events:add_event('grenade_thrown') 
events:add_event('buytime_ended')
events:add_event('silencer_off')
events:add_event('silencer_on')
events:add_event('player_falldamage') 
events:add_event('player_hurt')

local callbacks = fatality.callbacks
callbacks:add( 'events', event )


--epic meme