-- Animated event-log by eslipe v.1.3 (current version of 17.02.2019)
 
--[[ Updatelog:
 
(17.02.2019)
Added RGB colour changer
Background now is customizable
Changed fonts to make them look better
Alpha is changing itself at the start and at the end of animation
 
 
(16.02.2019)
Fixed amination bug
Added indicator of miss due to resolver
Added developer 0/1 control function
 
 
(16.02.2019)
Release
 
 
]]
 
 
 
-- interfaces
local cvar = csgo.interface_handler:get_cvar( )
local render = fatality.render
local entity_list = csgo.interface_handler:get_entity_list( )
local global_vars = csgo.interface_handler:get_global_vars( )
 
-- config & menu access
local menu = fatality.menu
local config = fatality.config
 
-- adding checboxes & slider in menu to customize the script
local advanced_logs_item = config:add_item( "advanced_logs_item", 0 )
local advanced_logs_checkbox = menu:add_checkbox( "Advanced event-log", "visuals", "esp", "world", advanced_logs_item )
local background_item = config:add_item( "background_item", 0 )
local background_checkbox = menu:add_checkbox( "Event-log background", "visuals", "esp", "world", background_item )
local chroma_item = config:add_item( "chroma_item", 0 )
local chroma_checkbox = menu:add_checkbox( "Chroma mode", "visuals", "esp", "world", chroma_item )
local customX_item = config:add_item( "customX_item", 0 )
local customX_slider = menu:add_slider( "Custom X", "visuals", "esp", "world", customX_item, 0, 500, 1 )
local customY_item = config:add_item( "customY_item", 0 )
local customY_slider = menu:add_slider( "Custom Y", "visuals", "esp", "world", customY_item, 0, 500, 1 )
local customWidth_item = config:add_item( "customWidth_item", 15 )
local customWidth_slider = menu:add_slider( "Indicator width", "visuals", "esp", "world", customWidth_item, 0, 30, 1 )
 
local red_item = config:add_item( "red_item", 0 )
local red_slider = menu:add_slider( "[ r ] Amount", "visuals", "esp", "world", red_item, 0, 255, 1 )
local green_item = config:add_item( "green_item", 0 )
local green_slider = menu:add_slider( "[ g ] Amount", "visuals", "esp", "world", green_item, 0, 255, 1 )
local blue_item = config:add_item( "blue_item", 0 )
local blue_slider = menu:add_slider( "[ b ] Amount", "visuals", "esp", "world", blue_item, 0, 255, 1 )
 
-- adding developer cvar to set it to 0 in future
local developer = cvar:find_var("developer")
 
-- setting cvar to 0
developer:set_int(0)
 
-- creating logs variable to place the logs there
local logs = {}
 
-- creating function to take logs from on shot function
function add_log(text)
    table.insert(logs, {text = text, expiration = 5, fadein = 0})
end
 
-- needed variables
local normal_font = render:create_font( "Smallest Pixel-7", 11, 100, false );
local screensize = render:screen_size();
 
 
-- on pain function
function on_paint()
 
    -- variables to be able to use chroma colour change
    local r = math.floor( math.sin( global_vars.realtime * 2) * 127 + 128 )
    local g =  math.floor( math.sin( global_vars.realtime * 2 + 2 ) * 127 + 128 )
    local b = math.floor( math.sin( global_vars.realtime * 2 + 4 ) * 127 + 128 );
 
    -- changes float value to the int value
    local customX_value = customX_item:get_float() * 1
    local customY_value = customY_item:get_float() * 1
    local customWidth_value = customWidth_item:get_float() * 1
    local red_value = red_item:get_float() * 1
    local green_value = green_item:get_float() * 1
    local blue_value = blue_item:get_float() * 1
 
 
 
    -- event log
    for i = 1, #logs do
 
        -- nil check
        if (logs[i] ~= nil) then
 
            -- variable of ratio
            local ratio = 1
 
            -- alpha value of rendered items on screen
            local alpha = 0;
 
            -- setting the time of animation
            if (logs[i].expiration <= 1) then
                ratio = (logs[i].expiration) / 1
            end
 
            -- setting different alpha for the begin and the end of logs
            if (logs[i].expiration >= 4 and logs[i].expiration <= 5 or logs[i].expiration <= 1) then
                alpha = 150
            else
                alpha = 255
            end
 
 
                -- [ CHROMA MODE ON ] --
                if chroma_item:get_bool() then
 
                    -- if user activated the background checkbox, then add background
                    if background_item:get_bool() then
                        render:rect_filled( customX_value + 0 - ((1 - ratio) * 300), customY_value + 12 * (i - 1) * 2 - 5, 395, 24, csgo.color(r, g, b,alpha))
                        render:rect_filled( customX_value + 0 - ((1 - ratio) * 600),  customY_value + 12 * (i - 1) * 2 - 5, 380, 24, csgo.color(12,12,12,255))
                    end
 
                    -- if user activated the background checkbox, then change text distance
                    if background_item:get_bool() then
                        render:text(normal_font, customX_value + 5 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  "[ fatality ] -", csgo.color(r, g, b,alpha))
                        render:text(normal_font, customX_value + 72 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  logs[i].text, csgo.color(255,255,255,alpha))
                    else
                        render:text(normal_font, customX_value + 5 - ((1 - ratio) * 600), customY_value +  7 * (i - 1) * 2,  "[ fatality ] -", csgo.color(r, g, b,alpha))
                        render:text(normal_font, customX_value + 72 - ((1 - ratio) * 600), customY_value +  7 * (i - 1) * 2,  logs[i].text, csgo.color(255,255,255,alpha))
                    end
 
                -- [ CHROMA MODE OFF ] --
 
 
                -- [ ORIDNARY MODE ON ] --
                else
 
                    -- if user activated the background checkbox, then add background
                    if background_item:get_bool() then
                        render:rect_filled( customX_value + 0 - ((1 - ratio) * 300), customY_value +  12 * (i - 1) * 2 - 5, 395, 24, csgo.color(red_value, green_value, blue_value,alpha))
                        render:rect_filled( customX_value + 0 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 - 5, 380, 24, csgo.color(12,12,12,255))
                    end
 
                    -- if user activated the background checkbox, then change text distance
                    if background_item:get_bool() then
                        render:text(normal_font, customX_value + 5 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  "[ fatality ] -", csgo.color(red_value, green_value, blue_value,alpha))
                        render:text(normal_font, customX_value + 72 - ((1 - ratio) * 600), customY_value +  12 * (i - 1) * 2 + 3,  logs[i].text, csgo.color(255,255,255,alpha))
                    else
                        render:text(normal_font, customX_value + 5 - ((1 - ratio) * 600), customY_value +  7 * (i - 1) * 2,  "[ fatality ] -", csgo.color(red_value, green_value, blue_value,alpha))
                        render:text(normal_font, customX_value + 72 - ((1 - ratio) * 600), customY_value +  7 * (i - 1) * 2,  logs[i].text, csgo.color(255,255,255,alpha))
                    end
 
                end
                -- [ ORIDNARY MODE OFF ] --
     
            -- removes log if time is expired
            logs[i].expiration = logs[i].expiration - 0.01
            if (logs[i].expiration <= -1) then
                table.remove(logs, i)
            end
 
        end
 
    end
 
end
 
 
 
-- on shot function
function on_registered_shot( shot )
 
    -- enabled check
    if not advanced_logs_item:get_bool( ) then
        return
    end
 
    -- creating a variable of the enemy
    local enemy = entity_list:get_player( shot.victim )
 
    -- nil check
    if enemy == nil then
        return
    end
 
    -- getting shot info
    local shot_info_t = shot.shot_info
 
    -- returns the function if something goes wrong
    if not shot_info_t.has_info then
        return
    end
 
    -- creating a variable of default hitgroup
    local hitgroup=0
 
    -- if we did a hit
    if shot.hurt then
 
        --
        hitgroup=shot.hit_hitgroup
 
        -- hitgroup renaming from int to string
        if hitgroup == 1 then
            hitgroup = "head"
            elseif hitgroup == 2 then
            hitgroup = "chest"
            elseif hitgroup == 3 then
            hitgroup = "stomach"
            elseif hitgroup == 4 then
            hitgroup = "hand"
            elseif hitgroup == 5 then
            hitgroup = "Arm"
            elseif hitgroup == 6 then
            hitgroup = "Leg"
            elseif hitgroup == 7 then
            hitgroup = "Leg"
            elseif hitgroup == 8 then
            hitgroup = "Neck"
        end
 
        -- log that shows if we did a hit
        add_log("hit to the player " .. enemy:get_name( ) .. " in " .. hitgroup .. " for " .. shot.hit_damage .. " dmg")
 
    elseif not shot.hurt and shot.hit then
        -- log that shows if cheat did a miss due to resolver
        add_log("missed shot due to resolver")
 
    else
        -- log that shows if we did a miss
        add_log("missed shot due to spread")
    end
 
end
 
 
 
-- callbacks
local callbacks = fatality.callbacks
callbacks:add( "registered_shot", on_registered_shot )
callbacks:add( "paint", on_paint )
 
-- end of the code